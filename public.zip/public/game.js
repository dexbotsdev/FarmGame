var _STRINGS = {
    'Ad': {
        'Mobile': {
            'Preroll': {
                'ReadyIn': 'The\x20game\x20is\x20ready\x20in\x20',
                'Loading': 'Your\x20game\x20is\x20loading...',
                'Close': 'Close'
            },
            'Header': {
                'ReadyIn': 'The\x20game\x20is\x20ready\x20in\x20',
                'Loading': 'Your\x20game\x20is\x20loading...',
                'Close': 'Close'
            },
            'End': {
                'ReadyIn': 'Advertisement\x20ends\x20in\x20',
                'Loading': 'Please\x20wait\x20...',
                'Close': 'Close'
            }
        }
    },
    'Splash': {
        'Loading': 'Loading\x20...',
        'LogoLine1': 'Some\x20text\x20here',
        'LogoLine2': 'powered\x20by\x20MarketJS',
        'LogoLine3': 'none',
        'TapToStart': 'TAP\x20TO\x20START'
    },
    'Game': {
        'Settings': 'SETTINGS',
        'BGM': 'BGM',
        'SFX': 'SFX',
        'On': 'ON',
        'OFF': 'OFF',
        'Crops': 'Potatoes\x20Carrots\x20Wheats\x20Tomatoes\x20Cucumbers\x20Peppers\x20Turnips\x20Onions\x20Corn' ['split']('\x20'),
        'ShopTitle': 'UPGRADE\x20SHOP',
        'AutomateDesc': 'Stack\x20the\x20Harvest',
        'ProfitDesc': 'Increase\x20profit\x20{x}x',
        'SpeedDesc': 'Increase\x20speed\x20{x}x',
        'UnlockSpeed': 'Production\x20time\x20:',
        'UnlockProfit': 'Profit\x20multiplier\x20:',
        'SunTitle': 'SUNNY\x20DAYS!',
        'SunDesc': 'Earn\x202x\x20profits!',
        'Activate': 'Activate',
        'Seconds': 'Seconds',
        'CloudTitle': 'RAINY\x20DAYS!',
        'CloudDesc': '2x\x20HARVEST\x20SPEED!',
        'Chance': 'REMAINING',
        'Claim': 'CLAIM',
        'Daily': 'DAILY\x20REWARDS',
        'Hr': 'HRS',
        'Min': 'MINS',
        'Sec': 'SECS',
        'Okay': 'OKAY',
        'Harvest': 'HARVEST',
        'HarvestTitle': 'HARVEST\x20CROPS',
        'CurrentSeed': 'CURRENT\x20SEED\x20:',
        'SeedEarned': 'SEEDS\x20EARNED\x20:\x20',
        'BonusProfit': 'BONUS\x20PROFIT\x20:\x20',
        'HarvestDesc': ['Exchange\x20crops\x20for\x20seeds', '+2%\x20/\x20SEED'],
        'UpgradeMode': 'UPGRADE\x20MODE',
        'TutorialDesc': 'Buy\x20this\x20plot\x20of\x20land\x20to\x20start\x20planting;Swipe\x20repeatedly\x20to\x20collect\x20crops;Upgrade\x20plot\x20to\x20gain\x20better\x20rewards;Choose\x20which\x20plot\x20you\x20wish\x20to\x20upgrade;Now,\x20let\x27s\x20buy\x20this\x20plot\x20of\x20land;Hmm\x20what\x20could\x20they\x20have\x20here?;Let\x27s\x20buy\x20this\x20item\x20to\x20save\x20you\x20some\x20time;Rain\x20is\x20coming!;The\x20sun\x20is\x20shining\x20brightly' ['split'](';'),
        'TutorialHarvest': 'It\x27s\x20time\x20to\x20harvest\x20all\x20your\x20plots\x20and\x20plant\x20new\x20crops',
        'TutorialUnlock': 'Upgrade\x20your\x20land\x20plots\x20to\x20earn\x20more\x20bonuses!\x20Review\x20your\x20bonuses\x20here.',
        'Reset': 'Until\x20reset',
        'ProfitEarned': 'PROFIT\x20EARNED\x20:\x20'
    },
    'Results': {
        'Title': 'High\x20score'
    }
},
_SETTINGS = {
    'API': {
        'Enabled': !0x1,
        'Log': {
            'Events': {
                'InitializeGame': !0x0,
                'EndGame': !0x0,
                'Level': {
                    'Begin': !0x0,
                    'End': !0x0,
                    'Win': !0x0,
                    'Lose': !0x0,
                    'Draw': !0x0
                }
            }
        }
    },
    'Ad': {
        'Mobile': {
            'Preroll': {
                'Enabled': !0x1,
                'Duration': 0x5,
                'Width': 0x12c,
                'Height': 0xfa,
                'Rotation': {
                    'Enabled': !0x1,
                    'Weight': {
                        'MobileAdInGamePreroll': 0x28,
                        'MobileAdInGamePreroll2': 0x28,
                        'MobileAdInGamePreroll3': 0x14
                    }
                }
            },
            'Header': {
                'Enabled': !0x1,
                'Duration': 0x5,
                'Width': 0x140,
                'Height': 0x32,
                'Rotation': {
                    'Enabled': !0x1,
                    'Weight': {
                        'MobileAdInGameHeader': 0x28,
                        'MobileAdInGameHeader2': 0x28,
                        'MobileAdInGameHeader3': 0x14
                    }
                }
            },
            'Footer': {
                'Enabled': !0x1,
                'Duration': 0x5,
                'Width': 0x140,
                'Height': 0x32,
                'Rotation': {
                    'Enabled': !0x1,
                    'Weight': {
                        'MobileAdInGameFooter': 0x28,
                        'MobileAdInGameFooter2': 0x28,
                        'MobileAdInGameFooter3': 0x14
                    }
                }
            },
            'End': {
                'Enabled': !0x0,
                'Duration': 0x1,
                'Width': 0x12c,
                'Height': 0xfa,
                'Rotation': {
                    'Enabled': !0x1,
                    'Weight': {
                        'MobileAdInGameEnd': 0x28,
                        'MobileAdInGameEnd2': 0x28,
                        'MobileAdInGameEnd3': 0x14
                    }
                }
            }
        }
    },
    'Language': {
        'Default': 'en'
    },
    'DeveloperBranding': {
        'Splash': {
            'Enabled': !0x1
        },
        'Logo': {
            'Enabled': !0x1,
            'Link': '/index.html',
            'LinkEnabled': !0x1,
            'NewWindow': !0x1,
            'Width': 0xa6,
            'Height': 0x3d
        }
    },
    'Branding': {
        'Splash': {
            'Enabled': !0x1
        },
        'Logo': {
            'Enabled': !0x1,
            'Link': '/index.html',
            'LinkEnabled': !0x1,
            'NewWindow': !0x1,
            'Width': 0xa6,
            'Height': 0x3d
        }
    },
    'MoreGames': {
        'Enabled': !0x1,
        'Link': '/index.html',
        'NewWindow': !0x1
    },
    'TapToStartAudioUnlock': {
        'Enabled': !0x1
    },
    'Versioning': {
        'Version': '1.0.0',
        'Build': '43',
        'DisplayLog': !0x1,
        'DrawVersion': !0x1,
        'FontSize': '16px',
        'FontFamily': 'Arial',
        'FillStyle': '#000000'
    }
};
'undefined' !== typeof _SETTINGS['Versioning'] && null !== _SETTINGS['Versioning'] && !0x0 === _SETTINGS['Versioning']['DisplayLog'] && console['log']('Release:\x20v' + _SETTINGS['Versioning']['Version'] + '+build.' + _SETTINGS['Versioning']['Build']);
var MobileAdInGamePreroll = {
    'ad_duration': _SETTINGS['Ad']['Mobile']['Preroll']['Duration'],
    'ad_width': _SETTINGS['Ad']['Mobile']['Preroll']['Width'],
    'ad_height': _SETTINGS['Ad']['Mobile']['Preroll']['Height'],
    'ready_in': _STRINGS['Ad']['Mobile']['Preroll']['ReadyIn'],
    'loading': _STRINGS['Ad']['Mobile']['Preroll']['Loading'],
    'close': _STRINGS['Ad']['Mobile']['Preroll']['Close'] + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
    'Initialize': function() {
        if (_SETTINGS['Ad']['Mobile']['Preroll']['Rotation']['Enabled']) {
            var _0x4c7d88 = _SETTINGS['Ad']['Mobile']['Preroll']['Rotation']['Weight'],
                _0x2c95c5 = _0x4c7d88['MobileAdInGamePreroll'],
                _0x3d9a67 = _0x2c95c5 + _0x4c7d88['MobileAdInGamePreroll2'],
                _0x4c7d88 = _0x3d9a67 + _0x4c7d88['MobileAdInGamePreroll3'],
                _0x220385 = Math['floor'](0x64 * Math['random']());
            console['log']('seed:\x20', _0x220385), _0x220385 <= _0x2c95c5 ? this['selectedOverlayName'] = 'MobileAdInGamePreroll' : _0x220385 <= _0x3d9a67 ? this['selectedOverlayName'] = 'MobileAdInGamePreroll2' : _0x220385 <= _0x4c7d88 && (this['selectedOverlayName'] = 'MobileAdInGamePreroll3'), console['log']('Ad\x20rotating\x20preroll\x20enabled');
        } else this['selectedOverlayName'] = 'MobileAdInGamePreroll', console['log']('Ad\x20rotating\x20preroll\x20disabled');
        console['log']('selected:', this['selectedOverlayName']), this['overlay'] = $('#' + this['selectedOverlayName']), this['box'] = $('#' + this['selectedOverlayName'] + '-Box'), this['game'] = $('#game'), this['boxContents'] = {
            'footer': $('#' + this['selectedOverlayName'] + '-Box-Footer'),
            'header': $('#' + this['selectedOverlayName'] + '-Box-Header'),
            'close': $('#' + this['selectedOverlayName'] + '-Box-Close'),
            'body': $('#' + this['selectedOverlayName'] + '-Box-Body')
        }, this['box']['width'](this['ad_width']), this['box']['height'](this['ad_height']), this['box']['css']('left', (this['overlay']['width']() - this['box']['width']()) / 0x2), this['box']['css']('top', (this['overlay']['height']() - this['box']['height']() - this['boxContents']['header']['height']() - this['boxContents']['footer']['height']()) / 0x2), this['overlay']['show'](this['Timer'](this['ad_duration']));
    },
    'Timer': function(_0x128680) {
        var _0x1d2499 = _0x128680,
            _0x4ac022 = setInterval(function() {
                MobileAdInGamePreroll['boxContents']['header']['text'](MobileAdInGamePreroll['ready_in'] + _0x1d2499 + '...'), MobileAdInGamePreroll['boxContents']['footer']['text'](MobileAdInGamePreroll['loading']), _0x1d2499--, 0x0 > _0x1d2499 && (clearInterval(_0x4ac022), MobileAdInGamePreroll['boxContents']['close']['css']('left', MobileAdInGamePreroll['boxContents']['body']['width']() - 0x17), MobileAdInGamePreroll['boxContents']['close']['show'](), MobileAdInGamePreroll['boxContents']['header']['html'](MobileAdInGamePreroll['close']), MobileAdInGamePreroll['boxContents']['footer']['text'](''));
            }, 0x3e8);
    },
    'Close': function() {
        this['boxContents']['close']['hide'](), this['overlay']['hide']();
    }
},
MobileAdInGameHeader = {
    'ad_duration': _SETTINGS['Ad']['Mobile']['Header']['Duration'],
    'ad_width': _SETTINGS['Ad']['Mobile']['Header']['Width'],
    'ad_height': _SETTINGS['Ad']['Mobile']['Header']['Height'],
    'Initialize': function() {
        if (_SETTINGS['Ad']['Mobile']['Header']['Rotation']['Enabled']) {
            var _0x5942b0 = _SETTINGS['Ad']['Mobile']['Header']['Rotation']['Weight'],
                _0x372012 = _0x5942b0['MobileAdInGameHeader'],
                _0x55cf75 = _0x372012 + _0x5942b0['MobileAdInGameHeader2'],
                _0x5942b0 = _0x55cf75 + _0x5942b0['MobileAdInGameHeader3'],
                _0x140ef6 = Math['floor'](0x64 * Math['random']());
            console['log']('seed:\x20', _0x140ef6), _0x140ef6 <= _0x372012 ? this['selectedOverlayName'] = 'MobileAdInGameHeader' : _0x140ef6 <= _0x55cf75 ? this['selectedOverlayName'] = 'MobileAdInGameHeader2' : _0x140ef6 <= _0x5942b0 && (this['selectedOverlayName'] = 'MobileAdInGameHeader3'), console['log']('Ad\x20rotating\x20header\x20enabled');
        } else this['selectedOverlayName'] = 'MobileAdInGameHeader', console['log']('Ad\x20rotating\x20header\x20disabled');
        this['div'] = $('#' + this['selectedOverlayName']), this['game'] = $('#game'), this['div']['width'](this['ad_width']), this['div']['height'](this['ad_height']), this['div']['css']('left', this['game']['position']()['left'] + (this['game']['width']() - this['div']['width']()) / 0x2), this['div']['css']('top', 0x0), this['div']['show'](this['Timer'](this['ad_duration']));
    },
    'Timer': function(_0x51fb3e) {
        var _0x3fc9ae = setInterval(function() {
            _0x51fb3e--, 0x0 > _0x51fb3e && (MobileAdInGameHeader['div']['hide'](), clearInterval(_0x3fc9ae));
        }, 0x3e8);
    }
},
MobileAdInGameFooter = {
    'ad_duration': _SETTINGS['Ad']['Mobile']['Footer']['Duration'],
    'ad_width': _SETTINGS['Ad']['Mobile']['Footer']['Width'],
    'ad_height': _SETTINGS['Ad']['Mobile']['Footer']['Height'],
    'Initialize': function() {
        if (_SETTINGS['Ad']['Mobile']['Footer']['Rotation']['Enabled']) {
            var _0x170a63 = _SETTINGS['Ad']['Mobile']['Footer']['Rotation']['Weight'],
                _0x1e5af9 = _0x170a63['MobileAdInGameFooter'],
                _0x58ed45 = _0x1e5af9 + _0x170a63['MobileAdInGameFooter2'],
                _0x170a63 = _0x58ed45 + _0x170a63['MobileAdInGameFooter3'],
                _0x5e23e8 = Math['floor'](0x64 * Math['random']());
            console['log']('seed:\x20', _0x5e23e8), _0x5e23e8 <= _0x1e5af9 ? this['selectedOverlayName'] = 'MobileAdInGameFooter' : _0x5e23e8 <= _0x58ed45 ? this['selectedOverlayName'] = 'MobileAdInGameFooter2' : _0x5e23e8 <= _0x170a63 && (this['selectedOverlayName'] = 'MobileAdInGameFooter3'), console['log']('Ad\x20rotating\x20footer\x20enabled');
        } else this['selectedOverlayName'] = 'MobileAdInGameFooter', console['log']('Ad\x20rotating\x20footer\x20disabled');
        this['div'] = $('#' + this['selectedOverlayName']), this['game'] = $('#game'), this['div']['width'](this['ad_width']), this['div']['height'](this['ad_height']), this['div']['css']('left', this['game']['position']()['left'] + (this['game']['width']() - this['div']['width']()) / 0x2), this['div']['css']('top', this['game']['height']() - this['div']['height']() - 0x5), this['div']['show'](this['Timer'](this['ad_duration']));
    },
    'Timer': function(_0x7cd19c) {
        var _0x194652 = setInterval(function() {
            _0x7cd19c--, 0x0 > _0x7cd19c && (MobileAdInGameFooter['div']['hide'](), clearInterval(_0x194652));
        }, 0x3e8);
    }
},
MobileAdInGameEnd = {
    'ad_duration': _SETTINGS['Ad']['Mobile']['End']['Duration'],
    'ad_width': _SETTINGS['Ad']['Mobile']['End']['Width'],
    'ad_height': _SETTINGS['Ad']['Mobile']['End']['Height'],
    'ready_in': _STRINGS['Ad']['Mobile']['End']['ReadyIn'],
    'loading': _STRINGS['Ad']['Mobile']['End']['Loading'],
    'close': _STRINGS['Ad']['Mobile']['End']['Close'] + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
    'Initialize': function() {
        if (_SETTINGS['Ad']['Mobile']['End']['Rotation']['Enabled']) {
            var _0x475af3 = _SETTINGS['Ad']['Mobile']['End']['Rotation']['Weight'],
                _0x247510 = _0x475af3['MobileAdInGameEnd'],
                _0x1e34f8 = _0x247510 + _0x475af3['MobileAdInGameEnd2'],
                _0x475af3 = _0x1e34f8 + _0x475af3['MobileAdInGameEnd3'],
                _0x2a1c02 = Math['floor'](0x64 * Math['random']());
            console['log']('seed:\x20', _0x2a1c02), _0x2a1c02 <= _0x247510 ? this['selectedOverlayName'] = 'MobileAdInGameEnd' : _0x2a1c02 <= _0x1e34f8 ? this['selectedOverlayName'] = 'MobileAdInGameEnd2' : _0x2a1c02 <= _0x475af3 && (this['selectedOverlayName'] = 'MobileAdInGameEnd3'), console['log']('Ad\x20rotating\x20end\x20enabled');
        } else this['selectedOverlayName'] = 'MobileAdInGameEnd', console['log']('Ad\x20rotating\x20end\x20disabled');
        console['log']('selected:', this['selectedOverlayName']), this['overlay'] = $('#' + this['selectedOverlayName']), this['box'] = $('#' + this['selectedOverlayName'] + '-Box'), this['game'] = $('#game'), this['boxContents'] = {
            'footer': $('#' + this['selectedOverlayName'] + '-Box-Footer'),
            'header': $('#' + this['selectedOverlayName'] + '-Box-Header'),
            'close': $('#' + this['selectedOverlayName'] + '-Box-Close'),
            'body': $('#' + this['selectedOverlayName'] + '-Box-Body')
        }, this['box']['width'](this['ad_width']), this['box']['height'](this['ad_height']), this['box']['css']('left', (this['overlay']['width']() - this['box']['width']()) / 0x2), this['box']['css']('top', (this['overlay']['height']() - this['box']['height']() - this['boxContents']['header']['height']() - this['boxContents']['footer']['height']()) / 0x2), this['overlay']['show'](this['Timer'](this['ad_duration']));
    },
    'Timer': function(_0x1d7b59) {
        var _0x1683e1 = _0x1d7b59,
            _0x3db5e3 = setInterval(function() {
                MobileAdInGameEnd['boxContents']['header']['text'](MobileAdInGameEnd['ready_in'] + _0x1683e1 + '...'), MobileAdInGameEnd['boxContents']['footer']['text'](MobileAdInGameEnd['loading']), _0x1683e1--, 0x0 > _0x1683e1 && (clearInterval(_0x3db5e3), MobileAdInGameEnd['boxContents']['close']['css']('left', MobileAdInGameEnd['boxContents']['body']['width']() - 0x17), MobileAdInGameEnd['boxContents']['close']['show'](), MobileAdInGameEnd['boxContents']['header']['html'](MobileAdInGameEnd['close']), MobileAdInGameEnd['boxContents']['footer']['text'](''));
            }, 0x3e8);
    },
    'Close': function() {
        this['boxContents']['close']['hide'](), this['overlay']['hide']();
    }
};
! function(_0x98dc94, _0xe06343) {
'object' == typeof module && 'object' == typeof module['exports'] ? module['exports'] = _0x98dc94['document'] ? _0xe06343(_0x98dc94, !0x0) : function(_0x47d645) {
    if (!_0x47d645['document']) throw Error('jQuery\x20requires\x20a\x20window\x20with\x20a\x20document');
    return _0xe06343(_0x47d645);
} : _0xe06343(_0x98dc94);
}('undefined' != typeof window ? window : this, function(_0x10a213, _0x516e99) {
function _0x30d3e4(_0xa46da5, _0x545d4) {
    _0x545d4 = _0x545d4 || _0x5892f6;
    var _0x15b985 = _0x545d4['createElement']('script');
    _0x15b985['text'] = _0xa46da5, _0x545d4['head']['appendChild'](_0x15b985)['parentNode']['removeChild'](_0x15b985);
}

function _0x331354(_0x5e7cb8) {
    var _0x195f79 = !!_0x5e7cb8 && 'length' in _0x5e7cb8 && _0x5e7cb8['length'],
        _0xfbcb8f = _0x4f2fd6['type'](_0x5e7cb8);
    return 'function' !== _0xfbcb8f && !_0x4f2fd6['isWindow'](_0x5e7cb8) && ('array' === _0xfbcb8f || 0x0 === _0x195f79 || 'number' == typeof _0x195f79 && 0x0 < _0x195f79 && _0x195f79 - 0x1 in _0x5e7cb8);
}

function _0x443e90(_0x4e584e, _0x2ca2c2) {
    return _0x4e584e['nodeName'] && _0x4e584e['nodeName']['toLowerCase']() === _0x2ca2c2['toLowerCase']();
}

function _0x3e869d(_0x1def15, _0xf24329, _0x4281ea) {
    return _0x4f2fd6['isFunction'](_0xf24329) ? _0x4f2fd6['grep'](_0x1def15, function(_0x3bafee, _0x3021f2) {
        return !!_0xf24329['call'](_0x3bafee, _0x3021f2, _0x3bafee) !== _0x4281ea;
    }) : _0xf24329['nodeType'] ? _0x4f2fd6['grep'](_0x1def15, function(_0x182775) {
        return _0x182775 === _0xf24329 !== _0x4281ea;
    }) : 'string' != typeof _0xf24329 ? _0x4f2fd6['grep'](_0x1def15, function(_0x2bd3ac) {
        return -0x1 < _0x20db99['call'](_0xf24329, _0x2bd3ac) !== _0x4281ea;
    }) : _0x473693['test'](_0xf24329) ? _0x4f2fd6['filter'](_0xf24329, _0x1def15, _0x4281ea) : (_0xf24329 = _0x4f2fd6['filter'](_0xf24329, _0x1def15), _0x4f2fd6['grep'](_0x1def15, function(_0x44b7d3) {
        return -0x1 < _0x20db99['call'](_0xf24329, _0x44b7d3) !== _0x4281ea && 0x1 === _0x44b7d3['nodeType'];
    }));
}

function _0x5ea8be(_0x112410, _0x2bd841) {
    for (;
        (_0x112410 = _0x112410[_0x2bd841]) && 0x1 !== _0x112410['nodeType'];);
    return _0x112410;
}

function _0x30458c(_0x1cce61) {
    return _0x1cce61;
}

function _0x1db34f(_0x4d1f62) {
    throw _0x4d1f62;
}

function _0x2cb2bd(_0x34aa03, _0x158f8d, _0xa268af, _0x4b72c8) {
    var _0x5da009;
    try {
        _0x34aa03 && _0x4f2fd6['isFunction'](_0x5da009 = _0x34aa03['promise']) ? _0x5da009['call'](_0x34aa03)['done'](_0x158f8d)['fail'](_0xa268af) : _0x34aa03 && _0x4f2fd6['isFunction'](_0x5da009 = _0x34aa03['then']) ? _0x5da009['call'](_0x34aa03, _0x158f8d, _0xa268af) : _0x158f8d['apply'](void 0x0, [_0x34aa03]['slice'](_0x4b72c8));
    } catch (_0x56eb8b) {
        _0xa268af['apply'](void 0x0, [_0x56eb8b]);
    }
}

function _0x3898fd() {
    _0x5892f6['removeEventListener']('DOMContentLoaded', _0x3898fd), _0x10a213['removeEventListener']('load', _0x3898fd), _0x4f2fd6['ready']();
}

function _0x18ea0f() {
    this['expando'] = _0x4f2fd6['expando'] + _0x18ea0f['uid']++;
}

function _0x5b53a5(_0xa49598, _0x2bb261, _0x500888) {
    var _0x15a4ab;
    if (void 0x0 === _0x500888 && 0x1 === _0xa49598['nodeType']) {
        if (_0x15a4ab = 'data-' + _0x2bb261['replace'](_0x4a19a8, '-$&')['toLowerCase'](), _0x500888 = _0xa49598['getAttribute'](_0x15a4ab), 'string' == typeof _0x500888) {
            try {
                _0x500888 = 'true' === _0x500888 || 'false' !== _0x500888 && ('null' === _0x500888 ? null : _0x500888 === +_0x500888 + '' ? +_0x500888 : _0x4e5132['test'](_0x500888) ? JSON['parse'](_0x500888) : _0x500888);
            } catch (_0x267c57) {}
            _0xe80867['set'](_0xa49598, _0x2bb261, _0x500888);
        } else _0x500888 = void 0x0;
    }
    return _0x500888;
}

function _0x183b49(_0x22455f, _0x5bb74a, _0x4eac3e, _0x50ad51) {
    var _0x8e9017, _0x4d810d = 0x1,
        _0x1ac928 = 0x14,
        _0x1b1150 = _0x50ad51 ? function() {
            return _0x50ad51['cur']();
        } : function() {
            return _0x4f2fd6['css'](_0x22455f, _0x5bb74a, '');
        },
        _0x11c62e = _0x1b1150(),
        _0x409513 = _0x4eac3e && _0x4eac3e[0x3] || (_0x4f2fd6['cssNumber'][_0x5bb74a] ? '' : 'px'),
        _0x49b117 = (_0x4f2fd6['cssNumber'][_0x5bb74a] || 'px' !== _0x409513 && +_0x11c62e) && _0x31b6ba['exec'](_0x4f2fd6['css'](_0x22455f, _0x5bb74a));
    if (_0x49b117 && _0x49b117[0x3] !== _0x409513) {
        _0x409513 = _0x409513 || _0x49b117[0x3], _0x4eac3e = _0x4eac3e || [], _0x49b117 = +_0x11c62e || 0x1;
        do _0x4d810d = _0x4d810d || '.5', _0x49b117 /= _0x4d810d, _0x4f2fd6['style'](_0x22455f, _0x5bb74a, _0x49b117 + _0x409513); while (_0x4d810d !== (_0x4d810d = _0x1b1150() / _0x11c62e) && 0x1 !== _0x4d810d && --_0x1ac928);
    }
    return _0x4eac3e && (_0x49b117 = +_0x49b117 || +_0x11c62e || 0x0, _0x8e9017 = _0x4eac3e[0x1] ? _0x49b117 + (_0x4eac3e[0x1] + 0x1) * _0x4eac3e[0x2] : +_0x4eac3e[0x2], _0x50ad51 && (_0x50ad51['unit'] = _0x409513, _0x50ad51['start'] = _0x49b117, _0x50ad51['end'] = _0x8e9017)), _0x8e9017;
}

function _0x36b097(_0x5c869b, _0x115693) {
    for (var _0x3ccda1, _0x3c8e35, _0x59abc4 = [], _0xa3d5ae = 0x0, _0x1e68ff = _0x5c869b['length']; _0xa3d5ae < _0x1e68ff; _0xa3d5ae++)
        if (_0x3c8e35 = _0x5c869b[_0xa3d5ae], _0x3c8e35['style']) {
            if (_0x3ccda1 = _0x3c8e35['style']['display'], _0x115693) {
                if ('none' === _0x3ccda1 && (_0x59abc4[_0xa3d5ae] = _0x4f3277['get'](_0x3c8e35, 'display') || null, _0x59abc4[_0xa3d5ae] || (_0x3c8e35['style']['display'] = '')), '' === _0x3c8e35['style']['display'] && _0x2e6304(_0x3c8e35)) {
                    _0x3ccda1 = _0x59abc4;
                    var _0x133110 = _0xa3d5ae,
                        _0x3cf658, _0x4a98db = void 0x0;
                    _0x3cf658 = _0x3c8e35['ownerDocument'];
                    var _0x3e9209 = _0x3c8e35['nodeName'];
                    _0x3cf658 = (_0x3c8e35 = _0x4a5f2d[_0x3e9209]) ? _0x3c8e35 : (_0x4a98db = _0x3cf658['body']['appendChild'](_0x3cf658['createElement'](_0x3e9209)), _0x3c8e35 = _0x4f2fd6['css'](_0x4a98db, 'display'), _0x4a98db['parentNode']['removeChild'](_0x4a98db), 'none' === _0x3c8e35 && (_0x3c8e35 = 'block'), _0x4a5f2d[_0x3e9209] = _0x3c8e35, _0x3c8e35), _0x3ccda1[_0x133110] = _0x3cf658;
                }
            } else 'none' !== _0x3ccda1 && (_0x59abc4[_0xa3d5ae] = 'none', _0x4f3277['set'](_0x3c8e35, 'display', _0x3ccda1));
        }
    for (_0xa3d5ae = 0x0; _0xa3d5ae < _0x1e68ff; _0xa3d5ae++) null != _0x59abc4[_0xa3d5ae] && (_0x5c869b[_0xa3d5ae]['style']['display'] = _0x59abc4[_0xa3d5ae]);
    return _0x5c869b;
}

function _0x9d4e4c(_0x3d78d5, _0x219437) {
    var _0x4df152;
    return _0x4df152 = 'undefined' != typeof _0x3d78d5['getElementsByTagName'] ? _0x3d78d5['getElementsByTagName'](_0x219437 || '*') : 'undefined' != typeof _0x3d78d5['querySelectorAll'] ? _0x3d78d5['querySelectorAll'](_0x219437 || '*') : [], void 0x0 === _0x219437 || _0x219437 && _0x443e90(_0x3d78d5, _0x219437) ? _0x4f2fd6['merge']([_0x3d78d5], _0x4df152) : _0x4df152;
}

function _0x22c915(_0x467de9, _0x59e8b5) {
    for (var _0xffa14d = 0x0, _0x3fdcf2 = _0x467de9['length']; _0xffa14d < _0x3fdcf2; _0xffa14d++) _0x4f3277['set'](_0x467de9[_0xffa14d], 'globalEval', !_0x59e8b5 || _0x4f3277['get'](_0x59e8b5[_0xffa14d], 'globalEval'));
}

function _0x411eaf(_0x3bcac9, _0x36aad4, _0x28ae1a, _0x47f955, _0x3fc7a2) {
    for (var _0x584f3a, _0x1b253b, _0x21fa07, _0x2ebc8b, _0x442462 = _0x36aad4['createDocumentFragment'](), _0x1f2381 = [], _0xd79985 = 0x0, _0x443139 = _0x3bcac9['length']; _0xd79985 < _0x443139; _0xd79985++)
        if (_0x584f3a = _0x3bcac9[_0xd79985], _0x584f3a || 0x0 === _0x584f3a) {
            if ('object' === _0x4f2fd6['type'](_0x584f3a)) _0x4f2fd6['merge'](_0x1f2381, _0x584f3a['nodeType'] ? [_0x584f3a] : _0x584f3a);
            else {
                if (_0x4317c1['test'](_0x584f3a)) {
                    _0x1b253b = _0x1b253b || _0x442462['appendChild'](_0x36aad4['createElement']('div')), _0x21fa07 = (_0x4cde81['exec'](_0x584f3a) || ['', ''])[0x1]['toLowerCase'](), _0x21fa07 = _0x400845[_0x21fa07] || _0x400845['_default'], _0x1b253b['innerHTML'] = _0x21fa07[0x1] + _0x4f2fd6['htmlPrefilter'](_0x584f3a) + _0x21fa07[0x2];
                    for (_0x21fa07 = _0x21fa07[0x0]; _0x21fa07--;) _0x1b253b = _0x1b253b['lastChild'];
                    _0x4f2fd6['merge'](_0x1f2381, _0x1b253b['childNodes']), _0x1b253b = _0x442462['firstChild'], _0x1b253b['textContent'] = '';
                } else _0x1f2381['push'](_0x36aad4['createTextNode'](_0x584f3a));
            }
        }
    _0x442462['textContent'] = '';
    for (_0xd79985 = 0x0; _0x584f3a = _0x1f2381[_0xd79985++];)
        if (_0x47f955 && -0x1 < _0x4f2fd6['inArray'](_0x584f3a, _0x47f955)) _0x3fc7a2 && _0x3fc7a2['push'](_0x584f3a);
        else {
            if (_0x2ebc8b = _0x4f2fd6['contains'](_0x584f3a['ownerDocument'], _0x584f3a), _0x1b253b = _0x9d4e4c(_0x442462['appendChild'](_0x584f3a), 'script'), _0x2ebc8b && _0x22c915(_0x1b253b), _0x28ae1a) {
                for (_0x21fa07 = 0x0; _0x584f3a = _0x1b253b[_0x21fa07++];) _0x78aade['test'](_0x584f3a['type'] || '') && _0x28ae1a['push'](_0x584f3a);
            }
        }
    return _0x442462;
}

function _0x1f1868() {
    return !0x0;
}

function _0x4c6258() {
    return !0x1;
}

function _0x4b0a19() {
    try {
        return _0x5892f6['activeElement'];
    } catch (_0x287d67) {}
}

function _0x575457(_0x596d18, _0x544ebf, _0x1252d2, _0x33da1b, _0x330799, _0x3c3ce9) {
    var _0x5272b8, _0x50bcd3;
    if ('object' == typeof _0x544ebf) {
        'string' != typeof _0x1252d2 && (_0x33da1b = _0x33da1b || _0x1252d2, _0x1252d2 = void 0x0);
        for (_0x50bcd3 in _0x544ebf) _0x575457(_0x596d18, _0x50bcd3, _0x1252d2, _0x33da1b, _0x544ebf[_0x50bcd3], _0x3c3ce9);
        return _0x596d18;
    }
    if (null == _0x33da1b && null == _0x330799 ? (_0x330799 = _0x1252d2, _0x33da1b = _0x1252d2 = void 0x0) : null == _0x330799 && ('string' == typeof _0x1252d2 ? (_0x330799 = _0x33da1b, _0x33da1b = void 0x0) : (_0x330799 = _0x33da1b, _0x33da1b = _0x1252d2, _0x1252d2 = void 0x0)), !0x1 === _0x330799) _0x330799 = _0x4c6258;
    else {
        if (!_0x330799) return _0x596d18;
    }
    return 0x1 === _0x3c3ce9 && (_0x5272b8 = _0x330799, _0x330799 = function(_0x1acc2d) {
        return _0x4f2fd6()['off'](_0x1acc2d), _0x5272b8['apply'](this, arguments);
    }, _0x330799['guid'] = _0x5272b8['guid'] || (_0x5272b8['guid'] = _0x4f2fd6['guid']++)), _0x596d18['each'](function() {
        _0x4f2fd6['event']['add'](this, _0x544ebf, _0x330799, _0x33da1b, _0x1252d2);
    });
}

function _0x53606a(_0x43dd0e, _0x278e57) {
    return _0x443e90(_0x43dd0e, 'table') && _0x443e90(0xb !== _0x278e57['nodeType'] ? _0x278e57 : _0x278e57['firstChild'], 'tr') ? _0x4f2fd6('>tbody', _0x43dd0e)[0x0] || _0x43dd0e : _0x43dd0e;
}

function _0x22cd7d(_0x8e7487) {
    return _0x8e7487['type'] = (null !== _0x8e7487['getAttribute']('type')) + '/' + _0x8e7487['type'], _0x8e7487;
}

function _0x553bc6(_0xbd8b74) {
    var _0x3ee678 = _0x52deb1['exec'](_0xbd8b74['type']);
    return _0x3ee678 ? _0xbd8b74['type'] = _0x3ee678[0x1] : _0xbd8b74['removeAttribute']('type'), _0xbd8b74;
}

function _0x4c63bb(_0x1e8d76, _0x439d9b) {
    var _0x2f871a, _0x51fe36, _0x5b1db3, _0x2282ed, _0x61121d, _0x27bccd;
    if (0x1 === _0x439d9b['nodeType']) {
        if (_0x4f3277['hasData'](_0x1e8d76) && (_0x2f871a = _0x4f3277['access'](_0x1e8d76), _0x51fe36 = _0x4f3277['set'](_0x439d9b, _0x2f871a), _0x27bccd = _0x2f871a['events']))
            for (_0x5b1db3 in (delete _0x51fe36['handle'], _0x51fe36['events'] = {}, _0x27bccd)) {
                _0x2f871a = 0x0;
                for (_0x51fe36 = _0x27bccd[_0x5b1db3]['length']; _0x2f871a < _0x51fe36; _0x2f871a++) _0x4f2fd6['event']['add'](_0x439d9b, _0x5b1db3, _0x27bccd[_0x5b1db3][_0x2f871a]);
            }
        _0xe80867['hasData'](_0x1e8d76) && (_0x2282ed = _0xe80867['access'](_0x1e8d76), _0x61121d = _0x4f2fd6['extend']({}, _0x2282ed), _0xe80867['set'](_0x439d9b, _0x61121d));
    }
}

function _0x3b249b(_0x456e4c, _0x24130a, _0x4d956c, _0x132329) {
    _0x24130a = _0x12bb42['apply']([], _0x24130a);
    var _0x5a1908, _0x3d087f, _0x332cab, _0x1444f7, _0x52b315 = 0x0,
        _0x4a2be3 = _0x456e4c['length'],
        _0x3760c3 = _0x4a2be3 - 0x1,
        _0x332848 = _0x24130a[0x0],
        _0xa496bd = _0x4f2fd6['isFunction'](_0x332848);
    if (_0xa496bd || 0x1 < _0x4a2be3 && 'string' == typeof _0x332848 && !_0x395361['checkClone'] && _0x186884['test'](_0x332848)) return _0x456e4c['each'](function(_0xfd9d06) {
        var _0x3da387 = _0x456e4c['eq'](_0xfd9d06);
        _0xa496bd && (_0x24130a[0x0] = _0x332848['call'](this, _0xfd9d06, _0x3da387['html']())), _0x3b249b(_0x3da387, _0x24130a, _0x4d956c, _0x132329);
    });
    if (_0x4a2be3 && (_0x5a1908 = _0x411eaf(_0x24130a, _0x456e4c[0x0]['ownerDocument'], !0x1, _0x456e4c, _0x132329), _0x3d087f = _0x5a1908['firstChild'], 0x1 === _0x5a1908['childNodes']['length'] && (_0x5a1908 = _0x3d087f), _0x3d087f || _0x132329)) {
        _0x3d087f = _0x4f2fd6['map'](_0x9d4e4c(_0x5a1908, 'script'), _0x22cd7d);
        for (_0x332cab = _0x3d087f['length']; _0x52b315 < _0x4a2be3; _0x52b315++) _0x1444f7 = _0x5a1908, _0x52b315 !== _0x3760c3 && (_0x1444f7 = _0x4f2fd6['clone'](_0x1444f7, !0x0, !0x0), _0x332cab && _0x4f2fd6['merge'](_0x3d087f, _0x9d4e4c(_0x1444f7, 'script'))), _0x4d956c['call'](_0x456e4c[_0x52b315], _0x1444f7, _0x52b315);
        if (_0x332cab) {
            _0x5a1908 = _0x3d087f[_0x3d087f['length'] - 0x1]['ownerDocument'], _0x4f2fd6['map'](_0x3d087f, _0x553bc6);
            for (_0x52b315 = 0x0; _0x52b315 < _0x332cab; _0x52b315++) _0x1444f7 = _0x3d087f[_0x52b315], _0x78aade['test'](_0x1444f7['type'] || '') && !_0x4f3277['access'](_0x1444f7, 'globalEval') && _0x4f2fd6['contains'](_0x5a1908, _0x1444f7) && (_0x1444f7['src'] ? _0x4f2fd6['_evalUrl'] && _0x4f2fd6['_evalUrl'](_0x1444f7['src']) : _0x30d3e4(_0x1444f7['textContent']['replace'](_0x3d0bc7, ''), _0x5a1908));
        }
    }
    return _0x456e4c;
}

function _0x50f85d(_0x3959cc, _0x328a9a, _0x5c4f4f) {
    for (var _0x1d72a1 = _0x328a9a ? _0x4f2fd6['filter'](_0x328a9a, _0x3959cc) : _0x3959cc, _0x48e1bb = 0x0; null != (_0x328a9a = _0x1d72a1[_0x48e1bb]); _0x48e1bb++) _0x5c4f4f || 0x1 !== _0x328a9a['nodeType'] || _0x4f2fd6['cleanData'](_0x9d4e4c(_0x328a9a)), _0x328a9a['parentNode'] && (_0x5c4f4f && _0x4f2fd6['contains'](_0x328a9a['ownerDocument'], _0x328a9a) && _0x22c915(_0x9d4e4c(_0x328a9a, 'script')), _0x328a9a['parentNode']['removeChild'](_0x328a9a));
    return _0x3959cc;
}

function _0x4572ba(_0x15cf53, _0x2ab3e3, _0x1a9bf9) {
    var _0x5617b4, _0x70c7d6, _0xf94491, _0x38a5cb, _0x18b7ef = _0x15cf53['style'];
    return _0x1a9bf9 = _0x1a9bf9 || _0x3397eb(_0x15cf53), _0x1a9bf9 && (_0x38a5cb = _0x1a9bf9['getPropertyValue'](_0x2ab3e3) || _0x1a9bf9[_0x2ab3e3], '' !== _0x38a5cb || _0x4f2fd6['contains'](_0x15cf53['ownerDocument'], _0x15cf53) || (_0x38a5cb = _0x4f2fd6['style'](_0x15cf53, _0x2ab3e3)), !_0x395361['pixelMarginRight']() && _0x5ab946['test'](_0x38a5cb) && _0x1fc029['test'](_0x2ab3e3) && (_0x5617b4 = _0x18b7ef['width'], _0x70c7d6 = _0x18b7ef['minWidth'], _0xf94491 = _0x18b7ef['maxWidth'], _0x18b7ef['minWidth'] = _0x18b7ef['maxWidth'] = _0x18b7ef['width'] = _0x38a5cb, _0x38a5cb = _0x1a9bf9['width'], _0x18b7ef['width'] = _0x5617b4, _0x18b7ef['minWidth'] = _0x70c7d6, _0x18b7ef['maxWidth'] = _0xf94491)), void 0x0 !== _0x38a5cb ? _0x38a5cb + '' : _0x38a5cb;
}

function _0x3415d0(_0x300c8e, _0x541c7a) {
    return {
        'get': function() {
            return _0x300c8e() ? void delete this['get'] : (this['get'] = _0x541c7a)['apply'](this, arguments);
        }
    };
}

function _0x400025(_0x3a1170) {
    var _0x141ca9 = _0x4f2fd6['cssProps'][_0x3a1170];
    if (!_0x141ca9) {
        var _0x141ca9 = _0x4f2fd6['cssProps'],
            _0x409f9b;
        _0x580b7c: if (_0x409f9b = _0x3a1170, !(_0x409f9b in _0x278495)) {
            for (var _0x54a18a = _0x409f9b[0x0]['toUpperCase']() + _0x409f9b['slice'](0x1), _0x2c7ae0 = _0xc9d213['length']; _0x2c7ae0--;)
                if (_0x409f9b = _0xc9d213[_0x2c7ae0] + _0x54a18a, _0x409f9b in _0x278495) break _0x580b7c;
            _0x409f9b = void 0x0;
        }
        _0x141ca9 = _0x141ca9[_0x3a1170] = _0x409f9b || _0x3a1170;
    }
    return _0x141ca9;
}

function _0x22e22f(_0x5cd3e2, _0x430b29, _0x44602f) {
    return (_0x5cd3e2 = _0x31b6ba['exec'](_0x430b29)) ? Math['max'](0x0, _0x5cd3e2[0x2] - (_0x44602f || 0x0)) + (_0x5cd3e2[0x3] || 'px') : _0x430b29;
}

function _0x548192(_0x3f8488, _0x2dc39c, _0x1e6f41, _0x55e10e, _0x2065c5) {
    var _0x2e34bd = 0x0;
    for (_0x2dc39c = _0x1e6f41 === (_0x55e10e ? 'border' : 'content') ? 0x4 : 'width' === _0x2dc39c ? 0x1 : 0x0; 0x4 > _0x2dc39c; _0x2dc39c += 0x2) 'margin' === _0x1e6f41 && (_0x2e34bd += _0x4f2fd6['css'](_0x3f8488, _0x1e6f41 + _0x46bbe7[_0x2dc39c], !0x0, _0x2065c5)), _0x55e10e ? ('content' === _0x1e6f41 && (_0x2e34bd -= _0x4f2fd6['css'](_0x3f8488, 'padding' + _0x46bbe7[_0x2dc39c], !0x0, _0x2065c5)), 'margin' !== _0x1e6f41 && (_0x2e34bd -= _0x4f2fd6['css'](_0x3f8488, 'border' + _0x46bbe7[_0x2dc39c] + 'Width', !0x0, _0x2065c5))) : (_0x2e34bd += _0x4f2fd6['css'](_0x3f8488, 'padding' + _0x46bbe7[_0x2dc39c], !0x0, _0x2065c5), 'padding' !== _0x1e6f41 && (_0x2e34bd += _0x4f2fd6['css'](_0x3f8488, 'border' + _0x46bbe7[_0x2dc39c] + 'Width', !0x0, _0x2065c5)));
    return _0x2e34bd;
}

function _0x661927(_0x5b142b, _0x329b89, _0x536317) {
    var _0x8386a3, _0x2e6eec = _0x3397eb(_0x5b142b),
        _0x44b2ed = _0x4572ba(_0x5b142b, _0x329b89, _0x2e6eec),
        _0x25d0f7 = 'border-box' === _0x4f2fd6['css'](_0x5b142b, 'boxSizing', !0x1, _0x2e6eec);
    return _0x5ab946['test'](_0x44b2ed) ? _0x44b2ed : (_0x8386a3 = _0x25d0f7 && (_0x395361['boxSizingReliable']() || _0x44b2ed === _0x5b142b['style'][_0x329b89]), 'auto' === _0x44b2ed && (_0x44b2ed = _0x5b142b['offset' + _0x329b89[0x0]['toUpperCase']() + _0x329b89['slice'](0x1)]), _0x44b2ed = parseFloat(_0x44b2ed) || 0x0, _0x44b2ed + _0x548192(_0x5b142b, _0x329b89, _0x536317 || (_0x25d0f7 ? 'border' : 'content'), _0x8386a3, _0x2e6eec) + 'px');
}

function _0x84d2fb(_0xed007f, _0x52a02b, _0x105218, _0x37e90b, _0x1e5bc7) {
    return new _0x84d2fb['prototype']['init'](_0xed007f, _0x52a02b, _0x105218, _0x37e90b, _0x1e5bc7);
}

function _0x252d18() {
    _0xaaee55 && (!0x1 === _0x5892f6['hidden'] && _0x10a213['requestAnimationFrame'] ? _0x10a213['requestAnimationFrame'](_0x252d18) : _0x10a213['setTimeout'](_0x252d18, _0x4f2fd6['fx']['interval']), _0x4f2fd6['fx']['tick']());
}

function _0x40ebde() {
    return _0x10a213['setTimeout'](function() {
        _0x50a4d5 = void 0x0;
    }), _0x50a4d5 = _0x4f2fd6['now']();
}

function _0x49080a(_0x1b42bf, _0x1aded) {
    var _0x2223f7, _0x210958 = 0x0,
        _0x4cb7bd = {
            'height': _0x1b42bf
        };
    for (_0x1aded = _0x1aded ? 0x1 : 0x0; 0x4 > _0x210958; _0x210958 += 0x2 - _0x1aded) _0x2223f7 = _0x46bbe7[_0x210958], _0x4cb7bd['margin' + _0x2223f7] = _0x4cb7bd['padding' + _0x2223f7] = _0x1b42bf;
    return _0x1aded && (_0x4cb7bd['opacity'] = _0x4cb7bd['width'] = _0x1b42bf), _0x4cb7bd;
}

function _0x5af035(_0x1f015f, _0x5b66d9, _0x357c36) {
    for (var _0x1ccf8a, _0x88b7da = (_0x12fd14['tweeners'][_0x5b66d9] || [])['concat'](_0x12fd14['tweeners']['*']), _0x2be191 = 0x0, _0x20c35a = _0x88b7da['length']; _0x2be191 < _0x20c35a; _0x2be191++)
        if (_0x1ccf8a = _0x88b7da[_0x2be191]['call'](_0x357c36, _0x5b66d9, _0x1f015f)) return _0x1ccf8a;
}

function _0x12fd14(_0x3d58d0, _0x4e4527, _0x3b9e90) {
    var _0x464faa, _0xbe4b2f, _0x4b6c6a = 0x0,
        _0x4bb2bd = _0x12fd14['prefilters']['length'],
        _0x20feb0 = _0x4f2fd6['Deferred']()['always'](function() {
            delete _0x3ed06d['elem'];
        }),
        _0x3ed06d = function() {
            if (_0xbe4b2f) return !0x1;
            for (var _0x3c0504 = _0x50a4d5 || _0x40ebde(), _0x3c0504 = Math['max'](0x0, _0x28f297['startTime'] + _0x28f297['duration'] - _0x3c0504), _0x30c851 = 0x1 - (_0x3c0504 / _0x28f297['duration'] || 0x0), _0x2d58e0 = 0x0, _0x2aa38f = _0x28f297['tweens']['length']; _0x2d58e0 < _0x2aa38f; _0x2d58e0++) _0x28f297['tweens'][_0x2d58e0]['run'](_0x30c851);
            return _0x20feb0['notifyWith'](_0x3d58d0, [_0x28f297, _0x30c851, _0x3c0504]), 0x1 > _0x30c851 && _0x2aa38f ? _0x3c0504 : (_0x2aa38f || _0x20feb0['notifyWith'](_0x3d58d0, [_0x28f297, 0x1, 0x0]), _0x20feb0['resolveWith'](_0x3d58d0, [_0x28f297]), !0x1);
        },
        _0x28f297 = _0x20feb0['promise']({
            'elem': _0x3d58d0,
            'props': _0x4f2fd6['extend']({}, _0x4e4527),
            'opts': _0x4f2fd6['extend'](!0x0, {
                'specialEasing': {},
                'easing': _0x4f2fd6['easing']['_default']
            }, _0x3b9e90),
            'originalProperties': _0x4e4527,
            'originalOptions': _0x3b9e90,
            'startTime': _0x50a4d5 || _0x40ebde(),
            'duration': _0x3b9e90['duration'],
            'tweens': [],
            'createTween': function(_0x4fa397, _0x523482) {
                var _0xc48265 = _0x4f2fd6['Tween'](_0x3d58d0, _0x28f297['opts'], _0x4fa397, _0x523482, _0x28f297['opts']['specialEasing'][_0x4fa397] || _0x28f297['opts']['easing']);
                return _0x28f297['tweens']['push'](_0xc48265), _0xc48265;
            },
            'stop': function(_0x4f54d2) {
                var _0x1e450b = 0x0,
                    _0x208776 = _0x4f54d2 ? _0x28f297['tweens']['length'] : 0x0;
                if (_0xbe4b2f) return this;
                for (_0xbe4b2f = !0x0; _0x1e450b < _0x208776; _0x1e450b++) _0x28f297['tweens'][_0x1e450b]['run'](0x1);
                return _0x4f54d2 ? (_0x20feb0['notifyWith'](_0x3d58d0, [_0x28f297, 0x1, 0x0]), _0x20feb0['resolveWith'](_0x3d58d0, [_0x28f297, _0x4f54d2])) : _0x20feb0['rejectWith'](_0x3d58d0, [_0x28f297, _0x4f54d2]), this;
            }
        });
    _0x4e4527 = _0x28f297['props'], _0x3b9e90 = _0x28f297['opts']['specialEasing'];
    var _0x4f0d3c, _0x16d8a3, _0x2f1892, _0x505676;
    for (_0x464faa in _0x4e4527)
        if (_0x4f0d3c = _0x4f2fd6['camelCase'](_0x464faa), _0x16d8a3 = _0x3b9e90[_0x4f0d3c], _0x2f1892 = _0x4e4527[_0x464faa], Array['isArray'](_0x2f1892) && (_0x16d8a3 = _0x2f1892[0x1], _0x2f1892 = _0x4e4527[_0x464faa] = _0x2f1892[0x0]), _0x464faa !== _0x4f0d3c && (_0x4e4527[_0x4f0d3c] = _0x2f1892, delete _0x4e4527[_0x464faa]), _0x505676 = _0x4f2fd6['cssHooks'][_0x4f0d3c], _0x505676 && 'expand' in _0x505676) {
            for (_0x464faa in (_0x2f1892 = _0x505676['expand'](_0x2f1892), delete _0x4e4527[_0x4f0d3c], _0x2f1892)) _0x464faa in _0x4e4527 || (_0x4e4527[_0x464faa] = _0x2f1892[_0x464faa], _0x3b9e90[_0x464faa] = _0x16d8a3);
        } else _0x3b9e90[_0x4f0d3c] = _0x16d8a3;
    for (; _0x4b6c6a < _0x4bb2bd; _0x4b6c6a++)
        if (_0x464faa = _0x12fd14['prefilters'][_0x4b6c6a]['call'](_0x28f297, _0x3d58d0, _0x4e4527, _0x28f297['opts'])) return _0x4f2fd6['isFunction'](_0x464faa['stop']) && (_0x4f2fd6['_queueHooks'](_0x28f297['elem'], _0x28f297['opts']['queue'])['stop'] = _0x4f2fd6['proxy'](_0x464faa['stop'], _0x464faa)), _0x464faa;
    return _0x4f2fd6['map'](_0x4e4527, _0x5af035, _0x28f297), _0x4f2fd6['isFunction'](_0x28f297['opts']['start']) && _0x28f297['opts']['start']['call'](_0x3d58d0, _0x28f297), _0x28f297['progress'](_0x28f297['opts']['progress'])['done'](_0x28f297['opts']['done'], _0x28f297['opts']['complete'])['fail'](_0x28f297['opts']['fail'])['always'](_0x28f297['opts']['always']), _0x4f2fd6['fx']['timer'](_0x4f2fd6['extend'](_0x3ed06d, {
        'elem': _0x3d58d0,
        'anim': _0x28f297,
        'queue': _0x28f297['opts']['queue']
    })), _0x28f297;
}

function _0x5c31c3(_0x4c5467) {
    return (_0x4c5467['match'](_0x287fa1) || [])['join']('\x20');
}

function _0x354a0c(_0x2158f4) {
    return _0x2158f4['getAttribute'] && _0x2158f4['getAttribute']('class') || '';
}

function _0x37af5b(_0x31bd38, _0xd19f11, _0x6f5a05, _0x2f6074) {
    var _0x700268;
    if (Array['isArray'](_0xd19f11)) _0x4f2fd6['each'](_0xd19f11, function(_0x27dd21, _0x57a849) {
        _0x6f5a05 || _0x596950['test'](_0x31bd38) ? _0x2f6074(_0x31bd38, _0x57a849) : _0x37af5b(_0x31bd38 + '[' + ('object' == typeof _0x57a849 && null != _0x57a849 ? _0x27dd21 : '') + ']', _0x57a849, _0x6f5a05, _0x2f6074);
    });
    else {
        if (_0x6f5a05 || 'object' !== _0x4f2fd6['type'](_0xd19f11)) _0x2f6074(_0x31bd38, _0xd19f11);
        else {
            for (_0x700268 in _0xd19f11) _0x37af5b(_0x31bd38 + '[' + _0x700268 + ']', _0xd19f11[_0x700268], _0x6f5a05, _0x2f6074);
        }
    }
}

function _0x2dc415(_0x1f3ae2) {
    return function(_0x3e46af, _0xd424e5) {
        'string' != typeof _0x3e46af && (_0xd424e5 = _0x3e46af, _0x3e46af = '*');
        var _0x524248, _0xe2d31a = 0x0,
            _0x578984 = _0x3e46af['toLowerCase']()['match'](_0x287fa1) || [];
        if (_0x4f2fd6['isFunction'](_0xd424e5)) {
            for (; _0x524248 = _0x578984[_0xe2d31a++];) '+' === _0x524248[0x0] ? (_0x524248 = _0x524248['slice'](0x1) || '*', (_0x1f3ae2[_0x524248] = _0x1f3ae2[_0x524248] || [])['unshift'](_0xd424e5)) : (_0x1f3ae2[_0x524248] = _0x1f3ae2[_0x524248] || [])['push'](_0xd424e5);
        }
    };
}

function _0x1333c1(_0x44beb8, _0x4d9836, _0x880edf, _0x4716ac) {
    function _0x17f2be(_0x16ffc4) {
        var _0x410fc7;
        return _0x1982ac[_0x16ffc4] = !0x0, _0x4f2fd6['each'](_0x44beb8[_0x16ffc4] || [], function(_0x33c09a, _0x18ff71) {
            var _0x22d997 = _0x18ff71(_0x4d9836, _0x880edf, _0x4716ac);
            return 'string' != typeof _0x22d997 || _0x1c4847 || _0x1982ac[_0x22d997] ? _0x1c4847 ? !(_0x410fc7 = _0x22d997) : void 0x0 : (_0x4d9836['dataTypes']['unshift'](_0x22d997), _0x17f2be(_0x22d997), !0x1);
        }), _0x410fc7;
    }
    var _0x1982ac = {},
        _0x1c4847 = _0x44beb8 === _0x7e13db;
    return _0x17f2be(_0x4d9836['dataTypes'][0x0]) || !_0x1982ac['*'] && _0x17f2be('*');
}

function _0x332b1e(_0x203808, _0xfd58b5) {
    var _0x2fc8aa, _0x4e8642, _0x3dd511 = _0x4f2fd6['ajaxSettings']['flatOptions'] || {};
    for (_0x2fc8aa in _0xfd58b5) void 0x0 !== _0xfd58b5[_0x2fc8aa] && ((_0x3dd511[_0x2fc8aa] ? _0x203808 : _0x4e8642 || (_0x4e8642 = {}))[_0x2fc8aa] = _0xfd58b5[_0x2fc8aa]);
    return _0x4e8642 && _0x4f2fd6['extend'](!0x0, _0x203808, _0x4e8642), _0x203808;
}
var _0x5b16bf = [],
    _0x5892f6 = _0x10a213['document'],
    _0xee7cdc = Object['getPrototypeOf'],
    _0x324811 = _0x5b16bf['slice'],
    _0x12bb42 = _0x5b16bf['concat'],
    _0x58b69d = _0x5b16bf['push'],
    _0x20db99 = _0x5b16bf['indexOf'],
    _0x5ad0e0 = {},
    _0x2a76da = _0x5ad0e0['toString'],
    _0x2a78ae = _0x5ad0e0['hasOwnProperty'],
    _0x11c9d5 = _0x2a78ae['toString'],
    _0x1b315d = _0x11c9d5['call'](Object),
    _0x395361 = {},
    _0x4f2fd6 = function(_0x5e90d0, _0x509060) {
        return new _0x4f2fd6['fn']['init'](_0x5e90d0, _0x509060);
    },
    _0x2e7ea4 = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
    _0x120de9 = /^-ms-/,
    _0x47908a = /-([a-z])/g,
    _0x5e82b2 = function(_0x366f97, _0x1d4dbe) {
        return _0x1d4dbe['toUpperCase']();
    };
_0x4f2fd6['fn'] = _0x4f2fd6['prototype'] = {
    'jquery': '3.2.1',
    'constructor': _0x4f2fd6,
    'length': 0x0,
    'toArray': function() {
        return _0x324811['call'](this);
    },
    'get': function(_0x2e4313) {
        return null == _0x2e4313 ? _0x324811['call'](this) : 0x0 > _0x2e4313 ? this[_0x2e4313 + this['length']] : this[_0x2e4313];
    },
    'pushStack': function(_0x3759fe) {
        return _0x3759fe = _0x4f2fd6['merge'](this['constructor'](), _0x3759fe), (_0x3759fe['prevObject'] = this, _0x3759fe);
    },
    'each': function(_0x2b9e95) {
        return _0x4f2fd6['each'](this, _0x2b9e95);
    },
    'map': function(_0x509707) {
        return this['pushStack'](_0x4f2fd6['map'](this, function(_0x1ce428, _0x13b947) {
            return _0x509707['call'](_0x1ce428, _0x13b947, _0x1ce428);
        }));
    },
    'slice': function() {
        return this['pushStack'](_0x324811['apply'](this, arguments));
    },
    'first': function() {
        return this['eq'](0x0);
    },
    'last': function() {
        return this['eq'](-0x1);
    },
    'eq': function(_0x571d3a) {
        var _0x594e23 = this['length'];
        return _0x571d3a = +_0x571d3a + (0x0 > _0x571d3a ? _0x594e23 : 0x0), this['pushStack'](0x0 <= _0x571d3a && _0x571d3a < _0x594e23 ? [this[_0x571d3a]] : []);
    },
    'end': function() {
        return this['prevObject'] || this['constructor']();
    },
    'push': _0x58b69d,
    'sort': _0x5b16bf['sort'],
    'splice': _0x5b16bf['splice']
}, _0x4f2fd6['extend'] = _0x4f2fd6['fn']['extend'] = function() {
    var _0x21c409, _0x197c7c, _0x29ebed, _0x2b823c, _0x10436a, _0x5c6ba3, _0x4b2aea = arguments[0x0] || {},
        _0x3481de = 0x1,
        _0x1ccd70 = arguments['length'],
        _0x349070 = !0x1;
    'boolean' == typeof _0x4b2aea && (_0x349070 = _0x4b2aea, _0x4b2aea = arguments[_0x3481de] || {}, _0x3481de++), 'object' == typeof _0x4b2aea || _0x4f2fd6['isFunction'](_0x4b2aea) || (_0x4b2aea = {});
    for (_0x3481de === _0x1ccd70 && (_0x4b2aea = this, _0x3481de--); _0x3481de < _0x1ccd70; _0x3481de++)
        if (null != (_0x21c409 = arguments[_0x3481de])) {
            for (_0x197c7c in _0x21c409) _0x29ebed = _0x4b2aea[_0x197c7c], _0x2b823c = _0x21c409[_0x197c7c], _0x4b2aea !== _0x2b823c && (_0x349070 && _0x2b823c && (_0x4f2fd6['isPlainObject'](_0x2b823c) || (_0x10436a = Array['isArray'](_0x2b823c))) ? (_0x10436a ? (_0x10436a = !0x1, _0x5c6ba3 = _0x29ebed && Array['isArray'](_0x29ebed) ? _0x29ebed : []) : _0x5c6ba3 = _0x29ebed && _0x4f2fd6['isPlainObject'](_0x29ebed) ? _0x29ebed : {}, _0x4b2aea[_0x197c7c] = _0x4f2fd6['extend'](_0x349070, _0x5c6ba3, _0x2b823c)) : void 0x0 !== _0x2b823c && (_0x4b2aea[_0x197c7c] = _0x2b823c));
        }
    return _0x4b2aea;
}, _0x4f2fd6['extend']({
    'expando': 'jQuery' + ('3.2.1' + Math['random']())['replace'](/\D/g, ''),
    'isReady': !0x0,
    'error': function(_0x4b50c2) {
        throw Error(_0x4b50c2);
    },
    'noop': function() {},
    'isFunction': function(_0x33e20a) {
        return 'function' === _0x4f2fd6['type'](_0x33e20a);
    },
    'isWindow': function(_0x9e41a3) {
        return null != _0x9e41a3 && _0x9e41a3 === _0x9e41a3['window'];
    },
    'isNumeric': function(_0x4bbd73) {
        var _0x48f1f2 = _0x4f2fd6['type'](_0x4bbd73);
        return ('number' === _0x48f1f2 || 'string' === _0x48f1f2) && !isNaN(_0x4bbd73 - parseFloat(_0x4bbd73));
    },
    'isPlainObject': function(_0x2599fc) {
        var _0x3d315f, _0x14e5ce;
        return !(!_0x2599fc || '[object\x20Object]' !== _0x2a76da['call'](_0x2599fc)) && (!(_0x3d315f = _0xee7cdc(_0x2599fc)) || (_0x14e5ce = _0x2a78ae['call'](_0x3d315f, 'constructor') && _0x3d315f['constructor'], 'function' == typeof _0x14e5ce && _0x11c9d5['call'](_0x14e5ce) === _0x1b315d));
    },
    'isEmptyObject': function(_0x30a5a0) {
        for (var _0x11fae8 in _0x30a5a0) return !0x1;
        return !0x0;
    },
    'type': function(_0x1a1455) {
        return null == _0x1a1455 ? _0x1a1455 + '' : 'object' == typeof _0x1a1455 || 'function' == typeof _0x1a1455 ? _0x5ad0e0[_0x2a76da['call'](_0x1a1455)] || 'object' : typeof _0x1a1455;
    },
    'globalEval': function(_0x2812bd) {
        _0x30d3e4(_0x2812bd);
    },
    'camelCase': function(_0x147073) {
        return _0x147073['replace'](_0x120de9, 'ms-')['replace'](_0x47908a, _0x5e82b2);
    },
    'each': function(_0x8031fb, _0x133541) {
        var _0x3499b9, _0x4a5937 = 0x0;
        if (_0x331354(_0x8031fb)) {
            for (_0x3499b9 = _0x8031fb['length']; _0x4a5937 < _0x3499b9 && !0x1 !== _0x133541['call'](_0x8031fb[_0x4a5937], _0x4a5937, _0x8031fb[_0x4a5937]); _0x4a5937++);
        } else {
            for (_0x4a5937 in _0x8031fb)
                if (!0x1 === _0x133541['call'](_0x8031fb[_0x4a5937], _0x4a5937, _0x8031fb[_0x4a5937])) break;
        }
        return _0x8031fb;
    },
    'trim': function(_0x53ef93) {
        return null == _0x53ef93 ? '' : (_0x53ef93 + '')['replace'](_0x2e7ea4, '');
    },
    'makeArray': function(_0x46ed1e, _0x555e8b) {
        var _0x12799a = _0x555e8b || [];
        return null != _0x46ed1e && (_0x331354(Object(_0x46ed1e)) ? _0x4f2fd6['merge'](_0x12799a, 'string' == typeof _0x46ed1e ? [_0x46ed1e] : _0x46ed1e) : _0x58b69d['call'](_0x12799a, _0x46ed1e)), _0x12799a;
    },
    'inArray': function(_0x30757b, _0x1db6b8, _0x15b6dc) {
        return null == _0x1db6b8 ? -0x1 : _0x20db99['call'](_0x1db6b8, _0x30757b, _0x15b6dc);
    },
    'merge': function(_0x2b43ee, _0x424ce2) {
        for (var _0x44bbf5 = +_0x424ce2['length'], _0x2fbced = 0x0, _0x4e07cc = _0x2b43ee['length']; _0x2fbced < _0x44bbf5; _0x2fbced++) _0x2b43ee[_0x4e07cc++] = _0x424ce2[_0x2fbced];
        return _0x2b43ee['length'] = _0x4e07cc, _0x2b43ee;
    },
    'grep': function(_0x269cb1, _0x2921e6, _0x2b6cd2) {
        for (var _0x538876 = [], _0x9aa6be = 0x0, _0x57ed7e = _0x269cb1['length'], _0x1035f7 = !_0x2b6cd2; _0x9aa6be < _0x57ed7e; _0x9aa6be++) _0x2b6cd2 = !_0x2921e6(_0x269cb1[_0x9aa6be], _0x9aa6be), _0x2b6cd2 !== _0x1035f7 && _0x538876['push'](_0x269cb1[_0x9aa6be]);
        return _0x538876;
    },
    'map': function(_0x2c1da3, _0x311cd7, _0x5e6c38) {
        var _0x37fbf6, _0x47effd, _0x30e58 = 0x0,
            _0x53b9d7 = [];
        if (_0x331354(_0x2c1da3)) {
            for (_0x37fbf6 = _0x2c1da3['length']; _0x30e58 < _0x37fbf6; _0x30e58++) _0x47effd = _0x311cd7(_0x2c1da3[_0x30e58], _0x30e58, _0x5e6c38), null != _0x47effd && _0x53b9d7['push'](_0x47effd);
        } else {
            for (_0x30e58 in _0x2c1da3) _0x47effd = _0x311cd7(_0x2c1da3[_0x30e58], _0x30e58, _0x5e6c38), null != _0x47effd && _0x53b9d7['push'](_0x47effd);
        }
        return _0x12bb42['apply']([], _0x53b9d7);
    },
    'guid': 0x1,
    'proxy': function(_0x4df459, _0xc2af3f) {
        var _0x3ae447, _0x3879d7, _0x508bc0;
        if ('string' == typeof _0xc2af3f && (_0x3ae447 = _0x4df459[_0xc2af3f], _0xc2af3f = _0x4df459, _0x4df459 = _0x3ae447), _0x4f2fd6['isFunction'](_0x4df459)) return _0x3879d7 = _0x324811['call'](arguments, 0x2), _0x508bc0 = function() {
            return _0x4df459['apply'](_0xc2af3f || this, _0x3879d7['concat'](_0x324811['call'](arguments)));
        }, _0x508bc0['guid'] = _0x4df459['guid'] = _0x4df459['guid'] || _0x4f2fd6['guid']++, _0x508bc0;
    },
    'now': Date['now'],
    'support': _0x395361
}), 'function' == typeof Symbol && (_0x4f2fd6['fn'][Symbol['iterator']] = _0x5b16bf[Symbol['iterator']]), _0x4f2fd6['each']('Boolean\x20Number\x20String\x20Function\x20Array\x20Date\x20RegExp\x20Object\x20Error\x20Symbol' ['split']('\x20'), function(_0x563f1e, _0x11d195) {
    _0x5ad0e0['[object\x20' + _0x11d195 + ']'] = _0x11d195['toLowerCase']();
});
var _0x37271c, _0x2d2f4e = _0x10a213,
    _0x2b2ab0 = function(_0x257afd, _0x33256a, _0x4424b7, _0x323335) {
        var _0x4c43b7, _0x565d2b, _0x4ce1ef, _0x5815cc, _0x343bfb, _0x32000f = _0x33256a && _0x33256a['ownerDocument'],
            _0x47730f = _0x33256a ? _0x33256a['nodeType'] : 0x9;
        if (_0x4424b7 = _0x4424b7 || [], 'string' != typeof _0x257afd || !_0x257afd || 0x1 !== _0x47730f && 0x9 !== _0x47730f && 0xb !== _0x47730f) return _0x4424b7;
        if (!_0x323335 && ((_0x33256a ? _0x33256a['ownerDocument'] || _0x33256a : _0x57b845) !== _0x2c664f && _0x1789f1(_0x33256a), _0x33256a = _0x33256a || _0x2c664f, _0x1d0f18)) {
            if (0xb !== _0x47730f && (_0x5815cc = _0x40f0e3['exec'](_0x257afd))) {
                if (_0x4c43b7 = _0x5815cc[0x1]) {
                    if (0x9 === _0x47730f) {
                        if (!(_0x565d2b = _0x33256a['getElementById'](_0x4c43b7))) return _0x4424b7;
                        if (_0x565d2b['id'] === _0x4c43b7) return _0x4424b7['push'](_0x565d2b), _0x4424b7;
                    } else {
                        if (_0x32000f && (_0x565d2b = _0x32000f['getElementById'](_0x4c43b7)) && _0x202247(_0x33256a, _0x565d2b) && _0x565d2b['id'] === _0x4c43b7) return _0x4424b7['push'](_0x565d2b), _0x4424b7;
                    }
                } else {
                    if (_0x5815cc[0x2]) return _0x2db992['apply'](_0x4424b7, _0x33256a['getElementsByTagName'](_0x257afd)), _0x4424b7;
                    if ((_0x4c43b7 = _0x5815cc[0x3]) && _0xea81f6['getElementsByClassName'] && _0x33256a['getElementsByClassName']) return _0x2db992['apply'](_0x4424b7, _0x33256a['getElementsByClassName'](_0x4c43b7)), _0x4424b7;
                }
            }
            if (_0xea81f6['qsa'] && !_0x47a9e8[_0x257afd + '\x20'] && (!_0x1c5fff || !_0x1c5fff['test'](_0x257afd))) {
                if (0x1 !== _0x47730f) _0x32000f = _0x33256a, _0x343bfb = _0x257afd;
                else {
                    if ('object' !== _0x33256a['nodeName']['toLowerCase']()) {
                        (_0x4ce1ef = _0x33256a['getAttribute']('id')) ? _0x4ce1ef = _0x4ce1ef['replace'](_0x188271, _0x458a7e): _0x33256a['setAttribute']('id', _0x4ce1ef = _0x37e4cb), _0x565d2b = _0x460255(_0x257afd);
                        for (_0x4c43b7 = _0x565d2b['length']; _0x4c43b7--;) _0x565d2b[_0x4c43b7] = '#' + _0x4ce1ef + '\x20' + _0x1d5a67(_0x565d2b[_0x4c43b7]);
                        _0x343bfb = _0x565d2b['join'](','), _0x32000f = _0x455c20['test'](_0x257afd) && _0x2ee57c(_0x33256a['parentNode']) || _0x33256a;
                    }
                }
                if (_0x343bfb) try {
                    return _0x2db992['apply'](_0x4424b7, _0x32000f['querySelectorAll'](_0x343bfb)), _0x4424b7;
                } catch (_0x16304e) {} finally {
                    _0x4ce1ef === _0x37e4cb && _0x33256a['removeAttribute']('id');
                }
            }
        }
        return _0x15c49b(_0x257afd['replace'](_0x136fb2, '$1'), _0x33256a, _0x4424b7, _0x323335);
    },
    _0x5bda89 = function() {
        function _0x5ad672(_0x10d9a7, _0x3e445b) {
            return _0x59e3bb['push'](_0x10d9a7 + '\x20') > _0x132e4c['cacheLength'] && delete _0x5ad672[_0x59e3bb['shift']()], _0x5ad672[_0x10d9a7 + '\x20'] = _0x3e445b;
        }
        var _0x59e3bb = [];
        return _0x5ad672;
    },
    _0x4f216c = function(_0x8dc19a) {
        return _0x8dc19a[_0x37e4cb] = !0x0, _0x8dc19a;
    },
    _0x5935eb = function(_0x37919b) {
        var _0x329a78 = _0x2c664f['createElement']('fieldset');
        try {
            return !!_0x37919b(_0x329a78);
        } catch (_0xeed532) {
            return !0x1;
        } finally {
            _0x329a78['parentNode'] && _0x329a78['parentNode']['removeChild'](_0x329a78);
        }
    },
    _0x44ca03 = function(_0x542ea8, _0x1d769c) {
        for (var _0x341f08 = _0x542ea8['split']('|'), _0x1ae7af = _0x341f08['length']; _0x1ae7af--;) _0x132e4c['attrHandle'][_0x341f08[_0x1ae7af]] = _0x1d769c;
    },
    _0x379e30 = function(_0x48a853, _0xcf4f63) {
        var _0x15b26c = _0xcf4f63 && _0x48a853,
            _0x44f247 = _0x15b26c && 0x1 === _0x48a853['nodeType'] && 0x1 === _0xcf4f63['nodeType'] && _0x48a853['sourceIndex'] - _0xcf4f63['sourceIndex'];
        if (_0x44f247) return _0x44f247;
        if (_0x15b26c) {
            for (; _0x15b26c = _0x15b26c['nextSibling'];)
                if (_0x15b26c === _0xcf4f63) return -0x1;
        }
        return _0x48a853 ? 0x1 : -0x1;
    },
    _0x29aa88 = function(_0x507eff) {
        return function(_0x39b026) {
            return 'input' === _0x39b026['nodeName']['toLowerCase']() && _0x39b026['type'] === _0x507eff;
        };
    },
    _0x30202c = function(_0x420188) {
        return function(_0x338ca2) {
            var _0x5568ff = _0x338ca2['nodeName']['toLowerCase']();
            return ('input' === _0x5568ff || 'button' === _0x5568ff) && _0x338ca2['type'] === _0x420188;
        };
    },
    _0x1834b4 = function(_0x3123e2) {
        return function(_0x2e12ad) {
            return 'form' in _0x2e12ad ? _0x2e12ad['parentNode'] && !0x1 === _0x2e12ad['disabled'] ? 'label' in _0x2e12ad ? 'label' in _0x2e12ad['parentNode'] ? _0x2e12ad['parentNode']['disabled'] === _0x3123e2 : _0x2e12ad['disabled'] === _0x3123e2 : _0x2e12ad['isDisabled'] === _0x3123e2 || _0x2e12ad['isDisabled'] !== !_0x3123e2 && _0x1eafa5(_0x2e12ad) === _0x3123e2 : _0x2e12ad['disabled'] === _0x3123e2 : 'label' in _0x2e12ad && _0x2e12ad['disabled'] === _0x3123e2;
        };
    },
    _0x22721f = function(_0x449b17) {
        return _0x4f216c(function(_0x46090a) {
            return _0x46090a = +_0x46090a, _0x4f216c(function(_0x48de9e, _0x49fc59) {
                for (var _0xf564c6, _0x443b2e = _0x449b17([], _0x48de9e['length'], _0x46090a), _0x123916 = _0x443b2e['length']; _0x123916--;) _0x48de9e[_0xf564c6 = _0x443b2e[_0x123916]] && (_0x48de9e[_0xf564c6] = !(_0x49fc59[_0xf564c6] = _0x48de9e[_0xf564c6]));
            });
        });
    },
    _0x2ee57c = function(_0x326547) {
        return _0x326547 && 'undefined' != typeof _0x326547['getElementsByTagName'] && _0x326547;
    },
    _0x21e11f = function() {},
    _0x1d5a67 = function(_0x15ad72) {
        for (var _0xa3ef4a = 0x0, _0x33d72e = _0x15ad72['length'], _0x4db7bf = ''; _0xa3ef4a < _0x33d72e; _0xa3ef4a++) _0x4db7bf += _0x15ad72[_0xa3ef4a]['value'];
        return _0x4db7bf;
    },
    _0x3aa35f = function(_0x25336a, _0x49de17, _0x2cdb55) {
        var _0x189f70 = _0x49de17['dir'],
            _0x4832d5 = _0x49de17['next'],
            _0x5b260a = _0x4832d5 || _0x189f70,
            _0x5ebc34 = _0x2cdb55 && 'parentNode' === _0x5b260a,
            _0x45a67a = _0x32d0ea++;
        return _0x49de17['first'] ? function(_0xa87f0, _0x465e45, _0x2c7876) {
            for (; _0xa87f0 = _0xa87f0[_0x189f70];)
                if (0x1 === _0xa87f0['nodeType'] || _0x5ebc34) return _0x25336a(_0xa87f0, _0x465e45, _0x2c7876);
            return !0x1;
        } : function(_0x3c107e, _0x1b095e, _0x849593) {
            var _0x16795a, _0x33a943, _0x29e90d, _0x3994db = [_0x5d12fc, _0x45a67a];
            if (_0x849593)
                for (; _0x3c107e = _0x3c107e[_0x189f70];) {
                    if ((0x1 === _0x3c107e['nodeType'] || _0x5ebc34) && _0x25336a(_0x3c107e, _0x1b095e, _0x849593)) return !0x0;
                } else {
                    for (; _0x3c107e = _0x3c107e[_0x189f70];)
                        if (0x1 === _0x3c107e['nodeType'] || _0x5ebc34) {
                            if (_0x29e90d = _0x3c107e[_0x37e4cb] || (_0x3c107e[_0x37e4cb] = {}), _0x33a943 = _0x29e90d[_0x3c107e['uniqueID']] || (_0x29e90d[_0x3c107e['uniqueID']] = {}), _0x4832d5 && _0x4832d5 === _0x3c107e['nodeName']['toLowerCase']()) _0x3c107e = _0x3c107e[_0x189f70] || _0x3c107e;
                            else {
                                if ((_0x16795a = _0x33a943[_0x5b260a]) && _0x16795a[0x0] === _0x5d12fc && _0x16795a[0x1] === _0x45a67a) return _0x3994db[0x2] = _0x16795a[0x2];
                                if (_0x33a943[_0x5b260a] = _0x3994db, _0x3994db[0x2] = _0x25336a(_0x3c107e, _0x1b095e, _0x849593)) return !0x0;
                            }
                        }
                }
            return !0x1;
        };
    },
    _0x492096 = function(_0x3712b2) {
        return 0x1 < _0x3712b2['length'] ? function(_0x5d1b2c, _0x14457d, _0xbb0e9) {
            for (var _0x1e63ef = _0x3712b2['length']; _0x1e63ef--;)
                if (!_0x3712b2[_0x1e63ef](_0x5d1b2c, _0x14457d, _0xbb0e9)) return !0x1;
            return !0x0;
        } : _0x3712b2[0x0];
    },
    _0x530420 = function(_0x405539, _0x207d81, _0x2239d4, _0x477358, _0x4d79e6) {
        for (var _0x15a2fe, _0x49fb89 = [], _0x467097 = 0x0, _0x143fdc = _0x405539['length'], _0xbea020 = null != _0x207d81; _0x467097 < _0x143fdc; _0x467097++)(_0x15a2fe = _0x405539[_0x467097]) && (_0x2239d4 && !_0x2239d4(_0x15a2fe, _0x477358, _0x4d79e6) || (_0x49fb89['push'](_0x15a2fe), _0xbea020 && _0x207d81['push'](_0x467097)));
        return _0x49fb89;
    },
    _0x46d157 = function(_0x5f1a81, _0x45b84a, _0x5503e9, _0x27afe0, _0x5c6462, _0x518661) {
        return _0x27afe0 && !_0x27afe0[_0x37e4cb] && (_0x27afe0 = _0x46d157(_0x27afe0)), _0x5c6462 && !_0x5c6462[_0x37e4cb] && (_0x5c6462 = _0x46d157(_0x5c6462, _0x518661)), _0x4f216c(function(_0x5e1220, _0x2c9c1c, _0x3331c4, _0x8afeb8) {
            var _0x2afcb6, _0x226b41, _0x51a2e6 = [],
                _0x180823 = [],
                _0x241805 = _0x2c9c1c['length'],
                _0x5a4341;
            if (!(_0x5a4341 = _0x5e1220)) {
                _0x5a4341 = _0x45b84a || '*';
                for (var _0x3becb8 = _0x3331c4['nodeType'] ? [_0x3331c4] : _0x3331c4, _0x26158c = [], _0x496f91 = 0x0, _0x2ae221 = _0x3becb8['length']; _0x496f91 < _0x2ae221; _0x496f91++) _0x2b2ab0(_0x5a4341, _0x3becb8[_0x496f91], _0x26158c);
                _0x5a4341 = _0x26158c;
            }
            _0x5a4341 = !_0x5f1a81 || !_0x5e1220 && _0x45b84a ? _0x5a4341 : _0x530420(_0x5a4341, _0x51a2e6, _0x5f1a81, _0x3331c4, _0x8afeb8), _0x3becb8 = _0x5503e9 ? _0x5c6462 || (_0x5e1220 ? _0x5f1a81 : _0x241805 || _0x27afe0) ? [] : _0x2c9c1c : _0x5a4341;
            if (_0x5503e9 && _0x5503e9(_0x5a4341, _0x3becb8, _0x3331c4, _0x8afeb8), _0x27afe0) {
                _0x2afcb6 = _0x530420(_0x3becb8, _0x180823), _0x27afe0(_0x2afcb6, [], _0x3331c4, _0x8afeb8);
                for (_0x3331c4 = _0x2afcb6['length']; _0x3331c4--;)(_0x226b41 = _0x2afcb6[_0x3331c4]) && (_0x3becb8[_0x180823[_0x3331c4]] = !(_0x5a4341[_0x180823[_0x3331c4]] = _0x226b41));
            }
            if (_0x5e1220) {
                if (_0x5c6462 || _0x5f1a81) {
                    if (_0x5c6462) {
                        _0x2afcb6 = [];
                        for (_0x3331c4 = _0x3becb8['length']; _0x3331c4--;)(_0x226b41 = _0x3becb8[_0x3331c4]) && _0x2afcb6['push'](_0x5a4341[_0x3331c4] = _0x226b41);
                        _0x5c6462(null, _0x3becb8 = [], _0x2afcb6, _0x8afeb8);
                    }
                    for (_0x3331c4 = _0x3becb8['length']; _0x3331c4--;)(_0x226b41 = _0x3becb8[_0x3331c4]) && -0x1 < (_0x2afcb6 = _0x5c6462 ? _0x50ecab(_0x5e1220, _0x226b41) : _0x51a2e6[_0x3331c4]) && (_0x5e1220[_0x2afcb6] = !(_0x2c9c1c[_0x2afcb6] = _0x226b41));
                }
            } else _0x3becb8 = _0x530420(_0x3becb8 === _0x2c9c1c ? _0x3becb8['splice'](_0x241805, _0x3becb8['length']) : _0x3becb8), _0x5c6462 ? _0x5c6462(null, _0x2c9c1c, _0x3becb8, _0x8afeb8) : _0x2db992['apply'](_0x2c9c1c, _0x3becb8);
        });
    },
    _0x4727a5 = function(_0x23786c) {
        var _0x51469b, _0x104eec, _0x1d9d2c, _0xcb8ce6 = _0x23786c['length'],
            _0x3fc349 = _0x132e4c['relative'][_0x23786c[0x0]['type']];
        _0x104eec = _0x3fc349 || _0x132e4c['relative']['\x20'];
        for (var _0x4c8517 = _0x3fc349 ? 0x1 : 0x0, _0x2fb7cd = _0x3aa35f(function(_0x480a93) {
                return _0x480a93 === _0x51469b;
            }, _0x104eec, !0x0), _0x285efd = _0x3aa35f(function(_0x47a604) {
                return -0x1 < _0x50ecab(_0x51469b, _0x47a604);
            }, _0x104eec, !0x0), _0x19b4f7 = [function(_0x31cbd2, _0x4a0559, _0x4b0646) {
                return _0x31cbd2 = !_0x3fc349 && (_0x4b0646 || _0x4a0559 !== _0x5dacbd) || ((_0x51469b = _0x4a0559)['nodeType'] ? _0x2fb7cd(_0x31cbd2, _0x4a0559, _0x4b0646) : _0x285efd(_0x31cbd2, _0x4a0559, _0x4b0646)), (_0x51469b = null, _0x31cbd2);
            }]; _0x4c8517 < _0xcb8ce6; _0x4c8517++)
            if (_0x104eec = _0x132e4c['relative'][_0x23786c[_0x4c8517]['type']]) _0x19b4f7 = [_0x3aa35f(_0x492096(_0x19b4f7), _0x104eec)];
            else {
                if (_0x104eec = _0x132e4c['filter'][_0x23786c[_0x4c8517]['type']]['apply'](null, _0x23786c[_0x4c8517]['matches']), _0x104eec[_0x37e4cb]) {
                    for (_0x1d9d2c = ++_0x4c8517; _0x1d9d2c < _0xcb8ce6 && !_0x132e4c['relative'][_0x23786c[_0x1d9d2c]['type']]; _0x1d9d2c++);
                    return _0x46d157(0x1 < _0x4c8517 && _0x492096(_0x19b4f7), 0x1 < _0x4c8517 && _0x1d5a67(_0x23786c['slice'](0x0, _0x4c8517 - 0x1)['concat']({
                        'value': '\x20' === _0x23786c[_0x4c8517 - 0x2]['type'] ? '*' : ''
                    }))['replace'](_0x136fb2, '$1'), _0x104eec, _0x4c8517 < _0x1d9d2c && _0x4727a5(_0x23786c['slice'](_0x4c8517, _0x1d9d2c)), _0x1d9d2c < _0xcb8ce6 && _0x4727a5(_0x23786c = _0x23786c['slice'](_0x1d9d2c)), _0x1d9d2c < _0xcb8ce6 && _0x1d5a67(_0x23786c));
                }
                _0x19b4f7['push'](_0x104eec);
            }
        return _0x492096(_0x19b4f7);
    },
    _0x339742, _0xea81f6, _0x132e4c, _0x19b5e4, _0x44da27, _0x460255, _0x589207, _0x15c49b, _0x5dacbd, _0x4c2951, _0xf81cb8, _0x1789f1, _0x2c664f, _0x50c008, _0x1d0f18, _0x1c5fff, _0x513a8f, _0x3cc3c2, _0x202247, _0x37e4cb = 'sizzle' + 0x1 * new Date(),
    _0x57b845 = _0x2d2f4e['document'],
    _0x5d12fc = 0x0,
    _0x32d0ea = 0x0,
    _0x247771 = _0x5bda89(),
    _0xb5baa0 = _0x5bda89(),
    _0x47a9e8 = _0x5bda89(),
    _0x39b5f7 = function(_0x4247b5, _0x3334f0) {
        return _0x4247b5 === _0x3334f0 && (_0xf81cb8 = !0x0), 0x0;
    },
    _0x512410 = {}['hasOwnProperty'],
    _0x3da5dd = [],
    _0x4d2e7e = _0x3da5dd['pop'],
    _0x10f331 = _0x3da5dd['push'],
    _0x2db992 = _0x3da5dd['push'],
    _0x23e20a = _0x3da5dd['slice'],
    _0x50ecab = function(_0x120f87, _0x31f096) {
        for (var _0x528b06 = 0x0, _0x4fd272 = _0x120f87['length']; _0x528b06 < _0x4fd272; _0x528b06++)
            if (_0x120f87[_0x528b06] === _0x31f096) return _0x528b06;
        return -0x1;
    },
    _0x58dd95 = /[\x20\t\r\n\f]+/g,
    _0x136fb2 = /^[\x20\t\r\n\f]+|((?:^|[^\\])(?:\\.)*)[\x20\t\r\n\f]+$/g,
    _0x1635a1 = /^[\x20\t\r\n\f]*,[\x20\t\r\n\f]*/,
    _0x38d550 = /^[\x20\t\r\n\f]*([>+~]|[\x20\t\r\n\f])[\x20\t\r\n\f]*/,
    _0x2d066a = /=[\x20\t\r\n\f]*([^\]'"]*?)[\x20\t\r\n\f]*\]/g,
    _0x20bbfe = RegExp(':((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+)(?:\x5c(((\x27((?:\x5c\x5c.|[^\x5c\x5c\x27])*)\x27|\x22((?:\x5c\x5c.|[^\x5c\x5c\x22])*)\x22)|((?:\x5c\x5c.|[^\x5c\x5c()[\x5c]]|\x5c[[\x5cx20\x5ct\x5cr\x5cn\x5cf]*((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+)(?:[\x5cx20\x5ct\x5cr\x5cn\x5cf]*([*^$|!~]?=)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*(?:\x27((?:\x5c\x5c.|[^\x5c\x5c\x27])*)\x27|\x22((?:\x5c\x5c.|[^\x5c\x5c\x22])*)\x22|((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+))|)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*\x5c])*)|.*)\x5c)|)'),
    _0x2730f1 = /^(?:\\.|[\w-]|[^\x00-\xa0])+$/,
    _0x4b1682 = {
        'ID': /^#((?:\\.|[\w-]|[^\x00-\xa0])+)/,
        'CLASS': /^\.((?:\\.|[\w-]|[^\x00-\xa0])+)/,
        'TAG': /^((?:\\.|[\w-]|[^\x00-\xa0])+|[*])/,
        'ATTR': RegExp('^\x5c[[\x5cx20\x5ct\x5cr\x5cn\x5cf]*((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+)(?:[\x5cx20\x5ct\x5cr\x5cn\x5cf]*([*^$|!~]?=)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*(?:\x27((?:\x5c\x5c.|[^\x5c\x5c\x27])*)\x27|\x22((?:\x5c\x5c.|[^\x5c\x5c\x22])*)\x22|((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+))|)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*\x5c]'),
        'PSEUDO': RegExp('^:((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+)(?:\x5c(((\x27((?:\x5c\x5c.|[^\x5c\x5c\x27])*)\x27|\x22((?:\x5c\x5c.|[^\x5c\x5c\x22])*)\x22)|((?:\x5c\x5c.|[^\x5c\x5c()[\x5c]]|\x5c[[\x5cx20\x5ct\x5cr\x5cn\x5cf]*((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+)(?:[\x5cx20\x5ct\x5cr\x5cn\x5cf]*([*^$|!~]?=)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*(?:\x27((?:\x5c\x5c.|[^\x5c\x5c\x27])*)\x27|\x22((?:\x5c\x5c.|[^\x5c\x5c\x22])*)\x22|((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+))|)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*\x5c])*)|.*)\x5c)|)'),
        'CHILD': RegExp('^:(only|first|last|nth|nth-last)-(child|of-type)(?:\x5c([\x5cx20\x5ct\x5cr\x5cn\x5cf]*(even|odd|(([+-]|)(\x5cd*)n|)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*(?:([+-]|)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*(\x5cd+)|))[\x5cx20\x5ct\x5cr\x5cn\x5cf]*\x5c)|)', 'i'),
        'bool': RegExp('^(?:checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped)$', 'i'),
        'needsContext': RegExp('^[\x5cx20\x5ct\x5cr\x5cn\x5cf]*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\x5c([\x5cx20\x5ct\x5cr\x5cn\x5cf]*((?:-\x5cd)?\x5cd*)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*\x5c)|)(?=[^-]|$)', 'i')
    },
    _0x3e5628 = /^(?:input|select|textarea|button)$/i,
    _0x38d8be = /^h\d$/i,
    _0x2c6513 = /^[^{]+\{\s*\[native \w/,
    _0x40f0e3 = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
    _0x455c20 = /[+~]/,
    _0x191977 = /\\([\da-f]{1,6}[\x20\t\r\n\f]?|([\x20\t\r\n\f])|.)/ig,
    _0x410ece = function(_0x35eefd, _0x1c418a, _0x7d809f) {
        return _0x35eefd = '0x' + _0x1c418a - 0x10000, _0x35eefd !== _0x35eefd || _0x7d809f ? _0x1c418a : 0x0 > _0x35eefd ? String['fromCharCode'](_0x35eefd + 0x10000) : String['fromCharCode'](_0x35eefd >> 0xa | 0xd800, 0x3ff & _0x35eefd | 0xdc00);
    },
    _0x188271 = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
    _0x458a7e = function(_0x5afea6, _0x2c058c) {
        return _0x2c058c ? '\x00' === _0x5afea6 ? '�' : _0x5afea6['slice'](0x0, -0x1) + '\x5c' + _0x5afea6['charCodeAt'](_0x5afea6['length'] - 0x1)['toString'](0x10) + '\x20' : '\x5c' + _0x5afea6;
    },
    _0x4909ab = function() {
        _0x1789f1();
    },
    _0x1eafa5 = _0x3aa35f(function(_0xf4a2b5) {
        return !0x0 === _0xf4a2b5['disabled'] && ('form' in _0xf4a2b5 || 'label' in _0xf4a2b5);
    }, {
        'dir': 'parentNode',
        'next': 'legend'
    });
try {
    _0x2db992['apply'](_0x3da5dd = _0x23e20a['call'](_0x57b845['childNodes']), _0x57b845['childNodes']), _0x3da5dd[_0x57b845['childNodes']['length']]['nodeType'];
} catch (_0x34fa26) {
    _0x2db992 = {
        'apply': _0x3da5dd['length'] ? function(_0x855a5b, _0x1c7349) {
            _0x10f331['apply'](_0x855a5b, _0x23e20a['call'](_0x1c7349));
        } : function(_0xe6efa0, _0x224f2c) {
            for (var _0x4c2314 = _0xe6efa0['length'], _0x569249 = 0x0; _0xe6efa0[_0x4c2314++] = _0x224f2c[_0x569249++];);
            _0xe6efa0['length'] = _0x4c2314 - 0x1;
        }
    };
}
_0xea81f6 = _0x2b2ab0['support'] = {}, _0x44da27 = _0x2b2ab0['isXML'] = function(_0x1611ab) {
    return _0x1611ab = _0x1611ab && (_0x1611ab['ownerDocument'] || _0x1611ab)['documentElement'], !!_0x1611ab && 'HTML' !== _0x1611ab['nodeName'];
}, _0x1789f1 = _0x2b2ab0['setDocument'] = function(_0x4620c7) {
    var _0x422db8, _0x13da70;
    return _0x4620c7 = _0x4620c7 ? _0x4620c7['ownerDocument'] || _0x4620c7 : _0x57b845, _0x4620c7 !== _0x2c664f && 0x9 === _0x4620c7['nodeType'] && _0x4620c7['documentElement'] ? (_0x2c664f = _0x4620c7, _0x50c008 = _0x2c664f['documentElement'], _0x1d0f18 = !_0x44da27(_0x2c664f), _0x57b845 !== _0x2c664f && (_0x13da70 = _0x2c664f['defaultView']) && _0x13da70['top'] !== _0x13da70 && (_0x13da70['addEventListener'] ? _0x13da70['addEventListener']('unload', _0x4909ab, !0x1) : _0x13da70['attachEvent'] && _0x13da70['attachEvent']('onunload', _0x4909ab)), _0xea81f6['attributes'] = _0x5935eb(function(_0x547d62) {
        return _0x547d62['className'] = 'i', !_0x547d62['getAttribute']('className');
    }), _0xea81f6['getElementsByTagName'] = _0x5935eb(function(_0x4307d4) {
        return _0x4307d4['appendChild'](_0x2c664f['createComment']('')), !_0x4307d4['getElementsByTagName']('*')['length'];
    }), _0xea81f6['getElementsByClassName'] = _0x2c6513['test'](_0x2c664f['getElementsByClassName']), _0xea81f6['getById'] = _0x5935eb(function(_0x3b68a1) {
        return _0x50c008['appendChild'](_0x3b68a1)['id'] = _0x37e4cb, !_0x2c664f['getElementsByName'] || !_0x2c664f['getElementsByName'](_0x37e4cb)['length'];
    }), _0xea81f6['getById'] ? (_0x132e4c['filter']['ID'] = function(_0x357459) {
        var _0x5be1f8 = _0x357459['replace'](_0x191977, _0x410ece);
        return function(_0x508ade) {
            return _0x508ade['getAttribute']('id') === _0x5be1f8;
        };
    }, _0x132e4c['find']['ID'] = function(_0x550968, _0x19d4c7) {
        if ('undefined' != typeof _0x19d4c7['getElementById'] && _0x1d0f18) {
            var _0x2252b3 = _0x19d4c7['getElementById'](_0x550968);
            return _0x2252b3 ? [_0x2252b3] : [];
        }
    }) : (_0x132e4c['filter']['ID'] = function(_0x123ea7) {
        var _0x13a5c4 = _0x123ea7['replace'](_0x191977, _0x410ece);
        return function(_0x302153) {
            return (_0x302153 = 'undefined' != typeof _0x302153['getAttributeNode'] && _0x302153['getAttributeNode']('id')) && _0x302153['value'] === _0x13a5c4;
        };
    }, _0x132e4c['find']['ID'] = function(_0x213da7, _0x313c64) {
        if ('undefined' != typeof _0x313c64['getElementById'] && _0x1d0f18) {
            var _0x5f4f94, _0x2f6929, _0xbaa9cd, _0x40ec14 = _0x313c64['getElementById'](_0x213da7);
            if (_0x40ec14) {
                if (_0x5f4f94 = _0x40ec14['getAttributeNode']('id'), _0x5f4f94 && _0x5f4f94['value'] === _0x213da7) return [_0x40ec14];
                _0xbaa9cd = _0x313c64['getElementsByName'](_0x213da7);
                for (_0x2f6929 = 0x0; _0x40ec14 = _0xbaa9cd[_0x2f6929++];)
                    if (_0x5f4f94 = _0x40ec14['getAttributeNode']('id'), _0x5f4f94 && _0x5f4f94['value'] === _0x213da7) return [_0x40ec14];
            }
            return [];
        }
    }), _0x132e4c['find']['TAG'] = _0xea81f6['getElementsByTagName'] ? function(_0x211d51, _0x193964) {
        return 'undefined' != typeof _0x193964['getElementsByTagName'] ? _0x193964['getElementsByTagName'](_0x211d51) : _0xea81f6['qsa'] ? _0x193964['querySelectorAll'](_0x211d51) : void 0x0;
    } : function(_0x3742b2, _0x6dd2f9) {
        var _0x7527ce, _0x26503a = [],
            _0x4cdf71 = 0x0,
            _0x44d958 = _0x6dd2f9['getElementsByTagName'](_0x3742b2);
        if ('*' === _0x3742b2) {
            for (; _0x7527ce = _0x44d958[_0x4cdf71++];) 0x1 === _0x7527ce['nodeType'] && _0x26503a['push'](_0x7527ce);
            return _0x26503a;
        }
        return _0x44d958;
    }, _0x132e4c['find']['CLASS'] = _0xea81f6['getElementsByClassName'] && function(_0x2d9fb7, _0x17c88e) {
        if ('undefined' != typeof _0x17c88e['getElementsByClassName'] && _0x1d0f18) return _0x17c88e['getElementsByClassName'](_0x2d9fb7);
    }, _0x513a8f = [], _0x1c5fff = [], (_0xea81f6['qsa'] = _0x2c6513['test'](_0x2c664f['querySelectorAll'])) && (_0x5935eb(function(_0x488e8f) {
        _0x50c008['appendChild'](_0x488e8f)['innerHTML'] = '<a\x20id=\x27' + _0x37e4cb + '\x27></a><select\x20id=\x27' + _0x37e4cb + '-\x0d\x5c\x27\x20msallowcapture=\x27\x27><option\x20selected=\x27\x27></option></select>', _0x488e8f['querySelectorAll']('[msallowcapture^=\x27\x27]')['length'] && _0x1c5fff['push']('[*^$]=[\x5cx20\x5ct\x5cr\x5cn\x5cf]*(?:\x27\x27|\x22\x22)'), _0x488e8f['querySelectorAll']('[selected]')['length'] || _0x1c5fff['push']('\x5c[[\x5cx20\x5ct\x5cr\x5cn\x5cf]*(?:value|checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped)'), _0x488e8f['querySelectorAll']('[id~=' + _0x37e4cb + '-]')['length'] || _0x1c5fff['push']('~='), _0x488e8f['querySelectorAll'](':checked')['length'] || _0x1c5fff['push'](':checked'), _0x488e8f['querySelectorAll']('a#' + _0x37e4cb + '+*')['length'] || _0x1c5fff['push']('.#.+[+~]');
    }), _0x5935eb(function(_0x4d8466) {
        _0x4d8466['innerHTML'] = '<a\x20href=\x27\x27\x20disabled=\x27disabled\x27></a><select\x20disabled=\x27disabled\x27><option/></select>';
        var _0x5be4d7 = _0x2c664f['createElement']('input');
        _0x5be4d7['setAttribute']('type', 'hidden'), _0x4d8466['appendChild'](_0x5be4d7)['setAttribute']('name', 'D'), _0x4d8466['querySelectorAll']('[name=d]')['length'] && _0x1c5fff['push']('name[\x5cx20\x5ct\x5cr\x5cn\x5cf]*[*^$|!~]?='), 0x2 !== _0x4d8466['querySelectorAll'](':enabled')['length'] && _0x1c5fff['push'](':enabled', ':disabled'), _0x50c008['appendChild'](_0x4d8466)['disabled'] = !0x0, 0x2 !== _0x4d8466['querySelectorAll'](':disabled')['length'] && _0x1c5fff['push'](':enabled', ':disabled'), _0x4d8466['querySelectorAll']('*,:x'), _0x1c5fff['push'](',.*:');
    })), (_0xea81f6['matchesSelector'] = _0x2c6513['test'](_0x3cc3c2 = _0x50c008['matches'] || _0x50c008['webkitMatchesSelector'] || _0x50c008['mozMatchesSelector'] || _0x50c008['oMatchesSelector'] || _0x50c008['msMatchesSelector'])) && _0x5935eb(function(_0x11043b) {
        _0xea81f6['disconnectedMatch'] = _0x3cc3c2['call'](_0x11043b, '*'), _0x3cc3c2['call'](_0x11043b, '[s!=\x27\x27]:x'), _0x513a8f['push']('!=', ':((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+)(?:\x5c(((\x27((?:\x5c\x5c.|[^\x5c\x5c\x27])*)\x27|\x22((?:\x5c\x5c.|[^\x5c\x5c\x22])*)\x22)|((?:\x5c\x5c.|[^\x5c\x5c()[\x5c]]|\x5c[[\x5cx20\x5ct\x5cr\x5cn\x5cf]*((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+)(?:[\x5cx20\x5ct\x5cr\x5cn\x5cf]*([*^$|!~]?=)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*(?:\x27((?:\x5c\x5c.|[^\x5c\x5c\x27])*)\x27|\x22((?:\x5c\x5c.|[^\x5c\x5c\x22])*)\x22|((?:\x5c\x5c.|[\x5cw-]|[^\x00-\x5cxa0])+))|)[\x5cx20\x5ct\x5cr\x5cn\x5cf]*\x5c])*)|.*)\x5c)|)');
    }), _0x1c5fff = _0x1c5fff['length'] && RegExp(_0x1c5fff['join']('|')), _0x513a8f = _0x513a8f['length'] && RegExp(_0x513a8f['join']('|')), _0x422db8 = _0x2c6513['test'](_0x50c008['compareDocumentPosition']), _0x202247 = _0x422db8 || _0x2c6513['test'](_0x50c008['contains']) ? function(_0x5b8f87, _0x1fa1e4) {
        var _0x4e3134 = 0x9 === _0x5b8f87['nodeType'] ? _0x5b8f87['documentElement'] : _0x5b8f87,
            _0x1e96dd = _0x1fa1e4 && _0x1fa1e4['parentNode'];
        return _0x5b8f87 === _0x1e96dd || !(!_0x1e96dd || 0x1 !== _0x1e96dd['nodeType'] || !(_0x4e3134['contains'] ? _0x4e3134['contains'](_0x1e96dd) : _0x5b8f87['compareDocumentPosition'] && 0x10 & _0x5b8f87['compareDocumentPosition'](_0x1e96dd)));
    } : function(_0x208dc9, _0x43cdd4) {
        if (_0x43cdd4) {
            for (; _0x43cdd4 = _0x43cdd4['parentNode'];)
                if (_0x43cdd4 === _0x208dc9) return !0x0;
        }
        return !0x1;
    }, _0x39b5f7 = _0x422db8 ? function(_0x2ce334, _0x381472) {
        if (_0x2ce334 === _0x381472) return _0xf81cb8 = !0x0, 0x0;
        var _0x242c84 = !_0x2ce334['compareDocumentPosition'] - !_0x381472['compareDocumentPosition'];
        return _0x242c84 ? _0x242c84 : (_0x242c84 = (_0x2ce334['ownerDocument'] || _0x2ce334) === (_0x381472['ownerDocument'] || _0x381472) ? _0x2ce334['compareDocumentPosition'](_0x381472) : 0x1, 0x1 & _0x242c84 || !_0xea81f6['sortDetached'] && _0x381472['compareDocumentPosition'](_0x2ce334) === _0x242c84 ? _0x2ce334 === _0x2c664f || _0x2ce334['ownerDocument'] === _0x57b845 && _0x202247(_0x57b845, _0x2ce334) ? -0x1 : _0x381472 === _0x2c664f || _0x381472['ownerDocument'] === _0x57b845 && _0x202247(_0x57b845, _0x381472) ? 0x1 : _0x4c2951 ? _0x50ecab(_0x4c2951, _0x2ce334) - _0x50ecab(_0x4c2951, _0x381472) : 0x0 : 0x4 & _0x242c84 ? -0x1 : 0x1);
    } : function(_0x24ec2b, _0x2922ab) {
        if (_0x24ec2b === _0x2922ab) return _0xf81cb8 = !0x0, 0x0;
        var _0x1a5da0, _0x21d36c = 0x0;
        _0x1a5da0 = _0x24ec2b['parentNode'];
        var _0x28a887 = _0x2922ab['parentNode'],
            _0x52f439 = [_0x24ec2b],
            _0x456c45 = [_0x2922ab];
        if (!_0x1a5da0 || !_0x28a887) return _0x24ec2b === _0x2c664f ? -0x1 : _0x2922ab === _0x2c664f ? 0x1 : _0x1a5da0 ? -0x1 : _0x28a887 ? 0x1 : _0x4c2951 ? _0x50ecab(_0x4c2951, _0x24ec2b) - _0x50ecab(_0x4c2951, _0x2922ab) : 0x0;
        if (_0x1a5da0 === _0x28a887) return _0x379e30(_0x24ec2b, _0x2922ab);
        for (_0x1a5da0 = _0x24ec2b; _0x1a5da0 = _0x1a5da0['parentNode'];) _0x52f439['unshift'](_0x1a5da0);
        for (_0x1a5da0 = _0x2922ab; _0x1a5da0 = _0x1a5da0['parentNode'];) _0x456c45['unshift'](_0x1a5da0);
        for (; _0x52f439[_0x21d36c] === _0x456c45[_0x21d36c];) _0x21d36c++;
        return _0x21d36c ? _0x379e30(_0x52f439[_0x21d36c], _0x456c45[_0x21d36c]) : _0x52f439[_0x21d36c] === _0x57b845 ? -0x1 : _0x456c45[_0x21d36c] === _0x57b845 ? 0x1 : 0x0;
    }, _0x2c664f) : _0x2c664f;
}, _0x2b2ab0['matches'] = function(_0x351d85, _0x534eb2) {
    return _0x2b2ab0(_0x351d85, null, null, _0x534eb2);
}, _0x2b2ab0['matchesSelector'] = function(_0x19ad62, _0x1bae67) {
    if ((_0x19ad62['ownerDocument'] || _0x19ad62) !== _0x2c664f && _0x1789f1(_0x19ad62), _0x1bae67 = _0x1bae67['replace'](_0x2d066a, '=\x27$1\x27]'), _0xea81f6['matchesSelector'] && _0x1d0f18 && !_0x47a9e8[_0x1bae67 + '\x20'] && (!_0x513a8f || !_0x513a8f['test'](_0x1bae67)) && (!_0x1c5fff || !_0x1c5fff['test'](_0x1bae67))) try {
        var _0x576157 = _0x3cc3c2['call'](_0x19ad62, _0x1bae67);
        if (_0x576157 || _0xea81f6['disconnectedMatch'] || _0x19ad62['document'] && 0xb !== _0x19ad62['document']['nodeType']) return _0x576157;
    } catch (_0x232400) {}
    return 0x0 < _0x2b2ab0(_0x1bae67, _0x2c664f, null, [_0x19ad62])['length'];
}, _0x2b2ab0['contains'] = function(_0x28bd43, _0x3f9526) {
    return (_0x28bd43['ownerDocument'] || _0x28bd43) !== _0x2c664f && _0x1789f1(_0x28bd43), _0x202247(_0x28bd43, _0x3f9526);
}, _0x2b2ab0['attr'] = function(_0x2cfba0, _0x5a0f09) {
    (_0x2cfba0['ownerDocument'] || _0x2cfba0) !== _0x2c664f && _0x1789f1(_0x2cfba0);
    var _0x2f6e03 = _0x132e4c['attrHandle'][_0x5a0f09['toLowerCase']()],
        _0x2f6e03 = _0x2f6e03 && _0x512410['call'](_0x132e4c['attrHandle'], _0x5a0f09['toLowerCase']()) ? _0x2f6e03(_0x2cfba0, _0x5a0f09, !_0x1d0f18) : void 0x0;
    return void 0x0 !== _0x2f6e03 ? _0x2f6e03 : _0xea81f6['attributes'] || !_0x1d0f18 ? _0x2cfba0['getAttribute'](_0x5a0f09) : (_0x2f6e03 = _0x2cfba0['getAttributeNode'](_0x5a0f09)) && _0x2f6e03['specified'] ? _0x2f6e03['value'] : null;
}, _0x2b2ab0['escape'] = function(_0x22ec0c) {
    return (_0x22ec0c + '')['replace'](_0x188271, _0x458a7e);
}, _0x2b2ab0['error'] = function(_0x4d3966) {
    throw Error('Syntax\x20error,\x20unrecognized\x20expression:\x20' + _0x4d3966);
}, _0x2b2ab0['uniqueSort'] = function(_0x4d5a38) {
    var _0x21aef0, _0x1a889b = [],
        _0x3e2f0c = 0x0,
        _0x42f0cf = 0x0;
    if (_0xf81cb8 = !_0xea81f6['detectDuplicates'], _0x4c2951 = !_0xea81f6['sortStable'] && _0x4d5a38['slice'](0x0), _0x4d5a38['sort'](_0x39b5f7), _0xf81cb8) {
        for (; _0x21aef0 = _0x4d5a38[_0x42f0cf++];) _0x21aef0 === _0x4d5a38[_0x42f0cf] && (_0x3e2f0c = _0x1a889b['push'](_0x42f0cf));
        for (; _0x3e2f0c--;) _0x4d5a38['splice'](_0x1a889b[_0x3e2f0c], 0x1);
    }
    return _0x4c2951 = null, _0x4d5a38;
}, _0x19b5e4 = _0x2b2ab0['getText'] = function(_0x46128e) {
    var _0x49ede9, _0x17e864 = '',
        _0x45ed3a = 0x0;
    if (_0x49ede9 = _0x46128e['nodeType']) {
        if (0x1 === _0x49ede9 || 0x9 === _0x49ede9 || 0xb === _0x49ede9) {
            if ('string' == typeof _0x46128e['textContent']) return _0x46128e['textContent'];
            for (_0x46128e = _0x46128e['firstChild']; _0x46128e; _0x46128e = _0x46128e['nextSibling']) _0x17e864 += _0x19b5e4(_0x46128e);
        } else {
            if (0x3 === _0x49ede9 || 0x4 === _0x49ede9) return _0x46128e['nodeValue'];
        }
    } else {
        for (; _0x49ede9 = _0x46128e[_0x45ed3a++];) _0x17e864 += _0x19b5e4(_0x49ede9);
    }
    return _0x17e864;
}, _0x132e4c = _0x2b2ab0['selectors'] = {
    'cacheLength': 0x32,
    'createPseudo': _0x4f216c,
    'match': _0x4b1682,
    'attrHandle': {},
    'find': {},
    'relative': {
        '>': {
            'dir': 'parentNode',
            'first': !0x0
        },
        '\x20': {
            'dir': 'parentNode'
        },
        '+': {
            'dir': 'previousSibling',
            'first': !0x0
        },
        '~': {
            'dir': 'previousSibling'
        }
    },
    'preFilter': {
        'ATTR': function(_0x136d15) {
            return _0x136d15[0x1] = _0x136d15[0x1]['replace'](_0x191977, _0x410ece), _0x136d15[0x3] = (_0x136d15[0x3] || _0x136d15[0x4] || _0x136d15[0x5] || '')['replace'](_0x191977, _0x410ece), '~=' === _0x136d15[0x2] && (_0x136d15[0x3] = '\x20' + _0x136d15[0x3] + '\x20'), _0x136d15['slice'](0x0, 0x4);
        },
        'CHILD': function(_0x3bd927) {
            return _0x3bd927[0x1] = _0x3bd927[0x1]['toLowerCase'](), 'nth' === _0x3bd927[0x1]['slice'](0x0, 0x3) ? (_0x3bd927[0x3] || _0x2b2ab0['error'](_0x3bd927[0x0]), _0x3bd927[0x4] = +(_0x3bd927[0x4] ? _0x3bd927[0x5] + (_0x3bd927[0x6] || 0x1) : 0x2 * ('even' === _0x3bd927[0x3] || 'odd' === _0x3bd927[0x3])), _0x3bd927[0x5] = +(_0x3bd927[0x7] + _0x3bd927[0x8] || 'odd' === _0x3bd927[0x3])) : _0x3bd927[0x3] && _0x2b2ab0['error'](_0x3bd927[0x0]), _0x3bd927;
        },
        'PSEUDO': function(_0x324288) {
            var _0xd79c36, _0xcdb59 = !_0x324288[0x6] && _0x324288[0x2];
            return _0x4b1682['CHILD']['test'](_0x324288[0x0]) ? null : (_0x324288[0x3] ? _0x324288[0x2] = _0x324288[0x4] || _0x324288[0x5] || '' : _0xcdb59 && _0x20bbfe['test'](_0xcdb59) && (_0xd79c36 = _0x460255(_0xcdb59, !0x0)) && (_0xd79c36 = _0xcdb59['indexOf'](')', _0xcdb59['length'] - _0xd79c36) - _0xcdb59['length']) && (_0x324288[0x0] = _0x324288[0x0]['slice'](0x0, _0xd79c36), _0x324288[0x2] = _0xcdb59['slice'](0x0, _0xd79c36)), _0x324288['slice'](0x0, 0x3));
        }
    },
    'filter': {
        'TAG': function(_0x31eddb) {
            var _0x3a3c7b = _0x31eddb['replace'](_0x191977, _0x410ece)['toLowerCase']();
            return '*' === _0x31eddb ? function() {
                return !0x0;
            } : function(_0x426ff3) {
                return _0x426ff3['nodeName'] && _0x426ff3['nodeName']['toLowerCase']() === _0x3a3c7b;
            };
        },
        'CLASS': function(_0x5c8b51) {
            var _0x1be23f = _0x247771[_0x5c8b51 + '\x20'];
            return _0x1be23f || (_0x1be23f = RegExp('(^|[\x5cx20\x5ct\x5cr\x5cn\x5cf])' + _0x5c8b51 + '([\x5cx20\x5ct\x5cr\x5cn\x5cf]|$)')) && _0x247771(_0x5c8b51, function(_0x532217) {
                return _0x1be23f['test']('string' == typeof _0x532217['className'] && _0x532217['className'] || 'undefined' != typeof _0x532217['getAttribute'] && _0x532217['getAttribute']('class') || '');
            });
        },
        'ATTR': function(_0x2906aa, _0x432c3c, _0x5863ab) {
            return function(_0x137a21) {
                return _0x137a21 = _0x2b2ab0['attr'](_0x137a21, _0x2906aa), null == _0x137a21 ? '!=' === _0x432c3c : !_0x432c3c || (_0x137a21 += '', '=' === _0x432c3c ? _0x137a21 === _0x5863ab : '!=' === _0x432c3c ? _0x137a21 !== _0x5863ab : '^=' === _0x432c3c ? _0x5863ab && 0x0 === _0x137a21['indexOf'](_0x5863ab) : '*=' === _0x432c3c ? _0x5863ab && -0x1 < _0x137a21['indexOf'](_0x5863ab) : '$=' === _0x432c3c ? _0x5863ab && _0x137a21['slice'](-_0x5863ab['length']) === _0x5863ab : '~=' === _0x432c3c ? -0x1 < ('\x20' + _0x137a21['replace'](_0x58dd95, '\x20') + '\x20')['indexOf'](_0x5863ab) : '|=' === _0x432c3c && (_0x137a21 === _0x5863ab || _0x137a21['slice'](0x0, _0x5863ab['length'] + 0x1) === _0x5863ab + '-'));
            };
        },
        'CHILD': function(_0x1ae4f7, _0x949d3, _0x5dedbf, _0x30ac34, _0x49ca09) {
            var _0x4c38dc = 'nth' !== _0x1ae4f7['slice'](0x0, 0x3),
                _0x4250ae = 'last' !== _0x1ae4f7['slice'](-0x4),
                _0x13658a = 'of-type' === _0x949d3;
            return 0x1 === _0x30ac34 && 0x0 === _0x49ca09 ? function(_0x255735) {
                return !!_0x255735['parentNode'];
            } : function(_0x325b45, _0x425e13, _0x42046d) {
                var _0xb0a5aa, _0xfbbe52, _0x15d7d3, _0x3d1b56, _0x2ca14c, _0x18f5b6;
                _0x425e13 = _0x4c38dc !== _0x4250ae ? 'nextSibling' : 'previousSibling';
                var _0x543f7e = _0x325b45['parentNode'],
                    _0x19c91f = _0x13658a && _0x325b45['nodeName']['toLowerCase']();
                _0x42046d = !_0x42046d && !_0x13658a;
                var _0x33ef44 = !0x1;
                if (_0x543f7e) {
                    if (_0x4c38dc) {
                        for (; _0x425e13;) {
                            for (_0x3d1b56 = _0x325b45; _0x3d1b56 = _0x3d1b56[_0x425e13];)
                                if (_0x13658a ? _0x3d1b56['nodeName']['toLowerCase']() === _0x19c91f : 0x1 === _0x3d1b56['nodeType']) return !0x1;
                            _0x18f5b6 = _0x425e13 = 'only' === _0x1ae4f7 && !_0x18f5b6 && 'nextSibling';
                        }
                        return !0x0;
                    }
                    if (_0x18f5b6 = [_0x4250ae ? _0x543f7e['firstChild'] : _0x543f7e['lastChild']], _0x4250ae && _0x42046d) {
                        _0x3d1b56 = _0x543f7e, _0x15d7d3 = _0x3d1b56[_0x37e4cb] || (_0x3d1b56[_0x37e4cb] = {}), _0xfbbe52 = _0x15d7d3[_0x3d1b56['uniqueID']] || (_0x15d7d3[_0x3d1b56['uniqueID']] = {}), _0xb0a5aa = _0xfbbe52[_0x1ae4f7] || [], _0x33ef44 = (_0x2ca14c = _0xb0a5aa[0x0] === _0x5d12fc && _0xb0a5aa[0x1]) && _0xb0a5aa[0x2];
                        for (_0x3d1b56 = _0x2ca14c && _0x543f7e['childNodes'][_0x2ca14c]; _0x3d1b56 = ++_0x2ca14c && _0x3d1b56 && _0x3d1b56[_0x425e13] || (_0x33ef44 = _0x2ca14c = 0x0) || _0x18f5b6['pop']();)
                            if (0x1 === _0x3d1b56['nodeType'] && ++_0x33ef44 && _0x3d1b56 === _0x325b45) {
                                _0xfbbe52[_0x1ae4f7] = [_0x5d12fc, _0x2ca14c, _0x33ef44];
                                break;
                            }
                    } else {
                        if (_0x42046d && (_0x3d1b56 = _0x325b45, _0x15d7d3 = _0x3d1b56[_0x37e4cb] || (_0x3d1b56[_0x37e4cb] = {}), _0xfbbe52 = _0x15d7d3[_0x3d1b56['uniqueID']] || (_0x15d7d3[_0x3d1b56['uniqueID']] = {}), _0xb0a5aa = _0xfbbe52[_0x1ae4f7] || [], _0x2ca14c = _0xb0a5aa[0x0] === _0x5d12fc && _0xb0a5aa[0x1], _0x33ef44 = _0x2ca14c), !0x1 === _0x33ef44) {
                            for (;
                                (_0x3d1b56 = ++_0x2ca14c && _0x3d1b56 && _0x3d1b56[_0x425e13] || (_0x33ef44 = _0x2ca14c = 0x0) || _0x18f5b6['pop']()) && (!(_0x13658a ? _0x3d1b56['nodeName']['toLowerCase']() === _0x19c91f : 0x1 === _0x3d1b56['nodeType']) || !++_0x33ef44 || !(_0x42046d && (_0x15d7d3 = _0x3d1b56[_0x37e4cb] || (_0x3d1b56[_0x37e4cb] = {}), _0xfbbe52 = _0x15d7d3[_0x3d1b56['uniqueID']] || (_0x15d7d3[_0x3d1b56['uniqueID']] = {}), _0xfbbe52[_0x1ae4f7] = [_0x5d12fc, _0x33ef44]), _0x3d1b56 === _0x325b45)););
                        }
                    }
                    return _0x33ef44 -= _0x49ca09, _0x33ef44 === _0x30ac34 || 0x0 === _0x33ef44 % _0x30ac34 && 0x0 <= _0x33ef44 / _0x30ac34;
                }
            };
        },
        'PSEUDO': function(_0x7dac0c, _0x344d5e) {
            var _0x3a39b8, _0x2e62a2 = _0x132e4c['pseudos'][_0x7dac0c] || _0x132e4c['setFilters'][_0x7dac0c['toLowerCase']()] || _0x2b2ab0['error']('unsupported\x20pseudo:\x20' + _0x7dac0c);
            return _0x2e62a2[_0x37e4cb] ? _0x2e62a2(_0x344d5e) : 0x1 < _0x2e62a2['length'] ? (_0x3a39b8 = [_0x7dac0c, _0x7dac0c, '', _0x344d5e], _0x132e4c['setFilters']['hasOwnProperty'](_0x7dac0c['toLowerCase']()) ? _0x4f216c(function(_0x2c7794, _0x232c53) {
                for (var _0x4a5f09, _0x533f7f = _0x2e62a2(_0x2c7794, _0x344d5e), _0x123dc2 = _0x533f7f['length']; _0x123dc2--;) _0x4a5f09 = _0x50ecab(_0x2c7794, _0x533f7f[_0x123dc2]), _0x2c7794[_0x4a5f09] = !(_0x232c53[_0x4a5f09] = _0x533f7f[_0x123dc2]);
            }) : function(_0x1ec0a3) {
                return _0x2e62a2(_0x1ec0a3, 0x0, _0x3a39b8);
            }) : _0x2e62a2;
        }
    },
    'pseudos': {
        'not': _0x4f216c(function(_0x5cb012) {
            var _0x5b5ca2 = [],
                _0x98a1a1 = [],
                _0x4a3e53 = _0x589207(_0x5cb012['replace'](_0x136fb2, '$1'));
            return _0x4a3e53[_0x37e4cb] ? _0x4f216c(function(_0x5726b7, _0xb8993c, _0x37642a, _0x413aa0) {
                var _0x444a01;
                _0x37642a = _0x4a3e53(_0x5726b7, null, _0x413aa0, []);
                for (_0x413aa0 = _0x5726b7['length']; _0x413aa0--;)(_0x444a01 = _0x37642a[_0x413aa0]) && (_0x5726b7[_0x413aa0] = !(_0xb8993c[_0x413aa0] = _0x444a01));
            }) : function(_0x3d589b, _0x34ff36, _0xf94219) {
                return _0x5b5ca2[0x0] = _0x3d589b, _0x4a3e53(_0x5b5ca2, null, _0xf94219, _0x98a1a1), _0x5b5ca2[0x0] = null, !_0x98a1a1['pop']();
            };
        }),
        'has': _0x4f216c(function(_0x132c15) {
            return function(_0x51b832) {
                return 0x0 < _0x2b2ab0(_0x132c15, _0x51b832)['length'];
            };
        }),
        'contains': _0x4f216c(function(_0x223749) {
            return _0x223749 = _0x223749['replace'](_0x191977, _0x410ece),
                function(_0x1da512) {
                    return -0x1 < (_0x1da512['textContent'] || _0x1da512['innerText'] || _0x19b5e4(_0x1da512))['indexOf'](_0x223749);
                };
        }),
        'lang': _0x4f216c(function(_0x136eb5) {
            return _0x2730f1['test'](_0x136eb5 || '') || _0x2b2ab0['error']('unsupported\x20lang:\x20' + _0x136eb5), _0x136eb5 = _0x136eb5['replace'](_0x191977, _0x410ece)['toLowerCase'](),
                function(_0xead078) {
                    var _0x523f47;
                    do
                        if (_0x523f47 = _0x1d0f18 ? _0xead078['lang'] : _0xead078['getAttribute']('xml:lang') || _0xead078['getAttribute']('lang')) return _0x523f47 = _0x523f47['toLowerCase'](), _0x523f47 === _0x136eb5 || 0x0 === _0x523f47['indexOf'](_0x136eb5 + '-'); while ((_0xead078 = _0xead078['parentNode']) && 0x1 === _0xead078['nodeType']);
                    return !0x1;
                };
        }),
        'target': function(_0x38db57) {
            var _0x49b1b3 = _0x2d2f4e['location'] && _0x2d2f4e['location']['hash'];
            return _0x49b1b3 && _0x49b1b3['slice'](0x1) === _0x38db57['id'];
        },
        'root': function(_0x3e60f0) {
            return _0x3e60f0 === _0x50c008;
        },
        'focus': function(_0x4a8448) {
            return _0x4a8448 === _0x2c664f['activeElement'] && (!_0x2c664f['hasFocus'] || _0x2c664f['hasFocus']()) && !(!_0x4a8448['type'] && !_0x4a8448['href'] && !~_0x4a8448['tabIndex']);
        },
        'enabled': _0x1834b4(!0x1),
        'disabled': _0x1834b4(!0x0),
        'checked': function(_0x51b1a1) {
            var _0x5e8d1b = _0x51b1a1['nodeName']['toLowerCase']();
            return 'input' === _0x5e8d1b && !!_0x51b1a1['checked'] || 'option' === _0x5e8d1b && !!_0x51b1a1['selected'];
        },
        'selected': function(_0x3610e9) {
            return _0x3610e9['parentNode'] && _0x3610e9['parentNode']['selectedIndex'], !0x0 === _0x3610e9['selected'];
        },
        'empty': function(_0x347630) {
            for (_0x347630 = _0x347630['firstChild']; _0x347630; _0x347630 = _0x347630['nextSibling'])
                if (0x6 > _0x347630['nodeType']) return !0x1;
            return !0x0;
        },
        'parent': function(_0x1024dd) {
            return !_0x132e4c['pseudos']['empty'](_0x1024dd);
        },
        'header': function(_0x1ca6ec) {
            return _0x38d8be['test'](_0x1ca6ec['nodeName']);
        },
        'input': function(_0x477b34) {
            return _0x3e5628['test'](_0x477b34['nodeName']);
        },
        'button': function(_0x406a30) {
            var _0x4aa6a4 = _0x406a30['nodeName']['toLowerCase']();
            return 'input' === _0x4aa6a4 && 'button' === _0x406a30['type'] || 'button' === _0x4aa6a4;
        },
        'text': function(_0x12984e) {
            var _0x581860;
            return 'input' === _0x12984e['nodeName']['toLowerCase']() && 'text' === _0x12984e['type'] && (null == (_0x581860 = _0x12984e['getAttribute']('type')) || 'text' === _0x581860['toLowerCase']());
        },
        'first': _0x22721f(function() {
            return [0x0];
        }),
        'last': _0x22721f(function(_0x14d765, _0x3c86eb) {
            return [_0x3c86eb - 0x1];
        }),
        'eq': _0x22721f(function(_0x2cda2f, _0x4daa2c, _0x3ef261) {
            return [0x0 > _0x3ef261 ? _0x3ef261 + _0x4daa2c : _0x3ef261];
        }),
        'even': _0x22721f(function(_0x3460f3, _0x255b34) {
            for (var _0x523582 = 0x0; _0x523582 < _0x255b34; _0x523582 += 0x2) _0x3460f3['push'](_0x523582);
            return _0x3460f3;
        }),
        'odd': _0x22721f(function(_0x34917d, _0x143b20) {
            for (var _0xafb8ad = 0x1; _0xafb8ad < _0x143b20; _0xafb8ad += 0x2) _0x34917d['push'](_0xafb8ad);
            return _0x34917d;
        }),
        'lt': _0x22721f(function(_0x407615, _0x3a5774, _0x335360) {
            for (_0x3a5774 = 0x0 > _0x335360 ? _0x335360 + _0x3a5774 : _0x335360; 0x0 <= --_0x3a5774;) _0x407615['push'](_0x3a5774);
            return _0x407615;
        }),
        'gt': _0x22721f(function(_0x22f643, _0x713d83, _0x341a91) {
            for (_0x341a91 = 0x0 > _0x341a91 ? _0x341a91 + _0x713d83 : _0x341a91; ++_0x341a91 < _0x713d83;) _0x22f643['push'](_0x341a91);
            return _0x22f643;
        })
    }
}, _0x132e4c['pseudos']['nth'] = _0x132e4c['pseudos']['eq'];
for (_0x339742 in {
        'radio': !0x0,
        'checkbox': !0x0,
        'file': !0x0,
        'password': !0x0,
        'image': !0x0
    }) _0x132e4c['pseudos'][_0x339742] = _0x29aa88(_0x339742);
for (_0x339742 in {
        'submit': !0x0,
        'reset': !0x0
    }) _0x132e4c['pseudos'][_0x339742] = _0x30202c(_0x339742);
_0x21e11f['prototype'] = _0x132e4c['filters'] = _0x132e4c['pseudos'], _0x132e4c['setFilters'] = new _0x21e11f(), _0x460255 = _0x2b2ab0['tokenize'] = function(_0x461218, _0x306190) {
    var _0x3c4ea0, _0x4d56e5, _0x2a1946, _0x163402, _0x35f8aa, _0x18be95, _0x4f8bcd;
    if (_0x35f8aa = _0xb5baa0[_0x461218 + '\x20']) return _0x306190 ? 0x0 : _0x35f8aa['slice'](0x0);
    _0x35f8aa = _0x461218, _0x18be95 = [];
    for (_0x4f8bcd = _0x132e4c['preFilter']; _0x35f8aa;) {
        _0x3c4ea0 && !(_0x4d56e5 = _0x1635a1['exec'](_0x35f8aa)) || (_0x4d56e5 && (_0x35f8aa = _0x35f8aa['slice'](_0x4d56e5[0x0]['length']) || _0x35f8aa), _0x18be95['push'](_0x2a1946 = [])), _0x3c4ea0 = !0x1, (_0x4d56e5 = _0x38d550['exec'](_0x35f8aa)) && (_0x3c4ea0 = _0x4d56e5['shift'](), _0x2a1946['push']({
            'value': _0x3c4ea0,
            'type': _0x4d56e5[0x0]['replace'](_0x136fb2, '\x20')
        }), _0x35f8aa = _0x35f8aa['slice'](_0x3c4ea0['length']));
        for (_0x163402 in _0x132e4c['filter']) !(_0x4d56e5 = _0x4b1682[_0x163402]['exec'](_0x35f8aa)) || _0x4f8bcd[_0x163402] && !(_0x4d56e5 = _0x4f8bcd[_0x163402](_0x4d56e5)) || (_0x3c4ea0 = _0x4d56e5['shift'](), _0x2a1946['push']({
            'value': _0x3c4ea0,
            'type': _0x163402,
            'matches': _0x4d56e5
        }), _0x35f8aa = _0x35f8aa['slice'](_0x3c4ea0['length']));
        if (!_0x3c4ea0) break;
    }
    return _0x306190 ? _0x35f8aa['length'] : _0x35f8aa ? _0x2b2ab0['error'](_0x461218) : _0xb5baa0(_0x461218, _0x18be95)['slice'](0x0);
}, _0x37271c = (_0x589207 = _0x2b2ab0['compile'] = function(_0x2b84f2, _0x23509b) {
    var _0x3fdc0f, _0x1ea33d = [],
        _0x1fcefd = [],
        _0x3fed4d = _0x47a9e8[_0x2b84f2 + '\x20'];
    if (!_0x3fed4d) {
        _0x23509b || (_0x23509b = _0x460255(_0x2b84f2));
        for (_0x3fdc0f = _0x23509b['length']; _0x3fdc0f--;) _0x3fed4d = _0x4727a5(_0x23509b[_0x3fdc0f]), _0x3fed4d[_0x37e4cb] ? _0x1ea33d['push'](_0x3fed4d) : _0x1fcefd['push'](_0x3fed4d);
        _0x3fdc0f = _0x47a9e8;
        var _0x7257e7 = 0x0 < _0x1ea33d['length'],
            _0x439a2a = 0x0 < _0x1fcefd['length'],
            _0x3fed4d = function(_0x47bb77, _0x44a267, _0x288843, _0x17183b, _0x3d4eea) {
                var _0x33ada4, _0x5b6fac, _0x46536c, _0x46b5da = 0x0,
                    _0x1bc82a = '0',
                    _0x4b4c05 = _0x47bb77 && [],
                    _0x2e5448 = [],
                    _0x307b7c = _0x5dacbd,
                    _0x28a445 = _0x47bb77 || _0x439a2a && _0x132e4c['find']['TAG']('*', _0x3d4eea),
                    _0x480b54 = _0x5d12fc += null == _0x307b7c ? 0x1 : Math['random']() || 0.1,
                    _0x14ff06 = _0x28a445['length'];
                for (_0x3d4eea && (_0x5dacbd = _0x44a267 === _0x2c664f || _0x44a267 || _0x3d4eea); _0x1bc82a !== _0x14ff06 && null != (_0x33ada4 = _0x28a445[_0x1bc82a]); _0x1bc82a++) {
                    if (_0x439a2a && _0x33ada4) {
                        _0x5b6fac = 0x0;
                        for (_0x44a267 || _0x33ada4['ownerDocument'] === _0x2c664f || (_0x1789f1(_0x33ada4), _0x288843 = !_0x1d0f18); _0x46536c = _0x1fcefd[_0x5b6fac++];)
                            if (_0x46536c(_0x33ada4, _0x44a267 || _0x2c664f, _0x288843)) {
                                _0x17183b['push'](_0x33ada4);
                                break;
                            }
                        _0x3d4eea && (_0x5d12fc = _0x480b54);
                    }
                    _0x7257e7 && ((_0x33ada4 = !_0x46536c && _0x33ada4) && _0x46b5da--, _0x47bb77 && _0x4b4c05['push'](_0x33ada4));
                }
                if (_0x46b5da += _0x1bc82a, _0x7257e7 && _0x1bc82a !== _0x46b5da) {
                    for (_0x5b6fac = 0x0; _0x46536c = _0x1ea33d[_0x5b6fac++];) _0x46536c(_0x4b4c05, _0x2e5448, _0x44a267, _0x288843);
                    if (_0x47bb77) {
                        if (0x0 < _0x46b5da) {
                            for (; _0x1bc82a--;) _0x4b4c05[_0x1bc82a] || _0x2e5448[_0x1bc82a] || (_0x2e5448[_0x1bc82a] = _0x4d2e7e['call'](_0x17183b));
                        }
                        _0x2e5448 = _0x530420(_0x2e5448);
                    }
                    _0x2db992['apply'](_0x17183b, _0x2e5448), _0x3d4eea && !_0x47bb77 && 0x0 < _0x2e5448['length'] && 0x1 < _0x46b5da + _0x1ea33d['length'] && _0x2b2ab0['uniqueSort'](_0x17183b);
                }
                return _0x3d4eea && (_0x5d12fc = _0x480b54, _0x5dacbd = _0x307b7c), _0x4b4c05;
            },
            _0x3fed4d = _0x7257e7 ? _0x4f216c(_0x3fed4d) : _0x3fed4d,
            _0x3fed4d = _0x3fdc0f(_0x2b84f2, _0x3fed4d);
        _0x3fed4d['selector'] = _0x2b84f2;
    }
    return _0x3fed4d;
}, _0x15c49b = _0x2b2ab0['select'] = function(_0x1c4d57, _0x67e7db, _0x1c3c1c, _0x3f3fbd) {
    var _0x13e9e1, _0x37f7c4, _0x586819, _0x34fb8e, _0xb86041, _0x219924 = 'function' == typeof _0x1c4d57 && _0x1c4d57,
        _0x15b4dd = !_0x3f3fbd && _0x460255(_0x1c4d57 = _0x219924['selector'] || _0x1c4d57);
    if (_0x1c3c1c = _0x1c3c1c || [], 0x1 === _0x15b4dd['length']) {
        if (_0x37f7c4 = _0x15b4dd[0x0] = _0x15b4dd[0x0]['slice'](0x0), 0x2 < _0x37f7c4['length'] && 'ID' === (_0x586819 = _0x37f7c4[0x0])['type'] && 0x9 === _0x67e7db['nodeType'] && _0x1d0f18 && _0x132e4c['relative'][_0x37f7c4[0x1]['type']]) {
            if (_0x67e7db = (_0x132e4c['find']['ID'](_0x586819['matches'][0x0]['replace'](_0x191977, _0x410ece), _0x67e7db) || [])[0x0], !_0x67e7db) return _0x1c3c1c;
            _0x219924 && (_0x67e7db = _0x67e7db['parentNode']), _0x1c4d57 = _0x1c4d57['slice'](_0x37f7c4['shift']()['value']['length']);
        }
        for (_0x13e9e1 = _0x4b1682['needsContext']['test'](_0x1c4d57) ? 0x0 : _0x37f7c4['length']; _0x13e9e1-- && !(_0x586819 = _0x37f7c4[_0x13e9e1], _0x132e4c['relative'][_0x34fb8e = _0x586819['type']]);)
            if ((_0xb86041 = _0x132e4c['find'][_0x34fb8e]) && (_0x3f3fbd = _0xb86041(_0x586819['matches'][0x0]['replace'](_0x191977, _0x410ece), _0x455c20['test'](_0x37f7c4[0x0]['type']) && _0x2ee57c(_0x67e7db['parentNode']) || _0x67e7db))) {
                if (_0x37f7c4['splice'](_0x13e9e1, 0x1), _0x1c4d57 = _0x3f3fbd['length'] && _0x1d5a67(_0x37f7c4), !_0x1c4d57) return _0x2db992['apply'](_0x1c3c1c, _0x3f3fbd), _0x1c3c1c;
                break;
            }
    }
    return (_0x219924 || _0x589207(_0x1c4d57, _0x15b4dd))(_0x3f3fbd, _0x67e7db, !_0x1d0f18, _0x1c3c1c, !_0x67e7db || _0x455c20['test'](_0x1c4d57) && _0x2ee57c(_0x67e7db['parentNode']) || _0x67e7db), _0x1c3c1c;
}, _0xea81f6['sortStable'] = _0x37e4cb['split']('')['sort'](_0x39b5f7)['join']('') === _0x37e4cb, _0xea81f6['detectDuplicates'] = !!_0xf81cb8, _0x1789f1(), _0xea81f6['sortDetached'] = _0x5935eb(function(_0x971da1) {
    return 0x1 & _0x971da1['compareDocumentPosition'](_0x2c664f['createElement']('fieldset'));
}), _0x5935eb(function(_0x41b97a) {
    return _0x41b97a['innerHTML'] = '<a\x20href=\x27#\x27></a>', '#' === _0x41b97a['firstChild']['getAttribute']('href');
}) || _0x44ca03('type|href|height|width', function(_0x43c065, _0x5a110e, _0x5a948f) {
    if (!_0x5a948f) return _0x43c065['getAttribute'](_0x5a110e, 'type' === _0x5a110e['toLowerCase']() ? 0x1 : 0x2);
}), _0xea81f6['attributes'] && _0x5935eb(function(_0x13bd41) {
    return _0x13bd41['innerHTML'] = '<input/>', _0x13bd41['firstChild']['setAttribute']('value', ''), '' === _0x13bd41['firstChild']['getAttribute']('value');
}) || _0x44ca03('value', function(_0x34c97a, _0x5a4de4, _0x421bea) {
    if (!_0x421bea && 'input' === _0x34c97a['nodeName']['toLowerCase']()) return _0x34c97a['defaultValue'];
}), _0x5935eb(function(_0x50aabd) {
    return null == _0x50aabd['getAttribute']('disabled');
}) || _0x44ca03('checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped', function(_0x3153ce, _0x477397, _0x39f39f) {
    var _0x315798;
    if (!_0x39f39f) return !0x0 === _0x3153ce[_0x477397] ? _0x477397['toLowerCase']() : (_0x315798 = _0x3153ce['getAttributeNode'](_0x477397)) && _0x315798['specified'] ? _0x315798['value'] : null;
}), _0x2b2ab0), _0x4f2fd6['find'] = _0x37271c, _0x4f2fd6['expr'] = _0x37271c['selectors'], _0x4f2fd6['expr'][':'] = _0x4f2fd6['expr']['pseudos'], _0x4f2fd6['uniqueSort'] = _0x4f2fd6['unique'] = _0x37271c['uniqueSort'], _0x4f2fd6['text'] = _0x37271c['getText'], _0x4f2fd6['isXMLDoc'] = _0x37271c['isXML'], _0x4f2fd6['contains'] = _0x37271c['contains'], _0x4f2fd6['escapeSelector'] = _0x37271c['escape'];
var _0x26c24b = function(_0x5b0c1c, _0x4fef92, _0x5e90e5) {
        for (var _0x368984 = [], _0x43ec08 = void 0x0 !== _0x5e90e5;
            (_0x5b0c1c = _0x5b0c1c[_0x4fef92]) && 0x9 !== _0x5b0c1c['nodeType'];)
            if (0x1 === _0x5b0c1c['nodeType']) {
                if (_0x43ec08 && _0x4f2fd6(_0x5b0c1c)['is'](_0x5e90e5)) break;
                _0x368984['push'](_0x5b0c1c);
            }
        return _0x368984;
    },
    _0x14e073 = function(_0x10231a, _0x45aec8) {
        for (var _0x10c549 = []; _0x10231a; _0x10231a = _0x10231a['nextSibling']) 0x1 === _0x10231a['nodeType'] && _0x10231a !== _0x45aec8 && _0x10c549['push'](_0x10231a);
        return _0x10c549;
    },
    _0x2caf7b = _0x4f2fd6['expr']['match']['needsContext'],
    _0x11a67c = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i,
    _0x473693 = /^.[^:#\[\.,]*$/;
_0x4f2fd6['filter'] = function(_0x428087, _0x58c5af, _0x5a7fac) {
    var _0x35e291 = _0x58c5af[0x0];
    return _0x5a7fac && (_0x428087 = ':not(' + _0x428087 + ')'), 0x1 === _0x58c5af['length'] && 0x1 === _0x35e291['nodeType'] ? _0x4f2fd6['find']['matchesSelector'](_0x35e291, _0x428087) ? [_0x35e291] : [] : _0x4f2fd6['find']['matches'](_0x428087, _0x4f2fd6['grep'](_0x58c5af, function(_0x407c40) {
        return 0x1 === _0x407c40['nodeType'];
    }));
}, _0x4f2fd6['fn']['extend']({
    'find': function(_0x851315) {
        var _0x4e5da7, _0xe9ab0b, _0x205fda = this['length'],
            _0x19f914 = this;
        if ('string' != typeof _0x851315) return this['pushStack'](_0x4f2fd6(_0x851315)['filter'](function() {
            for (_0x4e5da7 = 0x0; _0x4e5da7 < _0x205fda; _0x4e5da7++)
                if (_0x4f2fd6['contains'](_0x19f914[_0x4e5da7], this)) return !0x0;
        }));
        _0xe9ab0b = this['pushStack']([]);
        for (_0x4e5da7 = 0x0; _0x4e5da7 < _0x205fda; _0x4e5da7++) _0x4f2fd6['find'](_0x851315, _0x19f914[_0x4e5da7], _0xe9ab0b);
        return 0x1 < _0x205fda ? _0x4f2fd6['uniqueSort'](_0xe9ab0b) : _0xe9ab0b;
    },
    'filter': function(_0x2b7cc7) {
        return this['pushStack'](_0x3e869d(this, _0x2b7cc7 || [], !0x1));
    },
    'not': function(_0x5f5dd9) {
        return this['pushStack'](_0x3e869d(this, _0x5f5dd9 || [], !0x0));
    },
    'is': function(_0x5936ca) {
        return !!_0x3e869d(this, 'string' == typeof _0x5936ca && _0x2caf7b['test'](_0x5936ca) ? _0x4f2fd6(_0x5936ca) : _0x5936ca || [], !0x1)['length'];
    }
});
var _0x260550, _0x427022 = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
(_0x4f2fd6['fn']['init'] = function(_0x29c6e3, _0x183213, _0x5e6e8e) {
    var _0x81ecea, _0x3009af;
    if (!_0x29c6e3) return this;
    if (_0x5e6e8e = _0x5e6e8e || _0x260550, 'string' == typeof _0x29c6e3) {
        if (_0x81ecea = '<' === _0x29c6e3[0x0] && '>' === _0x29c6e3[_0x29c6e3['length'] - 0x1] && 0x3 <= _0x29c6e3['length'] ? [null, _0x29c6e3, null] : _0x427022['exec'](_0x29c6e3), !_0x81ecea || !_0x81ecea[0x1] && _0x183213) return !_0x183213 || _0x183213['jquery'] ? (_0x183213 || _0x5e6e8e)['find'](_0x29c6e3) : this['constructor'](_0x183213)['find'](_0x29c6e3);
        if (_0x81ecea[0x1]) {
            if (_0x183213 = _0x183213 instanceof _0x4f2fd6 ? _0x183213[0x0] : _0x183213, _0x4f2fd6['merge'](this, _0x4f2fd6['parseHTML'](_0x81ecea[0x1], _0x183213 && _0x183213['nodeType'] ? _0x183213['ownerDocument'] || _0x183213 : _0x5892f6, !0x0)), _0x11a67c['test'](_0x81ecea[0x1]) && _0x4f2fd6['isPlainObject'](_0x183213)) {
                for (_0x81ecea in _0x183213) _0x4f2fd6['isFunction'](this[_0x81ecea]) ? this[_0x81ecea](_0x183213[_0x81ecea]) : this['attr'](_0x81ecea, _0x183213[_0x81ecea]);
            }
            return this;
        }
        return _0x3009af = _0x5892f6['getElementById'](_0x81ecea[0x2]), _0x3009af && (this[0x0] = _0x3009af, this['length'] = 0x1), this;
    }
    return _0x29c6e3['nodeType'] ? (this[0x0] = _0x29c6e3, this['length'] = 0x1, this) : _0x4f2fd6['isFunction'](_0x29c6e3) ? void 0x0 !== _0x5e6e8e['ready'] ? _0x5e6e8e['ready'](_0x29c6e3) : _0x29c6e3(_0x4f2fd6) : _0x4f2fd6['makeArray'](_0x29c6e3, this);
})['prototype'] = _0x4f2fd6['fn'], _0x260550 = _0x4f2fd6(_0x5892f6);
var _0x5054e7 = /^(?:parents|prev(?:Until|All))/,
    _0x3bcaf4 = {
        'children': !0x0,
        'contents': !0x0,
        'next': !0x0,
        'prev': !0x0
    };
_0x4f2fd6['fn']['extend']({
    'has': function(_0x33b3f9) {
        var _0x2d2813 = _0x4f2fd6(_0x33b3f9, this),
            _0x59ad3f = _0x2d2813['length'];
        return this['filter'](function() {
            for (var _0x51ae16 = 0x0; _0x51ae16 < _0x59ad3f; _0x51ae16++)
                if (_0x4f2fd6['contains'](this, _0x2d2813[_0x51ae16])) return !0x0;
        });
    },
    'closest': function(_0x59ce0c, _0x14eef8) {
        var _0x1311cb, _0x4c5c9a = 0x0,
            _0x546c35 = this['length'],
            _0x5d71a7 = [],
            _0x55c8cc = 'string' != typeof _0x59ce0c && _0x4f2fd6(_0x59ce0c);
        if (!_0x2caf7b['test'](_0x59ce0c)) {
            for (; _0x4c5c9a < _0x546c35; _0x4c5c9a++)
                for (_0x1311cb = this[_0x4c5c9a]; _0x1311cb && _0x1311cb !== _0x14eef8; _0x1311cb = _0x1311cb['parentNode'])
                    if (0xb > _0x1311cb['nodeType'] && (_0x55c8cc ? -0x1 < _0x55c8cc['index'](_0x1311cb) : 0x1 === _0x1311cb['nodeType'] && _0x4f2fd6['find']['matchesSelector'](_0x1311cb, _0x59ce0c))) {
                        _0x5d71a7['push'](_0x1311cb);
                        break;
                    }
        }
        return this['pushStack'](0x1 < _0x5d71a7['length'] ? _0x4f2fd6['uniqueSort'](_0x5d71a7) : _0x5d71a7);
    },
    'index': function(_0x111fb3) {
        return _0x111fb3 ? 'string' == typeof _0x111fb3 ? _0x20db99['call'](_0x4f2fd6(_0x111fb3), this[0x0]) : _0x20db99['call'](this, _0x111fb3['jquery'] ? _0x111fb3[0x0] : _0x111fb3) : this[0x0] && this[0x0]['parentNode'] ? this['first']()['prevAll']()['length'] : -0x1;
    },
    'add': function(_0x277a62, _0x59f05d) {
        return this['pushStack'](_0x4f2fd6['uniqueSort'](_0x4f2fd6['merge'](this['get'](), _0x4f2fd6(_0x277a62, _0x59f05d))));
    },
    'addBack': function(_0x207a18) {
        return this['add'](null == _0x207a18 ? this['prevObject'] : this['prevObject']['filter'](_0x207a18));
    }
}), _0x4f2fd6['each']({
    'parent': function(_0x3dd151) {
        return (_0x3dd151 = _0x3dd151['parentNode']) && 0xb !== _0x3dd151['nodeType'] ? _0x3dd151 : null;
    },
    'parents': function(_0x2a23b9) {
        return _0x26c24b(_0x2a23b9, 'parentNode');
    },
    'parentsUntil': function(_0x338816, _0x7f339d, _0x3afdc5) {
        return _0x26c24b(_0x338816, 'parentNode', _0x3afdc5);
    },
    'next': function(_0xc9751c) {
        return _0x5ea8be(_0xc9751c, 'nextSibling');
    },
    'prev': function(_0x138268) {
        return _0x5ea8be(_0x138268, 'previousSibling');
    },
    'nextAll': function(_0xa5bf3c) {
        return _0x26c24b(_0xa5bf3c, 'nextSibling');
    },
    'prevAll': function(_0x9dec24) {
        return _0x26c24b(_0x9dec24, 'previousSibling');
    },
    'nextUntil': function(_0x3776c7, _0x6887bc, _0x2d805f) {
        return _0x26c24b(_0x3776c7, 'nextSibling', _0x2d805f);
    },
    'prevUntil': function(_0x1b3eea, _0x22c58d, _0x965440) {
        return _0x26c24b(_0x1b3eea, 'previousSibling', _0x965440);
    },
    'siblings': function(_0x5d6da3) {
        return _0x14e073((_0x5d6da3['parentNode'] || {})['firstChild'], _0x5d6da3);
    },
    'children': function(_0x3ed0a2) {
        return _0x14e073(_0x3ed0a2['firstChild']);
    },
    'contents': function(_0x621b08) {
        return _0x443e90(_0x621b08, 'iframe') ? _0x621b08['contentDocument'] : (_0x443e90(_0x621b08, 'template') && (_0x621b08 = _0x621b08['content'] || _0x621b08), _0x4f2fd6['merge']([], _0x621b08['childNodes']));
    }
}, function(_0x4584eb, _0x1bc30e) {
    _0x4f2fd6['fn'][_0x4584eb] = function(_0x392787, _0x4c149c) {
        var _0x19e017 = _0x4f2fd6['map'](this, _0x1bc30e, _0x392787);
        return 'Until' !== _0x4584eb['slice'](-0x5) && (_0x4c149c = _0x392787), _0x4c149c && 'string' == typeof _0x4c149c && (_0x19e017 = _0x4f2fd6['filter'](_0x4c149c, _0x19e017)), 0x1 < this['length'] && (_0x3bcaf4[_0x4584eb] || _0x4f2fd6['uniqueSort'](_0x19e017), _0x5054e7['test'](_0x4584eb) && _0x19e017['reverse']()), this['pushStack'](_0x19e017);
    };
});
var _0x287fa1 = /[^\x20\t\r\n\f]+/g;
_0x4f2fd6['Callbacks'] = function(_0x2ed476) {
    var _0x53e358;
    if ('string' == typeof _0x2ed476) {
        var _0x200205 = {};
        _0x53e358 = (_0x4f2fd6['each'](_0x2ed476['match'](_0x287fa1) || [], function(_0x411f0f, _0x175593) {
            _0x200205[_0x175593] = !0x0;
        }), _0x200205);
    } else _0x53e358 = _0x4f2fd6['extend']({}, _0x2ed476);
    _0x2ed476 = _0x53e358;
    var _0x206ea8, _0x1f0ee0, _0x29147b, _0x5d1a0a, _0x3c0afa = [],
        _0x29ab8e = [],
        _0x3ccbfa = -0x1,
        _0x538a4b = function() {
            _0x5d1a0a = _0x5d1a0a || _0x2ed476['once'];
            for (_0x29147b = _0x206ea8 = !0x0; _0x29ab8e['length']; _0x3ccbfa = -0x1)
                for (_0x1f0ee0 = _0x29ab8e['shift'](); ++_0x3ccbfa < _0x3c0afa['length'];) !0x1 === _0x3c0afa[_0x3ccbfa]['apply'](_0x1f0ee0[0x0], _0x1f0ee0[0x1]) && _0x2ed476['stopOnFalse'] && (_0x3ccbfa = _0x3c0afa['length'], _0x1f0ee0 = !0x1);
            _0x2ed476['memory'] || (_0x1f0ee0 = !0x1), _0x206ea8 = !0x1, _0x5d1a0a && (_0x3c0afa = _0x1f0ee0 ? [] : '');
        },
        _0x16e87a = {
            'add': function() {
                return _0x3c0afa && (_0x1f0ee0 && !_0x206ea8 && (_0x3ccbfa = _0x3c0afa['length'] - 0x1, _0x29ab8e['push'](_0x1f0ee0)), function _0x4ef43d(_0x4971a3) {
                    _0x4f2fd6['each'](_0x4971a3, function(_0x50b042, _0x933c70) {
                        _0x4f2fd6['isFunction'](_0x933c70) ? _0x2ed476['unique'] && _0x16e87a['has'](_0x933c70) || _0x3c0afa['push'](_0x933c70) : _0x933c70 && _0x933c70['length'] && 'string' !== _0x4f2fd6['type'](_0x933c70) && _0x4ef43d(_0x933c70);
                    });
                }(arguments), _0x1f0ee0 && !_0x206ea8 && _0x538a4b()), this;
            },
            'remove': function() {
                return _0x4f2fd6['each'](arguments, function(_0x5bb7e8, _0x1b14f3) {
                    for (var _0x4e66f1; - 0x1 < (_0x4e66f1 = _0x4f2fd6['inArray'](_0x1b14f3, _0x3c0afa, _0x4e66f1));) _0x3c0afa['splice'](_0x4e66f1, 0x1), _0x4e66f1 <= _0x3ccbfa && _0x3ccbfa--;
                }), this;
            },
            'has': function(_0x56e502) {
                return _0x56e502 ? -0x1 < _0x4f2fd6['inArray'](_0x56e502, _0x3c0afa) : 0x0 < _0x3c0afa['length'];
            },
            'empty': function() {
                return _0x3c0afa && (_0x3c0afa = []), this;
            },
            'disable': function() {
                return _0x5d1a0a = _0x29ab8e = [], _0x3c0afa = _0x1f0ee0 = '', this;
            },
            'disabled': function() {
                return !_0x3c0afa;
            },
            'lock': function() {
                return _0x5d1a0a = _0x29ab8e = [], _0x1f0ee0 || _0x206ea8 || (_0x3c0afa = _0x1f0ee0 = ''), this;
            },
            'locked': function() {
                return !!_0x5d1a0a;
            },
            'fireWith': function(_0x46a3cc, _0x375691) {
                return _0x5d1a0a || (_0x375691 = _0x375691 || [], _0x375691 = [_0x46a3cc, _0x375691['slice'] ? _0x375691['slice']() : _0x375691], _0x29ab8e['push'](_0x375691), _0x206ea8 || _0x538a4b()), this;
            },
            'fire': function() {
                return _0x16e87a['fireWith'](this, arguments), this;
            },
            'fired': function() {
                return !!_0x29147b;
            }
        };
    return _0x16e87a;
}, _0x4f2fd6['extend']({
    'Deferred': function(_0x38e82d) {
        var _0x59829e = [
                ['notify', 'progress', _0x4f2fd6['Callbacks']('memory'), _0x4f2fd6['Callbacks']('memory'), 0x2],
                ['resolve', 'done', _0x4f2fd6['Callbacks']('once\x20memory'), _0x4f2fd6['Callbacks']('once\x20memory'), 0x0, 'resolved'],
                ['reject', 'fail', _0x4f2fd6['Callbacks']('once\x20memory'), _0x4f2fd6['Callbacks']('once\x20memory'), 0x1, 'rejected']
            ],
            _0x55f682 = 'pending',
            _0x525ced = {
                'state': function() {
                    return _0x55f682;
                },
                'always': function() {
                    return _0x3e313c['done'](arguments)['fail'](arguments), this;
                },
                'catch': function(_0x1d73dd) {
                    return _0x525ced['then'](null, _0x1d73dd);
                },
                'pipe': function() {
                    var _0x5ba8b0 = arguments;
                    return _0x4f2fd6['Deferred'](function(_0xc3bc84) {
                        _0x4f2fd6['each'](_0x59829e, function(_0x5cb45f, _0x155fcf) {
                            var _0x3ae1cf = _0x4f2fd6['isFunction'](_0x5ba8b0[_0x155fcf[0x4]]) && _0x5ba8b0[_0x155fcf[0x4]];
                            _0x3e313c[_0x155fcf[0x1]](function() {
                                var _0xb4adb2 = _0x3ae1cf && _0x3ae1cf['apply'](this, arguments);
                                _0xb4adb2 && _0x4f2fd6['isFunction'](_0xb4adb2['promise']) ? _0xb4adb2['promise']()['progress'](_0xc3bc84['notify'])['done'](_0xc3bc84['resolve'])['fail'](_0xc3bc84['reject']) : _0xc3bc84[_0x155fcf[0x0] + 'With'](this, _0x3ae1cf ? [_0xb4adb2] : arguments);
                            });
                        }), _0x5ba8b0 = null;
                    })['promise']();
                },
                'then': function(_0x233a51, _0x894b72, _0x5d5a06) {
                    function _0x3ba52a(_0x113622, _0x44cb6e, _0x4ec0ea, _0x5aeead) {
                        return function() {
                            var _0x16d480 = this,
                                _0x381363 = arguments,
                                _0x42fb02 = function() {
                                    var _0xd72efa, _0xb8d09a;
                                    if (!(_0x113622 < _0x3b2786)) {
                                        if (_0xd72efa = _0x4ec0ea['apply'](_0x16d480, _0x381363), _0xd72efa === _0x44cb6e['promise']()) throw new TypeError('Thenable\x20self-resolution');
                                        _0xb8d09a = _0xd72efa && ('object' == typeof _0xd72efa || 'function' == typeof _0xd72efa) && _0xd72efa['then'], _0x4f2fd6['isFunction'](_0xb8d09a) ? _0x5aeead ? _0xb8d09a['call'](_0xd72efa, _0x3ba52a(_0x3b2786, _0x44cb6e, _0x30458c, _0x5aeead), _0x3ba52a(_0x3b2786, _0x44cb6e, _0x1db34f, _0x5aeead)) : (_0x3b2786++, _0xb8d09a['call'](_0xd72efa, _0x3ba52a(_0x3b2786, _0x44cb6e, _0x30458c, _0x5aeead), _0x3ba52a(_0x3b2786, _0x44cb6e, _0x1db34f, _0x5aeead), _0x3ba52a(_0x3b2786, _0x44cb6e, _0x30458c, _0x44cb6e['notifyWith']))) : (_0x4ec0ea !== _0x30458c && (_0x16d480 = void 0x0, _0x381363 = [_0xd72efa]), (_0x5aeead || _0x44cb6e['resolveWith'])(_0x16d480, _0x381363));
                                    }
                                },
                                _0x3fa46f = _0x5aeead ? _0x42fb02 : function() {
                                    try {
                                        _0x42fb02();
                                    } catch (_0x245463) {
                                        _0x4f2fd6['Deferred']['exceptionHook'] && _0x4f2fd6['Deferred']['exceptionHook'](_0x245463, _0x3fa46f['stackTrace']), _0x113622 + 0x1 >= _0x3b2786 && (_0x4ec0ea !== _0x1db34f && (_0x16d480 = void 0x0, _0x381363 = [_0x245463]), _0x44cb6e['rejectWith'](_0x16d480, _0x381363));
                                    }
                                };
                            _0x113622 ? _0x3fa46f() : (_0x4f2fd6['Deferred']['getStackHook'] && (_0x3fa46f['stackTrace'] = _0x4f2fd6['Deferred']['getStackHook']()), _0x10a213['setTimeout'](_0x3fa46f));
                        };
                    }
                    var _0x3b2786 = 0x0;
                    return _0x4f2fd6['Deferred'](function(_0x533c9c) {
                        _0x59829e[0x0][0x3]['add'](_0x3ba52a(0x0, _0x533c9c, _0x4f2fd6['isFunction'](_0x5d5a06) ? _0x5d5a06 : _0x30458c, _0x533c9c['notifyWith'])), _0x59829e[0x1][0x3]['add'](_0x3ba52a(0x0, _0x533c9c, _0x4f2fd6['isFunction'](_0x233a51) ? _0x233a51 : _0x30458c)), _0x59829e[0x2][0x3]['add'](_0x3ba52a(0x0, _0x533c9c, _0x4f2fd6['isFunction'](_0x894b72) ? _0x894b72 : _0x1db34f));
                    })['promise']();
                },
                'promise': function(_0x3c6535) {
                    return null != _0x3c6535 ? _0x4f2fd6['extend'](_0x3c6535, _0x525ced) : _0x525ced;
                }
            },
            _0x3e313c = {};
        return _0x4f2fd6['each'](_0x59829e, function(_0x42bdae, _0x4284e2) {
            var _0x1ab01e = _0x4284e2[0x2],
                _0x5b0685 = _0x4284e2[0x5];
            _0x525ced[_0x4284e2[0x1]] = _0x1ab01e['add'], _0x5b0685 && _0x1ab01e['add'](function() {
                _0x55f682 = _0x5b0685;
            }, _0x59829e[0x3 - _0x42bdae][0x2]['disable'], _0x59829e[0x0][0x2]['lock']), _0x1ab01e['add'](_0x4284e2[0x3]['fire']), _0x3e313c[_0x4284e2[0x0]] = function() {
                return _0x3e313c[_0x4284e2[0x0] + 'With'](this === _0x3e313c ? void 0x0 : this, arguments), this;
            }, _0x3e313c[_0x4284e2[0x0] + 'With'] = _0x1ab01e['fireWith'];
        }), _0x525ced['promise'](_0x3e313c), _0x38e82d && _0x38e82d['call'](_0x3e313c, _0x3e313c), _0x3e313c;
    },
    'when': function(_0x56fb30) {
        var _0x59f6e6 = arguments['length'],
            _0x3c4af4 = _0x59f6e6,
            _0x494e10 = Array(_0x3c4af4),
            _0x1bf199 = _0x324811['call'](arguments),
            _0x3d7616 = _0x4f2fd6['Deferred'](),
            _0x5badcf = function(_0x3914d5) {
                return function(_0x9174e5) {
                    _0x494e10[_0x3914d5] = this, _0x1bf199[_0x3914d5] = 0x1 < arguments['length'] ? _0x324811['call'](arguments) : _0x9174e5, --_0x59f6e6 || _0x3d7616['resolveWith'](_0x494e10, _0x1bf199);
                };
            };
        if (0x1 >= _0x59f6e6 && (_0x2cb2bd(_0x56fb30, _0x3d7616['done'](_0x5badcf(_0x3c4af4))['resolve'], _0x3d7616['reject'], !_0x59f6e6), 'pending' === _0x3d7616['state']() || _0x4f2fd6['isFunction'](_0x1bf199[_0x3c4af4] && _0x1bf199[_0x3c4af4]['then']))) return _0x3d7616['then']();
        for (; _0x3c4af4--;) _0x2cb2bd(_0x1bf199[_0x3c4af4], _0x5badcf(_0x3c4af4), _0x3d7616['reject']);
        return _0x3d7616['promise']();
    }
});
var _0x330044 = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
_0x4f2fd6['Deferred']['exceptionHook'] = function(_0xd28143, _0xe8f4a6) {
    _0x10a213['console'] && _0x10a213['console']['warn'] && _0xd28143 && _0x330044['test'](_0xd28143['name']) && _0x10a213['console']['warn']('jQuery.Deferred\x20exception:\x20' + _0xd28143['message'], _0xd28143['stack'], _0xe8f4a6);
}, _0x4f2fd6['readyException'] = function(_0x361012) {
    _0x10a213['setTimeout'](function() {
        throw _0x361012;
    });
};
var _0x152fa8 = _0x4f2fd6['Deferred']();
_0x4f2fd6['fn']['ready'] = function(_0x265e35) {
    return _0x152fa8['then'](_0x265e35)['catch'](function(_0x50ff3a) {
        _0x4f2fd6['readyException'](_0x50ff3a);
    }), this;
}, _0x4f2fd6['extend']({
    'isReady': !0x1,
    'readyWait': 0x1,
    'ready': function(_0x1ac8b7) {
        (!0x0 === _0x1ac8b7 ? --_0x4f2fd6['readyWait'] : _0x4f2fd6['isReady']) || (_0x4f2fd6['isReady'] = !0x0, !0x0 !== _0x1ac8b7 && 0x0 < --_0x4f2fd6['readyWait'] || _0x152fa8['resolveWith'](_0x5892f6, [_0x4f2fd6]));
    }
}), _0x4f2fd6['ready']['then'] = _0x152fa8['then'], 'complete' === _0x5892f6['readyState'] || 'loading' !== _0x5892f6['readyState'] && !_0x5892f6['documentElement']['doScroll'] ? _0x10a213['setTimeout'](_0x4f2fd6['ready']) : (_0x5892f6['addEventListener']('DOMContentLoaded', _0x3898fd), _0x10a213['addEventListener']('load', _0x3898fd));
var _0x3e0938 = function(_0x5b5d07, _0x43eb71, _0x44bcbb, _0x3b327e, _0x4ee56f, _0x59702b, _0x5d2f00) {
        var _0x2314f0 = 0x0,
            _0x361fb1 = _0x5b5d07['length'],
            _0x5bd94b = null == _0x44bcbb;
        if ('object' === _0x4f2fd6['type'](_0x44bcbb)) {
            for (_0x2314f0 in (_0x4ee56f = !0x0, _0x44bcbb)) _0x3e0938(_0x5b5d07, _0x43eb71, _0x2314f0, _0x44bcbb[_0x2314f0], !0x0, _0x59702b, _0x5d2f00);
        } else {
            if (void 0x0 !== _0x3b327e && (_0x4ee56f = !0x0, _0x4f2fd6['isFunction'](_0x3b327e) || (_0x5d2f00 = !0x0), _0x5bd94b && (_0x5d2f00 ? (_0x43eb71['call'](_0x5b5d07, _0x3b327e), _0x43eb71 = null) : (_0x5bd94b = _0x43eb71, _0x43eb71 = function(_0x586047, _0x16d96e, _0x5a286f) {
                    return _0x5bd94b['call'](_0x4f2fd6(_0x586047), _0x5a286f);
                })), _0x43eb71)) {
                for (; _0x2314f0 < _0x361fb1; _0x2314f0++) _0x43eb71(_0x5b5d07[_0x2314f0], _0x44bcbb, _0x5d2f00 ? _0x3b327e : _0x3b327e['call'](_0x5b5d07[_0x2314f0], _0x2314f0, _0x43eb71(_0x5b5d07[_0x2314f0], _0x44bcbb)));
            }
        }
        return _0x4ee56f ? _0x5b5d07 : _0x5bd94b ? _0x43eb71['call'](_0x5b5d07) : _0x361fb1 ? _0x43eb71(_0x5b5d07[0x0], _0x44bcbb) : _0x59702b;
    },
    _0x384786 = function(_0x1fbc84) {
        return 0x1 === _0x1fbc84['nodeType'] || 0x9 === _0x1fbc84['nodeType'] || !+_0x1fbc84['nodeType'];
    };
_0x18ea0f['uid'] = 0x1, _0x18ea0f['prototype'] = {
    'cache': function(_0x218963) {
        var _0x42e78e = _0x218963[this['expando']];
        return _0x42e78e || (_0x42e78e = {}, _0x384786(_0x218963) && (_0x218963['nodeType'] ? _0x218963[this['expando']] = _0x42e78e : Object['defineProperty'](_0x218963, this['expando'], {
            'value': _0x42e78e,
            'configurable': !0x0
        }))), _0x42e78e;
    },
    'set': function(_0x5cb540, _0x42e75e, _0x473ac5) {
        var _0x1fc3a6;
        _0x5cb540 = this['cache'](_0x5cb540);
        if ('string' == typeof _0x42e75e) _0x5cb540[_0x4f2fd6['camelCase'](_0x42e75e)] = _0x473ac5;
        else {
            for (_0x1fc3a6 in _0x42e75e) _0x5cb540[_0x4f2fd6['camelCase'](_0x1fc3a6)] = _0x42e75e[_0x1fc3a6];
        }
        return _0x5cb540;
    },
    'get': function(_0x1ffffc, _0x24284f) {
        return void 0x0 === _0x24284f ? this['cache'](_0x1ffffc) : _0x1ffffc[this['expando']] && _0x1ffffc[this['expando']][_0x4f2fd6['camelCase'](_0x24284f)];
    },
    'access': function(_0x101eba, _0x4062be, _0x3a6426) {
        return void 0x0 === _0x4062be || _0x4062be && 'string' == typeof _0x4062be && void 0x0 === _0x3a6426 ? this['get'](_0x101eba, _0x4062be) : (this['set'](_0x101eba, _0x4062be, _0x3a6426), void 0x0 !== _0x3a6426 ? _0x3a6426 : _0x4062be);
    },
    'remove': function(_0x395557, _0x15e055) {
        var _0x23b0af, _0x2ed2db = _0x395557[this['expando']];
        if (void 0x0 !== _0x2ed2db) {
            if (void 0x0 !== _0x15e055) {
                Array['isArray'](_0x15e055) ? _0x15e055 = _0x15e055['map'](_0x4f2fd6['camelCase']) : (_0x15e055 = _0x4f2fd6['camelCase'](_0x15e055), _0x15e055 = _0x15e055 in _0x2ed2db ? [_0x15e055] : _0x15e055['match'](_0x287fa1) || []);
                for (_0x23b0af = _0x15e055['length']; _0x23b0af--;) delete _0x2ed2db[_0x15e055[_0x23b0af]];
            }(void 0x0 === _0x15e055 || _0x4f2fd6['isEmptyObject'](_0x2ed2db)) && (_0x395557['nodeType'] ? _0x395557[this['expando']] = void 0x0 : delete _0x395557[this['expando']]);
        }
    },
    'hasData': function(_0xdd879e) {
        return _0xdd879e = _0xdd879e[this['expando']], void 0x0 !== _0xdd879e && !_0x4f2fd6['isEmptyObject'](_0xdd879e);
    }
};
var _0x4f3277 = new _0x18ea0f(),
    _0xe80867 = new _0x18ea0f(),
    _0x4e5132 = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
    _0x4a19a8 = /[A-Z]/g;
_0x4f2fd6['extend']({
    'hasData': function(_0x263850) {
        return _0xe80867['hasData'](_0x263850) || _0x4f3277['hasData'](_0x263850);
    },
    'data': function(_0x1f3553, _0x1deec4, _0x5e76a9) {
        return _0xe80867['access'](_0x1f3553, _0x1deec4, _0x5e76a9);
    },
    'removeData': function(_0xd1839a, _0x188487) {
        _0xe80867['remove'](_0xd1839a, _0x188487);
    },
    '_data': function(_0x227fef, _0x4f85dc, _0x4e121d) {
        return _0x4f3277['access'](_0x227fef, _0x4f85dc, _0x4e121d);
    },
    '_removeData': function(_0x4bae9b, _0x2a2dbb) {
        _0x4f3277['remove'](_0x4bae9b, _0x2a2dbb);
    }
}), _0x4f2fd6['fn']['extend']({
    'data': function(_0x4c9627, _0x749c66) {
        var _0x47c4a7, _0x421780, _0x26e5db, _0x37be15 = this[0x0],
            _0x40bb64 = _0x37be15 && _0x37be15['attributes'];
        if (void 0x0 === _0x4c9627) {
            if (this['length'] && (_0x26e5db = _0xe80867['get'](_0x37be15), 0x1 === _0x37be15['nodeType'] && !_0x4f3277['get'](_0x37be15, 'hasDataAttrs'))) {
                for (_0x47c4a7 = _0x40bb64['length']; _0x47c4a7--;) _0x40bb64[_0x47c4a7] && (_0x421780 = _0x40bb64[_0x47c4a7]['name'], 0x0 === _0x421780['indexOf']('data-') && (_0x421780 = _0x4f2fd6['camelCase'](_0x421780['slice'](0x5)), _0x5b53a5(_0x37be15, _0x421780, _0x26e5db[_0x421780])));
                _0x4f3277['set'](_0x37be15, 'hasDataAttrs', !0x0);
            }
            return _0x26e5db;
        }
        return 'object' == typeof _0x4c9627 ? this['each'](function() {
            _0xe80867['set'](this, _0x4c9627);
        }) : _0x3e0938(this, function(_0x25712e) {
            var _0x52a323;
            if (_0x37be15 && void 0x0 === _0x25712e) {
                if ((_0x52a323 = _0xe80867['get'](_0x37be15, _0x4c9627), void 0x0 !== _0x52a323) || (_0x52a323 = _0x5b53a5(_0x37be15, _0x4c9627), void 0x0 !== _0x52a323)) return _0x52a323;
            } else this['each'](function() {
                _0xe80867['set'](this, _0x4c9627, _0x25712e);
            });
        }, null, _0x749c66, 0x1 < arguments['length'], null, !0x0);
    },
    'removeData': function(_0x210a86) {
        return this['each'](function() {
            _0xe80867['remove'](this, _0x210a86);
        });
    }
}), _0x4f2fd6['extend']({
    'queue': function(_0x28d064, _0x26bbbd, _0x8451f2) {
        var _0x3ba086;
        if (_0x28d064) return _0x26bbbd = (_0x26bbbd || 'fx') + 'queue', _0x3ba086 = _0x4f3277['get'](_0x28d064, _0x26bbbd), _0x8451f2 && (!_0x3ba086 || Array['isArray'](_0x8451f2) ? _0x3ba086 = _0x4f3277['access'](_0x28d064, _0x26bbbd, _0x4f2fd6['makeArray'](_0x8451f2)) : _0x3ba086['push'](_0x8451f2)), _0x3ba086 || [];
    },
    'dequeue': function(_0x19cbda, _0x1c953c) {
        _0x1c953c = _0x1c953c || 'fx';
        var _0x967092 = _0x4f2fd6['queue'](_0x19cbda, _0x1c953c),
            _0x2f87eb = _0x967092['length'],
            _0x59910f = _0x967092['shift'](),
            _0x5963dd = _0x4f2fd6['_queueHooks'](_0x19cbda, _0x1c953c),
            _0x550f78 = function() {
                _0x4f2fd6['dequeue'](_0x19cbda, _0x1c953c);
            };
        'inprogress' === _0x59910f && (_0x59910f = _0x967092['shift'](), _0x2f87eb--), _0x59910f && ('fx' === _0x1c953c && _0x967092['unshift']('inprogress'), delete _0x5963dd['stop'], _0x59910f['call'](_0x19cbda, _0x550f78, _0x5963dd)), !_0x2f87eb && _0x5963dd && _0x5963dd['empty']['fire']();
    },
    '_queueHooks': function(_0x31d615, _0x14e043) {
        var _0x31fc63 = _0x14e043 + 'queueHooks';
        return _0x4f3277['get'](_0x31d615, _0x31fc63) || _0x4f3277['access'](_0x31d615, _0x31fc63, {
            'empty': _0x4f2fd6['Callbacks']('once\x20memory')['add'](function() {
                _0x4f3277['remove'](_0x31d615, [_0x14e043 + 'queue', _0x31fc63]);
            })
        });
    }
}), _0x4f2fd6['fn']['extend']({
    'queue': function(_0x39a8bb, _0x2ed064) {
        var _0x366a96 = 0x2;
        return 'string' != typeof _0x39a8bb && (_0x2ed064 = _0x39a8bb, _0x39a8bb = 'fx', _0x366a96--), arguments['length'] < _0x366a96 ? _0x4f2fd6['queue'](this[0x0], _0x39a8bb) : void 0x0 === _0x2ed064 ? this : this['each'](function() {
            var _0x4d6264 = _0x4f2fd6['queue'](this, _0x39a8bb, _0x2ed064);
            _0x4f2fd6['_queueHooks'](this, _0x39a8bb), 'fx' === _0x39a8bb && 'inprogress' !== _0x4d6264[0x0] && _0x4f2fd6['dequeue'](this, _0x39a8bb);
        });
    },
    'dequeue': function(_0x2c057e) {
        return this['each'](function() {
            _0x4f2fd6['dequeue'](this, _0x2c057e);
        });
    },
    'clearQueue': function(_0xe55b21) {
        return this['queue'](_0xe55b21 || 'fx', []);
    },
    'promise': function(_0x571c51, _0x3bd31e) {
        var _0x4e6719, _0x43b438 = 0x1,
            _0x518f96 = _0x4f2fd6['Deferred'](),
            _0x1087b3 = this,
            _0x397b7a = this['length'],
            _0x3704da = function() {
                --_0x43b438 || _0x518f96['resolveWith'](_0x1087b3, [_0x1087b3]);
            };
        'string' != typeof _0x571c51 && (_0x3bd31e = _0x571c51, _0x571c51 = void 0x0);
        for (_0x571c51 = _0x571c51 || 'fx'; _0x397b7a--;)(_0x4e6719 = _0x4f3277['get'](_0x1087b3[_0x397b7a], _0x571c51 + 'queueHooks')) && _0x4e6719['empty'] && (_0x43b438++, _0x4e6719['empty']['add'](_0x3704da));
        return _0x3704da(), _0x518f96['promise'](_0x3bd31e);
    }
});
var _0x5d9cb3 = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/ ['source'],
    _0x31b6ba = RegExp('^(?:([+-])=|)(' + _0x5d9cb3 + ')([a-z%]*)$', 'i'),
    _0x46bbe7 = ['Top', 'Right', 'Bottom', 'Left'],
    _0x2e6304 = function(_0x206e31, _0x2d7875) {
        return _0x206e31 = _0x2d7875 || _0x206e31, 'none' === _0x206e31['style']['display'] || '' === _0x206e31['style']['display'] && _0x4f2fd6['contains'](_0x206e31['ownerDocument'], _0x206e31) && 'none' === _0x4f2fd6['css'](_0x206e31, 'display');
    },
    _0x9353f = function(_0x26e89a, _0x32a7d5, _0x4c9838, _0x1ed69b) {
        var _0x37361e, _0x2d1bc8 = {};
        for (_0x37361e in _0x32a7d5) _0x2d1bc8[_0x37361e] = _0x26e89a['style'][_0x37361e], _0x26e89a['style'][_0x37361e] = _0x32a7d5[_0x37361e];
        _0x4c9838 = _0x4c9838['apply'](_0x26e89a, _0x1ed69b || []);
        for (_0x37361e in _0x32a7d5) _0x26e89a['style'][_0x37361e] = _0x2d1bc8[_0x37361e];
        return _0x4c9838;
    },
    _0x4a5f2d = {};
_0x4f2fd6['fn']['extend']({
    'show': function() {
        return _0x36b097(this, !0x0);
    },
    'hide': function() {
        return _0x36b097(this);
    },
    'toggle': function(_0x4346de) {
        return 'boolean' == typeof _0x4346de ? _0x4346de ? this['show']() : this['hide']() : this['each'](function() {
            _0x2e6304(this) ? _0x4f2fd6(this)['show']() : _0x4f2fd6(this)['hide']();
        });
    }
});
var _0x502163 = /^(?:checkbox|radio)$/i,
    _0x4cde81 = /<([a-z][^\/\0>\x20\t\r\n\f]+)/i,
    _0x78aade = /^$|\/(?:java|ecma)script/i,
    _0x400845 = {
        'option': [0x1, '<select\x20multiple=\x27multiple\x27>', '</select>'],
        'thead': [0x1, '<table>', '</table>'],
        'col': [0x2, '<table><colgroup>', '</colgroup></table>'],
        'tr': [0x2, '<table><tbody>', '</tbody></table>'],
        'td': [0x3, '<table><tbody><tr>', '</tr></tbody></table>'],
        '_default': [0x0, '', '']
    };
_0x400845['optgroup'] = _0x400845['option'], _0x400845['tbody'] = _0x400845['tfoot'] = _0x400845['colgroup'] = _0x400845['caption'] = _0x400845['thead'], _0x400845['th'] = _0x400845['td'];
var _0x4317c1 = /<|&#?\w+;/,
    _0x4a7bd4 = _0x5892f6['createDocumentFragment']()['appendChild'](_0x5892f6['createElement']('div')),
    _0x5f39e0 = _0x5892f6['createElement']('input');
_0x5f39e0['setAttribute']('type', 'radio'), _0x5f39e0['setAttribute']('checked', 'checked'), _0x5f39e0['setAttribute']('name', 't'), _0x4a7bd4['appendChild'](_0x5f39e0), _0x395361['checkClone'] = _0x4a7bd4['cloneNode'](!0x0)['cloneNode'](!0x0)['lastChild']['checked'], _0x4a7bd4['innerHTML'] = '<textarea>x</textarea>', _0x395361['noCloneChecked'] = !!_0x4a7bd4['cloneNode'](!0x0)['lastChild']['defaultValue'], !0x0;
var _0x400e40 = _0x5892f6['documentElement'],
    _0x258efb = /^key/,
    _0x189031 = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
    _0x578a87 = /^([^.]*)(?:\.(.+)|)/;
_0x4f2fd6['event'] = {
    'global': {},
    'add': function(_0x49b849, _0x136d89, _0x4050f1, _0x131aac, _0x23fc7e) {
        var _0x3f1713, _0x560bdb, _0x1e313c, _0x545318, _0x335c8d, _0x930ee6, _0xb020a0, _0x123561, _0x312a5e, _0x3bc89e;
        if (_0x335c8d = _0x4f3277['get'](_0x49b849)) {
            _0x4050f1['handler'] && (_0x3f1713 = _0x4050f1, _0x4050f1 = _0x3f1713['handler'], _0x23fc7e = _0x3f1713['selector']), _0x23fc7e && _0x4f2fd6['find']['matchesSelector'](_0x400e40, _0x23fc7e), _0x4050f1['guid'] || (_0x4050f1['guid'] = _0x4f2fd6['guid']++), (_0x545318 = _0x335c8d['events']) || (_0x545318 = _0x335c8d['events'] = {}), (_0x560bdb = _0x335c8d['handle']) || (_0x560bdb = _0x335c8d['handle'] = function(_0x2ba582) {
                return 'undefined' != typeof _0x4f2fd6 && _0x4f2fd6['event']['triggered'] !== _0x2ba582['type'] ? _0x4f2fd6['event']['dispatch']['apply'](_0x49b849, arguments) : void 0x0;
            }), _0x136d89 = (_0x136d89 || '')['match'](_0x287fa1) || [''];
            for (_0x335c8d = _0x136d89['length']; _0x335c8d--;) _0x1e313c = _0x578a87['exec'](_0x136d89[_0x335c8d]) || [], _0x312a5e = _0x3bc89e = _0x1e313c[0x1], _0x1e313c = (_0x1e313c[0x2] || '')['split']('.')['sort'](), _0x312a5e && (_0xb020a0 = _0x4f2fd6['event']['special'][_0x312a5e] || {}, _0x312a5e = (_0x23fc7e ? _0xb020a0['delegateType'] : _0xb020a0['bindType']) || _0x312a5e, _0xb020a0 = _0x4f2fd6['event']['special'][_0x312a5e] || {}, _0x930ee6 = _0x4f2fd6['extend']({
                'type': _0x312a5e,
                'origType': _0x3bc89e,
                'data': _0x131aac,
                'handler': _0x4050f1,
                'guid': _0x4050f1['guid'],
                'selector': _0x23fc7e,
                'needsContext': _0x23fc7e && _0x4f2fd6['expr']['match']['needsContext']['test'](_0x23fc7e),
                'namespace': _0x1e313c['join']('.')
            }, _0x3f1713), (_0x123561 = _0x545318[_0x312a5e]) || (_0x123561 = _0x545318[_0x312a5e] = [], _0x123561['delegateCount'] = 0x0, _0xb020a0['setup'] && !0x1 !== _0xb020a0['setup']['call'](_0x49b849, _0x131aac, _0x1e313c, _0x560bdb) || _0x49b849['addEventListener'] && _0x49b849['addEventListener'](_0x312a5e, _0x560bdb)), _0xb020a0['add'] && (_0xb020a0['add']['call'](_0x49b849, _0x930ee6), _0x930ee6['handler']['guid'] || (_0x930ee6['handler']['guid'] = _0x4050f1['guid'])), _0x23fc7e ? _0x123561['splice'](_0x123561['delegateCount']++, 0x0, _0x930ee6) : _0x123561['push'](_0x930ee6), _0x4f2fd6['event']['global'][_0x312a5e] = !0x0);
        }
    },
    'remove': function(_0x162e7e, _0x59043a, _0x22e9a0, _0x1d6e9e, _0x124c52) {
        var _0x3f4739, _0x384525, _0x308c2f, _0x1a4ded, _0x20b6c7, _0x37daae, _0x3324d5, _0x262c55, _0x5d4ed1, _0x1bc954, _0x4e4abe, _0x5ec05 = _0x4f3277['hasData'](_0x162e7e) && _0x4f3277['get'](_0x162e7e);
        if (_0x5ec05 && (_0x1a4ded = _0x5ec05['events'])) {
            _0x59043a = (_0x59043a || '')['match'](_0x287fa1) || [''];
            for (_0x20b6c7 = _0x59043a['length']; _0x20b6c7--;)
                if (_0x308c2f = _0x578a87['exec'](_0x59043a[_0x20b6c7]) || [], _0x5d4ed1 = _0x4e4abe = _0x308c2f[0x1], _0x1bc954 = (_0x308c2f[0x2] || '')['split']('.')['sort'](), _0x5d4ed1) {
                    _0x3324d5 = _0x4f2fd6['event']['special'][_0x5d4ed1] || {}, _0x5d4ed1 = (_0x1d6e9e ? _0x3324d5['delegateType'] : _0x3324d5['bindType']) || _0x5d4ed1, _0x262c55 = _0x1a4ded[_0x5d4ed1] || [], _0x308c2f = _0x308c2f[0x2] && RegExp('(^|\x5c.)' + _0x1bc954['join']('\x5c.(?:.*\x5c.|)') + '(\x5c.|$)');
                    for (_0x384525 = _0x3f4739 = _0x262c55['length']; _0x3f4739--;) _0x37daae = _0x262c55[_0x3f4739], !_0x124c52 && _0x4e4abe !== _0x37daae['origType'] || _0x22e9a0 && _0x22e9a0['guid'] !== _0x37daae['guid'] || _0x308c2f && !_0x308c2f['test'](_0x37daae['namespace']) || _0x1d6e9e && _0x1d6e9e !== _0x37daae['selector'] && ('**' !== _0x1d6e9e || !_0x37daae['selector']) || (_0x262c55['splice'](_0x3f4739, 0x1), _0x37daae['selector'] && _0x262c55['delegateCount']--, _0x3324d5['remove'] && _0x3324d5['remove']['call'](_0x162e7e, _0x37daae));
                    _0x384525 && !_0x262c55['length'] && (_0x3324d5['teardown'] && !0x1 !== _0x3324d5['teardown']['call'](_0x162e7e, _0x1bc954, _0x5ec05['handle']) || _0x4f2fd6['removeEvent'](_0x162e7e, _0x5d4ed1, _0x5ec05['handle']), delete _0x1a4ded[_0x5d4ed1]);
                } else {
                    for (_0x5d4ed1 in _0x1a4ded) _0x4f2fd6['event']['remove'](_0x162e7e, _0x5d4ed1 + _0x59043a[_0x20b6c7], _0x22e9a0, _0x1d6e9e, !0x0);
                }
            _0x4f2fd6['isEmptyObject'](_0x1a4ded) && _0x4f3277['remove'](_0x162e7e, 'handle\x20events');
        }
    },
    'dispatch': function(_0x1aef42) {
        var _0x1e75f3 = _0x4f2fd6['event']['fix'](_0x1aef42),
            _0x40f2fe, _0x2b36af, _0x1282a4, _0x393efa, _0x49ce4b, _0x483ab0, _0x47442c = Array(arguments['length']);
        _0x2b36af = (_0x4f3277['get'](this, 'events') || {})[_0x1e75f3['type']] || [];
        var _0x7a29fb = _0x4f2fd6['event']['special'][_0x1e75f3['type']] || {};
        _0x47442c[0x0] = _0x1e75f3;
        for (_0x40f2fe = 0x1; _0x40f2fe < arguments['length']; _0x40f2fe++) _0x47442c[_0x40f2fe] = arguments[_0x40f2fe];
        if (_0x1e75f3['delegateTarget'] = this, !_0x7a29fb['preDispatch'] || !0x1 !== _0x7a29fb['preDispatch']['call'](this, _0x1e75f3)) {
            _0x483ab0 = _0x4f2fd6['event']['handlers']['call'](this, _0x1e75f3, _0x2b36af);
            for (_0x40f2fe = 0x0;
                (_0x393efa = _0x483ab0[_0x40f2fe++]) && !_0x1e75f3['isPropagationStopped']();) {
                _0x1e75f3['currentTarget'] = _0x393efa['elem'];
                for (_0x2b36af = 0x0;
                    (_0x49ce4b = _0x393efa['handlers'][_0x2b36af++]) && !_0x1e75f3['isImmediatePropagationStopped']();) _0x1e75f3['rnamespace'] && !_0x1e75f3['rnamespace']['test'](_0x49ce4b['namespace']) || (_0x1e75f3['handleObj'] = _0x49ce4b, _0x1e75f3['data'] = _0x49ce4b['data'], _0x1282a4 = ((_0x4f2fd6['event']['special'][_0x49ce4b['origType']] || {})['handle'] || _0x49ce4b['handler'])['apply'](_0x393efa['elem'], _0x47442c), void 0x0 !== _0x1282a4 && !0x1 === (_0x1e75f3['result'] = _0x1282a4) && (_0x1e75f3['preventDefault'](), _0x1e75f3['stopPropagation']()));
            }
            return _0x7a29fb['postDispatch'] && _0x7a29fb['postDispatch']['call'](this, _0x1e75f3), _0x1e75f3['result'];
        }
    },
    'handlers': function(_0x2a40e6, _0x3e09e6) {
        var _0x4ff643, _0x1eb19e, _0x13d32c, _0x13a721, _0x13a3df, _0x523e58 = [],
            _0x1b0ac1 = _0x3e09e6['delegateCount'],
            _0x48405b = _0x2a40e6['target'];
        if (_0x1b0ac1 && _0x48405b['nodeType'] && !('click' === _0x2a40e6['type'] && 0x1 <= _0x2a40e6['button'])) {
            for (; _0x48405b !== this; _0x48405b = _0x48405b['parentNode'] || this)
                if (0x1 === _0x48405b['nodeType'] && ('click' !== _0x2a40e6['type'] || !0x0 !== _0x48405b['disabled'])) {
                    _0x13a721 = [], _0x13a3df = {};
                    for (_0x4ff643 = 0x0; _0x4ff643 < _0x1b0ac1; _0x4ff643++) _0x1eb19e = _0x3e09e6[_0x4ff643], _0x13d32c = _0x1eb19e['selector'] + '\x20', void 0x0 === _0x13a3df[_0x13d32c] && (_0x13a3df[_0x13d32c] = _0x1eb19e['needsContext'] ? -0x1 < _0x4f2fd6(_0x13d32c, this)['index'](_0x48405b) : _0x4f2fd6['find'](_0x13d32c, this, null, [_0x48405b])['length']), _0x13a3df[_0x13d32c] && _0x13a721['push'](_0x1eb19e);
                    _0x13a721['length'] && _0x523e58['push']({
                        'elem': _0x48405b,
                        'handlers': _0x13a721
                    });
                }
        }
        return _0x48405b = this, _0x1b0ac1 < _0x3e09e6['length'] && _0x523e58['push']({
            'elem': _0x48405b,
            'handlers': _0x3e09e6['slice'](_0x1b0ac1)
        }), _0x523e58;
    },
    'addProp': function(_0x458a60, _0x3e163c) {
        Object['defineProperty'](_0x4f2fd6['Event']['prototype'], _0x458a60, {
            'enumerable': !0x0,
            'configurable': !0x0,
            'get': _0x4f2fd6['isFunction'](_0x3e163c) ? function() {
                if (this['originalEvent']) return _0x3e163c(this['originalEvent']);
            } : function() {
                if (this['originalEvent']) return this['originalEvent'][_0x458a60];
            },
            'set': function(_0x4db726) {
                Object['defineProperty'](this, _0x458a60, {
                    'enumerable': !0x0,
                    'configurable': !0x0,
                    'writable': !0x0,
                    'value': _0x4db726
                });
            }
        });
    },
    'fix': function(_0x49833b) {
        return _0x49833b[_0x4f2fd6['expando']] ? _0x49833b : new _0x4f2fd6['Event'](_0x49833b);
    },
    'special': {
        'load': {
            'noBubble': !0x0
        },
        'focus': {
            'trigger': function() {
                if (this !== _0x4b0a19() && this['focus']) return this['focus'](), !0x1;
            },
            'delegateType': 'focusin'
        },
        'blur': {
            'trigger': function() {
                if (this === _0x4b0a19() && this['blur']) return this['blur'](), !0x1;
            },
            'delegateType': 'focusout'
        },
        'click': {
            'trigger': function() {
                if ('checkbox' === this['type'] && this['click'] && _0x443e90(this, 'input')) return this['click'](), !0x1;
            },
            '_default': function(_0x4d7d76) {
                return _0x443e90(_0x4d7d76['target'], 'a');
            }
        },
        'beforeunload': {
            'postDispatch': function(_0x3aaa67) {
                void 0x0 !== _0x3aaa67['result'] && _0x3aaa67['originalEvent'] && (_0x3aaa67['originalEvent']['returnValue'] = _0x3aaa67['result']);
            }
        }
    }
}, _0x4f2fd6['removeEvent'] = function(_0x5ca5e7, _0x285fff, _0x32742a) {
    _0x5ca5e7['removeEventListener'] && _0x5ca5e7['removeEventListener'](_0x285fff, _0x32742a);
}, _0x4f2fd6['Event'] = function(_0x4dc12d, _0x494bb4) {
    return this instanceof _0x4f2fd6['Event'] ? (_0x4dc12d && _0x4dc12d['type'] ? (this['originalEvent'] = _0x4dc12d, this['type'] = _0x4dc12d['type'], this['isDefaultPrevented'] = _0x4dc12d['defaultPrevented'] || void 0x0 === _0x4dc12d['defaultPrevented'] && !0x1 === _0x4dc12d['returnValue'] ? _0x1f1868 : _0x4c6258, this['target'] = _0x4dc12d['target'] && 0x3 === _0x4dc12d['target']['nodeType'] ? _0x4dc12d['target']['parentNode'] : _0x4dc12d['target'], this['currentTarget'] = _0x4dc12d['currentTarget'], this['relatedTarget'] = _0x4dc12d['relatedTarget']) : this['type'] = _0x4dc12d, _0x494bb4 && _0x4f2fd6['extend'](this, _0x494bb4), this['timeStamp'] = _0x4dc12d && _0x4dc12d['timeStamp'] || _0x4f2fd6['now'](), void(this[_0x4f2fd6['expando']] = !0x0)) : new _0x4f2fd6['Event'](_0x4dc12d, _0x494bb4);
}, _0x4f2fd6['Event']['prototype'] = {
    'constructor': _0x4f2fd6['Event'],
    'isDefaultPrevented': _0x4c6258,
    'isPropagationStopped': _0x4c6258,
    'isImmediatePropagationStopped': _0x4c6258,
    'isSimulated': !0x1,
    'preventDefault': function() {
        var _0xbd7b3f = this['originalEvent'];
        this['isDefaultPrevented'] = _0x1f1868, _0xbd7b3f && !this['isSimulated'] && _0xbd7b3f['preventDefault']();
    },
    'stopPropagation': function() {
        var _0x256a26 = this['originalEvent'];
        this['isPropagationStopped'] = _0x1f1868, _0x256a26 && !this['isSimulated'] && _0x256a26['stopPropagation']();
    },
    'stopImmediatePropagation': function() {
        var _0x13d0c7 = this['originalEvent'];
        this['isImmediatePropagationStopped'] = _0x1f1868, _0x13d0c7 && !this['isSimulated'] && _0x13d0c7['stopImmediatePropagation'](), this['stopPropagation']();
    }
}, _0x4f2fd6['each']({
    'altKey': !0x0,
    'bubbles': !0x0,
    'cancelable': !0x0,
    'changedTouches': !0x0,
    'ctrlKey': !0x0,
    'detail': !0x0,
    'eventPhase': !0x0,
    'metaKey': !0x0,
    'pageX': !0x0,
    'pageY': !0x0,
    'shiftKey': !0x0,
    'view': !0x0,
    'char': !0x0,
    'charCode': !0x0,
    'key': !0x0,
    'keyCode': !0x0,
    'button': !0x0,
    'buttons': !0x0,
    'clientX': !0x0,
    'clientY': !0x0,
    'offsetX': !0x0,
    'offsetY': !0x0,
    'pointerId': !0x0,
    'pointerType': !0x0,
    'screenX': !0x0,
    'screenY': !0x0,
    'targetTouches': !0x0,
    'toElement': !0x0,
    'touches': !0x0,
    'which': function(_0x7c8499) {
        var _0x458ad9 = _0x7c8499['button'];
        return null == _0x7c8499['which'] && _0x258efb['test'](_0x7c8499['type']) ? null != _0x7c8499['charCode'] ? _0x7c8499['charCode'] : _0x7c8499['keyCode'] : !_0x7c8499['which'] && void 0x0 !== _0x458ad9 && _0x189031['test'](_0x7c8499['type']) ? 0x1 & _0x458ad9 ? 0x1 : 0x2 & _0x458ad9 ? 0x3 : 0x4 & _0x458ad9 ? 0x2 : 0x0 : _0x7c8499['which'];
    }
}, _0x4f2fd6['event']['addProp']), _0x4f2fd6['each']({
    'mouseenter': 'mouseover',
    'mouseleave': 'mouseout',
    'pointerenter': 'pointerover',
    'pointerleave': 'pointerout'
}, function(_0xd00771, _0x387152) {
    _0x4f2fd6['event']['special'][_0xd00771] = {
        'delegateType': _0x387152,
        'bindType': _0x387152,
        'handle': function(_0x173281) {
            var _0x5ddc6e, _0x24d033 = _0x173281['relatedTarget'],
                _0x4a7e80 = _0x173281['handleObj'];
            return _0x24d033 && (_0x24d033 === this || _0x4f2fd6['contains'](this, _0x24d033)) || (_0x173281['type'] = _0x4a7e80['origType'], _0x5ddc6e = _0x4a7e80['handler']['apply'](this, arguments), _0x173281['type'] = _0x387152), _0x5ddc6e;
        }
    };
}), _0x4f2fd6['fn']['extend']({
    'on': function(_0x2da563, _0x14fd69, _0x41de2f, _0x43820d) {
        return _0x575457(this, _0x2da563, _0x14fd69, _0x41de2f, _0x43820d);
    },
    'one': function(_0x45d713, _0x3d6a12, _0x12265f, _0x122b8c) {
        return _0x575457(this, _0x45d713, _0x3d6a12, _0x12265f, _0x122b8c, 0x1);
    },
    'off': function(_0x46a493, _0x3c07f7, _0x41923c) {
        var _0x119b34, _0x3b0aab;
        if (_0x46a493 && _0x46a493['preventDefault'] && _0x46a493['handleObj']) return _0x119b34 = _0x46a493['handleObj'], _0x4f2fd6(_0x46a493['delegateTarget'])['off'](_0x119b34['namespace'] ? _0x119b34['origType'] + '.' + _0x119b34['namespace'] : _0x119b34['origType'], _0x119b34['selector'], _0x119b34['handler']), this;
        if ('object' == typeof _0x46a493) {
            for (_0x3b0aab in _0x46a493) this['off'](_0x3b0aab, _0x3c07f7, _0x46a493[_0x3b0aab]);
            return this;
        }
        return !0x1 !== _0x3c07f7 && 'function' != typeof _0x3c07f7 || (_0x41923c = _0x3c07f7, _0x3c07f7 = void 0x0), !0x1 === _0x41923c && (_0x41923c = _0x4c6258), this['each'](function() {
            _0x4f2fd6['event']['remove'](this, _0x46a493, _0x41923c, _0x3c07f7);
        });
    }
});
var _0x2437b6 = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
    _0x4a635f = /<script|<style|<link/i,
    _0x186884 = /checked\s*(?:[^=]|=\s*.checked.)/i,
    _0x52deb1 = /^true\/(.*)/,
    _0x3d0bc7 = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
_0x4f2fd6['extend']({
    'htmlPrefilter': function(_0x45e14c) {
        return _0x45e14c['replace'](_0x2437b6, '<$1></$2>');
    },
    'clone': function(_0x425f27, _0x6e9da5, _0x54bf6b) {
        var _0x3051f9, _0x48a594, _0x483db2, _0x2f31f7, _0x5e3ed4 = _0x425f27['cloneNode'](!0x0),
            _0x38fa70 = _0x4f2fd6['contains'](_0x425f27['ownerDocument'], _0x425f27);
        if (!_0x395361['noCloneChecked'] && !(0x1 !== _0x425f27['nodeType'] && 0xb !== _0x425f27['nodeType'] || _0x4f2fd6['isXMLDoc'](_0x425f27))) {
            _0x2f31f7 = _0x9d4e4c(_0x5e3ed4), _0x483db2 = _0x9d4e4c(_0x425f27), _0x3051f9 = 0x0;
            for (_0x48a594 = _0x483db2['length']; _0x3051f9 < _0x48a594; _0x3051f9++) {
                var _0x7b408a = _0x483db2[_0x3051f9],
                    _0x3752e1 = _0x2f31f7[_0x3051f9],
                    _0x222c7b = _0x3752e1['nodeName']['toLowerCase']();
                'input' === _0x222c7b && _0x502163['test'](_0x7b408a['type']) ? _0x3752e1['checked'] = _0x7b408a['checked'] : 'input' !== _0x222c7b && 'textarea' !== _0x222c7b || (_0x3752e1['defaultValue'] = _0x7b408a['defaultValue']);
            }
        }
        if (_0x6e9da5) {
            if (_0x54bf6b) {
                _0x483db2 = _0x483db2 || _0x9d4e4c(_0x425f27), _0x2f31f7 = _0x2f31f7 || _0x9d4e4c(_0x5e3ed4), _0x3051f9 = 0x0;
                for (_0x48a594 = _0x483db2['length']; _0x3051f9 < _0x48a594; _0x3051f9++) _0x4c63bb(_0x483db2[_0x3051f9], _0x2f31f7[_0x3051f9]);
            } else _0x4c63bb(_0x425f27, _0x5e3ed4);
        }
        return _0x2f31f7 = _0x9d4e4c(_0x5e3ed4, 'script'), 0x0 < _0x2f31f7['length'] && _0x22c915(_0x2f31f7, !_0x38fa70 && _0x9d4e4c(_0x425f27, 'script')), _0x5e3ed4;
    },
    'cleanData': function(_0x24301d) {
        for (var _0x158787, _0x16d2db, _0x5f1ef5, _0x5202fa = _0x4f2fd6['event']['special'], _0x2ab2c3 = 0x0; void 0x0 !== (_0x16d2db = _0x24301d[_0x2ab2c3]); _0x2ab2c3++)
            if (_0x384786(_0x16d2db)) {
                if (_0x158787 = _0x16d2db[_0x4f3277['expando']]) {
                    if (_0x158787['events']) {
                        for (_0x5f1ef5 in _0x158787['events']) _0x5202fa[_0x5f1ef5] ? _0x4f2fd6['event']['remove'](_0x16d2db, _0x5f1ef5) : _0x4f2fd6['removeEvent'](_0x16d2db, _0x5f1ef5, _0x158787['handle']);
                    }
                    _0x16d2db[_0x4f3277['expando']] = void 0x0;
                }
                _0x16d2db[_0xe80867['expando']] && (_0x16d2db[_0xe80867['expando']] = void 0x0);
            }
    }
}), _0x4f2fd6['fn']['extend']({
    'detach': function(_0x2bc401) {
        return _0x50f85d(this, _0x2bc401, !0x0);
    },
    'remove': function(_0x1ee0b2) {
        return _0x50f85d(this, _0x1ee0b2);
    },
    'text': function(_0x10663d) {
        return _0x3e0938(this, function(_0x4ed0c3) {
            return void 0x0 === _0x4ed0c3 ? _0x4f2fd6['text'](this) : this['empty']()['each'](function() {
                0x1 !== this['nodeType'] && 0xb !== this['nodeType'] && 0x9 !== this['nodeType'] || (this['textContent'] = _0x4ed0c3);
            });
        }, null, _0x10663d, arguments['length']);
    },
    'append': function() {
        return _0x3b249b(this, arguments, function(_0x3e55c6) {
            (0x1 === this['nodeType'] || 0xb === this['nodeType'] || 0x9 === this['nodeType']) && _0x53606a(this, _0x3e55c6)['appendChild'](_0x3e55c6);
        });
    },
    'prepend': function() {
        return _0x3b249b(this, arguments, function(_0x265eb1) {
            if (0x1 === this['nodeType'] || 0xb === this['nodeType'] || 0x9 === this['nodeType']) {
                var _0x29a251 = _0x53606a(this, _0x265eb1);
                _0x29a251['insertBefore'](_0x265eb1, _0x29a251['firstChild']);
            }
        });
    },
    'before': function() {
        return _0x3b249b(this, arguments, function(_0x35eab3) {
            this['parentNode'] && this['parentNode']['insertBefore'](_0x35eab3, this);
        });
    },
    'after': function() {
        return _0x3b249b(this, arguments, function(_0x5d10c7) {
            this['parentNode'] && this['parentNode']['insertBefore'](_0x5d10c7, this['nextSibling']);
        });
    },
    'empty': function() {
        for (var _0x9f9ef8, _0x11fbe1 = 0x0; null != (_0x9f9ef8 = this[_0x11fbe1]); _0x11fbe1++) 0x1 === _0x9f9ef8['nodeType'] && (_0x4f2fd6['cleanData'](_0x9d4e4c(_0x9f9ef8, !0x1)), _0x9f9ef8['textContent'] = '');
        return this;
    },
    'clone': function(_0x5a8e75, _0x5bdbaf) {
        return _0x5a8e75 = null != _0x5a8e75 && _0x5a8e75, _0x5bdbaf = null == _0x5bdbaf ? _0x5a8e75 : _0x5bdbaf, this['map'](function() {
            return _0x4f2fd6['clone'](this, _0x5a8e75, _0x5bdbaf);
        });
    },
    'html': function(_0xf49cc4) {
        return _0x3e0938(this, function(_0x149f6d) {
            var _0x1352ac = this[0x0] || {},
                _0x1ce085 = 0x0,
                _0x5f2195 = this['length'];
            if (void 0x0 === _0x149f6d && 0x1 === _0x1352ac['nodeType']) return _0x1352ac['innerHTML'];
            if ('string' == typeof _0x149f6d && !_0x4a635f['test'](_0x149f6d) && !_0x400845[(_0x4cde81['exec'](_0x149f6d) || ['', ''])[0x1]['toLowerCase']()]) {
                _0x149f6d = _0x4f2fd6['htmlPrefilter'](_0x149f6d);
                try {
                    for (; _0x1ce085 < _0x5f2195; _0x1ce085++) _0x1352ac = this[_0x1ce085] || {}, 0x1 === _0x1352ac['nodeType'] && (_0x4f2fd6['cleanData'](_0x9d4e4c(_0x1352ac, !0x1)), _0x1352ac['innerHTML'] = _0x149f6d);
                    _0x1352ac = 0x0;
                } catch (_0x4db692) {}
            }
            _0x1352ac && this['empty']()['append'](_0x149f6d);
        }, null, _0xf49cc4, arguments['length']);
    },
    'replaceWith': function() {
        var _0x33b60b = [];
        return _0x3b249b(this, arguments, function(_0x4e3ba1) {
            var _0x472af5 = this['parentNode'];
            0x0 > _0x4f2fd6['inArray'](this, _0x33b60b) && (_0x4f2fd6['cleanData'](_0x9d4e4c(this)), _0x472af5 && _0x472af5['replaceChild'](_0x4e3ba1, this));
        }, _0x33b60b);
    }
}), _0x4f2fd6['each']({
    'appendTo': 'append',
    'prependTo': 'prepend',
    'insertBefore': 'before',
    'insertAfter': 'after',
    'replaceAll': 'replaceWith'
}, function(_0x33b96e, _0x2f435b) {
    _0x4f2fd6['fn'][_0x33b96e] = function(_0x2f4466) {
        for (var _0x2f318c = [], _0x3a0753 = _0x4f2fd6(_0x2f4466), _0x1340f5 = _0x3a0753['length'] - 0x1, _0x435603 = 0x0; _0x435603 <= _0x1340f5; _0x435603++) _0x2f4466 = _0x435603 === _0x1340f5 ? this : this['clone'](!0x0), _0x4f2fd6(_0x3a0753[_0x435603])[_0x2f435b](_0x2f4466), _0x58b69d['apply'](_0x2f318c, _0x2f4466['get']());
        return this['pushStack'](_0x2f318c);
    };
});
var _0x1fc029 = /^margin/,
    _0x5ab946 = RegExp('^(' + _0x5d9cb3 + ')(?!px)[a-z%]+$', 'i'),
    _0x3397eb = function(_0x2b9b3a) {
        var _0x2a7fc4 = _0x2b9b3a['ownerDocument']['defaultView'];
        return _0x2a7fc4 && _0x2a7fc4['opener'] || (_0x2a7fc4 = _0x10a213), _0x2a7fc4['getComputedStyle'](_0x2b9b3a);
    },
    _0x29806b = function() {
        if (_0x484a95) {
            _0x484a95['style']['cssText'] = 'box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%', _0x484a95['innerHTML'] = '', _0x400e40['appendChild'](_0x4da8d1);
            var _0x297f45 = _0x10a213['getComputedStyle'](_0x484a95);
            _0x47e5a2 = '1%' !== _0x297f45['top'], _0x5c2354 = '2px' === _0x297f45['marginLeft'], _0x3b787f = '4px' === _0x297f45['width'], _0x484a95['style']['marginRight'] = '50%', _0x21a7ea = '4px' === _0x297f45['marginRight'], _0x400e40['removeChild'](_0x4da8d1), _0x484a95 = null;
        }
    },
    _0x47e5a2, _0x3b787f, _0x21a7ea, _0x5c2354, _0x4da8d1 = _0x5892f6['createElement']('div'),
    _0x484a95 = _0x5892f6['createElement']('div');
_0x484a95['style'] && (_0x484a95['style']['backgroundClip'] = 'content-box', _0x484a95['cloneNode'](!0x0)['style']['backgroundClip'] = '', _0x395361['clearCloneStyle'] = 'content-box' === _0x484a95['style']['backgroundClip'], _0x4da8d1['style']['cssText'] = 'border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute', _0x4da8d1['appendChild'](_0x484a95), _0x4f2fd6['extend'](_0x395361, {
    'pixelPosition': function() {
        return _0x29806b(), _0x47e5a2;
    },
    'boxSizingReliable': function() {
        return _0x29806b(), _0x3b787f;
    },
    'pixelMarginRight': function() {
        return _0x29806b(), _0x21a7ea;
    },
    'reliableMarginLeft': function() {
        return _0x29806b(), _0x5c2354;
    }
})), !0x0;
var _0x270eff = /^(none|table(?!-c[ea]).+)/,
    _0x40a0c4 = /^--/,
    _0x1c56ec = {
        'position': 'absolute',
        'visibility': 'hidden',
        'display': 'block'
    },
    _0x4ffeec = {
        'letterSpacing': '0',
        'fontWeight': '400'
    },
    _0xc9d213 = ['Webkit', 'Moz', 'ms'],
    _0x278495 = _0x5892f6['createElement']('div')['style'];
_0x4f2fd6['extend']({
    'cssHooks': {
        'opacity': {
            'get': function(_0x31c69f, _0x480c7c) {
                if (_0x480c7c) {
                    var _0x276522 = _0x4572ba(_0x31c69f, 'opacity');
                    return '' === _0x276522 ? '1' : _0x276522;
                }
            }
        }
    },
    'cssNumber': {
        'animationIterationCount': !0x0,
        'columnCount': !0x0,
        'fillOpacity': !0x0,
        'flexGrow': !0x0,
        'flexShrink': !0x0,
        'fontWeight': !0x0,
        'lineHeight': !0x0,
        'opacity': !0x0,
        'order': !0x0,
        'orphans': !0x0,
        'widows': !0x0,
        'zIndex': !0x0,
        'zoom': !0x0
    },
    'cssProps': {
        'float': 'cssFloat'
    },
    'style': function(_0x5ac198, _0x2d39d0, _0x5ea6e0, _0x2d8ec0) {
        if (_0x5ac198 && 0x3 !== _0x5ac198['nodeType'] && 0x8 !== _0x5ac198['nodeType'] && _0x5ac198['style']) {
            var _0x52ae42, _0x17b8e0, _0x55da97, _0x2af124 = _0x4f2fd6['camelCase'](_0x2d39d0),
                _0x20d731 = _0x40a0c4['test'](_0x2d39d0),
                _0x2864d2 = _0x5ac198['style'];
            return _0x20d731 || (_0x2d39d0 = _0x400025(_0x2af124)), _0x55da97 = _0x4f2fd6['cssHooks'][_0x2d39d0] || _0x4f2fd6['cssHooks'][_0x2af124], void 0x0 === _0x5ea6e0 ? _0x55da97 && 'get' in _0x55da97 && void 0x0 !== (_0x52ae42 = _0x55da97['get'](_0x5ac198, !0x1, _0x2d8ec0)) ? _0x52ae42 : _0x2864d2[_0x2d39d0] : (_0x17b8e0 = typeof _0x5ea6e0, 'string' === _0x17b8e0 && (_0x52ae42 = _0x31b6ba['exec'](_0x5ea6e0)) && _0x52ae42[0x1] && (_0x5ea6e0 = _0x183b49(_0x5ac198, _0x2d39d0, _0x52ae42), _0x17b8e0 = 'number'), null != _0x5ea6e0 && _0x5ea6e0 === _0x5ea6e0 && ('number' === _0x17b8e0 && (_0x5ea6e0 += _0x52ae42 && _0x52ae42[0x3] || (_0x4f2fd6['cssNumber'][_0x2af124] ? '' : 'px')), _0x395361['clearCloneStyle'] || '' !== _0x5ea6e0 || 0x0 !== _0x2d39d0['indexOf']('background') || (_0x2864d2[_0x2d39d0] = 'inherit'), _0x55da97 && 'set' in _0x55da97 && void 0x0 === (_0x5ea6e0 = _0x55da97['set'](_0x5ac198, _0x5ea6e0, _0x2d8ec0)) || (_0x20d731 ? _0x2864d2['setProperty'](_0x2d39d0, _0x5ea6e0) : _0x2864d2[_0x2d39d0] = _0x5ea6e0)), void 0x0);
        }
    },
    'css': function(_0x11b9c5, _0x415013, _0x16c538, _0x43e07a) {
        var _0x566595, _0x857c95, _0x24e342, _0x2141d3 = _0x4f2fd6['camelCase'](_0x415013);
        return _0x40a0c4['test'](_0x415013) || (_0x415013 = _0x400025(_0x2141d3)), _0x24e342 = _0x4f2fd6['cssHooks'][_0x415013] || _0x4f2fd6['cssHooks'][_0x2141d3], _0x24e342 && 'get' in _0x24e342 && (_0x566595 = _0x24e342['get'](_0x11b9c5, !0x0, _0x16c538)), void 0x0 === _0x566595 && (_0x566595 = _0x4572ba(_0x11b9c5, _0x415013, _0x43e07a)), 'normal' === _0x566595 && _0x415013 in _0x4ffeec && (_0x566595 = _0x4ffeec[_0x415013]), '' === _0x16c538 || _0x16c538 ? (_0x857c95 = parseFloat(_0x566595), !0x0 === _0x16c538 || isFinite(_0x857c95) ? _0x857c95 || 0x0 : _0x566595) : _0x566595;
    }
}), _0x4f2fd6['each'](['height', 'width'], function(_0x49a341, _0x4a5d64) {
    _0x4f2fd6['cssHooks'][_0x4a5d64] = {
        'get': function(_0x1eaaf1, _0x3f4985, _0x2b1974) {
            if (_0x3f4985) return !_0x270eff['test'](_0x4f2fd6['css'](_0x1eaaf1, 'display')) || _0x1eaaf1['getClientRects']()['length'] && _0x1eaaf1['getBoundingClientRect']()['width'] ? _0x661927(_0x1eaaf1, _0x4a5d64, _0x2b1974) : _0x9353f(_0x1eaaf1, _0x1c56ec, function() {
                return _0x661927(_0x1eaaf1, _0x4a5d64, _0x2b1974);
            });
        },
        'set': function(_0x4d61a9, _0x175498, _0x1c0501) {
            var _0x24ced6, _0x154ef9 = _0x1c0501 && _0x3397eb(_0x4d61a9);
            return _0x1c0501 = _0x1c0501 && _0x548192(_0x4d61a9, _0x4a5d64, _0x1c0501, 'border-box' === _0x4f2fd6['css'](_0x4d61a9, 'boxSizing', !0x1, _0x154ef9), _0x154ef9), (_0x1c0501 && (_0x24ced6 = _0x31b6ba['exec'](_0x175498)) && 'px' !== (_0x24ced6[0x3] || 'px') && (_0x4d61a9['style'][_0x4a5d64] = _0x175498, _0x175498 = _0x4f2fd6['css'](_0x4d61a9, _0x4a5d64)), _0x22e22f(_0x4d61a9, _0x175498, _0x1c0501));
        }
    };
}), _0x4f2fd6['cssHooks']['marginLeft'] = _0x3415d0(_0x395361['reliableMarginLeft'], function(_0x3dc97a, _0x3e64e1) {
    if (_0x3e64e1) return (parseFloat(_0x4572ba(_0x3dc97a, 'marginLeft')) || _0x3dc97a['getBoundingClientRect']()['left'] - _0x9353f(_0x3dc97a, {
        'marginLeft': 0x0
    }, function() {
        return _0x3dc97a['getBoundingClientRect']()['left'];
    })) + 'px';
}), _0x4f2fd6['each']({
    'margin': '',
    'padding': '',
    'border': 'Width'
}, function(_0x2e65bf, _0x413547) {
    _0x4f2fd6['cssHooks'][_0x2e65bf + _0x413547] = {
        'expand': function(_0x115b3e) {
            var _0x26580e = 0x0,
                _0x497fd8 = {};
            for (_0x115b3e = 'string' == typeof _0x115b3e ? _0x115b3e['split']('\x20') : [_0x115b3e]; 0x4 > _0x26580e; _0x26580e++) _0x497fd8[_0x2e65bf + _0x46bbe7[_0x26580e] + _0x413547] = _0x115b3e[_0x26580e] || _0x115b3e[_0x26580e - 0x2] || _0x115b3e[0x0];
            return _0x497fd8;
        }
    }, _0x1fc029['test'](_0x2e65bf) || (_0x4f2fd6['cssHooks'][_0x2e65bf + _0x413547]['set'] = _0x22e22f);
}), _0x4f2fd6['fn']['extend']({
    'css': function(_0x4a7043, _0x4b09db) {
        return _0x3e0938(this, function(_0xc9e54a, _0x134d02, _0x2fb2e8) {
            var _0x5ec489, _0x806894 = {},
                _0x45791a = 0x0;
            if (Array['isArray'](_0x134d02)) {
                _0x2fb2e8 = _0x3397eb(_0xc9e54a);
                for (_0x5ec489 = _0x134d02['length']; _0x45791a < _0x5ec489; _0x45791a++) _0x806894[_0x134d02[_0x45791a]] = _0x4f2fd6['css'](_0xc9e54a, _0x134d02[_0x45791a], !0x1, _0x2fb2e8);
                return _0x806894;
            }
            return void 0x0 !== _0x2fb2e8 ? _0x4f2fd6['style'](_0xc9e54a, _0x134d02, _0x2fb2e8) : _0x4f2fd6['css'](_0xc9e54a, _0x134d02);
        }, _0x4a7043, _0x4b09db, 0x1 < arguments['length']);
    }
}), _0x4f2fd6['Tween'] = _0x84d2fb, _0x84d2fb['prototype'] = {
    'constructor': _0x84d2fb,
    'init': function(_0x5aef13, _0x556614, _0x1675bc, _0x18b070, _0x52645a, _0x15143b) {
        this['elem'] = _0x5aef13, this['prop'] = _0x1675bc, this['easing'] = _0x52645a || _0x4f2fd6['easing']['_default'], this['options'] = _0x556614, this['start'] = this['now'] = this['cur'](), this['end'] = _0x18b070, this['unit'] = _0x15143b || (_0x4f2fd6['cssNumber'][_0x1675bc] ? '' : 'px');
    },
    'cur': function() {
        var _0x3ee3c4 = _0x84d2fb['propHooks'][this['prop']];
        return _0x3ee3c4 && _0x3ee3c4['get'] ? _0x3ee3c4['get'](this) : _0x84d2fb['propHooks']['_default']['get'](this);
    },
    'run': function(_0x20ca72) {
        var _0x3a60b6, _0x520564 = _0x84d2fb['propHooks'][this['prop']];
        return this['options']['duration'] ? this['pos'] = _0x3a60b6 = _0x4f2fd6['easing'][this['easing']](_0x20ca72, this['options']['duration'] * _0x20ca72, 0x0, 0x1, this['options']['duration']) : this['pos'] = _0x3a60b6 = _0x20ca72, this['now'] = (this['end'] - this['start']) * _0x3a60b6 + this['start'], this['options']['step'] && this['options']['step']['call'](this['elem'], this['now'], this), _0x520564 && _0x520564['set'] ? _0x520564['set'](this) : _0x84d2fb['propHooks']['_default']['set'](this), this;
    }
}, _0x84d2fb['prototype']['init']['prototype'] = _0x84d2fb['prototype'], _0x84d2fb['propHooks'] = {
    '_default': {
        'get': function(_0x2cccc3) {
            var _0x23d4d1;
            return 0x1 !== _0x2cccc3['elem']['nodeType'] || null != _0x2cccc3['elem'][_0x2cccc3['prop']] && null == _0x2cccc3['elem']['style'][_0x2cccc3['prop']] ? _0x2cccc3['elem'][_0x2cccc3['prop']] : (_0x23d4d1 = _0x4f2fd6['css'](_0x2cccc3['elem'], _0x2cccc3['prop'], ''), _0x23d4d1 && 'auto' !== _0x23d4d1 ? _0x23d4d1 : 0x0);
        },
        'set': function(_0x49b527) {
            _0x4f2fd6['fx']['step'][_0x49b527['prop']] ? _0x4f2fd6['fx']['step'][_0x49b527['prop']](_0x49b527) : 0x1 !== _0x49b527['elem']['nodeType'] || null == _0x49b527['elem']['style'][_0x4f2fd6['cssProps'][_0x49b527['prop']]] && !_0x4f2fd6['cssHooks'][_0x49b527['prop']] ? _0x49b527['elem'][_0x49b527['prop']] = _0x49b527['now'] : _0x4f2fd6['style'](_0x49b527['elem'], _0x49b527['prop'], _0x49b527['now'] + _0x49b527['unit']);
        }
    }
}, _0x84d2fb['propHooks']['scrollTop'] = _0x84d2fb['propHooks']['scrollLeft'] = {
    'set': function(_0x5225b8) {
        _0x5225b8['elem']['nodeType'] && _0x5225b8['elem']['parentNode'] && (_0x5225b8['elem'][_0x5225b8['prop']] = _0x5225b8['now']);
    }
}, _0x4f2fd6['easing'] = {
    'linear': function(_0x16b37c) {
        return _0x16b37c;
    },
    'swing': function(_0x40aa55) {
        return 0.5 - Math['cos'](_0x40aa55 * Math['PI']) / 0x2;
    },
    '_default': 'swing'
}, _0x4f2fd6['fx'] = _0x84d2fb['prototype']['init'], _0x4f2fd6['fx']['step'] = {};
var _0x50a4d5, _0xaaee55, _0x3d36f0 = /^(?:toggle|show|hide)$/,
    _0x36fe54 = /queueHooks$/;
_0x4f2fd6['Animation'] = _0x4f2fd6['extend'](_0x12fd14, {
    'tweeners': {
        '*': [function(_0x5cc15, _0x419af2) {
            var _0x52eb88 = this['createTween'](_0x5cc15, _0x419af2);
            return _0x183b49(_0x52eb88['elem'], _0x5cc15, _0x31b6ba['exec'](_0x419af2), _0x52eb88), _0x52eb88;
        }]
    },
    'tweener': function(_0x184d82, _0x2b3714) {
        _0x4f2fd6['isFunction'](_0x184d82) ? (_0x2b3714 = _0x184d82, _0x184d82 = ['*']) : _0x184d82 = _0x184d82['match'](_0x287fa1);
        for (var _0x4ba283, _0x3ecddb = 0x0, _0x1031c9 = _0x184d82['length']; _0x3ecddb < _0x1031c9; _0x3ecddb++) _0x4ba283 = _0x184d82[_0x3ecddb], _0x12fd14['tweeners'][_0x4ba283] = _0x12fd14['tweeners'][_0x4ba283] || [], _0x12fd14['tweeners'][_0x4ba283]['unshift'](_0x2b3714);
    },
    'prefilters': [function(_0x2e7a97, _0x5bc637, _0x1cc0ce) {
        var _0xf32295, _0x1e162a, _0x4e7ba8, _0x3585cd, _0x1bb676, _0x2aaa40, _0x584cdf, _0x451597, _0x541f0b = 'width' in _0x5bc637 || 'height' in _0x5bc637,
            _0x28e61c = this,
            _0x5e19ec = {},
            _0x4f1573 = _0x2e7a97['style'],
            _0x56d565 = _0x2e7a97['nodeType'] && _0x2e6304(_0x2e7a97),
            _0x235068 = _0x4f3277['get'](_0x2e7a97, 'fxshow');
        _0x1cc0ce['queue'] || (_0x3585cd = _0x4f2fd6['_queueHooks'](_0x2e7a97, 'fx'), null == _0x3585cd['unqueued'] && (_0x3585cd['unqueued'] = 0x0, _0x1bb676 = _0x3585cd['empty']['fire'], _0x3585cd['empty']['fire'] = function() {
            _0x3585cd['unqueued'] || _0x1bb676();
        }), _0x3585cd['unqueued']++, _0x28e61c['always'](function() {
            _0x28e61c['always'](function() {
                _0x3585cd['unqueued']--, _0x4f2fd6['queue'](_0x2e7a97, 'fx')['length'] || _0x3585cd['empty']['fire']();
            });
        }));
        for (_0xf32295 in _0x5bc637)
            if (_0x1e162a = _0x5bc637[_0xf32295], _0x3d36f0['test'](_0x1e162a)) {
                if (delete _0x5bc637[_0xf32295], _0x4e7ba8 = _0x4e7ba8 || 'toggle' === _0x1e162a, _0x1e162a === (_0x56d565 ? 'hide' : 'show')) {
                    if ('show' !== _0x1e162a || !_0x235068 || void 0x0 === _0x235068[_0xf32295]) continue;
                    _0x56d565 = !0x0;
                }
                _0x5e19ec[_0xf32295] = _0x235068 && _0x235068[_0xf32295] || _0x4f2fd6['style'](_0x2e7a97, _0xf32295);
            }
        if (_0x2aaa40 = !_0x4f2fd6['isEmptyObject'](_0x5bc637), _0x2aaa40 || !_0x4f2fd6['isEmptyObject'](_0x5e19ec)) {
            for (_0xf32295 in (_0x541f0b && 0x1 === _0x2e7a97['nodeType'] && (_0x1cc0ce['overflow'] = [_0x4f1573['overflow'], _0x4f1573['overflowX'], _0x4f1573['overflowY']], _0x584cdf = _0x235068 && _0x235068['display'], null == _0x584cdf && (_0x584cdf = _0x4f3277['get'](_0x2e7a97, 'display')), _0x451597 = _0x4f2fd6['css'](_0x2e7a97, 'display'), 'none' === _0x451597 && (_0x584cdf ? _0x451597 = _0x584cdf : (_0x36b097([_0x2e7a97], !0x0), _0x584cdf = _0x2e7a97['style']['display'] || _0x584cdf, _0x451597 = _0x4f2fd6['css'](_0x2e7a97, 'display'), _0x36b097([_0x2e7a97]))), ('inline' === _0x451597 || 'inline-block' === _0x451597 && null != _0x584cdf) && 'none' === _0x4f2fd6['css'](_0x2e7a97, 'float') && (_0x2aaa40 || (_0x28e61c['done'](function() {
                    _0x4f1573['display'] = _0x584cdf;
                }), null == _0x584cdf && (_0x451597 = _0x4f1573['display'], _0x584cdf = 'none' === _0x451597 ? '' : _0x451597)), _0x4f1573['display'] = 'inline-block')), _0x1cc0ce['overflow'] && (_0x4f1573['overflow'] = 'hidden', _0x28e61c['always'](function() {
                    _0x4f1573['overflow'] = _0x1cc0ce['overflow'][0x0], _0x4f1573['overflowX'] = _0x1cc0ce['overflow'][0x1], _0x4f1573['overflowY'] = _0x1cc0ce['overflow'][0x2];
                })), _0x2aaa40 = !0x1, _0x5e19ec)) _0x2aaa40 || (_0x235068 ? 'hidden' in _0x235068 && (_0x56d565 = _0x235068['hidden']) : _0x235068 = _0x4f3277['access'](_0x2e7a97, 'fxshow', {
                'display': _0x584cdf
            }), _0x4e7ba8 && (_0x235068['hidden'] = !_0x56d565), _0x56d565 && _0x36b097([_0x2e7a97], !0x0), _0x28e61c['done'](function() {
                _0x56d565 || _0x36b097([_0x2e7a97]), _0x4f3277['remove'](_0x2e7a97, 'fxshow');
                for (_0xf32295 in _0x5e19ec) _0x4f2fd6['style'](_0x2e7a97, _0xf32295, _0x5e19ec[_0xf32295]);
            })), _0x2aaa40 = _0x5af035(_0x56d565 ? _0x235068[_0xf32295] : 0x0, _0xf32295, _0x28e61c), _0xf32295 in _0x235068 || (_0x235068[_0xf32295] = _0x2aaa40['start'], _0x56d565 && (_0x2aaa40['end'] = _0x2aaa40['start'], _0x2aaa40['start'] = 0x0));
        }
    }],
    'prefilter': function(_0x32faf7, _0x3c5df1) {
        _0x3c5df1 ? _0x12fd14['prefilters']['unshift'](_0x32faf7) : _0x12fd14['prefilters']['push'](_0x32faf7);
    }
}), _0x4f2fd6['speed'] = function(_0x4a34d9, _0x5ad5f4, _0x2b9a2c) {
    var _0x5ed36a = _0x4a34d9 && 'object' == typeof _0x4a34d9 ? _0x4f2fd6['extend']({}, _0x4a34d9) : {
        'complete': _0x2b9a2c || !_0x2b9a2c && _0x5ad5f4 || _0x4f2fd6['isFunction'](_0x4a34d9) && _0x4a34d9,
        'duration': _0x4a34d9,
        'easing': _0x2b9a2c && _0x5ad5f4 || _0x5ad5f4 && !_0x4f2fd6['isFunction'](_0x5ad5f4) && _0x5ad5f4
    };
    return _0x4f2fd6['fx']['off'] ? _0x5ed36a['duration'] = 0x0 : 'number' != typeof _0x5ed36a['duration'] && (_0x5ed36a['duration'] in _0x4f2fd6['fx']['speeds'] ? _0x5ed36a['duration'] = _0x4f2fd6['fx']['speeds'][_0x5ed36a['duration']] : _0x5ed36a['duration'] = _0x4f2fd6['fx']['speeds']['_default']), null != _0x5ed36a['queue'] && !0x0 !== _0x5ed36a['queue'] || (_0x5ed36a['queue'] = 'fx'), _0x5ed36a['old'] = _0x5ed36a['complete'], _0x5ed36a['complete'] = function() {
        _0x4f2fd6['isFunction'](_0x5ed36a['old']) && _0x5ed36a['old']['call'](this), _0x5ed36a['queue'] && _0x4f2fd6['dequeue'](this, _0x5ed36a['queue']);
    }, _0x5ed36a;
}, _0x4f2fd6['fn']['extend']({
    'fadeTo': function(_0x32ca54, _0x2b8740, _0x257057, _0x1f9107) {
        return this['filter'](_0x2e6304)['css']('opacity', 0x0)['show']()['end']()['animate']({
            'opacity': _0x2b8740
        }, _0x32ca54, _0x257057, _0x1f9107);
    },
    'animate': function(_0x2a08eb, _0x445518, _0x1e59f7, _0x4aa857) {
        var _0x414da4 = _0x4f2fd6['isEmptyObject'](_0x2a08eb),
            _0x413bbb = _0x4f2fd6['speed'](_0x445518, _0x1e59f7, _0x4aa857);
        return _0x445518 = function() {
            var _0x52da34 = _0x12fd14(this, _0x4f2fd6['extend']({}, _0x2a08eb), _0x413bbb);
            (_0x414da4 || _0x4f3277['get'](this, 'finish')) && _0x52da34['stop'](!0x0);
        }, (_0x445518['finish'] = _0x445518, _0x414da4 || !0x1 === _0x413bbb['queue'] ? this['each'](_0x445518) : this['queue'](_0x413bbb['queue'], _0x445518));
    },
    'stop': function(_0x2316c7, _0x1282bb, _0x6c3f72) {
        var _0x5e08e9 = function(_0x15e70b) {
            var _0x586ba5 = _0x15e70b['stop'];
            delete _0x15e70b['stop'], _0x586ba5(_0x6c3f72);
        };
        return 'string' != typeof _0x2316c7 && (_0x6c3f72 = _0x1282bb, _0x1282bb = _0x2316c7, _0x2316c7 = void 0x0), _0x1282bb && !0x1 !== _0x2316c7 && this['queue'](_0x2316c7 || 'fx', []), this['each'](function() {
            var _0x4bc7b0 = !0x0,
                _0x4f85f2 = null != _0x2316c7 && _0x2316c7 + 'queueHooks',
                _0x3a43fb = _0x4f2fd6['timers'],
                _0x55a869 = _0x4f3277['get'](this);
            if (_0x4f85f2) _0x55a869[_0x4f85f2] && _0x55a869[_0x4f85f2]['stop'] && _0x5e08e9(_0x55a869[_0x4f85f2]);
            else {
                for (_0x4f85f2 in _0x55a869) _0x55a869[_0x4f85f2] && _0x55a869[_0x4f85f2]['stop'] && _0x36fe54['test'](_0x4f85f2) && _0x5e08e9(_0x55a869[_0x4f85f2]);
            }
            for (_0x4f85f2 = _0x3a43fb['length']; _0x4f85f2--;) _0x3a43fb[_0x4f85f2]['elem'] !== this || null != _0x2316c7 && _0x3a43fb[_0x4f85f2]['queue'] !== _0x2316c7 || (_0x3a43fb[_0x4f85f2]['anim']['stop'](_0x6c3f72), _0x4bc7b0 = !0x1, _0x3a43fb['splice'](_0x4f85f2, 0x1));
            !_0x4bc7b0 && _0x6c3f72 || _0x4f2fd6['dequeue'](this, _0x2316c7);
        });
    },
    'finish': function(_0x5f3bc6) {
        return !0x1 !== _0x5f3bc6 && (_0x5f3bc6 = _0x5f3bc6 || 'fx'), this['each'](function() {
            var _0x423426, _0x6f366f = _0x4f3277['get'](this),
                _0x592b06 = _0x6f366f[_0x5f3bc6 + 'queue'];
            _0x423426 = _0x6f366f[_0x5f3bc6 + 'queueHooks'];
            var _0x304c69 = _0x4f2fd6['timers'],
                _0x5ad51a = _0x592b06 ? _0x592b06['length'] : 0x0;
            _0x6f366f['finish'] = !0x0, _0x4f2fd6['queue'](this, _0x5f3bc6, []), _0x423426 && _0x423426['stop'] && _0x423426['stop']['call'](this, !0x0);
            for (_0x423426 = _0x304c69['length']; _0x423426--;) _0x304c69[_0x423426]['elem'] === this && _0x304c69[_0x423426]['queue'] === _0x5f3bc6 && (_0x304c69[_0x423426]['anim']['stop'](!0x0), _0x304c69['splice'](_0x423426, 0x1));
            for (_0x423426 = 0x0; _0x423426 < _0x5ad51a; _0x423426++) _0x592b06[_0x423426] && _0x592b06[_0x423426]['finish'] && _0x592b06[_0x423426]['finish']['call'](this);
            delete _0x6f366f['finish'];
        });
    }
}), _0x4f2fd6['each'](['toggle', 'show', 'hide'], function(_0x33ac3c, _0x474340) {
    var _0x234282 = _0x4f2fd6['fn'][_0x474340];
    _0x4f2fd6['fn'][_0x474340] = function(_0x286b74, _0x79ab5f, _0x4d3db4) {
        return null == _0x286b74 || 'boolean' == typeof _0x286b74 ? _0x234282['apply'](this, arguments) : this['animate'](_0x49080a(_0x474340, !0x0), _0x286b74, _0x79ab5f, _0x4d3db4);
    };
}), _0x4f2fd6['each']({
    'slideDown': _0x49080a('show'),
    'slideUp': _0x49080a('hide'),
    'slideToggle': _0x49080a('toggle'),
    'fadeIn': {
        'opacity': 'show'
    },
    'fadeOut': {
        'opacity': 'hide'
    },
    'fadeToggle': {
        'opacity': 'toggle'
    }
}, function(_0x2176a6, _0x5a129d) {
    _0x4f2fd6['fn'][_0x2176a6] = function(_0x25910c, _0x5c8d38, _0x5270d9) {
        return this['animate'](_0x5a129d, _0x25910c, _0x5c8d38, _0x5270d9);
    };
}), _0x4f2fd6['timers'] = [], _0x4f2fd6['fx']['tick'] = function() {
    var _0xc5982e, _0x26501d = 0x0,
        _0x1c25b2 = _0x4f2fd6['timers'];
    for (_0x50a4d5 = _0x4f2fd6['now'](); _0x26501d < _0x1c25b2['length']; _0x26501d++) _0xc5982e = _0x1c25b2[_0x26501d], _0xc5982e() || _0x1c25b2[_0x26501d] !== _0xc5982e || _0x1c25b2['splice'](_0x26501d--, 0x1);
    _0x1c25b2['length'] || _0x4f2fd6['fx']['stop'](), _0x50a4d5 = void 0x0;
}, _0x4f2fd6['fx']['timer'] = function(_0x40ea6c) {
    _0x4f2fd6['timers']['push'](_0x40ea6c), _0x4f2fd6['fx']['start']();
}, _0x4f2fd6['fx']['interval'] = 0xd, _0x4f2fd6['fx']['start'] = function() {
    _0xaaee55 || (_0xaaee55 = !0x0, _0x252d18());
}, _0x4f2fd6['fx']['stop'] = function() {
    _0xaaee55 = null;
}, _0x4f2fd6['fx']['speeds'] = {
    'slow': 0x258,
    'fast': 0xc8,
    '_default': 0x190
}, _0x4f2fd6['fn']['delay'] = function(_0x1159ae, _0x328464) {
    return _0x1159ae = _0x4f2fd6['fx'] ? _0x4f2fd6['fx']['speeds'][_0x1159ae] || _0x1159ae : _0x1159ae, _0x328464 = _0x328464 || 'fx', this['queue'](_0x328464, function(_0x3272f6, _0xe810a9) {
        var _0x465a4e = _0x10a213['setTimeout'](_0x3272f6, _0x1159ae);
        _0xe810a9['stop'] = function() {
            _0x10a213['clearTimeout'](_0x465a4e);
        };
    });
};
var _0x5b2648 = _0x5892f6['createElement']('input'),
    _0x5655ff = _0x5892f6['createElement']('select')['appendChild'](_0x5892f6['createElement']('option'));
_0x5b2648['type'] = 'checkbox', _0x395361['checkOn'] = '' !== _0x5b2648['value'], _0x395361['optSelected'] = _0x5655ff['selected'], _0x5b2648 = _0x5892f6['createElement']('input'), _0x5b2648['value'] = 't', _0x5b2648['type'] = 'radio', _0x395361['radioValue'] = 't' === _0x5b2648['value'];
var _0x58a9d5, _0x6a410a = _0x4f2fd6['expr']['attrHandle'];
_0x4f2fd6['fn']['extend']({
    'attr': function(_0x1ce582, _0xf64e9e) {
        return _0x3e0938(this, _0x4f2fd6['attr'], _0x1ce582, _0xf64e9e, 0x1 < arguments['length']);
    },
    'removeAttr': function(_0xdb30a9) {
        return this['each'](function() {
            _0x4f2fd6['removeAttr'](this, _0xdb30a9);
        });
    }
}), _0x4f2fd6['extend']({
    'attr': function(_0x2df48f, _0x581135, _0x2a8011) {
        var _0x2cffc4, _0x172554, _0x442b63 = _0x2df48f['nodeType'];
        if (0x3 !== _0x442b63 && 0x8 !== _0x442b63 && 0x2 !== _0x442b63) return 'undefined' == typeof _0x2df48f['getAttribute'] ? _0x4f2fd6['prop'](_0x2df48f, _0x581135, _0x2a8011) : (0x1 === _0x442b63 && _0x4f2fd6['isXMLDoc'](_0x2df48f) || (_0x172554 = _0x4f2fd6['attrHooks'][_0x581135['toLowerCase']()] || (_0x4f2fd6['expr']['match']['bool']['test'](_0x581135) ? _0x58a9d5 : void 0x0)), void 0x0 !== _0x2a8011 ? null === _0x2a8011 ? void _0x4f2fd6['removeAttr'](_0x2df48f, _0x581135) : _0x172554 && 'set' in _0x172554 && void 0x0 !== (_0x2cffc4 = _0x172554['set'](_0x2df48f, _0x2a8011, _0x581135)) ? _0x2cffc4 : (_0x2df48f['setAttribute'](_0x581135, _0x2a8011 + ''), _0x2a8011) : _0x172554 && 'get' in _0x172554 && null !== (_0x2cffc4 = _0x172554['get'](_0x2df48f, _0x581135)) ? _0x2cffc4 : (_0x2cffc4 = _0x4f2fd6['find']['attr'](_0x2df48f, _0x581135), null == _0x2cffc4 ? void 0x0 : _0x2cffc4));
    },
    'attrHooks': {
        'type': {
            'set': function(_0x20fb14, _0x48a221) {
                if (!_0x395361['radioValue'] && 'radio' === _0x48a221 && _0x443e90(_0x20fb14, 'input')) {
                    var _0x21335f = _0x20fb14['value'];
                    return _0x20fb14['setAttribute']('type', _0x48a221), _0x21335f && (_0x20fb14['value'] = _0x21335f), _0x48a221;
                }
            }
        }
    },
    'removeAttr': function(_0x1e617f, _0x287adf) {
        var _0x69a013, _0x4d19d0 = 0x0,
            _0x4914c8 = _0x287adf && _0x287adf['match'](_0x287fa1);
        if (_0x4914c8 && 0x1 === _0x1e617f['nodeType']) {
            for (; _0x69a013 = _0x4914c8[_0x4d19d0++];) _0x1e617f['removeAttribute'](_0x69a013);
        }
    }
}), _0x58a9d5 = {
    'set': function(_0x55c031, _0x1466fe, _0x823a5a) {
        return !0x1 === _0x1466fe ? _0x4f2fd6['removeAttr'](_0x55c031, _0x823a5a) : _0x55c031['setAttribute'](_0x823a5a, _0x823a5a), _0x823a5a;
    }
}, _0x4f2fd6['each'](_0x4f2fd6['expr']['match']['bool']['source']['match'](/\w+/g), function(_0x30102a, _0x502eec) {
    var _0x3d6d2f = _0x6a410a[_0x502eec] || _0x4f2fd6['find']['attr'];
    _0x6a410a[_0x502eec] = function(_0x45f932, _0x10a943, _0x1af7f9) {
        var _0x152838, _0x54f649, _0x37b8af = _0x10a943['toLowerCase']();
        return _0x1af7f9 || (_0x54f649 = _0x6a410a[_0x37b8af], _0x6a410a[_0x37b8af] = _0x152838, _0x152838 = null != _0x3d6d2f(_0x45f932, _0x10a943, _0x1af7f9) ? _0x37b8af : null, _0x6a410a[_0x37b8af] = _0x54f649), _0x152838;
    };
});
var _0x450308 = /^(?:input|select|textarea|button)$/i,
    _0x142665 = /^(?:a|area)$/i;
_0x4f2fd6['fn']['extend']({
    'prop': function(_0x3ab70f, _0x5a4ef9) {
        return _0x3e0938(this, _0x4f2fd6['prop'], _0x3ab70f, _0x5a4ef9, 0x1 < arguments['length']);
    },
    'removeProp': function(_0xf3ffdb) {
        return this['each'](function() {
            delete this[_0x4f2fd6['propFix'][_0xf3ffdb] || _0xf3ffdb];
        });
    }
}), _0x4f2fd6['extend']({
    'prop': function(_0x4826d7, _0x363eaf, _0x134984) {
        var _0x12d96f, _0x95538e, _0x49e7c9 = _0x4826d7['nodeType'];
        if (0x3 !== _0x49e7c9 && 0x8 !== _0x49e7c9 && 0x2 !== _0x49e7c9) return 0x1 === _0x49e7c9 && _0x4f2fd6['isXMLDoc'](_0x4826d7) || (_0x363eaf = _0x4f2fd6['propFix'][_0x363eaf] || _0x363eaf, _0x95538e = _0x4f2fd6['propHooks'][_0x363eaf]), void 0x0 !== _0x134984 ? _0x95538e && 'set' in _0x95538e && void 0x0 !== (_0x12d96f = _0x95538e['set'](_0x4826d7, _0x134984, _0x363eaf)) ? _0x12d96f : _0x4826d7[_0x363eaf] = _0x134984 : _0x95538e && 'get' in _0x95538e && null !== (_0x12d96f = _0x95538e['get'](_0x4826d7, _0x363eaf)) ? _0x12d96f : _0x4826d7[_0x363eaf];
    },
    'propHooks': {
        'tabIndex': {
            'get': function(_0x45bf3b) {
                var _0x425581 = _0x4f2fd6['find']['attr'](_0x45bf3b, 'tabindex');
                return _0x425581 ? parseInt(_0x425581, 0xa) : _0x450308['test'](_0x45bf3b['nodeName']) || _0x142665['test'](_0x45bf3b['nodeName']) && _0x45bf3b['href'] ? 0x0 : -0x1;
            }
        }
    },
    'propFix': {
        'for': 'htmlFor',
        'class': 'className'
    }
}), _0x395361['optSelected'] || (_0x4f2fd6['propHooks']['selected'] = {
    'get': function(_0x3e66d0) {
        return _0x3e66d0 = _0x3e66d0['parentNode'], (_0x3e66d0 && _0x3e66d0['parentNode'] && _0x3e66d0['parentNode']['selectedIndex'], null);
    },
    'set': function(_0x4cbceb) {
        _0x4cbceb = _0x4cbceb['parentNode'], _0x4cbceb && (_0x4cbceb['selectedIndex'], _0x4cbceb['parentNode'] && _0x4cbceb['parentNode']['selectedIndex']);
    }
}), _0x4f2fd6['each']('tabIndex\x20readOnly\x20maxLength\x20cellSpacing\x20cellPadding\x20rowSpan\x20colSpan\x20useMap\x20frameBorder\x20contentEditable' ['split']('\x20'), function() {
    _0x4f2fd6['propFix'][this['toLowerCase']()] = this;
}), _0x4f2fd6['fn']['extend']({
    'addClass': function(_0x343275) {
        var _0x3b7feb, _0x34f442, _0xf499b5, _0x9ad5d5, _0x3140fb, _0x3889e1, _0x2d69e1 = 0x0;
        if (_0x4f2fd6['isFunction'](_0x343275)) return this['each'](function(_0x3818d6) {
            _0x4f2fd6(this)['addClass'](_0x343275['call'](this, _0x3818d6, _0x354a0c(this)));
        });
        if ('string' == typeof _0x343275 && _0x343275) {
            for (_0x3b7feb = _0x343275['match'](_0x287fa1) || []; _0x34f442 = this[_0x2d69e1++];)
                if (_0x9ad5d5 = _0x354a0c(_0x34f442), _0xf499b5 = 0x1 === _0x34f442['nodeType'] && '\x20' + _0x5c31c3(_0x9ad5d5) + '\x20') {
                    for (_0x3889e1 = 0x0; _0x3140fb = _0x3b7feb[_0x3889e1++];) 0x0 > _0xf499b5['indexOf']('\x20' + _0x3140fb + '\x20') && (_0xf499b5 += _0x3140fb + '\x20');
                    _0xf499b5 = _0x5c31c3(_0xf499b5), _0x9ad5d5 !== _0xf499b5 && _0x34f442['setAttribute']('class', _0xf499b5);
                }
        }
        return this;
    },
    'removeClass': function(_0x1678b5) {
        var _0x42a3bf, _0x5d94a3, _0x2b80bb, _0x52094f, _0x4ea2b3, _0x4140e2, _0x54919d = 0x0;
        if (_0x4f2fd6['isFunction'](_0x1678b5)) return this['each'](function(_0x334dc7) {
            _0x4f2fd6(this)['removeClass'](_0x1678b5['call'](this, _0x334dc7, _0x354a0c(this)));
        });
        if (!arguments['length']) return this['attr']('class', '');
        if ('string' == typeof _0x1678b5 && _0x1678b5) {
            for (_0x42a3bf = _0x1678b5['match'](_0x287fa1) || []; _0x5d94a3 = this[_0x54919d++];)
                if (_0x52094f = _0x354a0c(_0x5d94a3), _0x2b80bb = 0x1 === _0x5d94a3['nodeType'] && '\x20' + _0x5c31c3(_0x52094f) + '\x20') {
                    for (_0x4140e2 = 0x0; _0x4ea2b3 = _0x42a3bf[_0x4140e2++];)
                        for (; - 0x1 < _0x2b80bb['indexOf']('\x20' + _0x4ea2b3 + '\x20');) _0x2b80bb = _0x2b80bb['replace']('\x20' + _0x4ea2b3 + '\x20', '\x20');
                    _0x2b80bb = _0x5c31c3(_0x2b80bb), _0x52094f !== _0x2b80bb && _0x5d94a3['setAttribute']('class', _0x2b80bb);
                }
        }
        return this;
    },
    'toggleClass': function(_0x1dd174, _0x4cf59b) {
        var _0x3754f0 = typeof _0x1dd174;
        return 'boolean' == typeof _0x4cf59b && 'string' === _0x3754f0 ? _0x4cf59b ? this['addClass'](_0x1dd174) : this['removeClass'](_0x1dd174) : _0x4f2fd6['isFunction'](_0x1dd174) ? this['each'](function(_0x3341a9) {
            _0x4f2fd6(this)['toggleClass'](_0x1dd174['call'](this, _0x3341a9, _0x354a0c(this), _0x4cf59b), _0x4cf59b);
        }) : this['each'](function() {
            var _0x4b1d41, _0x44bad3, _0x3e6d11, _0x407799;
            if ('string' === _0x3754f0) {
                _0x44bad3 = 0x0, _0x3e6d11 = _0x4f2fd6(this);
                for (_0x407799 = _0x1dd174['match'](_0x287fa1) || []; _0x4b1d41 = _0x407799[_0x44bad3++];) _0x3e6d11['hasClass'](_0x4b1d41) ? _0x3e6d11['removeClass'](_0x4b1d41) : _0x3e6d11['addClass'](_0x4b1d41);
            } else void 0x0 !== _0x1dd174 && 'boolean' !== _0x3754f0 || (_0x4b1d41 = _0x354a0c(this), _0x4b1d41 && _0x4f3277['set'](this, '__className__', _0x4b1d41), this['setAttribute'] && this['setAttribute']('class', _0x4b1d41 || !0x1 === _0x1dd174 ? '' : _0x4f3277['get'](this, '__className__') || ''));
        });
    },
    'hasClass': function(_0x26d8f0) {
        var _0x44fa9a, _0x217b09 = 0x0;
        for (_0x26d8f0 = '\x20' + _0x26d8f0 + '\x20'; _0x44fa9a = this[_0x217b09++];)
            if (0x1 === _0x44fa9a['nodeType'] && -0x1 < ('\x20' + _0x5c31c3(_0x354a0c(_0x44fa9a)) + '\x20')['indexOf'](_0x26d8f0)) return !0x0;
        return !0x1;
    }
});
var _0x5ecd34 = /\r/g;
_0x4f2fd6['fn']['extend']({
    'val': function(_0x155a0d) {
        var _0x4c3f9e, _0x241198, _0x371360, _0xdf2d41 = this[0x0];
        if (arguments['length']) return _0x371360 = _0x4f2fd6['isFunction'](_0x155a0d), this['each'](function(_0x2da43e) {
            var _0x776d95;
            0x1 === this['nodeType'] && (_0x776d95 = _0x371360 ? _0x155a0d['call'](this, _0x2da43e, _0x4f2fd6(this)['val']()) : _0x155a0d, null == _0x776d95 ? _0x776d95 = '' : 'number' == typeof _0x776d95 ? _0x776d95 += '' : Array['isArray'](_0x776d95) && (_0x776d95 = _0x4f2fd6['map'](_0x776d95, function(_0x20d6b9) {
                return null == _0x20d6b9 ? '' : _0x20d6b9 + '';
            })), _0x4c3f9e = _0x4f2fd6['valHooks'][this['type']] || _0x4f2fd6['valHooks'][this['nodeName']['toLowerCase']()], _0x4c3f9e && 'set' in _0x4c3f9e && void 0x0 !== _0x4c3f9e['set'](this, _0x776d95, 'value') || (this['value'] = _0x776d95));
        });
        if (_0xdf2d41) return _0x4c3f9e = _0x4f2fd6['valHooks'][_0xdf2d41['type']] || _0x4f2fd6['valHooks'][_0xdf2d41['nodeName']['toLowerCase']()], _0x4c3f9e && 'get' in _0x4c3f9e && void 0x0 !== (_0x241198 = _0x4c3f9e['get'](_0xdf2d41, 'value')) ? _0x241198 : (_0x241198 = _0xdf2d41['value'], 'string' == typeof _0x241198 ? _0x241198['replace'](_0x5ecd34, '') : null == _0x241198 ? '' : _0x241198);
    }
}), _0x4f2fd6['extend']({
    'valHooks': {
        'option': {
            'get': function(_0x1948e0) {
                var _0x560373 = _0x4f2fd6['find']['attr'](_0x1948e0, 'value');
                return null != _0x560373 ? _0x560373 : _0x5c31c3(_0x4f2fd6['text'](_0x1948e0));
            }
        },
        'select': {
            'get': function(_0x37d641) {
                var _0x11ab88, _0xe30c0b, _0x3f6fac = _0x37d641['options'],
                    _0x3998c4 = _0x37d641['selectedIndex'],
                    _0x367a91 = 'select-one' === _0x37d641['type'],
                    _0xaa9743 = _0x367a91 ? null : [],
                    _0x5a5ed2 = _0x367a91 ? _0x3998c4 + 0x1 : _0x3f6fac['length'];
                for (_0xe30c0b = 0x0 > _0x3998c4 ? _0x5a5ed2 : _0x367a91 ? _0x3998c4 : 0x0; _0xe30c0b < _0x5a5ed2; _0xe30c0b++)
                    if (_0x11ab88 = _0x3f6fac[_0xe30c0b], (_0x11ab88['selected'] || _0xe30c0b === _0x3998c4) && !_0x11ab88['disabled'] && (!_0x11ab88['parentNode']['disabled'] || !_0x443e90(_0x11ab88['parentNode'], 'optgroup'))) {
                        if (_0x37d641 = _0x4f2fd6(_0x11ab88)['val'](), _0x367a91) return _0x37d641;
                        _0xaa9743['push'](_0x37d641);
                    }
                return _0xaa9743;
            },
            'set': function(_0x311925, _0x32fa8e) {
                for (var _0xb5cc04, _0x4e7899, _0x93da21 = _0x311925['options'], _0x50319e = _0x4f2fd6['makeArray'](_0x32fa8e), _0xa31cbd = _0x93da21['length']; _0xa31cbd--;) _0x4e7899 = _0x93da21[_0xa31cbd], (_0x4e7899['selected'] = -0x1 < _0x4f2fd6['inArray'](_0x4f2fd6['valHooks']['option']['get'](_0x4e7899), _0x50319e)) && (_0xb5cc04 = !0x0);
                return _0xb5cc04 || (_0x311925['selectedIndex'] = -0x1), _0x50319e;
            }
        }
    }
}), _0x4f2fd6['each'](['radio', 'checkbox'], function() {
    _0x4f2fd6['valHooks'][this] = {
        'set': function(_0x27c7e6, _0x23e404) {
            if (Array['isArray'](_0x23e404)) return _0x27c7e6['checked'] = -0x1 < _0x4f2fd6['inArray'](_0x4f2fd6(_0x27c7e6)['val'](), _0x23e404);
        }
    }, _0x395361['checkOn'] || (_0x4f2fd6['valHooks'][this]['get'] = function(_0x31658c) {
        return null === _0x31658c['getAttribute']('value') ? 'on' : _0x31658c['value'];
    });
});
var _0x9d8ee7 = /^(?:focusinfocus|focusoutblur)$/;
_0x4f2fd6['extend'](_0x4f2fd6['event'], {
    'trigger': function(_0x53cb24, _0x3db22e, _0x1e038f, _0x57dc96) {
        var _0x5526f8, _0x2ed68f, _0x40053a, _0x18aa03, _0xaaa750, _0x17e001, _0x7b7bb5, _0x2a2b87 = [_0x1e038f || _0x5892f6],
            _0x3cc3b9 = _0x2a78ae['call'](_0x53cb24, 'type') ? _0x53cb24['type'] : _0x53cb24;
        _0x5526f8 = _0x2a78ae['call'](_0x53cb24, 'namespace') ? _0x53cb24['namespace']['split']('.') : [];
        if (_0x2ed68f = _0x40053a = _0x1e038f = _0x1e038f || _0x5892f6, 0x3 !== _0x1e038f['nodeType'] && 0x8 !== _0x1e038f['nodeType'] && !_0x9d8ee7['test'](_0x3cc3b9 + _0x4f2fd6['event']['triggered']) && (-0x1 < _0x3cc3b9['indexOf']('.') && (_0x5526f8 = _0x3cc3b9['split']('.'), _0x3cc3b9 = _0x5526f8['shift'](), _0x5526f8['sort']()), _0xaaa750 = 0x0 > _0x3cc3b9['indexOf'](':') && 'on' + _0x3cc3b9, _0x53cb24 = _0x53cb24[_0x4f2fd6['expando']] ? _0x53cb24 : new _0x4f2fd6['Event'](_0x3cc3b9, 'object' == typeof _0x53cb24 && _0x53cb24), _0x53cb24['isTrigger'] = _0x57dc96 ? 0x2 : 0x3, _0x53cb24['namespace'] = _0x5526f8['join']('.'), _0x53cb24['rnamespace'] = _0x53cb24['namespace'] ? RegExp('(^|\x5c.)' + _0x5526f8['join']('\x5c.(?:.*\x5c.|)') + '(\x5c.|$)') : null, _0x53cb24['result'] = void 0x0, _0x53cb24['target'] || (_0x53cb24['target'] = _0x1e038f), _0x3db22e = null == _0x3db22e ? [_0x53cb24] : _0x4f2fd6['makeArray'](_0x3db22e, [_0x53cb24]), _0x7b7bb5 = _0x4f2fd6['event']['special'][_0x3cc3b9] || {}, _0x57dc96 || !_0x7b7bb5['trigger'] || !0x1 !== _0x7b7bb5['trigger']['apply'](_0x1e038f, _0x3db22e))) {
            if (!_0x57dc96 && !_0x7b7bb5['noBubble'] && !_0x4f2fd6['isWindow'](_0x1e038f)) {
                _0x18aa03 = _0x7b7bb5['delegateType'] || _0x3cc3b9;
                for (_0x9d8ee7['test'](_0x18aa03 + _0x3cc3b9) || (_0x2ed68f = _0x2ed68f['parentNode']); _0x2ed68f; _0x2ed68f = _0x2ed68f['parentNode']) _0x2a2b87['push'](_0x2ed68f), _0x40053a = _0x2ed68f;
                _0x40053a === (_0x1e038f['ownerDocument'] || _0x5892f6) && _0x2a2b87['push'](_0x40053a['defaultView'] || _0x40053a['parentWindow'] || _0x10a213);
            }
            for (_0x5526f8 = 0x0;
                (_0x2ed68f = _0x2a2b87[_0x5526f8++]) && !_0x53cb24['isPropagationStopped']();) _0x53cb24['type'] = 0x1 < _0x5526f8 ? _0x18aa03 : _0x7b7bb5['bindType'] || _0x3cc3b9, (_0x17e001 = (_0x4f3277['get'](_0x2ed68f, 'events') || {})[_0x53cb24['type']] && _0x4f3277['get'](_0x2ed68f, 'handle')) && _0x17e001['apply'](_0x2ed68f, _0x3db22e), (_0x17e001 = _0xaaa750 && _0x2ed68f[_0xaaa750]) && _0x17e001['apply'] && _0x384786(_0x2ed68f) && (_0x53cb24['result'] = _0x17e001['apply'](_0x2ed68f, _0x3db22e), !0x1 === _0x53cb24['result'] && _0x53cb24['preventDefault']());
            return _0x53cb24['type'] = _0x3cc3b9, _0x57dc96 || _0x53cb24['isDefaultPrevented']() || _0x7b7bb5['_default'] && !0x1 !== _0x7b7bb5['_default']['apply'](_0x2a2b87['pop'](), _0x3db22e) || !_0x384786(_0x1e038f) || _0xaaa750 && _0x4f2fd6['isFunction'](_0x1e038f[_0x3cc3b9]) && !_0x4f2fd6['isWindow'](_0x1e038f) && (_0x40053a = _0x1e038f[_0xaaa750], _0x40053a && (_0x1e038f[_0xaaa750] = null), _0x4f2fd6['event']['triggered'] = _0x3cc3b9, _0x1e038f[_0x3cc3b9](), _0x4f2fd6['event']['triggered'] = void 0x0, _0x40053a && (_0x1e038f[_0xaaa750] = _0x40053a)), _0x53cb24['result'];
        }
    },
    'simulate': function(_0x134252, _0x30b7ac, _0x4f07df) {
        _0x134252 = _0x4f2fd6['extend'](new _0x4f2fd6['Event'](), _0x4f07df, {
            'type': _0x134252,
            'isSimulated': !0x0
        }), _0x4f2fd6['event']['trigger'](_0x134252, null, _0x30b7ac);
    }
}), _0x4f2fd6['fn']['extend']({
    'trigger': function(_0x112847, _0x356ae4) {
        return this['each'](function() {
            _0x4f2fd6['event']['trigger'](_0x112847, _0x356ae4, this);
        });
    },
    'triggerHandler': function(_0x54d005, _0x5963df) {
        var _0x470fdd = this[0x0];
        if (_0x470fdd) return _0x4f2fd6['event']['trigger'](_0x54d005, _0x5963df, _0x470fdd, !0x0);
    }
}), _0x4f2fd6['each']('blur\x20focus\x20focusin\x20focusout\x20resize\x20scroll\x20click\x20dblclick\x20mousedown\x20mouseup\x20mousemove\x20mouseover\x20mouseout\x20mouseenter\x20mouseleave\x20change\x20select\x20submit\x20keydown\x20keypress\x20keyup\x20contextmenu' ['split']('\x20'), function(_0x561228, _0x24ffda) {
    _0x4f2fd6['fn'][_0x24ffda] = function(_0x17a926, _0x58d51a) {
        return 0x0 < arguments['length'] ? this['on'](_0x24ffda, null, _0x17a926, _0x58d51a) : this['trigger'](_0x24ffda);
    };
}), _0x4f2fd6['fn']['extend']({
    'hover': function(_0x3e27ed, _0x5d566c) {
        return this['mouseenter'](_0x3e27ed)['mouseleave'](_0x5d566c || _0x3e27ed);
    }
}), _0x395361['focusin'] = 'onfocusin' in _0x10a213, _0x395361['focusin'] || _0x4f2fd6['each']({
    'focus': 'focusin',
    'blur': 'focusout'
}, function(_0x39eaba, _0x543a98) {
    var _0x12a847 = function(_0x18c4f3) {
        _0x4f2fd6['event']['simulate'](_0x543a98, _0x18c4f3['target'], _0x4f2fd6['event']['fix'](_0x18c4f3));
    };
    _0x4f2fd6['event']['special'][_0x543a98] = {
        'setup': function() {
            var _0x4b4197 = this['ownerDocument'] || this,
                _0x3ee14f = _0x4f3277['access'](_0x4b4197, _0x543a98);
            _0x3ee14f || _0x4b4197['addEventListener'](_0x39eaba, _0x12a847, !0x0), _0x4f3277['access'](_0x4b4197, _0x543a98, (_0x3ee14f || 0x0) + 0x1);
        },
        'teardown': function() {
            var _0x4c8940 = this['ownerDocument'] || this,
                _0x30978e = _0x4f3277['access'](_0x4c8940, _0x543a98) - 0x1;
            _0x30978e ? _0x4f3277['access'](_0x4c8940, _0x543a98, _0x30978e) : (_0x4c8940['removeEventListener'](_0x39eaba, _0x12a847, !0x0), _0x4f3277['remove'](_0x4c8940, _0x543a98));
        }
    };
});
var _0x3403e7 = _0x10a213['location'],
    _0x4d18e0 = _0x4f2fd6['now'](),
    _0x1437ec = /\?/;
_0x4f2fd6['parseXML'] = function(_0x540011) {
    var _0x2f6094;
    if (!_0x540011 || 'string' != typeof _0x540011) return null;
    try {
        _0x2f6094 = new _0x10a213['DOMParser']()['parseFromString'](_0x540011, 'text/xml');
    } catch (_0x558072) {
        _0x2f6094 = void 0x0;
    }
    return _0x2f6094 && !_0x2f6094['getElementsByTagName']('parsererror')['length'] || _0x4f2fd6['error']('Invalid\x20XML:\x20' + _0x540011), _0x2f6094;
};
var _0x596950 = /\[\]$/,
    _0x18a7ef = /\r?\n/g,
    _0x3d7552 = /^(?:submit|button|image|reset|file)$/i,
    _0x35b490 = /^(?:input|select|textarea|keygen)/i;
_0x4f2fd6['param'] = function(_0x573e80, _0x338645) {
    var _0x1cd082, _0x408c9f = [],
        _0x4c20ab = function(_0x47cb6e, _0x1f530a) {
            var _0x3e6104 = _0x4f2fd6['isFunction'](_0x1f530a) ? _0x1f530a() : _0x1f530a;
            _0x408c9f[_0x408c9f['length']] = encodeURIComponent(_0x47cb6e) + '=' + encodeURIComponent(null == _0x3e6104 ? '' : _0x3e6104);
        };
    if (Array['isArray'](_0x573e80) || _0x573e80['jquery'] && !_0x4f2fd6['isPlainObject'](_0x573e80)) _0x4f2fd6['each'](_0x573e80, function() {
        _0x4c20ab(this['name'], this['value']);
    });
    else {
        for (_0x1cd082 in _0x573e80) _0x37af5b(_0x1cd082, _0x573e80[_0x1cd082], _0x338645, _0x4c20ab);
    }
    return _0x408c9f['join']('&');
}, _0x4f2fd6['fn']['extend']({
    'serialize': function() {
        return _0x4f2fd6['param'](this['serializeArray']());
    },
    'serializeArray': function() {
        return this['map'](function() {
            var _0x1fe5fd = _0x4f2fd6['prop'](this, 'elements');
            return _0x1fe5fd ? _0x4f2fd6['makeArray'](_0x1fe5fd) : this;
        })['filter'](function() {
            var _0x206857 = this['type'];
            return this['name'] && !_0x4f2fd6(this)['is'](':disabled') && _0x35b490['test'](this['nodeName']) && !_0x3d7552['test'](_0x206857) && (this['checked'] || !_0x502163['test'](_0x206857));
        })['map'](function(_0xa3898a, _0x27233e) {
            var _0x361a07 = _0x4f2fd6(this)['val']();
            return null == _0x361a07 ? null : Array['isArray'](_0x361a07) ? _0x4f2fd6['map'](_0x361a07, function(_0x2d8db4) {
                return {
                    'name': _0x27233e['name'],
                    'value': _0x2d8db4['replace'](_0x18a7ef, '\x0d\x0a')
                };
            }) : {
                'name': _0x27233e['name'],
                'value': _0x361a07['replace'](_0x18a7ef, '\x0d\x0a')
            };
        })['get']();
    }
});
var _0x44d71a = /%20/g,
    _0x55ea99 = /#.*$/,
    _0x7b5cdd = /([?&])_=[^&]*/,
    _0x9572dd = /^(.*?):[ \t]*([^\r\n]*)$/gm,
    _0x2b589c = /^(?:GET|HEAD)$/,
    _0x1d6528 = /^\/\//,
    _0x102b5e = {},
    _0x7e13db = {},
    _0x2b7abb = '*/' ['concat']('*'),
    _0x578e22 = _0x5892f6['createElement']('a');
_0x578e22['href'] = _0x3403e7['href'], _0x4f2fd6['extend']({
    'active': 0x0,
    'lastModified': {},
    'etag': {},
    'ajaxSettings': {
        'url': _0x3403e7['href'],
        'type': 'GET',
        'isLocal': '',
        'global': !0x1,
        'processData': !0x1,
        'async': !0x1,
        'contentType': 'application/x-www-form-urlencoded;\x20charset=UTF-8',
        'accepts': {
            '*': _0x2b7abb,
            'text': 'text/plain',
            'html': 'text/html',
            'xml': 'application/xml,\x20text/xml',
            'json': 'application/json,\x20text/javascript'
        },
        'contents': {
            'xml': /\bxml\b/,
            'html': /\bhtml/,
            'json': /\bjson\b/
        },
        'responseFields': {
            'xml': 'responseXML',
            'text': 'responseText',
            'json': 'responseJSON'
        },
        'converters': {
            '*\x20text': String,
            'text\x20html': !0x0,
            'text\x20json': JSON['parse'],
            'text\x20xml': _0x4f2fd6['parseXML']
        },
        'flatOptions': {
            'url': !0x1,
            'context': !0x1
        }
    },
    'ajaxSetup': function(_0x157b33, _0x1b3e61) {
        return _0x1b3e61 ? _0x332b1e(_0x332b1e(_0x157b33, _0x4f2fd6['ajaxSettings']), _0x1b3e61) : _0x332b1e(_0x4f2fd6['ajaxSettings'], _0x157b33);
    },
    'ajaxPrefilter': _0x2dc415(_0x102b5e),
    'ajaxTransport': _0x2dc415(_0x7e13db),
    'ajax': function(_0x5869e4, _0xea1f59) {
        function _0x3dde4d(_0x5bc481, _0x5cd481, _0x229513, _0x4da161) {
            var _0x473ed2, _0x21d5f4, _0x1462d0, _0x24f261, _0x51a3c7 = _0x5cd481;
            if (!_0x1fec6e) {
                _0x1fec6e = !0x0, _0x2a7d30 && _0x10a213['clearTimeout'](_0x2a7d30), _0x445138 = void 0x0, _0x44f0dc = _0x4da161 || '', _0x264a2e['readyState'] = 0x0 < _0x5bc481 ? 0x4 : 0x0, _0x4da161 = 0xc8 <= _0x5bc481 && 0x12c > _0x5bc481 || 0x130 === _0x5bc481;
                if (_0x229513) {
                    _0x1462d0 = _0x207d65;
                    for (var _0x5930e5 = _0x264a2e, _0x3876da, _0x31855b, _0x2bc5da, _0x532d34, _0xc11a56 = _0x1462d0['contents'], _0x314427 = _0x1462d0['dataTypes'];
                        '*' === _0x314427[0x0];) _0x314427['shift'](), void 0x0 === _0x3876da && (_0x3876da = _0x1462d0['mimeType'] || _0x5930e5['getResponseHeader']('Content-Type'));
                    if (_0x3876da) {
                        for (_0x31855b in _0xc11a56)
                            if (_0xc11a56[_0x31855b] && _0xc11a56[_0x31855b]['test'](_0x3876da)) {
                                _0x314427['unshift'](_0x31855b);
                                break;
                            }
                    }
                    if (_0x314427[0x0] in _0x229513) _0x2bc5da = _0x314427[0x0];
                    else {
                        for (_0x31855b in _0x229513) {
                            if (!_0x314427[0x0] || _0x1462d0['converters'][_0x31855b + '\x20' + _0x314427[0x0]]) {
                                _0x2bc5da = _0x31855b;
                                break;
                            }
                            _0x532d34 || (_0x532d34 = _0x31855b);
                        }
                        _0x2bc5da = _0x2bc5da || _0x532d34;
                    }
                    _0x1462d0 = _0x229513 = _0x2bc5da ? (_0x2bc5da !== _0x314427[0x0] && _0x314427['unshift'](_0x2bc5da), _0x229513[_0x2bc5da]) : void 0x0;
                }
                var _0x2a1b21;
                _0x3c905b: {
                    _0x229513 = _0x207d65,
                    _0x3876da = _0x1462d0,
                    _0x31855b = _0x264a2e,
                    _0x2bc5da = _0x4da161;
                    var _0x1e0ea2, _0x5f5a39, _0x2abb8d;_0x1462d0 = {},
                    _0x5930e5 = _0x229513['dataTypes']['slice']();
                    if (_0x5930e5[0x1]) {
                        for (_0x1e0ea2 in _0x229513['converters']) _0x1462d0[_0x1e0ea2['toLowerCase']()] = _0x229513['converters'][_0x1e0ea2];
                    }
                    for (_0x532d34 = _0x5930e5['shift'](); _0x532d34;)
                        if (_0x229513['responseFields'][_0x532d34] && (_0x31855b[_0x229513['responseFields'][_0x532d34]] = _0x3876da), !_0x2abb8d && _0x2bc5da && _0x229513['dataFilter'] && (_0x3876da = _0x229513['dataFilter'](_0x3876da, _0x229513['dataType'])), _0x2abb8d = _0x532d34, _0x532d34 = _0x5930e5['shift']()) {
                            if ('*' === _0x532d34) _0x532d34 = _0x2abb8d;
                            else {
                                if ('*' !== _0x2abb8d && _0x2abb8d !== _0x532d34) {
                                    if (_0x1e0ea2 = _0x1462d0[_0x2abb8d + '\x20' + _0x532d34] || _0x1462d0['*\x20' + _0x532d34], !_0x1e0ea2) {
                                        for (_0x2a1b21 in _0x1462d0)
                                            if (_0x5f5a39 = _0x2a1b21['split']('\x20'), _0x5f5a39[0x1] === _0x532d34 && (_0x1e0ea2 = _0x1462d0[_0x2abb8d + '\x20' + _0x5f5a39[0x0]] || _0x1462d0['*\x20' + _0x5f5a39[0x0]])) {
                                                !0x0 === _0x1e0ea2 ? _0x1e0ea2 = _0x1462d0[_0x2a1b21] : !0x0 !== _0x1462d0[_0x2a1b21] && (_0x532d34 = _0x5f5a39[0x0], _0x5930e5['unshift'](_0x5f5a39[0x1]));
                                                break;
                                            }
                                    }
                                    if (!0x0 !== _0x1e0ea2) {
                                        if (_0x1e0ea2 && _0x229513['throws']) _0x3876da = _0x1e0ea2(_0x3876da);
                                        else try {
                                            _0x3876da = _0x1e0ea2(_0x3876da);
                                        } catch (_0x10428c) {
                                            _0x2a1b21 = {
                                                'state': 'parsererror',
                                                'error': _0x1e0ea2 ? _0x10428c : 'No\x20conversion\x20from\x20' + _0x2abb8d + '\x20to\x20' + _0x532d34
                                            };
                                            break _0x3c905b;
                                        }
                                    }
                                }
                            }
                        }
                    _0x2a1b21 = {
                        'state': 'success',
                        'data': _0x3876da
                    };
                }
                _0x1462d0 = _0x2a1b21, _0x4da161 ? (_0x207d65['ifModified'] && (_0x24f261 = _0x264a2e['getResponseHeader']('Last-Modified'), _0x24f261 && (_0x4f2fd6['lastModified'][_0x1d38f5] = _0x24f261), _0x24f261 = _0x264a2e['getResponseHeader']('etag'), _0x24f261 && (_0x4f2fd6['etag'][_0x1d38f5] = _0x24f261)), 0xcc === _0x5bc481 || 'HEAD' === _0x207d65['type'] ? _0x51a3c7 = 'nocontent' : 0x130 === _0x5bc481 ? _0x51a3c7 = 'notmodified' : (_0x51a3c7 = _0x1462d0['state'], _0x473ed2 = _0x1462d0['data'], _0x21d5f4 = _0x1462d0['error'], _0x4da161 = !_0x21d5f4)) : (_0x21d5f4 = _0x51a3c7, !_0x5bc481 && _0x51a3c7 || (_0x51a3c7 = 'error', 0x0 > _0x5bc481 && (_0x5bc481 = 0x0))), _0x264a2e['status'] = _0x5bc481, _0x264a2e['statusText'] = (_0x5cd481 || _0x51a3c7) + '', _0x4da161 ? _0x582bac['resolveWith'](_0xe79bc2, [_0x473ed2, _0x51a3c7, _0x264a2e]) : _0x582bac['rejectWith'](_0xe79bc2, [_0x264a2e, _0x51a3c7, _0x21d5f4]), _0x264a2e['statusCode'](_0x4e2cdc), _0x4e2cdc = void 0x0, _0x31ea53 && _0x53e8ba['trigger'](_0x4da161 ? 'ajaxSuccess' : 'ajaxError', [_0x264a2e, _0x207d65, _0x4da161 ? _0x473ed2 : _0x21d5f4]), _0xd4bc9['fireWith'](_0xe79bc2, [_0x264a2e, _0x51a3c7]), _0x31ea53 && (_0x53e8ba['trigger']('ajaxComplete', [_0x264a2e, _0x207d65]), --_0x4f2fd6['active'] || _0x4f2fd6['event']['trigger']('ajaxStop'));
            }
        }
        'object' == typeof _0x5869e4 && (_0xea1f59 = _0x5869e4, _0x5869e4 = void 0x0), _0xea1f59 = _0xea1f59 || {};
        var _0x445138, _0x1d38f5, _0x44f0dc, _0x258e72, _0x2a7d30, _0x214c45, _0x1fec6e, _0x31ea53, _0x2d3b27, _0x56e0b8, _0x207d65 = _0x4f2fd6['ajaxSetup']({}, _0xea1f59),
            _0xe79bc2 = _0x207d65['context'] || _0x207d65,
            _0x53e8ba = _0x207d65['context'] && (_0xe79bc2['nodeType'] || _0xe79bc2['jquery']) ? _0x4f2fd6(_0xe79bc2) : _0x4f2fd6['event'],
            _0x582bac = _0x4f2fd6['Deferred'](),
            _0xd4bc9 = _0x4f2fd6['Callbacks']('once\x20memory'),
            _0x4e2cdc = _0x207d65['statusCode'] || {},
            _0x1f56dc = {},
            _0x1e56b8 = {},
            _0x582fa0 = 'canceled',
            _0x264a2e = {
                'readyState': 0x0,
                'getResponseHeader': function(_0x1b1091) {
                    var _0x167c67;
                    if (_0x1fec6e) {
                        if (!_0x258e72) {
                            for (_0x258e72 = {}; _0x167c67 = _0x9572dd['exec'](_0x44f0dc);) _0x258e72[_0x167c67[0x1]['toLowerCase']()] = _0x167c67[0x2];
                        }
                        _0x167c67 = _0x258e72[_0x1b1091['toLowerCase']()];
                    }
                    return null == _0x167c67 ? null : _0x167c67;
                },
                'getAllResponseHeaders': function() {
                    return _0x1fec6e ? _0x44f0dc : null;
                },
                'setRequestHeader': function(_0x42fec9, _0x4772ac) {
                    return null == _0x1fec6e && (_0x42fec9 = _0x1e56b8[_0x42fec9['toLowerCase']()] = _0x1e56b8[_0x42fec9['toLowerCase']()] || _0x42fec9, _0x1f56dc[_0x42fec9] = _0x4772ac), this;
                },
                'overrideMimeType': function(_0xc0a97f) {
                    return null == _0x1fec6e && (_0x207d65['mimeType'] = _0xc0a97f), this;
                },
                'statusCode': function(_0x235c96) {
                    var _0x1caab0;
                    if (_0x235c96) {
                        if (_0x1fec6e) _0x264a2e['always'](_0x235c96[_0x264a2e['status']]);
                        else {
                            for (_0x1caab0 in _0x235c96) _0x4e2cdc[_0x1caab0] = [_0x4e2cdc[_0x1caab0], _0x235c96[_0x1caab0]];
                        }
                    }
                    return this;
                },
                'abort': function(_0x3d3914) {
                    return _0x3d3914 = _0x3d3914 || _0x582fa0, (_0x445138 && _0x445138['abort'](_0x3d3914), _0x3dde4d(0x0, _0x3d3914), this);
                }
            };
        if (_0x582bac['promise'](_0x264a2e), _0x207d65['url'] = ((_0x5869e4 || _0x207d65['url'] || _0x3403e7['href']) + '')['replace'](_0x1d6528, _0x3403e7['protocol'] + '//'), _0x207d65['type'] = _0xea1f59['method'] || _0xea1f59['type'] || _0x207d65['method'] || _0x207d65['type'], _0x207d65['dataTypes'] = (_0x207d65['dataType'] || '*')['toLowerCase']()['match'](_0x287fa1) || [''], null == _0x207d65['crossDomain']) {
            _0x214c45 = _0x5892f6['createElement']('a');
            try {
                _0x214c45['href'] = _0x207d65['url'], _0x214c45['href'] = _0x214c45['href'], _0x207d65['crossDomain'] = _0x578e22['protocol'] + '//' + _0x578e22['host'] != _0x214c45['protocol'] + '//' + _0x214c45['host'];
            } catch (_0x4bf0b5) {
                _0x207d65['crossDomain'] = !0x0;
            }
        }
        if (_0x207d65['data'] && _0x207d65['processData'] && 'string' != typeof _0x207d65['data'] && (_0x207d65['data'] = _0x4f2fd6['param'](_0x207d65['data'], _0x207d65['traditional'])), _0x1333c1(_0x102b5e, _0x207d65, _0xea1f59, _0x264a2e), _0x1fec6e) return _0x264a2e;
        (_0x31ea53 = _0x4f2fd6['event'] && _0x207d65['global']) && 0x0 === _0x4f2fd6['active']++ && _0x4f2fd6['event']['trigger']('ajaxStart'), _0x207d65['type'] = _0x207d65['type']['toUpperCase'](), _0x207d65['hasContent'] = !_0x2b589c['test'](_0x207d65['type']), _0x1d38f5 = _0x207d65['url']['replace'](_0x55ea99, ''), _0x207d65['hasContent'] ? _0x207d65['data'] && _0x207d65['processData'] && 0x0 === (_0x207d65['contentType'] || '')['indexOf']('application/x-www-form-urlencoded') && (_0x207d65['data'] = _0x207d65['data']['replace'](_0x44d71a, '+')) : (_0x56e0b8 = _0x207d65['url']['slice'](_0x1d38f5['length']), _0x207d65['data'] && (_0x1d38f5 += (_0x1437ec['test'](_0x1d38f5) ? '&' : '?') + _0x207d65['data'], delete _0x207d65['data']), !0x1 === _0x207d65['cache'] && (_0x1d38f5 = _0x1d38f5['replace'](_0x7b5cdd, '$1'), _0x56e0b8 = (_0x1437ec['test'](_0x1d38f5) ? '&' : '?') + '_=' + _0x4d18e0++ + _0x56e0b8), _0x207d65['url'] = _0x1d38f5 + _0x56e0b8), _0x207d65['ifModified'] && (_0x4f2fd6['lastModified'][_0x1d38f5] && _0x264a2e['setRequestHeader']('If-Modified-Since', _0x4f2fd6['lastModified'][_0x1d38f5]), _0x4f2fd6['etag'][_0x1d38f5] && _0x264a2e['setRequestHeader']('If-None-Match', _0x4f2fd6['etag'][_0x1d38f5])), (_0x207d65['data'] && _0x207d65['hasContent'] && !0x1 !== _0x207d65['contentType'] || _0xea1f59['contentType']) && _0x264a2e['setRequestHeader']('Content-Type', _0x207d65['contentType']), _0x264a2e['setRequestHeader']('Accept', _0x207d65['dataTypes'][0x0] && _0x207d65['accepts'][_0x207d65['dataTypes'][0x0]] ? _0x207d65['accepts'][_0x207d65['dataTypes'][0x0]] + ('*' !== _0x207d65['dataTypes'][0x0] ? ',\x20' + _0x2b7abb + ';\x20q=0.01' : '') : _0x207d65['accepts']['*']);
        for (_0x2d3b27 in _0x207d65['headers']) _0x264a2e['setRequestHeader'](_0x2d3b27, _0x207d65['headers'][_0x2d3b27]);
        if (_0x207d65['beforeSend'] && (!0x1 === _0x207d65['beforeSend']['call'](_0xe79bc2, _0x264a2e, _0x207d65) || _0x1fec6e)) return _0x264a2e['abort']();
        if (_0x582fa0 = 'abort', _0xd4bc9['add'](_0x207d65['complete']), _0x264a2e['done'](_0x207d65['success']), _0x264a2e['fail'](_0x207d65['error']), _0x445138 = _0x1333c1(_0x7e13db, _0x207d65, _0xea1f59, _0x264a2e)) {
            if (_0x264a2e['readyState'] = 0x1, _0x31ea53 && _0x53e8ba['trigger']('ajaxSend', [_0x264a2e, _0x207d65]), _0x1fec6e) return _0x264a2e;
            _0x207d65['async'] && 0x0 < _0x207d65['timeout'] && (_0x2a7d30 = _0x10a213['setTimeout'](function() {
                _0x264a2e['abort']('timeout');
            }, _0x207d65['timeout']));
            try {
                _0x1fec6e = !0x1, _0x445138['send'](_0x1f56dc, _0x3dde4d);
            } catch (_0x505ea5) {
                if (_0x1fec6e) throw _0x505ea5;
                _0x3dde4d(-0x1, _0x505ea5);
            }
        } else _0x3dde4d(-0x1, 'No\x20Transport');
        return _0x264a2e;
    },
    'getJSON': function(_0x160bd2, _0x35147d, _0x2a361b) {
        return _0x4f2fd6['get'](_0x160bd2, _0x35147d, _0x2a361b, 'json');
    },
    'getScript': function(_0x57ac0e, _0x3f3553) {
        return _0x4f2fd6['get'](_0x57ac0e, void 0x0, _0x3f3553, 'script');
    }
}), _0x4f2fd6['each'](['get', 'post'], function(_0x548dd7, _0x319fd9) {
    _0x4f2fd6[_0x319fd9] = function(_0x2d1ff7, _0x2bdfa6, _0x51dc79, _0x511bf2) {
        return _0x4f2fd6['isFunction'](_0x2bdfa6) && (_0x511bf2 = _0x511bf2 || _0x51dc79, _0x51dc79 = _0x2bdfa6, _0x2bdfa6 = void 0x0), _0x4f2fd6['ajax'](_0x4f2fd6['extend']({
            'url': _0x2d1ff7,
            'type': _0x319fd9,
            'dataType': _0x511bf2,
            'data': _0x2bdfa6,
            'success': _0x51dc79
        }, _0x4f2fd6['isPlainObject'](_0x2d1ff7) && _0x2d1ff7));
    };
}), _0x4f2fd6['_evalUrl'] = function(_0x3981d8) {
    return _0x4f2fd6['ajax']({
        'url': _0x3981d8,
        'type': 'GET',
        'dataType': 'script',
        'cache': !0x0,
        'async': !0x1,
        'global': !0x1,
        'throws': !0x0
    });
}, _0x4f2fd6['fn']['extend']({
    'wrapAll': function(_0x4b8bcc) {
        var _0x264bd1;
        return this[0x0] && (_0x4f2fd6['isFunction'](_0x4b8bcc) && (_0x4b8bcc = _0x4b8bcc['call'](this[0x0])), _0x264bd1 = _0x4f2fd6(_0x4b8bcc, this[0x0]['ownerDocument'])['eq'](0x0)['clone'](!0x0), this[0x0]['parentNode'] && _0x264bd1['insertBefore'](this[0x0]), _0x264bd1['map'](function() {
            for (var _0x2d2528 = this; _0x2d2528['firstElementChild'];) _0x2d2528 = _0x2d2528['firstElementChild'];
            return _0x2d2528;
        })['append'](this)), this;
    },
    'wrapInner': function(_0x168f51) {
        return _0x4f2fd6['isFunction'](_0x168f51) ? this['each'](function(_0x1f345a) {
            _0x4f2fd6(this)['wrapInner'](_0x168f51['call'](this, _0x1f345a));
        }) : this['each'](function() {
            var _0x15756a = _0x4f2fd6(this),
                _0x26d7d0 = _0x15756a['contents']();
            _0x26d7d0['length'] ? _0x26d7d0['wrapAll'](_0x168f51) : _0x15756a['append'](_0x168f51);
        });
    },
    'wrap': function(_0xd2a025) {
        var _0x46c789 = _0x4f2fd6['isFunction'](_0xd2a025);
        return this['each'](function(_0x2a307c) {
            _0x4f2fd6(this)['wrapAll'](_0x46c789 ? _0xd2a025['call'](this, _0x2a307c) : _0xd2a025);
        });
    },
    'unwrap': function(_0x90501e) {
        return this['parent'](_0x90501e)['not']('body')['each'](function() {
            _0x4f2fd6(this)['replaceWith'](this['childNodes']);
        }), this;
    }
}), _0x4f2fd6['expr']['pseudos']['hidden'] = function(_0x1def6b) {
    return !_0x4f2fd6['expr']['pseudos']['visible'](_0x1def6b);
}, _0x4f2fd6['expr']['pseudos']['visible'] = function(_0x4e307a) {
    return !(!_0x4e307a['offsetWidth'] && !_0x4e307a['offsetHeight'] && !_0x4e307a['getClientRects']()['length']);
}, _0x4f2fd6['ajaxSettings']['xhr'] = function() {
    try {
        return new _0x10a213['XMLHttpRequest']();
    } catch (_0x4d9938) {}
};
var _0x21ca91 = {
        '0': 0xc8,
        0x4c7: 0xcc
    },
    _0x55331e = _0x4f2fd6['ajaxSettings']['xhr']();
_0x395361['cors'] = !!_0x55331e && 'withCredentials' in _0x55331e, _0x395361['ajax'] = _0x55331e = !!_0x55331e, _0x4f2fd6['ajaxTransport'](function(_0x4b09b1) {
    var _0x22db43, _0x44847d;
    if (_0x395361['cors'] || _0x55331e && !_0x4b09b1['crossDomain']) return {
        'send': function(_0xc13a13, _0x3ab981) {
            var _0x177df7, _0x373986 = _0x4b09b1['xhr']();
            if (_0x373986['open'](_0x4b09b1['type'], _0x4b09b1['url'], _0x4b09b1['async'], _0x4b09b1['username'], _0x4b09b1['password']), _0x4b09b1['xhrFields']) {
                for (_0x177df7 in _0x4b09b1['xhrFields']) _0x373986[_0x177df7] = _0x4b09b1['xhrFields'][_0x177df7];
            }
            _0x4b09b1['mimeType'] && _0x373986['overrideMimeType'] && _0x373986['overrideMimeType'](_0x4b09b1['mimeType']), _0x4b09b1['crossDomain'] || _0xc13a13['X-Requested-With'] || (_0xc13a13['X-Requested-With'] = 'XMLHttpRequest');
            for (_0x177df7 in _0xc13a13) _0x373986['setRequestHeader'](_0x177df7, _0xc13a13[_0x177df7]);
            _0x22db43 = function(_0x148dc3) {
                return function() {
                    _0x22db43 && (_0x22db43 = _0x44847d = _0x373986['onload'] = _0x373986['onerror'] = _0x373986['onabort'] = _0x373986['onreadystatechange'] = null, 'abort' === _0x148dc3 ? _0x373986['abort']() : 'error' === _0x148dc3 ? 'number' != typeof _0x373986['status'] ? _0x3ab981(0x0, 'error') : _0x3ab981(_0x373986['status'], _0x373986['statusText']) : _0x3ab981(_0x21ca91[_0x373986['status']] || _0x373986['status'], _0x373986['statusText'], 'text' !== (_0x373986['responseType'] || 'text') || 'string' != typeof _0x373986['responseText'] ? {
                        'binary': _0x373986['response']
                    } : {
                        'text': _0x373986['responseText']
                    }, _0x373986['getAllResponseHeaders']()));
                };
            }, _0x373986['onload'] = _0x22db43(), _0x44847d = _0x373986['onerror'] = _0x22db43('error'), void 0x0 !== _0x373986['onabort'] ? _0x373986['onabort'] = _0x44847d : _0x373986['onreadystatechange'] = function() {
                0x4 === _0x373986['readyState'] && _0x10a213['setTimeout'](function() {
                    _0x22db43 && _0x44847d();
                });
            }, _0x22db43 = _0x22db43('abort');
            try {
                _0x373986['send'](_0x4b09b1['hasContent'] && _0x4b09b1['data'] || null);
            } catch (_0x2318bc) {
                if (_0x22db43) throw _0x2318bc;
            }
        },
        'abort': function() {
            _0x22db43 && _0x22db43();
        }
    };
}), _0x4f2fd6['ajaxPrefilter'](function(_0x4d4eca) {
    _0x4d4eca['crossDomain'] && (_0x4d4eca['contents']['script'] = !0x1);
}), _0x4f2fd6['ajaxSetup']({
    'accepts': {
        'script': 'text/javascript,\x20application/javascript,\x20application/ecmascript,\x20application/x-ecmascript'
    },
    'contents': {
        'script': /\b(?:java|ecma)script\b/
    },
    'converters': {
        'text\x20script': function(_0x206558) {
            return _0x4f2fd6['globalEval'](_0x206558), _0x206558;
        }
    }
}), _0x4f2fd6['ajaxPrefilter']('script', function(_0x3004cb) {
    void 0x0 === _0x3004cb['cache'] && (_0x3004cb['cache'] = !0x1), _0x3004cb['crossDomain'] && (_0x3004cb['type'] = 'GET');
}), _0x4f2fd6['ajaxTransport']('script', function(_0x4803f2) {
    if (_0x4803f2['crossDomain']) {
        var _0x64b77c, _0x3e2217;
        return {
            'send': function(_0x7a8e08, _0x1ba7c8) {
                _0x64b77c = _0x4f2fd6('<script>')['prop']({
                    'charset': _0x4803f2['scriptCharset'],
                    'src': _0x4803f2['url']
                })['on']('load\x20error', _0x3e2217 = function(_0x47398f) {
                    _0x64b77c['remove'](), _0x3e2217 = null, _0x47398f && _0x1ba7c8('error' === _0x47398f['type'] ? 0x194 : 0xc8, _0x47398f['type']);
                }), _0x5892f6['head']['appendChild'](_0x64b77c[0x0]);
            },
            'abort': function() {
                _0x3e2217 && _0x3e2217();
            }
        };
    }
});
var _0x5997f1 = [],
    _0x3a2bee = /(=)\?(?=&|$)|\?\?/;
_0x4f2fd6['ajaxSetup']({
    'jsonp': 'callback',
    'jsonpCallback': function() {
        var _0x43d75f = _0x5997f1['pop']() || _0x4f2fd6['expando'] + '_' + _0x4d18e0++;
        return this[_0x43d75f] = !0x0, _0x43d75f;
    }
}), _0x4f2fd6['ajaxPrefilter']('json\x20jsonp', function(_0x568fff, _0x2a44c, _0x2c1971) {
    var _0x1e50dc, _0x114e3a, _0x115ca2, _0x35b43f = !0x1 !== _0x568fff['jsonp'] && (_0x3a2bee['test'](_0x568fff['url']) ? 'url' : 'string' == typeof _0x568fff['data'] && 0x0 === (_0x568fff['contentType'] || '')['indexOf']('application/x-www-form-urlencoded') && _0x3a2bee['test'](_0x568fff['data']) && 'data');
    if (_0x35b43f || 'jsonp' === _0x568fff['dataTypes'][0x0]) return _0x1e50dc = _0x568fff['jsonpCallback'] = _0x4f2fd6['isFunction'](_0x568fff['jsonpCallback']) ? _0x568fff['jsonpCallback']() : _0x568fff['jsonpCallback'], _0x35b43f ? _0x568fff[_0x35b43f] = _0x568fff[_0x35b43f]['replace'](_0x3a2bee, '$1' + _0x1e50dc) : !0x1 !== _0x568fff['jsonp'] && (_0x568fff['url'] += (_0x1437ec['test'](_0x568fff['url']) ? '&' : '?') + _0x568fff['jsonp'] + '=' + _0x1e50dc), _0x568fff['converters']['script\x20json'] = function() {
        return _0x115ca2 || _0x4f2fd6['error'](_0x1e50dc + '\x20was\x20not\x20called'), _0x115ca2[0x0];
    }, _0x568fff['dataTypes'][0x0] = 'json', _0x114e3a = _0x10a213[_0x1e50dc], _0x10a213[_0x1e50dc] = function() {
        _0x115ca2 = arguments;
    }, _0x2c1971['always'](function() {
        void 0x0 === _0x114e3a ? _0x4f2fd6(_0x10a213)['removeProp'](_0x1e50dc) : _0x10a213[_0x1e50dc] = _0x114e3a, _0x568fff[_0x1e50dc] && (_0x568fff['jsonpCallback'] = _0x2a44c['jsonpCallback'], _0x5997f1['push'](_0x1e50dc)), _0x115ca2 && _0x4f2fd6['isFunction'](_0x114e3a) && _0x114e3a(_0x115ca2[0x0]), _0x115ca2 = _0x114e3a = void 0x0;
    }), 'script';
});
var _0x1539f5 = _0x395361,
    _0x32e217, _0x5e68e1 = _0x5892f6['implementation']['createHTMLDocument']('')['body'];
_0x32e217 = (_0x5e68e1['innerHTML'] = '<form></form><form></form>', 0x2 === _0x5e68e1['childNodes']['length']), _0x1539f5['createHTMLDocument'] = _0x32e217, _0x4f2fd6['parseHTML'] = function(_0x12400a, _0x47d1c, _0x410d3d) {
    if ('string' != typeof _0x12400a) return [];
    'boolean' == typeof _0x47d1c && (_0x410d3d = _0x47d1c, _0x47d1c = !0x1);
    var _0x127e7b, _0x33c1c1, _0x432c47;
    return _0x47d1c || (_0x395361['createHTMLDocument'] ? (_0x47d1c = _0x5892f6['implementation']['createHTMLDocument'](''), _0x127e7b = _0x47d1c['createElement']('base'), _0x127e7b['href'] = _0x5892f6['location']['href'], _0x47d1c['head']['appendChild'](_0x127e7b)) : _0x47d1c = _0x5892f6), _0x33c1c1 = _0x11a67c['exec'](_0x12400a), _0x432c47 = !_0x410d3d && [], _0x33c1c1 ? [_0x47d1c['createElement'](_0x33c1c1[0x1])] : (_0x33c1c1 = _0x411eaf([_0x12400a], _0x47d1c, _0x432c47), _0x432c47 && _0x432c47['length'] && _0x4f2fd6(_0x432c47)['remove'](), _0x4f2fd6['merge']([], _0x33c1c1['childNodes']));
}, _0x4f2fd6['fn']['load'] = function(_0x326146, _0x45413d, _0x50bd59) {
    var _0x56f354, _0x7c0ba6, _0x4977ce, _0x5542d1 = this,
        _0x5b37b5 = _0x326146['indexOf']('\x20');
    return -0x1 < _0x5b37b5 && (_0x56f354 = _0x5c31c3(_0x326146['slice'](_0x5b37b5)), _0x326146 = _0x326146['slice'](0x0, _0x5b37b5)), _0x4f2fd6['isFunction'](_0x45413d) ? (_0x50bd59 = _0x45413d, _0x45413d = void 0x0) : _0x45413d && 'object' == typeof _0x45413d && (_0x7c0ba6 = 'POST'), 0x0 < _0x5542d1['length'] && _0x4f2fd6['ajax']({
        'url': _0x326146,
        'type': _0x7c0ba6 || 'GET',
        'dataType': 'html',
        'data': _0x45413d
    })['done'](function(_0x263527) {
        _0x4977ce = arguments, _0x5542d1['html'](_0x56f354 ? _0x4f2fd6('<div>')['append'](_0x4f2fd6['parseHTML'](_0x263527))['find'](_0x56f354) : _0x263527);
    })['always'](_0x50bd59 && function(_0x1470c4, _0x26df58) {
        _0x5542d1['each'](function() {
            _0x50bd59['apply'](this, _0x4977ce || [_0x1470c4['responseText'], _0x26df58, _0x1470c4]);
        });
    }), this;
}, _0x4f2fd6['each']('ajaxStart\x20ajaxStop\x20ajaxComplete\x20ajaxError\x20ajaxSuccess\x20ajaxSend' ['split']('\x20'), function(_0x1c4ccb, _0x460b32) {
    _0x4f2fd6['fn'][_0x460b32] = function(_0x59c52e) {
        return this['on'](_0x460b32, _0x59c52e);
    };
}), _0x4f2fd6['expr']['pseudos']['animated'] = function(_0x58cd51) {
    return _0x4f2fd6['grep'](_0x4f2fd6['timers'], function(_0x1af4eb) {
        return _0x58cd51 === _0x1af4eb['elem'];
    })['length'];
}, _0x4f2fd6['offset'] = {
    'setOffset': function(_0x414f6d, _0x23d140, _0x14b28a) {
        var _0x4d13e3, _0x7cfdb, _0x889a65, _0x520140, _0xf90e26, _0x43105b, _0x3d0d1d = _0x4f2fd6['css'](_0x414f6d, 'position'),
            _0x18a3c = _0x4f2fd6(_0x414f6d),
            _0x21cf10 = {};
        'static' === _0x3d0d1d && (_0x414f6d['style']['position'] = 'relative'), _0xf90e26 = _0x18a3c['offset'](), _0x889a65 = _0x4f2fd6['css'](_0x414f6d, 'top'), _0x43105b = _0x4f2fd6['css'](_0x414f6d, 'left'), ('absolute' === _0x3d0d1d || 'fixed' === _0x3d0d1d) && -0x1 < (_0x889a65 + _0x43105b)['indexOf']('auto') ? (_0x4d13e3 = _0x18a3c['position'](), _0x520140 = _0x4d13e3['top'], _0x7cfdb = _0x4d13e3['left']) : (_0x520140 = parseFloat(_0x889a65) || 0x0, _0x7cfdb = parseFloat(_0x43105b) || 0x0), _0x4f2fd6['isFunction'](_0x23d140) && (_0x23d140 = _0x23d140['call'](_0x414f6d, _0x14b28a, _0x4f2fd6['extend']({}, _0xf90e26))), null != _0x23d140['top'] && (_0x21cf10['top'] = _0x23d140['top'] - _0xf90e26['top'] + _0x520140), null != _0x23d140['left'] && (_0x21cf10['left'] = _0x23d140['left'] - _0xf90e26['left'] + _0x7cfdb), 'using' in _0x23d140 ? _0x23d140['using']['call'](_0x414f6d, _0x21cf10) : _0x18a3c['css'](_0x21cf10);
    }
}, _0x4f2fd6['fn']['extend']({
    'offset': function(_0x352cae) {
        if (arguments['length']) return void 0x0 === _0x352cae ? this : this['each'](function(_0x4debed) {
            _0x4f2fd6['offset']['setOffset'](this, _0x352cae, _0x4debed);
        });
        var _0x4cb489, _0x403097, _0x2d7044, _0xf1325c, _0x398699 = this[0x0];
        if (_0x398699) return _0x398699['getClientRects']()['length'] ? (_0x2d7044 = _0x398699['getBoundingClientRect'](), _0x4cb489 = _0x398699['ownerDocument'], _0x403097 = _0x4cb489['documentElement'], _0xf1325c = _0x4cb489['defaultView'], {
            'top': _0x2d7044['top'] + _0xf1325c['pageYOffset'] - _0x403097['clientTop'],
            'left': _0x2d7044['left'] + _0xf1325c['pageXOffset'] - _0x403097['clientLeft']
        }) : {
            'top': 0x0,
            'left': 0x0
        };
    },
    'position': function() {
        if (this[0x0]) {
            var _0x803e6e, _0x14633b, _0x3b5c63 = this[0x0],
                _0x34779e = {
                    'top': 0x0,
                    'left': 0x0
                };
            return 'fixed' === _0x4f2fd6['css'](_0x3b5c63, 'position') ? _0x14633b = _0x3b5c63['getBoundingClientRect']() : (_0x803e6e = this['offsetParent'](), _0x14633b = this['offset'](), _0x443e90(_0x803e6e[0x0], 'html') || (_0x34779e = _0x803e6e['offset']()), _0x34779e = {
                'top': _0x34779e['top'] + _0x4f2fd6['css'](_0x803e6e[0x0], 'borderTopWidth', !0x0),
                'left': _0x34779e['left'] + _0x4f2fd6['css'](_0x803e6e[0x0], 'borderLeftWidth', !0x0)
            }), {
                'top': _0x14633b['top'] - _0x34779e['top'] - _0x4f2fd6['css'](_0x3b5c63, 'marginTop', !0x0),
                'left': _0x14633b['left'] - _0x34779e['left'] - _0x4f2fd6['css'](_0x3b5c63, 'marginLeft', !0x0)
            };
        }
    },
    'offsetParent': function() {
        return this['map'](function() {
            for (var _0x5be02f = this['offsetParent']; _0x5be02f && 'static' === _0x4f2fd6['css'](_0x5be02f, 'position');) _0x5be02f = _0x5be02f['offsetParent'];
            return _0x5be02f || _0x400e40;
        });
    }
}), _0x4f2fd6['each']({
    'scrollLeft': 'pageXOffset',
    'scrollTop': 'pageYOffset'
}, function(_0x1f4fcf, _0x8cabb9) {
    var _0x13889d = 'pageYOffset' === _0x8cabb9;
    _0x4f2fd6['fn'][_0x1f4fcf] = function(_0x12cffb) {
        return _0x3e0938(this, function(_0x191b68, _0x4ea694, _0x30e557) {
            var _0x4bd33c;
            return _0x4f2fd6['isWindow'](_0x191b68) ? _0x4bd33c = _0x191b68 : 0x9 === _0x191b68['nodeType'] && (_0x4bd33c = _0x191b68['defaultView']), void 0x0 === _0x30e557 ? _0x4bd33c ? _0x4bd33c[_0x8cabb9] : _0x191b68[_0x4ea694] : void(_0x4bd33c ? _0x4bd33c['scrollTo'](_0x13889d ? _0x4bd33c['pageXOffset'] : _0x30e557, _0x13889d ? _0x30e557 : _0x4bd33c['pageYOffset']) : _0x191b68[_0x4ea694] = _0x30e557);
        }, _0x1f4fcf, _0x12cffb, arguments['length']);
    };
}), _0x4f2fd6['each'](['top', 'left'], function(_0x2b5581, _0x24df14) {
    _0x4f2fd6['cssHooks'][_0x24df14] = _0x3415d0(_0x395361['pixelPosition'], function(_0x3037d6, _0x297a50) {
        if (_0x297a50) return _0x297a50 = _0x4572ba(_0x3037d6, _0x24df14), _0x5ab946['test'](_0x297a50) ? _0x4f2fd6(_0x3037d6)['position']()[_0x24df14] + 'px' : _0x297a50;
    });
}), _0x4f2fd6['each']({
    'Height': 'height',
    'Width': 'width'
}, function(_0x43104b, _0x1b48c4) {
    _0x4f2fd6['each']({
        'padding': 'inner' + _0x43104b,
        'content': _0x1b48c4,
        '': 'outer' + _0x43104b
    }, function(_0x49c542, _0x5445f6) {
        _0x4f2fd6['fn'][_0x5445f6] = function(_0x46fa12, _0xfa6ac5) {
            var _0x1d3412 = arguments['length'] && (_0x49c542 || 'boolean' != typeof _0x46fa12),
                _0x4f1d01 = _0x49c542 || (!0x0 === _0x46fa12 || !0x0 === _0xfa6ac5 ? 'margin' : 'border');
            return _0x3e0938(this, function(_0x14f04d, _0x269acc, _0x3f26be) {
                var _0x313ee6;
                return _0x4f2fd6['isWindow'](_0x14f04d) ? 0x0 === _0x5445f6['indexOf']('outer') ? _0x14f04d['inner' + _0x43104b] : _0x14f04d['document']['documentElement']['client' + _0x43104b] : 0x9 === _0x14f04d['nodeType'] ? (_0x313ee6 = _0x14f04d['documentElement'], Math['max'](_0x14f04d['body']['scroll' + _0x43104b], _0x313ee6['scroll' + _0x43104b], _0x14f04d['body']['offset' + _0x43104b], _0x313ee6['offset' + _0x43104b], _0x313ee6['client' + _0x43104b])) : void 0x0 === _0x3f26be ? _0x4f2fd6['css'](_0x14f04d, _0x269acc, _0x4f1d01) : _0x4f2fd6['style'](_0x14f04d, _0x269acc, _0x3f26be, _0x4f1d01);
            }, _0x1b48c4, _0x1d3412 ? _0x46fa12 : void 0x0, _0x1d3412);
        };
    });
}), _0x4f2fd6['fn']['extend']({
    'bind': function(_0x474b3b, _0x42e61b, _0x3c43fe) {
        return this['on'](_0x474b3b, null, _0x42e61b, _0x3c43fe);
    },
    'unbind': function(_0x3cc209, _0x38d990) {
        return this['off'](_0x3cc209, null, _0x38d990);
    },
    'delegate': function(_0x3401b8, _0x7415ca, _0x5af286, _0xacc8a6) {
        return this['on'](_0x7415ca, _0x3401b8, _0x5af286, _0xacc8a6);
    },
    'undelegate': function(_0x38b62f, _0x2f736d, _0x3ca8b5) {
        return 0x1 === arguments['length'] ? this['off'](_0x38b62f, '**') : this['off'](_0x2f736d, _0x38b62f || '**', _0x3ca8b5);
    }
}), _0x4f2fd6['holdReady'] = function(_0x9ee456) {
    _0x9ee456 ? _0x4f2fd6['readyWait']++ : _0x4f2fd6['ready'](!0x0);
}, _0x4f2fd6['isArray'] = Array['isArray'], _0x4f2fd6['parseJSON'] = JSON['parse'], _0x4f2fd6['nodeName'] = _0x443e90, 'function' == typeof define && define['amd'] && define('jquery', [], function() {
    return _0x4f2fd6;
});
var _0x42f227 = _0x10a213['jQuery'],
    _0x1f3f56 = _0x10a213['$'];
return _0x4f2fd6['noConflict'] = function(_0x3483ea) {
    return _0x10a213['$'] === _0x4f2fd6 && (_0x10a213['$'] = _0x1f3f56), _0x3483ea && _0x10a213['jQuery'] === _0x4f2fd6 && (_0x10a213['jQuery'] = _0x42f227), _0x4f2fd6;
}, _0x516e99 || (_0x10a213['jQuery'] = _0x10a213['$'] = _0x4f2fd6), _0x4f2fd6;
});

function getInternetExplorerVersion() {
var _0x19b470 = -0x1;
return 'Microsoft\x20Internet\x20Explorer' == navigator['appName'] && null != /MSIE ([0-9]{1,}[.0-9]{0,})/ ['exec'](navigator['userAgent']) && (_0x19b470 = parseFloat(RegExp['$1'])), _0x19b470;
}
var ie = getInternetExplorerVersion();

function getQueryVariable(_0x4cee4f) {
for (var _0x265fda = window['location']['search']['substring'](0x1)['split']('&'), _0x3c51c5 = 0x0; _0x3c51c5 < _0x265fda['length']; _0x3c51c5++) {
    var _0x395ea0 = _0x265fda[_0x3c51c5]['match'](/([^=]+?)=(.+)/);
    if (_0x395ea0 && decodeURIComponent(_0x395ea0[0x1]) == _0x4cee4f) return decodeURIComponent(_0x395ea0[0x2]);
}
}
this['jukebox'] = {}, jukebox['Player'] = function(_0x593cc7, _0x4dce59) {
this['id'] = ++jukebox['__jukeboxId'], this['origin'] = _0x4dce59 || null, this['settings'] = {};
for (var _0x524660 in this['defaults']) this['settings'][_0x524660] = this['defaults'][_0x524660];
if ('[object\x20Object]' === Object['prototype']['toString']['call'](_0x593cc7)) {
    for (var _0x909446 in _0x593cc7) this['settings'][_0x909446] = _0x593cc7[_0x909446];
}
'[object\x20Function]' === Object['prototype']['toString']['call'](jukebox['Manager']) && (jukebox['Manager'] = new jukebox['Manager']()), this['resource'] = this['isPlaying'] = null, this['resource'] = '[object\x20Object]' === Object['prototype']['toString']['call'](jukebox['Manager']) ? jukebox['Manager']['getPlayableResource'](this['settings']['resources']) : this['settings']['resources'][0x0] || null;
if (null === this['resource']) throw 'Your\x20browser\x20can\x27t\x20playback\x20the\x20given\x20resources\x20-\x20or\x20you\x20have\x20missed\x20to\x20include\x20jukebox.Manager';
return this['__init'](), this;
}, jukebox['__jukeboxId'] = 0x0, jukebox['Player']['prototype'] = {
'defaults': {
    'resources': [],
    'autoplay': !0x1,
    'spritemap': {},
    'flashMediaElement': './swf/FlashMediaElement.swf',
    'timeout': 0x3e8
},
'__addToManager': function() {
    !0x0 !== this['__wasAddedToManager'] && (jukebox['Manager']['add'](this), this['__wasAddedToManager'] = !0x0);
},
'__init': function() {
    var _0x4bd86e = this,
        _0x1a514f = this['settings'],
        _0x38fa75 = {},
        _0x5c0a6f;
    jukebox['Manager'] && void 0x0 !== jukebox['Manager']['features'] && (_0x38fa75 = jukebox['Manager']['features']);
    if (!0x0 === _0x38fa75['html5audio']) {
        this['context'] = new Audio(), this['context']['src'] = this['resource'];
        if (null === this['origin']) {
            var _0x16f584 = function(_0x4fa7b2) {
                _0x4bd86e['__addToManager'](_0x4fa7b2);
            };
            this['context']['addEventListener']('canplaythrough', _0x16f584, !0x0), window['setTimeout'](function() {
                _0x4bd86e['context']['removeEventListener']('canplaythrough', _0x16f584, !0x0), _0x16f584('timeout');
            }, _0x1a514f['timeout']);
        }
        this['context']['autobuffer'] = !0x0, this['context']['preload'] = !0x0;
        for (_0x5c0a6f in this['HTML5API']) this[_0x5c0a6f] = this['HTML5API'][_0x5c0a6f];
        0x1 < _0x38fa75['channels'] ? !0x0 === _0x1a514f['autoplay'] ? this['context']['autoplay'] = !0x0 : void 0x0 !== _0x1a514f['spritemap'][_0x1a514f['autoplay']] && this['play'](_0x1a514f['autoplay']) : 0x1 === _0x38fa75['channels'] && void 0x0 !== _0x1a514f['spritemap'][_0x1a514f['autoplay']] && (this['backgroundMusic'] = _0x1a514f['spritemap'][_0x1a514f['autoplay']], this['backgroundMusic']['started'] = Date['now'] ? Date['now']() : +new Date(), this['play'](_0x1a514f['autoplay'])), 0x1 == _0x38fa75['channels'] && !0x0 !== _0x1a514f['canPlayBackground'] && (window['addEventListener']('pagehide', function() {
            null !== _0x4bd86e['isPlaying'] && (_0x4bd86e['pause'](), _0x4bd86e['__wasAutoPaused'] = !0x0);
        }), window['addEventListener']('pageshow', function() {
            _0x4bd86e['__wasAutoPaused'] && (_0x4bd86e['resume'](), delete _0x4bd86e['_wasAutoPaused']);
        }));
    } else {
        if (!0x0 === _0x38fa75['flashaudio']) {
            for (_0x5c0a6f in this['FLASHAPI']) this[_0x5c0a6f] = this['FLASHAPI'][_0x5c0a6f];
            _0x38fa75 = ['id=jukebox-flashstream-' + this['id'], 'autoplay=' + _0x1a514f['autoplay'], 'file=' + window['encodeURIComponent'](this['resource'])], this['__initFlashContext'](_0x38fa75), !0x0 === _0x1a514f['autoplay'] ? this['play'](0x0) : _0x1a514f['spritemap'][_0x1a514f['autoplay']] && this['play'](_0x1a514f['autoplay']);
        } else throw 'Your\x20Browser\x20does\x20not\x20support\x20Flash\x20Audio\x20or\x20HTML5\x20Audio.';
    }
},
'__initFlashContext': function(_0x217b00) {
    var _0x144965, _0x5b8d30 = this['settings']['flashMediaElement'],
        _0x34ab36, _0xa526a8 = {
            'flashvars': _0x217b00['join']('&'),
            'quality': 'high',
            'bgcolor': '#000000',
            'wmode': 'transparent',
            'allowscriptaccess': 'always',
            'allowfullscreen': 'true'
        };
    if (navigator['userAgent']['match'](/MSIE/)) {
        _0x144965 = document['createElement']('div'), document['getElementsByTagName']('body')[0x0]['appendChild'](_0x144965);
        var _0xab2c74 = document['createElement']('object');
        _0xab2c74['id'] = 'jukebox-flashstream-' + this['id'], _0xab2c74['setAttribute']('type', 'application/x-shockwave-flash'), _0xab2c74['setAttribute']('classid', 'clsid:d27cdb6e-ae6d-11cf-96b8-444553540000'), _0xab2c74['setAttribute']('width', '0'), _0xab2c74['setAttribute']('height', '0'), _0xa526a8['movie'] = _0x5b8d30 + '?x=' + (Date['now'] ? Date['now']() : +new Date()), _0xa526a8['flashvars'] = _0x217b00['join']('&amp;');
        for (_0x34ab36 in _0xa526a8) _0x217b00 = document['createElement']('param'), _0x217b00['setAttribute']('name', _0x34ab36), _0x217b00['setAttribute']('value', _0xa526a8[_0x34ab36]), _0xab2c74['appendChild'](_0x217b00);
        _0x144965['outerHTML'] = _0xab2c74['outerHTML'], this['context'] = document['getElementById']('jukebox-flashstream-' + this['id']);
    } else {
        _0x144965 = document['createElement']('embed'), _0x144965['id'] = 'jukebox-flashstream-' + this['id'], _0x144965['setAttribute']('type', 'application/x-shockwave-flash'), _0x144965['setAttribute']('width', '100'), _0x144965['setAttribute']('height', '100'), _0xa526a8['play'] = !0x1, _0xa526a8['loop'] = !0x1, _0xa526a8['src'] = _0x5b8d30 + '?x=' + (Date['now'] ? Date['now']() : +new Date());
        for (_0x34ab36 in _0xa526a8) _0x144965['setAttribute'](_0x34ab36, _0xa526a8[_0x34ab36]);
        document['getElementsByTagName']('body')[0x0]['appendChild'](_0x144965), this['context'] = _0x144965;
    }
},
'backgroundHackForiOS': function() {
    if (void 0x0 !== this['backgroundMusic']) {
        var _0x59a83a = Date['now'] ? Date['now']() : +new Date();
        void 0x0 === this['backgroundMusic']['started'] ? (this['backgroundMusic']['started'] = _0x59a83a, this['setCurrentTime'](this['backgroundMusic']['start'])) : (this['backgroundMusic']['lastPointer'] = (_0x59a83a - this['backgroundMusic']['started']) / 0x3e8 % (this['backgroundMusic']['end'] - this['backgroundMusic']['start']) + this['backgroundMusic']['start'], this['play'](this['backgroundMusic']['lastPointer']));
    }
},
'play': function(_0xca8c30, _0x52d149) {
    if (null !== this['isPlaying'] && !0x0 !== _0x52d149) void 0x0 !== jukebox['Manager'] && jukebox['Manager']['addToQueue'](_0xca8c30, this['id']);
    else {
        var _0x13946b = this['settings']['spritemap'],
            _0x33e880;
        if (void 0x0 !== _0x13946b[_0xca8c30]) _0x33e880 = _0x13946b[_0xca8c30]['start'];
        else {
            if ('number' === typeof _0xca8c30) {
                _0x33e880 = _0xca8c30;
                for (var _0x215d0b in _0x13946b)
                    if (_0x33e880 >= _0x13946b[_0x215d0b]['start'] && _0x33e880 <= _0x13946b[_0x215d0b]['end']) {
                        _0xca8c30 = _0x215d0b;
                        break;
                    }
            }
        }
        void 0x0 !== _0x33e880 && '[object\x20Object]' === Object['prototype']['toString']['call'](_0x13946b[_0xca8c30]) && (this['isPlaying'] = this['settings']['spritemap'][_0xca8c30], this['context']['play'] && this['context']['play'](), this['wasReady'] = this['setCurrentTime'](_0x33e880));
    }
},
'stop': function() {
    return this['__lastPosition'] = 0x0, this['isPlaying'] = null, this['backgroundMusic'] ? this['backgroundHackForiOS']() : this['context']['pause'](), !0x0;
},
'pause': function() {
    return this['isPlaying'] = null, this['__lastPosition'] = this['getCurrentTime'](), this['context']['pause'](), this['__lastPosition'];
},
'resume': function(_0x4d6182) {
    _0x4d6182 = 'number' === typeof _0x4d6182 ? _0x4d6182 : this['__lastPosition'];
    if (null !== _0x4d6182) return this['play'](_0x4d6182), this['__lastPosition'] = null, !0x0;
    return this['context']['play'](), !0x1;
},
'HTML5API': {
    'getVolume': function() {
        return this['context']['volume'] || 0x1;
    },
    'setVolume': function(_0x4e43dc) {
        return this['context']['volume'] = _0x4e43dc, 0.0001 > Math['abs'](this['context']['volume'] - _0x4e43dc) ? !0x0 : !0x1;
    },
    'getCurrentTime': function() {
        return this['context']['currentTime'] || 0x0;
    },
    'setCurrentTime': function(_0x4d9408) {
        try {
            return this['context']['currentTime'] = _0x4d9408, !0x0;
        } catch (_0xf396c1) {
            return !0x1;
        }
    }
},
'FLASHAPI': {
    'getVolume': function() {
        return this['context'] && 'function' === typeof this['context']['getVolume'] ? this['context']['getVolume']() : 0x1;
    },
    'setVolume': function(_0x2c9921) {
        return this['context'] && 'function' === typeof this['context']['setVolume'] ? (this['context']['setVolume'](_0x2c9921), !0x0) : !0x1;
    },
    'getCurrentTime': function() {
        return this['context'] && 'function' === typeof this['context']['getCurrentTime'] ? this['context']['getCurrentTime']() : 0x0;
    },
    'setCurrentTime': function(_0x12a5d8) {
        return this['context'] && 'function' === typeof this['context']['setCurrentTime'] ? this['context']['setCurrentTime'](_0x12a5d8) : !0x1;
    }
}
};
if (void 0x0 === this['jukebox']) throw 'jukebox.Manager\x20requires\x20jukebox.Player\x20(Player.js)\x20to\x20run\x20properly.';
jukebox['Manager'] = function(_0x46a98e) {
    this['features'] = {}, this['codecs'] = {}, this['__players'] = {}, this['__playersLength'] = 0x0, this['__clones'] = {}, this['__queue'] = [], this['settings'] = {};
    for (var _0x1ed8c6 in this['defaults']) this['settings'][_0x1ed8c6] = this['defaults'][_0x1ed8c6];
    if ('[object\x20Object]' === Object['prototype']['toString']['call'](_0x46a98e)) {
        for (var _0x13751c in _0x46a98e) this['settings'][_0x13751c] = _0x46a98e[_0x13751c];
    }
    this['__detectFeatures'](), jukebox['Manager']['__initialized'] = !0x1 === this['settings']['useGameLoop'] ? window['setInterval'](function() {
        jukebox['Manager']['loop']();
    }, 0x14) : !0x0;
}, jukebox['Manager']['prototype'] = {
    'defaults': {
        'useFlash': !0x1,
        'useGameLoop': !0x1
    },
    '__detectFeatures': function() {
        var _0x1c8c3a = window['Audio'] && new Audio();
        if (_0x1c8c3a && _0x1c8c3a['canPlayType'] && !0x1 === this['settings']['useFlash']) {
            for (var _0x2c0af6 = [{
                    'e': '3gp',
                    'm': ['audio/3gpp', 'audio/amr']
                }, {
                    'e': 'aac',
                    'm': ['audio/aac', 'audio/aacp']
                }, {
                    'e': 'amr',
                    'm': ['audio/amr', 'audio/3gpp']
                }, {
                    'e': 'caf',
                    'm': ['audio/IMA-ADPCM', 'audio/x-adpcm', 'audio/x-aiff;\x20codecs=\x22IMA-ADPCM,\x20ADPCM\x22']
                }, {
                    'e': 'm4a',
                    'm': 'audio/mp4{audio/mp4;\x20codecs=\x22mp4a.40.2,avc1.42E01E\x22{audio/mpeg4{audio/mpeg4-generic{audio/mp4a-latm{audio/MP4A-LATM{audio/x-m4a' ['split']('{')
                }, {
                    'e': 'mp3',
                    'm': ['audio/mp3', 'audio/mpeg', 'audio/mpeg;\x20codecs=\x22mp3\x22', 'audio/MPA', 'audio/mpa-robust']
                }, {
                    'e': 'mpga',
                    'm': ['audio/MPA', 'audio/mpa-robust', 'audio/mpeg', 'video/mpeg']
                }, {
                    'e': 'mp4',
                    'm': ['audio/mp4', 'video/mp4']
                }, {
                    'e': 'ogg',
                    'm': ['application/ogg', 'audio/ogg', 'audio/ogg;\x20codecs=\x22theora,\x20vorbis\x22', 'video/ogg', 'video/ogg;\x20codecs=\x22theora,\x20vorbis\x22']
                }, {
                    'e': 'wav',
                    'm': ['audio/wave', 'audio/wav', 'audio/wav;\x20codecs=\x221\x22', 'audio/x-wav', 'audio/x-pn-wav']
                }, {
                    'e': 'webm',
                    'm': ['audio/webm', 'audio/webm;\x20codecs=\x22vorbis\x22', 'video/webm']
                }], _0xf340c, _0x1590ee, _0x4a340f = 0x0, _0x49ffdf = _0x2c0af6['length']; _0x4a340f < _0x49ffdf; _0x4a340f++)
                if (_0x1590ee = _0x2c0af6[_0x4a340f]['e'], _0x2c0af6[_0x4a340f]['m']['length'] && 'object' === typeof _0x2c0af6[_0x4a340f]['m']) {
                    for (var _0x2bd241 = 0x0, _0x2a1381 = _0x2c0af6[_0x4a340f]['m']['length']; _0x2bd241 < _0x2a1381; _0x2bd241++)
                        if (_0xf340c = _0x2c0af6[_0x4a340f]['m'][_0x2bd241], '' !== _0x1c8c3a['canPlayType'](_0xf340c)) {
                            this['codecs'][_0x1590ee] = _0xf340c;
                            break;
                        } else this['codecs'][_0x1590ee] || (this['codecs'][_0x1590ee] = !0x1);
                }
            this['features']['html5audio'] = !(!this['codecs']['mp3'] && !this['codecs']['ogg'] && !this['codecs']['webm'] && !this['codecs']['wav']), this['features']['channels'] = 0x8, _0x1c8c3a['volume'] = 0.1337, this['features']['volume'] = !!(0.0001 > Math['abs'](_0x1c8c3a['volume'] - 0.1337)), navigator['userAgent']['match'](/iPhone|iPod|iPad/i) && (this['features']['channels'] = 0x1);
        }
        this['features']['flashaudio'] = !!navigator['mimeTypes']['application/x-shockwave-flash'] || !!navigator['plugins']['Shockwave\x20Flash'] || !0x1;
        if (window['ActiveXObject']) try {
            new ActiveXObject('ShockwaveFlash.ShockwaveFlash.10'), this['features']['flashaudio'] = !0x0;
        } catch (_0x5dfaca) {}!0x0 === this['settings']['useFlash'] && (this['features']['flashaudio'] = !0x0), !0x0 === this['features']['flashaudio'] && !this['features']['html5audio'] && (this['codecs']['mp3'] = 'audio/mp3', this['codecs']['mpga'] = 'audio/mpeg', this['codecs']['mp4'] = 'audio/mp4', this['codecs']['m4a'] = 'audio/mp4', this['codecs']['3gp'] = 'audio/3gpp', this['codecs']['amr'] = 'audio/amr', this['features']['volume'] = !0x0, this['features']['channels'] = 0x1);
    },
    '__getPlayerById': function(_0x3ba205) {
        return this['__players'] && void 0x0 !== this['__players'][_0x3ba205] ? this['__players'][_0x3ba205] : null;
    },
    '__getClone': function(_0x45da53, _0x3ac71a) {
        for (var _0x4d93c8 in this['__clones']) {
            var _0x4ee96c = this['__clones'][_0x4d93c8];
            if (null === _0x4ee96c['isPlaying'] && _0x4ee96c['origin'] === _0x45da53) return _0x4ee96c;
        }
        if ('[object\x20Object]' === Object['prototype']['toString']['call'](_0x3ac71a)) {
            _0x4d93c8 = {};
            for (var _0x59bf4d in _0x3ac71a) _0x4d93c8[_0x59bf4d] = _0x3ac71a[_0x59bf4d];
            return _0x4d93c8['autoplay'] = !0x1, _0x59bf4d = new jukebox['Player'](_0x4d93c8, _0x45da53), _0x59bf4d['isClone'] = !0x0, _0x59bf4d['wasReady'] = !0x1, this['__clones'][_0x59bf4d['id']] = _0x59bf4d;
        }
        return null;
    },
    'loop': function() {
        if (0x0 !== this['__playersLength']) {
            if (this['__queue']['length'] && this['__playersLength'] < this['features']['channels']) {
                var _0x27e363 = this['__queue'][0x0],
                    _0x38211f = this['__getPlayerById'](_0x27e363['origin']);
                if (null !== _0x38211f) {
                    var _0x9908b3 = this['__getClone'](_0x27e363['origin'], _0x38211f['settings']);
                    null !== _0x9908b3 && (!0x0 === this['features']['volume'] && (_0x38211f = this['__players'][_0x27e363['origin']]) && _0x9908b3['setVolume'](_0x38211f['getVolume']()), this['add'](_0x9908b3), _0x9908b3['play'](_0x27e363['pointer'], !0x0));
                }
                this['__queue']['splice'](0x0, 0x1);
            } else {
                for (_0x9908b3 in (this['__queue']['length'] && 0x1 === this['features']['channels'] && (_0x27e363 = this['__queue'][0x0], _0x38211f = this['__getPlayerById'](_0x27e363['origin']), null !== _0x38211f && _0x38211f['play'](_0x27e363['pointer'], !0x0), this['__queue']['splice'](0x0, 0x1)), this['__players'])) _0x27e363 = this['__players'][_0x9908b3], _0x38211f = _0x27e363['getCurrentTime']() || 0x0, _0x27e363['isPlaying'] && !0x1 === _0x27e363['wasReady'] ? _0x27e363['wasReady'] = _0x27e363['setCurrentTime'](_0x27e363['isPlaying']['start']) : _0x27e363['isPlaying'] && !0x0 === _0x27e363['wasReady'] ? _0x38211f > _0x27e363['isPlaying']['end'] && (!0x0 === _0x27e363['isPlaying']['loop'] ? _0x27e363['play'](_0x27e363['isPlaying']['start'], !0x0) : _0x27e363['stop']()) : _0x27e363['isClone'] && null === _0x27e363['isPlaying'] ? this['remove'](_0x27e363) : void 0x0 !== _0x27e363['backgroundMusic'] && null === _0x27e363['isPlaying'] && _0x38211f > _0x27e363['backgroundMusic']['end'] && _0x27e363['backgroundHackForiOS']();
            }
        }
    },
    'getPlayableResource': function(_0x7901ab) {
        '[object\x20Array]' !== Object['prototype']['toString']['call'](_0x7901ab) && (_0x7901ab = [_0x7901ab]);
        for (var _0x136808 = 0x0, _0x4f47d5 = _0x7901ab['length']; _0x136808 < _0x4f47d5; _0x136808++) {
            var _0x3e9237 = _0x7901ab[_0x136808],
                _0x5a7e86 = _0x3e9237['match'](/\.([^\.]*)$/)[0x1];
            if (_0x5a7e86 && this['codecs'][_0x5a7e86]) return _0x3e9237;
        }
        return null;
    },
    'add': function(_0x4415ed) {
        return _0x4415ed instanceof jukebox['Player'] && void 0x0 === this['__players'][_0x4415ed['id']] ? (this['__playersLength']++, this['__players'][_0x4415ed['id']] = _0x4415ed, !0x0) : !0x1;
    },
    'remove': function(_0x2417ee) {
        return _0x2417ee instanceof jukebox['Player'] && void 0x0 !== this['__players'][_0x2417ee['id']] ? (this['__playersLength']--, delete this['__players'][_0x2417ee['id']], !0x0) : !0x1;
    },
    'addToQueue': function(_0x22f98f, _0x1e7d09) {
        return ('string' === typeof _0x22f98f || 'number' === typeof _0x22f98f) && void 0x0 !== this['__players'][_0x1e7d09] ? (this['__queue']['push']({
            'pointer': _0x22f98f,
            'origin': _0x1e7d09
        }), !0x0) : !0x1;
    }
},
function() {
    var _0x1325c5 = function() {
        this['init']();
    };
    _0x1325c5['prototype'] = {
        'init': function() {
            var _0x1dc72 = this || _0x4e2829;
            return _0x1dc72['_counter'] = 0x3e8, _0x1dc72['_html5AudioPool'] = [], _0x1dc72['html5PoolSize'] = 0xa, _0x1dc72['_codecs'] = {}, _0x1dc72['_howls'] = [], _0x1dc72['_muted'] = !0x1, _0x1dc72['_volume'] = 0x1, _0x1dc72['_canPlayEvent'] = 'canplaythrough', _0x1dc72['_navigator'] = 'undefined' !== typeof window && window['navigator'] ? window['navigator'] : null, _0x1dc72['masterGain'] = null, _0x1dc72['noAudio'] = !0x1, _0x1dc72['usingWebAudio'] = !0x0, _0x1dc72['autoSuspend'] = !0x1, _0x1dc72['ctx'] = null, _0x1dc72['autoUnlock'] = !0x0, _0x1dc72['_setup'](), _0x1dc72;
        },
        'volume': function(_0x428cf4) {
            var _0x4a3f69 = this || _0x4e2829;
            _0x428cf4 = parseFloat(_0x428cf4), _0x4a3f69['ctx'] || _0x35fc5e();
            if ('undefined' !== typeof _0x428cf4 && 0x0 <= _0x428cf4 && 0x1 >= _0x428cf4) {
                _0x4a3f69['_volume'] = _0x428cf4;
                if (_0x4a3f69['_muted']) return _0x4a3f69;
                _0x4a3f69['usingWebAudio'] && _0x4a3f69['masterGain']['gain']['setValueAtTime'](_0x428cf4, _0x4e2829['ctx']['currentTime']);
                for (var _0x280dc8 = 0x0; _0x280dc8 < _0x4a3f69['_howls']['length']; _0x280dc8++)
                    if (!_0x4a3f69['_howls'][_0x280dc8]['_webAudio'])
                        for (var _0x145541 = _0x4a3f69['_howls'][_0x280dc8]['_getSoundIds'](), _0x20a9e2 = 0x0; _0x20a9e2 < _0x145541['length']; _0x20a9e2++) {
                            var _0x1a895f = _0x4a3f69['_howls'][_0x280dc8]['_soundById'](_0x145541[_0x20a9e2]);
                            _0x1a895f && _0x1a895f['_node'] && (_0x1a895f['_node']['volume'] = _0x1a895f['_volume'] * _0x428cf4);
                        }
                return _0x4a3f69;
            }
            return _0x4a3f69['_volume'];
        },
        'mute': function(_0x326a21) {
            var _0x22627d = this || _0x4e2829;
            _0x22627d['ctx'] || _0x35fc5e(), _0x22627d['_muted'] = _0x326a21, _0x22627d['usingWebAudio'] && _0x22627d['masterGain']['gain']['setValueAtTime'](_0x326a21 ? 0x0 : _0x22627d['_volume'], _0x4e2829['ctx']['currentTime']);
            for (var _0x1e3ab2 = 0x0; _0x1e3ab2 < _0x22627d['_howls']['length']; _0x1e3ab2++)
                if (!_0x22627d['_howls'][_0x1e3ab2]['_webAudio'])
                    for (var _0x27767b = _0x22627d['_howls'][_0x1e3ab2]['_getSoundIds'](), _0xb3d24d = 0x0; _0xb3d24d < _0x27767b['length']; _0xb3d24d++) {
                        var _0x55e1f5 = _0x22627d['_howls'][_0x1e3ab2]['_soundById'](_0x27767b[_0xb3d24d]);
                        _0x55e1f5 && _0x55e1f5['_node'] && (_0x55e1f5['_node']['muted'] = _0x326a21 ? !0x0 : _0x55e1f5['_muted']);
                    }
            return _0x22627d;
        },
        'stop': function() {
            for (var _0x1d2ef5 = this || _0x4e2829, _0x4e4a2c = 0x0; _0x4e4a2c < _0x1d2ef5['_howls']['length']; _0x4e4a2c++) _0x1d2ef5['_howls'][_0x4e4a2c]['stop']();
            return _0x1d2ef5;
        },
        'unload': function() {
            for (var _0x405e1a = this || _0x4e2829, _0x210e02 = _0x405e1a['_howls']['length'] - 0x1; 0x0 <= _0x210e02; _0x210e02--) _0x405e1a['_howls'][_0x210e02]['unload']();
            return _0x405e1a['usingWebAudio'] && _0x405e1a['ctx'] && 'undefined' !== typeof _0x405e1a['ctx']['close'] && (_0x405e1a['ctx']['close'](), _0x405e1a['ctx'] = null, _0x35fc5e()), _0x405e1a;
        },
        'codecs': function(_0x743db8) {
            return (this || _0x4e2829)['_codecs'][_0x743db8['replace'](/^x-/, '')];
        },
        '_setup': function() {
            var _0x34f414 = this || _0x4e2829;
            _0x34f414['state'] = _0x34f414['ctx'] ? _0x34f414['ctx']['state'] || 'suspended' : 'suspended', _0x34f414['_autoSuspend']();
            if (!_0x34f414['usingWebAudio']) {
                if ('undefined' !== typeof Audio) try {
                    var _0xa57b4b = new Audio();
                    'undefined' === typeof _0xa57b4b['oncanplaythrough'] && (_0x34f414['_canPlayEvent'] = 'canplay');
                } catch (_0xa8301a) {
                    _0x34f414['noAudio'] = !0x0;
                } else _0x34f414['noAudio'] = !0x0;
            }
            try {
                _0xa57b4b = new Audio(), _0xa57b4b['muted'] && (_0x34f414['noAudio'] = !0x0);
            } catch (_0x41c6ae) {}
            return _0x34f414['noAudio'] || _0x34f414['_setupCodecs'](), _0x34f414;
        },
        '_setupCodecs': function() {
            var _0x49ebbc = this || _0x4e2829,
                _0x115a4c = null;
            try {
                _0x115a4c = 'undefined' !== typeof Audio ? new Audio() : null;
            } catch (_0x5d34ea) {
                return _0x49ebbc;
            }
            if (!_0x115a4c || 'function' !== typeof _0x115a4c['canPlayType']) return _0x49ebbc;
            var _0x3b160d = _0x115a4c['canPlayType']('audio/mpeg;')['replace'](/^no$/, ''),
                _0x470c63 = _0x49ebbc['_navigator'] && _0x49ebbc['_navigator']['userAgent']['match'](/OPR\/([0-6].)/g),
                _0x470c63 = _0x470c63 && 0x21 > parseInt(_0x470c63[0x0]['split']('/')[0x1], 0xa);
            return _0x49ebbc['_codecs'] = {
                'mp3': !(_0x470c63 || !_0x3b160d && !_0x115a4c['canPlayType']('audio/mp3;')['replace'](/^no$/, '')),
                'mpeg': !!_0x3b160d,
                'opus': !!_0x115a4c['canPlayType']('audio/ogg;\x20codecs=\x22opus\x22')['replace'](/^no$/, ''),
                'ogg': !!_0x115a4c['canPlayType']('audio/ogg;\x20codecs=\x22vorbis\x22')['replace'](/^no$/, ''),
                'oga': !!_0x115a4c['canPlayType']('audio/ogg;\x20codecs=\x22vorbis\x22')['replace'](/^no$/, ''),
                'wav': !!_0x115a4c['canPlayType']('audio/wav;\x20codecs=\x221\x22')['replace'](/^no$/, ''),
                'aac': !!_0x115a4c['canPlayType']('audio/aac;')['replace'](/^no$/, ''),
                'caf': !!_0x115a4c['canPlayType']('audio/x-caf;')['replace'](/^no$/, ''),
                'm4a': !!(_0x115a4c['canPlayType']('audio/x-m4a;') || _0x115a4c['canPlayType']('audio/m4a;') || _0x115a4c['canPlayType']('audio/aac;'))['replace'](/^no$/, ''),
                'm4b': !!(_0x115a4c['canPlayType']('audio/x-m4b;') || _0x115a4c['canPlayType']('audio/m4b;') || _0x115a4c['canPlayType']('audio/aac;'))['replace'](/^no$/, ''),
                'mp4': !!(_0x115a4c['canPlayType']('audio/x-mp4;') || _0x115a4c['canPlayType']('audio/mp4;') || _0x115a4c['canPlayType']('audio/aac;'))['replace'](/^no$/, ''),
                'weba': !!_0x115a4c['canPlayType']('audio/webm;\x20codecs=\x22vorbis\x22')['replace'](/^no$/, ''),
                'webm': !!_0x115a4c['canPlayType']('audio/webm;\x20codecs=\x22vorbis\x22')['replace'](/^no$/, ''),
                'dolby': !!_0x115a4c['canPlayType']('audio/mp4;\x20codecs=\x22ec-3\x22')['replace'](/^no$/, ''),
                'flac': !!(_0x115a4c['canPlayType']('audio/x-flac;') || _0x115a4c['canPlayType']('audio/flac;'))['replace'](/^no$/, '')
            }, _0x49ebbc;
        },
        '_unlockAudio': function() {
            var _0xe2bd7b = this || _0x4e2829;
            if (!_0xe2bd7b['_audioUnlocked'] && _0xe2bd7b['ctx']) {
                _0xe2bd7b['_audioUnlocked'] = !0x1, _0xe2bd7b['autoUnlock'] = !0x1, !_0xe2bd7b['_mobileUnloaded'] && 0xac44 !== _0xe2bd7b['ctx']['sampleRate'] && (_0xe2bd7b['_mobileUnloaded'] = !0x0, _0xe2bd7b['unload']()), _0xe2bd7b['_scratchBuffer'] = _0xe2bd7b['ctx']['createBuffer'](0x1, 0x1, 0x5622);
                var _0x3dcaef = function() {
                    for (; _0xe2bd7b['_html5AudioPool']['length'] < _0xe2bd7b['html5PoolSize'];) try {
                        var _0x18e033 = new Audio();
                        _0x18e033['_unlocked'] = !0x0, _0xe2bd7b['_releaseHtml5Audio'](_0x18e033);
                    } catch (_0x8dfa84) {
                        _0xe2bd7b['noAudio'] = !0x0;
                        break;
                    }
                    for (_0x18e033 = 0x0; _0x18e033 < _0xe2bd7b['_howls']['length']; _0x18e033++)
                        if (!_0xe2bd7b['_howls'][_0x18e033]['_webAudio'])
                            for (var _0x2c7475 = _0xe2bd7b['_howls'][_0x18e033]['_getSoundIds'](), _0x4b6719 = 0x0; _0x4b6719 < _0x2c7475['length']; _0x4b6719++) {
                                var _0x236b86 = _0xe2bd7b['_howls'][_0x18e033]['_soundById'](_0x2c7475[_0x4b6719]);
                                _0x236b86 && _0x236b86['_node'] && !_0x236b86['_node']['_unlocked'] && (_0x236b86['_node']['_unlocked'] = !0x0, _0x236b86['_node']['load']());
                            }
                    _0xe2bd7b['_autoResume']();
                    var _0x49788f = _0xe2bd7b['ctx']['createBufferSource']();
                    _0x49788f['buffer'] = _0xe2bd7b['_scratchBuffer'], _0x49788f['connect'](_0xe2bd7b['ctx']['destination']), 'undefined' === typeof _0x49788f['start'] ? _0x49788f['noteOn'](0x0) : _0x49788f['start'](0x0), 'function' === typeof _0xe2bd7b['ctx']['resume'] && _0xe2bd7b['ctx']['resume'](), _0x49788f['onended'] = function() {
                        _0x49788f['disconnect'](0x0), _0xe2bd7b['_audioUnlocked'] = !0x0, document['removeEventListener']('touchstart', _0x3dcaef, !0x0), document['removeEventListener']('touchend', _0x3dcaef, !0x0), document['removeEventListener']('click', _0x3dcaef, !0x0);
                        for (var _0x12fd74 = 0x0; _0x12fd74 < _0xe2bd7b['_howls']['length']; _0x12fd74++) _0xe2bd7b['_howls'][_0x12fd74]['_emit']('unlock');
                    };
                };
                return document['addEventListener']('touchstart', _0x3dcaef, !0x0), document['addEventListener']('touchend', _0x3dcaef, !0x0), document['addEventListener']('click', _0x3dcaef, !0x0), _0xe2bd7b;
            }
        },
        '_obtainHtml5Audio': function() {
            var _0x5806e5 = this || _0x4e2829;
            if (_0x5806e5['_html5AudioPool']['length']) return _0x5806e5['_html5AudioPool']['pop']();
            return (_0x5806e5 = new Audio()['play']()) && 'undefined' !== typeof Promise && (_0x5806e5 instanceof Promise || 'function' === typeof _0x5806e5['then']) && _0x5806e5['catch'](function() {
                console['warn']('HTML5\x20Audio\x20pool\x20exhausted,\x20returning\x20potentially\x20locked\x20audio\x20object.');
            }), new Audio();
        },
        '_releaseHtml5Audio': function(_0x6131fe) {
            var _0x17fc03 = this || _0x4e2829;
            return _0x6131fe['_unlocked'] && _0x17fc03['_html5AudioPool']['push'](_0x6131fe), _0x17fc03;
        },
        '_autoSuspend': function() {
            var _0x51b217 = this;
            if (_0x51b217['autoSuspend'] && _0x51b217['ctx'] && 'undefined' !== typeof _0x51b217['ctx']['suspend'] && _0x4e2829['usingWebAudio']) {
                for (var _0x1fc73f = 0x0; _0x1fc73f < _0x51b217['_howls']['length']; _0x1fc73f++)
                    if (_0x51b217['_howls'][_0x1fc73f]['_webAudio']) {
                        for (var _0x1099a8 = 0x0; _0x1099a8 < _0x51b217['_howls'][_0x1fc73f]['_sounds']['length']; _0x1099a8++)
                            if (!_0x51b217['_howls'][_0x1fc73f]['_sounds'][_0x1099a8]['_paused']) return _0x51b217;
                    }
                return _0x51b217['_suspendTimer'] && clearTimeout(_0x51b217['_suspendTimer']), _0x51b217['_suspendTimer'] = setTimeout(function() {
                    if (_0x51b217['autoSuspend']) {
                        _0x51b217['_suspendTimer'] = null, _0x51b217['state'] = 'suspending';
                        var _0x3d4888 = function() {
                            _0x51b217['state'] = 'suspended', _0x51b217['_resumeAfterSuspend'] && (delete _0x51b217['_resumeAfterSuspend'], _0x51b217['_autoResume']());
                        };
                        _0x51b217['ctx']['suspend']()['then'](_0x3d4888, _0x3d4888);
                    }
                }, 0x7530), _0x51b217;
            }
        },
        '_autoResume': function() {
            var _0x13397f = this;
            if (_0x13397f['ctx'] && 'undefined' !== typeof _0x13397f['ctx']['resume'] && _0x4e2829['usingWebAudio']) return 'running' === _0x13397f['state'] && 'interrupted' !== _0x13397f['ctx']['state'] && _0x13397f['_suspendTimer'] ? (clearTimeout(_0x13397f['_suspendTimer']), _0x13397f['_suspendTimer'] = null) : 'suspended' === _0x13397f['state'] || 'running' === _0x13397f['state'] && 'interrupted' === _0x13397f['ctx']['state'] ? (_0x13397f['ctx']['resume']()['then'](function() {
                _0x13397f['state'] = 'running';
                for (var _0x2ab0df = 0x0; _0x2ab0df < _0x13397f['_howls']['length']; _0x2ab0df++) _0x13397f['_howls'][_0x2ab0df]['_emit']('resume');
            }), _0x13397f['_suspendTimer'] && (clearTimeout(_0x13397f['_suspendTimer']), _0x13397f['_suspendTimer'] = null)) : 'suspending' === _0x13397f['state'] && (_0x13397f['_resumeAfterSuspend'] = !0x0), _0x13397f;
        }
    };
    var _0x4e2829 = new _0x1325c5(),
        _0x1a71df = function(_0x1e6f1c) {
            !_0x1e6f1c['src'] || 0x0 === _0x1e6f1c['src']['length'] ? console['error']('An\x20array\x20of\x20source\x20files\x20must\x20be\x20passed\x20with\x20any\x20new\x20Howl.') : this['init'](_0x1e6f1c);
        };
    _0x1a71df['prototype'] = {
        'init': function(_0x337d25) {
            var _0x45af52 = this;
            return _0x4e2829['ctx'] || _0x35fc5e(), _0x45af52['_autoplay'] = _0x337d25['autoplay'] || !0x1, _0x45af52['_format'] = 'string' !== typeof _0x337d25['format'] ? _0x337d25['format'] : [_0x337d25['format']], _0x45af52['_html5'] = _0x337d25['html5'] || !0x1, _0x45af52['_muted'] = _0x337d25['mute'] || !0x1, _0x45af52['_loop'] = _0x337d25['loop'] || !0x1, _0x45af52['_pool'] = _0x337d25['pool'] || 0x5, _0x45af52['_preload'] = 'boolean' === typeof _0x337d25['preload'] || 'metadata' === _0x337d25['preload'] ? _0x337d25['preload'] : !0x0, _0x45af52['_rate'] = _0x337d25['rate'] || 0x1, _0x45af52['_sprite'] = _0x337d25['sprite'] || {}, _0x45af52['_src'] = 'string' !== typeof _0x337d25['src'] ? _0x337d25['src'] : [_0x337d25['src']], _0x45af52['_volume'] = void 0x0 !== _0x337d25['volume'] ? _0x337d25['volume'] : 0x1, _0x45af52['_xhr'] = {
                'method': _0x337d25['xhr'] && _0x337d25['xhr']['method'] ? _0x337d25['xhr']['method'] : 'GET',
                'headers': _0x337d25['xhr'] && _0x337d25['xhr']['headers'] ? _0x337d25['xhr']['headers'] : null,
                'withCredentials': _0x337d25['xhr'] && _0x337d25['xhr']['withCredentials'] ? _0x337d25['xhr']['withCredentials'] : !0x1
            }, _0x45af52['_duration'] = 0x0, _0x45af52['_state'] = 'unloaded', _0x45af52['_sounds'] = [], _0x45af52['_endTimers'] = {}, _0x45af52['_queue'] = [], _0x45af52['_playLock'] = !0x1, _0x45af52['_onend'] = _0x337d25['onend'] ? [{
                'fn': _0x337d25['onend']
            }] : [], _0x45af52['_onfade'] = _0x337d25['onfade'] ? [{
                'fn': _0x337d25['onfade']
            }] : [], _0x45af52['_onload'] = _0x337d25['onload'] ? [{
                'fn': _0x337d25['onload']
            }] : [], _0x45af52['_onloaderror'] = _0x337d25['onloaderror'] ? [{
                'fn': _0x337d25['onloaderror']
            }] : [], _0x45af52['_onplayerror'] = _0x337d25['onplayerror'] ? [{
                'fn': _0x337d25['onplayerror']
            }] : [], _0x45af52['_onpause'] = _0x337d25['onpause'] ? [{
                'fn': _0x337d25['onpause']
            }] : [], _0x45af52['_onplay'] = _0x337d25['onplay'] ? [{
                'fn': _0x337d25['onplay']
            }] : [], _0x45af52['_onstop'] = _0x337d25['onstop'] ? [{
                'fn': _0x337d25['onstop']
            }] : [], _0x45af52['_onmute'] = _0x337d25['onmute'] ? [{
                'fn': _0x337d25['onmute']
            }] : [], _0x45af52['_onvolume'] = _0x337d25['onvolume'] ? [{
                'fn': _0x337d25['onvolume']
            }] : [], _0x45af52['_onrate'] = _0x337d25['onrate'] ? [{
                'fn': _0x337d25['onrate']
            }] : [], _0x45af52['_onseek'] = _0x337d25['onseek'] ? [{
                'fn': _0x337d25['onseek']
            }] : [], _0x45af52['_onunlock'] = _0x337d25['onunlock'] ? [{
                'fn': _0x337d25['onunlock']
            }] : [], _0x45af52['_onresume'] = [], _0x45af52['_webAudio'] = _0x4e2829['usingWebAudio'] && !_0x45af52['_html5'], 'undefined' !== typeof _0x4e2829['ctx'] && _0x4e2829['ctx'] && _0x4e2829['autoUnlock'] && _0x4e2829['_unlockAudio'](), _0x4e2829['_howls']['push'](_0x45af52), _0x45af52['_autoplay'] && _0x45af52['_queue']['push']({
                'event': 'play',
                'action': function() {
                    _0x45af52['play']();
                }
            }), _0x45af52['_preload'] && 'none' !== _0x45af52['_preload'] && _0x45af52['load'](), _0x45af52;
        },
        'load': function() {
            var _0x3fe04d = null;
            if (_0x4e2829['noAudio']) this['_emit']('loaderror', null, 'No\x20audio\x20support.');
            else {
                'string' === typeof this['_src'] && (this['_src'] = [this['_src']]);
                for (var _0x32b2ac = 0x0; _0x32b2ac < this['_src']['length']; _0x32b2ac++) {
                    var _0x4e6780, _0x42626f;
                    if (this['_format'] && this['_format'][_0x32b2ac]) _0x4e6780 = this['_format'][_0x32b2ac];
                    else {
                        _0x42626f = this['_src'][_0x32b2ac];
                        if ('string' !== typeof _0x42626f) {
                            this['_emit']('loaderror', null, 'Non-string\x20found\x20in\x20selected\x20audio\x20sources\x20-\x20ignoring.');
                            continue;
                        }(_0x4e6780 = /^data:audio\/([^;,]+);/i ['exec'](_0x42626f)) || (_0x4e6780 = /\.([^.]+)$/ ['exec'](_0x42626f['split']('?', 0x1)[0x0])), _0x4e6780 && (_0x4e6780 = _0x4e6780[0x1]['toLowerCase']());
                    }
                    _0x4e6780 || console['warn']('No\x20file\x20extension\x20was\x20found.\x20Consider\x20using\x20the\x20\x22format\x22\x20property\x20or\x20specify\x20an\x20extension.');
                    if (_0x4e6780 && _0x4e2829['codecs'](_0x4e6780)) {
                        _0x3fe04d = this['_src'][_0x32b2ac];
                        break;
                    }
                }
                if (_0x3fe04d) {
                    this['_src'] = _0x3fe04d, this['_state'] = 'loading', 'https:' === window['location']['protocol'] && 'http:' === _0x3fe04d['slice'](0x0, 0x5) && (this['_html5'] = !0x0, this['_webAudio'] = !0x1), new _0xc9b612(this);
                    if (this['_webAudio']) {
                        var _0x329e97 = this,
                            _0x4542fd = _0x329e97['_src'];
                        if (_0xc57a3b[_0x4542fd]) _0x329e97['_duration'] = _0xc57a3b[_0x4542fd]['duration'], _0xb651a9(_0x329e97);
                        else {
                            if (/^data:[^;]+;base64,/ ['test'](_0x4542fd)) {
                                _0x3fe04d = atob(_0x4542fd['split'](',')[0x1]), _0x32b2ac = new Uint8Array(_0x3fe04d['length']);
                                for (_0x4e6780 = 0x0; _0x4e6780 < _0x3fe04d['length']; ++_0x4e6780) _0x32b2ac[_0x4e6780] = _0x3fe04d['charCodeAt'](_0x4e6780);
                                _0x5e9293(_0x32b2ac['buffer'], _0x329e97);
                            } else {
                                var _0x304b15 = new XMLHttpRequest();
                                _0x304b15['open'](_0x329e97['_xhr']['method'], _0x4542fd, !0x0), _0x304b15['withCredentials'] = _0x329e97['_xhr']['withCredentials'], _0x304b15['responseType'] = 'arraybuffer', _0x329e97['_xhr']['headers'] && Object['keys'](_0x329e97['_xhr']['headers'])['forEach'](function(_0x4714af) {
                                    _0x304b15['setRequestHeader'](_0x4714af, _0x329e97['_xhr']['headers'][_0x4714af]);
                                }), _0x304b15['onload'] = function() {
                                    var _0x4c7f45 = (_0x304b15['status'] + '')[0x0];
                                    '0' !== _0x4c7f45 && '2' !== _0x4c7f45 && '3' !== _0x4c7f45 ? _0x329e97['_emit']('loaderror', null, 'Failed\x20loading\x20audio\x20file\x20with\x20status:\x20' + _0x304b15['status'] + '.') : _0x5e9293(_0x304b15['response'], _0x329e97);
                                }, _0x304b15['onerror'] = function() {
                                    _0x329e97['_webAudio'] && (_0x329e97['_html5'] = !0x0, _0x329e97['_webAudio'] = !0x1, _0x329e97['_sounds'] = [], delete _0xc57a3b[_0x4542fd], _0x329e97['load']());
                                };
                                try {
                                    _0x304b15['send']();
                                } catch (_0x2a2a72) {
                                    _0x304b15['onerror']();
                                }
                            }
                        }
                    }
                    return this;
                }
                this['_emit']('loaderror', null, 'No\x20codec\x20support\x20for\x20selected\x20audio\x20sources.');
            }
        },
        'play': function(_0x47c0f7, _0x1abf77) {
            var _0x1e07c0 = this,
                _0x16650e = null;
            if ('number' === typeof _0x47c0f7) _0x16650e = _0x47c0f7, _0x47c0f7 = null;
            else {
                if ('string' === typeof _0x47c0f7 && 'loaded' === _0x1e07c0['_state'] && !_0x1e07c0['_sprite'][_0x47c0f7]) return null;
                if ('undefined' === typeof _0x47c0f7 && (_0x47c0f7 = '__default', !_0x1e07c0['_playLock'])) {
                    for (var _0xe1ac62 = 0x0, _0xeaff71 = 0x0; _0xeaff71 < _0x1e07c0['_sounds']['length']; _0xeaff71++) _0x1e07c0['_sounds'][_0xeaff71]['_paused'] && !_0x1e07c0['_sounds'][_0xeaff71]['_ended'] && (_0xe1ac62++, _0x16650e = _0x1e07c0['_sounds'][_0xeaff71]['_id']);
                    0x1 === _0xe1ac62 ? _0x47c0f7 = null : _0x16650e = null;
                }
            }
            var _0x1fc48e = _0x16650e ? _0x1e07c0['_soundById'](_0x16650e) : _0x1e07c0['_inactiveSound']();
            if (!_0x1fc48e) return null;
            _0x16650e && !_0x47c0f7 && (_0x47c0f7 = _0x1fc48e['_sprite'] || '__default');
            if ('loaded' !== _0x1e07c0['_state']) {
                _0x1fc48e['_sprite'] = _0x47c0f7, _0x1fc48e['_ended'] = !0x1;
                var _0xd656e4 = _0x1fc48e['_id'];
                return _0x1e07c0['_queue']['push']({
                    'event': 'play',
                    'action': function() {
                        _0x1e07c0['play'](_0xd656e4);
                    }
                }), _0xd656e4;
            }
            if (_0x16650e && !_0x1fc48e['_paused']) return _0x1abf77 || _0x1e07c0['_loadQueue']('play'), _0x1fc48e['_id'];
            _0x1e07c0['_webAudio'] && _0x4e2829['_autoResume']();
            var _0x3883ec = Math['max'](0x0, 0x0 < _0x1fc48e['_seek'] ? _0x1fc48e['_seek'] : _0x1e07c0['_sprite'][_0x47c0f7][0x0] / 0x3e8),
                _0x1fa46a = Math['max'](0x0, (_0x1e07c0['_sprite'][_0x47c0f7][0x0] + _0x1e07c0['_sprite'][_0x47c0f7][0x1]) / 0x3e8 - _0x3883ec),
                _0x230904 = 0x3e8 * _0x1fa46a / Math['abs'](_0x1fc48e['_rate']),
                _0x33172d = _0x1e07c0['_sprite'][_0x47c0f7][0x0] / 0x3e8,
                _0x3b6404 = (_0x1e07c0['_sprite'][_0x47c0f7][0x0] + _0x1e07c0['_sprite'][_0x47c0f7][0x1]) / 0x3e8;
            _0x1fc48e['_sprite'] = _0x47c0f7, _0x1fc48e['_ended'] = !0x1;
            var _0x537b24 = function() {
                _0x1fc48e['_paused'] = !0x1, _0x1fc48e['_seek'] = _0x3883ec, _0x1fc48e['_start'] = _0x33172d, _0x1fc48e['_stop'] = _0x3b6404, _0x1fc48e['_loop'] = !(!_0x1fc48e['_loop'] && !_0x1e07c0['_sprite'][_0x47c0f7][0x2]);
            };
            if (_0x3883ec >= _0x3b6404) _0x1e07c0['_ended'](_0x1fc48e);
            else {
                var _0xbdf812 = _0x1fc48e['_node'];
                if (_0x1e07c0['_webAudio']) _0x16650e = function() {
                    _0x1e07c0['_playLock'] = !0x1, _0x537b24(), _0x1e07c0['_refreshBuffer'](_0x1fc48e), _0xbdf812['gain']['setValueAtTime'](_0x1fc48e['_muted'] || _0x1e07c0['_muted'] ? 0x0 : _0x1fc48e['_volume'], _0x4e2829['ctx']['currentTime']), _0x1fc48e['_playStart'] = _0x4e2829['ctx']['currentTime'], 'undefined' === typeof _0xbdf812['bufferSource']['start'] ? _0x1fc48e['_loop'] ? _0xbdf812['bufferSource']['noteGrainOn'](0x0, _0x3883ec, 0x15180) : _0xbdf812['bufferSource']['noteGrainOn'](0x0, _0x3883ec, _0x1fa46a) : _0x1fc48e['_loop'] ? _0xbdf812['bufferSource']['start'](0x0, _0x3883ec, 0x15180) : _0xbdf812['bufferSource']['start'](0x0, _0x3883ec, _0x1fa46a), Infinity !== _0x230904 && (_0x1e07c0['_endTimers'][_0x1fc48e['_id']] = setTimeout(_0x1e07c0['_ended']['bind'](_0x1e07c0, _0x1fc48e), _0x230904)), _0x1abf77 || setTimeout(function() {
                        _0x1e07c0['_emit']('play', _0x1fc48e['_id']), _0x1e07c0['_loadQueue']();
                    }, 0x0);
                }, 'running' === _0x4e2829['state'] && 'interrupted' !== _0x4e2829['ctx']['state'] ? _0x16650e() : (_0x1e07c0['_playLock'] = !0x0, _0x1e07c0['once']('resume', _0x16650e), _0x1e07c0['_clearTimer'](_0x1fc48e['_id']));
                else {
                    var _0x4849b6 = function() {
                        _0xbdf812['currentTime'] = _0x3883ec, _0xbdf812['muted'] = _0x1fc48e['_muted'] || _0x1e07c0['_muted'] || _0x4e2829['_muted'] || _0xbdf812['muted'], _0xbdf812['volume'] = _0x1fc48e['_volume'] * _0x4e2829['volume'](), _0xbdf812['playbackRate'] = _0x1fc48e['_rate'];
                        try {
                            var _0x2747a3 = _0xbdf812['play']();
                            _0x2747a3 && 'undefined' !== typeof Promise && (_0x2747a3 instanceof Promise || 'function' === typeof _0x2747a3['then']) ? (_0x1e07c0['_playLock'] = !0x0, _0x537b24(), _0x2747a3['then'](function() {
                                _0x1e07c0['_playLock'] = !0x1, _0xbdf812['_unlocked'] = !0x0, _0x1abf77 || (_0x1e07c0['_emit']('play', _0x1fc48e['_id']), _0x1e07c0['_loadQueue']());
                            })['catch'](function() {
                                _0x1e07c0['_playLock'] = !0x1, _0x1e07c0['_emit']('playerror', _0x1fc48e['_id'], 'Playback\x20was\x20unable\x20to\x20start.\x20This\x20is\x20most\x20commonly\x20an\x20issue\x20on\x20mobile\x20devices\x20and\x20Chrome\x20where\x20playback\x20was\x20not\x20within\x20a\x20user\x20interaction.'), _0x1fc48e['_ended'] = !0x0, _0x1fc48e['_paused'] = !0x0;
                            })) : _0x1abf77 || (_0x1e07c0['_playLock'] = !0x1, _0x537b24(), _0x1e07c0['_emit']('play', _0x1fc48e['_id']), _0x1e07c0['_loadQueue']()), _0xbdf812['playbackRate'] = _0x1fc48e['_rate'], _0xbdf812['paused'] ? _0x1e07c0['_emit']('playerror', _0x1fc48e['_id'], 'Playback\x20was\x20unable\x20to\x20start.\x20This\x20is\x20most\x20commonly\x20an\x20issue\x20on\x20mobile\x20devices\x20and\x20Chrome\x20where\x20playback\x20was\x20not\x20within\x20a\x20user\x20interaction.') : '__default' !== _0x47c0f7 || _0x1fc48e['_loop'] ? _0x1e07c0['_endTimers'][_0x1fc48e['_id']] = setTimeout(_0x1e07c0['_ended']['bind'](_0x1e07c0, _0x1fc48e), _0x230904) : (_0x1e07c0['_endTimers'][_0x1fc48e['_id']] = function() {
                                _0x1e07c0['_ended'](_0x1fc48e), _0xbdf812['removeEventListener']('ended', _0x1e07c0['_endTimers'][_0x1fc48e['_id']], !0x1);
                            }, _0xbdf812['addEventListener']('ended', _0x1e07c0['_endTimers'][_0x1fc48e['_id']], !0x1));
                        } catch (_0xef66b) {
                            _0x1e07c0['_emit']('playerror', _0x1fc48e['_id'], _0xef66b);
                        }
                    };
                    'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA' === _0xbdf812['src'] && (_0xbdf812['src'] = _0x1e07c0['_src'], _0xbdf812['load']()), _0x16650e = window && window['ejecta'] || !_0xbdf812['readyState'] && _0x4e2829['_navigator']['isCocoonJS'];
                    if (0x3 <= _0xbdf812['readyState'] || _0x16650e) _0x4849b6();
                    else {
                        _0x1e07c0['_playLock'] = !0x0;
                        var _0xe8f575 = function() {
                            _0x4849b6(), _0xbdf812['removeEventListener'](_0x4e2829['_canPlayEvent'], _0xe8f575, !0x1);
                        };
                        _0xbdf812['addEventListener'](_0x4e2829['_canPlayEvent'], _0xe8f575, !0x1), _0x1e07c0['_clearTimer'](_0x1fc48e['_id']);
                    }
                }
                return _0x1fc48e['_id'];
            }
        },
        'pause': function(_0x10dcb8, _0x4b770a) {
            var _0x3b5e55 = this;
            if ('loaded' !== _0x3b5e55['_state'] || _0x3b5e55['_playLock']) return _0x3b5e55['_queue']['push']({
                'event': 'pause',
                'action': function() {
                    _0x3b5e55['pause'](_0x10dcb8);
                }
            }), _0x3b5e55;
            for (var _0x202457 = _0x3b5e55['_getSoundIds'](_0x10dcb8), _0x1a0ece = 0x0; _0x1a0ece < _0x202457['length']; _0x1a0ece++) {
                _0x3b5e55['_clearTimer'](_0x202457[_0x1a0ece]);
                var _0x205aac = _0x3b5e55['_soundById'](_0x202457[_0x1a0ece]);
                if (_0x205aac && !_0x205aac['_paused'] && (_0x205aac['_seek'] = _0x3b5e55['seek'](_0x202457[_0x1a0ece]), _0x205aac['_rateSeek'] = 0x0, _0x205aac['_paused'] = !0x0, _0x3b5e55['_stopFade'](_0x202457[_0x1a0ece]), _0x205aac['_node'])) {
                    if (_0x3b5e55['_webAudio']) {
                        if (!_0x205aac['_node']['bufferSource']) continue;
                        'undefined' === typeof _0x205aac['_node']['bufferSource']['stop'] ? _0x205aac['_node']['bufferSource']['noteOff'](0x0) : _0x205aac['_node']['bufferSource']['stop'](0x0), _0x3b5e55['_cleanBuffer'](_0x205aac['_node']);
                    } else(!isNaN(_0x205aac['_node']['duration']) || Infinity === _0x205aac['_node']['duration']) && _0x205aac['_node']['pause']();
                }
                _0x4b770a || _0x3b5e55['_emit']('pause', _0x205aac ? _0x205aac['_id'] : null);
            }
            return _0x3b5e55;
        },
        'stop': function(_0x55a65f, _0x4b6a56) {
            var _0x5a91d5 = this;
            if ('loaded' !== _0x5a91d5['_state'] || _0x5a91d5['_playLock']) return _0x5a91d5['_queue']['push']({
                'event': 'stop',
                'action': function() {
                    _0x5a91d5['stop'](_0x55a65f);
                }
            }), _0x5a91d5;
            for (var _0x3d1dd4 = _0x5a91d5['_getSoundIds'](_0x55a65f), _0x558772 = 0x0; _0x558772 < _0x3d1dd4['length']; _0x558772++) {
                _0x5a91d5['_clearTimer'](_0x3d1dd4[_0x558772]);
                var _0x52c9e1 = _0x5a91d5['_soundById'](_0x3d1dd4[_0x558772]);
                if (_0x52c9e1) {
                    _0x52c9e1['_seek'] = _0x52c9e1['_start'] || 0x0, _0x52c9e1['_rateSeek'] = 0x0, _0x52c9e1['_paused'] = !0x0, _0x52c9e1['_ended'] = !0x0, _0x5a91d5['_stopFade'](_0x3d1dd4[_0x558772]);
                    if (_0x52c9e1['_node']) {
                        if (_0x5a91d5['_webAudio']) _0x52c9e1['_node']['bufferSource'] && ('undefined' === typeof _0x52c9e1['_node']['bufferSource']['stop'] ? _0x52c9e1['_node']['bufferSource']['noteOff'](0x0) : _0x52c9e1['_node']['bufferSource']['stop'](0x0), _0x5a91d5['_cleanBuffer'](_0x52c9e1['_node']));
                        else {
                            if (!isNaN(_0x52c9e1['_node']['duration']) || Infinity === _0x52c9e1['_node']['duration']) _0x52c9e1['_node']['currentTime'] = _0x52c9e1['_start'] || 0x0, _0x52c9e1['_node']['pause'](), Infinity === _0x52c9e1['_node']['duration'] && _0x5a91d5['_clearSound'](_0x52c9e1['_node']);
                        }
                    }
                    _0x4b6a56 || _0x5a91d5['_emit']('stop', _0x52c9e1['_id']);
                }
            }
            return _0x5a91d5;
        },
        'mute': function(_0x1ccf43, _0x5412e8) {
            var _0x305ae2 = this;
            if ('loaded' !== _0x305ae2['_state'] || _0x305ae2['_playLock']) return _0x305ae2['_queue']['push']({
                'event': 'mute',
                'action': function() {
                    _0x305ae2['mute'](_0x1ccf43, _0x5412e8);
                }
            }), _0x305ae2;
            if ('undefined' === typeof _0x5412e8) {
                if ('boolean' === typeof _0x1ccf43) _0x305ae2['_muted'] = _0x1ccf43;
                else return _0x305ae2['_muted'];
            }
            for (var _0x2daed3 = _0x305ae2['_getSoundIds'](_0x5412e8), _0x2caa6e = 0x0; _0x2caa6e < _0x2daed3['length']; _0x2caa6e++) {
                var _0xff5a2b = _0x305ae2['_soundById'](_0x2daed3[_0x2caa6e]);
                _0xff5a2b && (_0xff5a2b['_muted'] = _0x1ccf43, _0xff5a2b['_interval'] && _0x305ae2['_stopFade'](_0xff5a2b['_id']), _0x305ae2['_webAudio'] && _0xff5a2b['_node'] ? _0xff5a2b['_node']['gain']['setValueAtTime'](_0x1ccf43 ? 0x0 : _0xff5a2b['_volume'], _0x4e2829['ctx']['currentTime']) : _0xff5a2b['_node'] && (_0xff5a2b['_node']['muted'] = _0x4e2829['_muted'] ? !0x0 : _0x1ccf43), _0x305ae2['_emit']('mute', _0xff5a2b['_id']));
            }
            return _0x305ae2;
        },
        'volume': function() {
            var _0x4257b7 = this,
                _0x2189fa = arguments,
                _0x38ba8b, _0x46327c;
            if (0x0 === _0x2189fa['length']) return _0x4257b7['_volume'];
            0x1 === _0x2189fa['length'] || 0x2 === _0x2189fa['length'] && 'undefined' === typeof _0x2189fa[0x1] ? 0x0 <= _0x4257b7['_getSoundIds']()['indexOf'](_0x2189fa[0x0]) ? _0x46327c = parseInt(_0x2189fa[0x0], 0xa) : _0x38ba8b = parseFloat(_0x2189fa[0x0]) : 0x2 <= _0x2189fa['length'] && (_0x38ba8b = parseFloat(_0x2189fa[0x0]), _0x46327c = parseInt(_0x2189fa[0x1], 0xa));
            var _0x4164cd;
            if ('undefined' !== typeof _0x38ba8b && 0x0 <= _0x38ba8b && 0x1 >= _0x38ba8b) {
                if ('loaded' !== _0x4257b7['_state'] || _0x4257b7['_playLock']) return _0x4257b7['_queue']['push']({
                    'event': 'volume',
                    'action': function() {
                        _0x4257b7['volume']['apply'](_0x4257b7, _0x2189fa);
                    }
                }), _0x4257b7;
                'undefined' === typeof _0x46327c && (_0x4257b7['_volume'] = _0x38ba8b), _0x46327c = _0x4257b7['_getSoundIds'](_0x46327c);
                for (var _0x3f0dab = 0x0; _0x3f0dab < _0x46327c['length']; _0x3f0dab++)
                    if (_0x4164cd = _0x4257b7['_soundById'](_0x46327c[_0x3f0dab])) _0x4164cd['_volume'] = _0x38ba8b, _0x2189fa[0x2] || _0x4257b7['_stopFade'](_0x46327c[_0x3f0dab]), _0x4257b7['_webAudio'] && _0x4164cd['_node'] && !_0x4164cd['_muted'] ? _0x4164cd['_node']['gain']['setValueAtTime'](_0x38ba8b, _0x4e2829['ctx']['currentTime']) : _0x4164cd['_node'] && !_0x4164cd['_muted'] && (_0x4164cd['_node']['volume'] = _0x38ba8b * _0x4e2829['volume']()), _0x4257b7['_emit']('volume', _0x4164cd['_id']);
            } else return (_0x4164cd = _0x46327c ? _0x4257b7['_soundById'](_0x46327c) : _0x4257b7['_sounds'][0x0]) ? _0x4164cd['_volume'] : 0x0;
            return _0x4257b7;
        },
        'fade': function(_0x1b42c4, _0x4bc45a, _0x3c65f4, _0x3de630) {
            var _0x3ddbaf = this;
            if ('loaded' !== _0x3ddbaf['_state'] || _0x3ddbaf['_playLock']) return _0x3ddbaf['_queue']['push']({
                'event': 'fade',
                'action': function() {
                    _0x3ddbaf['fade'](_0x1b42c4, _0x4bc45a, _0x3c65f4, _0x3de630);
                }
            }), _0x3ddbaf;
            _0x1b42c4 = Math['min'](Math['max'](0x0, parseFloat(_0x1b42c4)), 0x1), _0x4bc45a = Math['min'](Math['max'](0x0, parseFloat(_0x4bc45a)), 0x1), _0x3c65f4 = parseFloat(_0x3c65f4), _0x3ddbaf['volume'](_0x1b42c4, _0x3de630);
            for (var _0x3b536e = _0x3ddbaf['_getSoundIds'](_0x3de630), _0x136dbd = 0x0; _0x136dbd < _0x3b536e['length']; _0x136dbd++) {
                var _0x3dfb6b = _0x3ddbaf['_soundById'](_0x3b536e[_0x136dbd]);
                if (_0x3dfb6b) {
                    _0x3de630 || _0x3ddbaf['_stopFade'](_0x3b536e[_0x136dbd]);
                    if (_0x3ddbaf['_webAudio'] && !_0x3dfb6b['_muted']) {
                        var _0x2a27c4 = _0x4e2829['ctx']['currentTime'],
                            _0x1079b8 = _0x2a27c4 + _0x3c65f4 / 0x3e8;
                        _0x3dfb6b['_volume'] = _0x1b42c4, _0x3dfb6b['_node']['gain']['setValueAtTime'](_0x1b42c4, _0x2a27c4), _0x3dfb6b['_node']['gain']['linearRampToValueAtTime'](_0x4bc45a, _0x1079b8);
                    }
                    _0x3ddbaf['_startFadeInterval'](_0x3dfb6b, _0x1b42c4, _0x4bc45a, _0x3c65f4, _0x3b536e[_0x136dbd], 'undefined' === typeof _0x3de630);
                }
            }
            return _0x3ddbaf;
        },
        '_startFadeInterval': function(_0x464790, _0x5026ec, _0x4acd7a, _0x3412f1, _0x4a1b71, _0x3ebbd4) {
            var _0x5b280c = this,
                _0x27f1fa = _0x5026ec,
                _0x5c0b77 = _0x4acd7a - _0x5026ec;
            _0x4a1b71 = Math['abs'](_0x5c0b77 / 0.01), _0x4a1b71 = Math['max'](0x4, 0x0 < _0x4a1b71 ? _0x3412f1 / _0x4a1b71 : _0x3412f1);
            var _0x131751 = Date['now']();
            _0x464790['_fadeTo'] = _0x4acd7a, _0x464790['_interval'] = setInterval(function() {
                var _0xc3636a = (Date['now']() - _0x131751) / _0x3412f1;
                _0x131751 = Date['now'](), _0x27f1fa += _0x5c0b77 * _0xc3636a, _0x27f1fa = 0x0 > _0x5c0b77 ? Math['max'](_0x4acd7a, _0x27f1fa) : Math['min'](_0x4acd7a, _0x27f1fa), _0x27f1fa = Math['round'](0x64 * _0x27f1fa) / 0x64, _0x5b280c['_webAudio'] ? _0x464790['_volume'] = _0x27f1fa : _0x5b280c['volume'](_0x27f1fa, _0x464790['_id'], !0x0), _0x3ebbd4 && (_0x5b280c['_volume'] = _0x27f1fa);
                if (_0x4acd7a < _0x5026ec && _0x27f1fa <= _0x4acd7a || _0x4acd7a > _0x5026ec && _0x27f1fa >= _0x4acd7a) clearInterval(_0x464790['_interval']), _0x464790['_interval'] = null, _0x464790['_fadeTo'] = null, _0x5b280c['volume'](_0x4acd7a, _0x464790['_id']), _0x5b280c['_emit']('fade', _0x464790['_id']);
            }, _0x4a1b71);
        },
        '_stopFade': function(_0x174d87) {
            var _0x396558 = this['_soundById'](_0x174d87);
            return _0x396558 && _0x396558['_interval'] && (this['_webAudio'] && _0x396558['_node']['gain']['cancelScheduledValues'](_0x4e2829['ctx']['currentTime']), clearInterval(_0x396558['_interval']), _0x396558['_interval'] = null, this['volume'](_0x396558['_fadeTo'], _0x174d87), _0x396558['_fadeTo'] = null, this['_emit']('fade', _0x174d87)), this;
        },
        'loop': function() {
            var _0x1a4f58 = arguments,
                _0x211168, _0x2fe4b3;
            if (0x0 === _0x1a4f58['length']) return this['_loop'];
            if (0x1 === _0x1a4f58['length']) {
                if ('boolean' === typeof _0x1a4f58[0x0]) this['_loop'] = _0x211168 = _0x1a4f58[0x0];
                else return (_0x1a4f58 = this['_soundById'](parseInt(_0x1a4f58[0x0], 0xa))) ? _0x1a4f58['_loop'] : !0x1;
            } else 0x2 === _0x1a4f58['length'] && (_0x211168 = _0x1a4f58[0x0], _0x2fe4b3 = parseInt(_0x1a4f58[0x1], 0xa));
            _0x2fe4b3 = this['_getSoundIds'](_0x2fe4b3);
            for (var _0x1447a1 = 0x0; _0x1447a1 < _0x2fe4b3['length']; _0x1447a1++)
                if (_0x1a4f58 = this['_soundById'](_0x2fe4b3[_0x1447a1])) {
                    if (_0x1a4f58['_loop'] = _0x211168, this['_webAudio'] && _0x1a4f58['_node'] && _0x1a4f58['_node']['bufferSource'] && (_0x1a4f58['_node']['bufferSource']['loop'] = _0x211168)) _0x1a4f58['_node']['bufferSource']['loopStart'] = _0x1a4f58['_start'] || 0x0, _0x1a4f58['_node']['bufferSource']['loopEnd'] = _0x1a4f58['_stop'];
                }
            return this;
        },
        'rate': function() {
            var _0x3fde88 = this,
                _0x355f86 = arguments,
                _0xe542bf, _0x1f063a;
            0x0 === _0x355f86['length'] ? _0x1f063a = _0x3fde88['_sounds'][0x0]['_id'] : 0x1 === _0x355f86['length'] ? 0x0 <= _0x3fde88['_getSoundIds']()['indexOf'](_0x355f86[0x0]) ? _0x1f063a = parseInt(_0x355f86[0x0], 0xa) : _0xe542bf = parseFloat(_0x355f86[0x0]) : 0x2 === _0x355f86['length'] && (_0xe542bf = parseFloat(_0x355f86[0x0]), _0x1f063a = parseInt(_0x355f86[0x1], 0xa));
            var _0x5a14d2;
            if ('number' === typeof _0xe542bf) {
                if ('loaded' !== _0x3fde88['_state'] || _0x3fde88['_playLock']) return _0x3fde88['_queue']['push']({
                    'event': 'rate',
                    'action': function() {
                        _0x3fde88['rate']['apply'](_0x3fde88, _0x355f86);
                    }
                }), _0x3fde88;
                'undefined' === typeof _0x1f063a && (_0x3fde88['_rate'] = _0xe542bf), _0x1f063a = _0x3fde88['_getSoundIds'](_0x1f063a);
                for (var _0xbc6350 = 0x0; _0xbc6350 < _0x1f063a['length']; _0xbc6350++)
                    if (_0x5a14d2 = _0x3fde88['_soundById'](_0x1f063a[_0xbc6350])) {
                        _0x3fde88['playing'](_0x1f063a[_0xbc6350]) && (_0x5a14d2['_rateSeek'] = _0x3fde88['seek'](_0x1f063a[_0xbc6350]), _0x5a14d2['_playStart'] = _0x3fde88['_webAudio'] ? _0x4e2829['ctx']['currentTime'] : _0x5a14d2['_playStart']), _0x5a14d2['_rate'] = _0xe542bf, _0x3fde88['_webAudio'] && _0x5a14d2['_node'] && _0x5a14d2['_node']['bufferSource'] ? _0x5a14d2['_node']['bufferSource']['playbackRate']['setValueAtTime'](_0xe542bf, _0x4e2829['ctx']['currentTime']) : _0x5a14d2['_node'] && (_0x5a14d2['_node']['playbackRate'] = _0xe542bf);
                        var _0x2d29be = _0x3fde88['seek'](_0x1f063a[_0xbc6350]),
                            _0x2d29be = 0x3e8 * ((_0x3fde88['_sprite'][_0x5a14d2['_sprite']][0x0] + _0x3fde88['_sprite'][_0x5a14d2['_sprite']][0x1]) / 0x3e8 - _0x2d29be) / Math['abs'](_0x5a14d2['_rate']);
                        if (_0x3fde88['_endTimers'][_0x1f063a[_0xbc6350]] || !_0x5a14d2['_paused']) _0x3fde88['_clearTimer'](_0x1f063a[_0xbc6350]), _0x3fde88['_endTimers'][_0x1f063a[_0xbc6350]] = setTimeout(_0x3fde88['_ended']['bind'](_0x3fde88, _0x5a14d2), _0x2d29be);
                        _0x3fde88['_emit']('rate', _0x5a14d2['_id']);
                    }
            } else return (_0x5a14d2 = _0x3fde88['_soundById'](_0x1f063a)) ? _0x5a14d2['_rate'] : _0x3fde88['_rate'];
            return _0x3fde88;
        },
        'seek': function() {
            var _0x51765f = this,
                _0x53c043 = arguments,
                _0x16f907, _0x57efd8;
            0x0 === _0x53c043['length'] ? _0x57efd8 = _0x51765f['_sounds'][0x0]['_id'] : 0x1 === _0x53c043['length'] ? 0x0 <= _0x51765f['_getSoundIds']()['indexOf'](_0x53c043[0x0]) ? _0x57efd8 = parseInt(_0x53c043[0x0], 0xa) : _0x51765f['_sounds']['length'] && (_0x57efd8 = _0x51765f['_sounds'][0x0]['_id'], _0x16f907 = parseFloat(_0x53c043[0x0])) : 0x2 === _0x53c043['length'] && (_0x16f907 = parseFloat(_0x53c043[0x0]), _0x57efd8 = parseInt(_0x53c043[0x1], 0xa));
            if ('undefined' === typeof _0x57efd8) return _0x51765f;
            if ('loaded' !== _0x51765f['_state'] || _0x51765f['_playLock']) return _0x51765f['_queue']['push']({
                'event': 'seek',
                'action': function() {
                    _0x51765f['seek']['apply'](_0x51765f, _0x53c043);
                }
            }), _0x51765f;
            var _0x2ea75f = _0x51765f['_soundById'](_0x57efd8);
            if (_0x2ea75f) {
                if ('number' === typeof _0x16f907 && 0x0 <= _0x16f907) {
                    var _0x2b72b4 = _0x51765f['playing'](_0x57efd8);
                    _0x2b72b4 && _0x51765f['pause'](_0x57efd8, !0x0), _0x2ea75f['_seek'] = _0x16f907, _0x2ea75f['_ended'] = !0x1, _0x51765f['_clearTimer'](_0x57efd8), !_0x51765f['_webAudio'] && _0x2ea75f['_node'] && !isNaN(_0x2ea75f['_node']['duration']) && (_0x2ea75f['_node']['currentTime'] = _0x16f907);
                    var _0x52c529 = function() {
                        _0x51765f['_emit']('seek', _0x57efd8), _0x2b72b4 && _0x51765f['play'](_0x57efd8, !0x0);
                    };
                    if (_0x2b72b4 && !_0x51765f['_webAudio']) {
                        var _0x5df6d0 = function() {
                            _0x51765f['_playLock'] ? setTimeout(_0x5df6d0, 0x0) : _0x52c529();
                        };
                        setTimeout(_0x5df6d0, 0x0);
                    } else _0x52c529();
                } else return _0x51765f['_webAudio'] ? (_0x16f907 = _0x51765f['playing'](_0x57efd8) ? _0x4e2829['ctx']['currentTime'] - _0x2ea75f['_playStart'] : 0x0, _0x2ea75f['_seek'] + ((_0x2ea75f['_rateSeek'] ? _0x2ea75f['_rateSeek'] - _0x2ea75f['_seek'] : 0x0) + _0x16f907 * Math['abs'](_0x2ea75f['_rate']))) : _0x2ea75f['_node']['currentTime'];
            }
            return _0x51765f;
        },
        'playing': function(_0x49942a) {
            if ('number' === typeof _0x49942a) return (_0x49942a = this['_soundById'](_0x49942a)) ? !_0x49942a['_paused'] : !0x1;
            for (_0x49942a = 0x0; _0x49942a < this['_sounds']['length']; _0x49942a++)
                if (!this['_sounds'][_0x49942a]['_paused']) return !0x0;
            return !0x1;
        },
        'duration': function(_0xdea245) {
            var _0x4affef = this['_duration'];
            return (_0xdea245 = this['_soundById'](_0xdea245)) && (_0x4affef = this['_sprite'][_0xdea245['_sprite']][0x1] / 0x3e8), _0x4affef;
        },
        'state': function() {
            return this['_state'];
        },
        'unload': function() {
            for (var _0x3773f4 = this['_sounds'], _0x29caf1 = 0x0; _0x29caf1 < _0x3773f4['length']; _0x29caf1++) _0x3773f4[_0x29caf1]['_paused'] || this['stop'](_0x3773f4[_0x29caf1]['_id']), this['_webAudio'] || (this['_clearSound'](_0x3773f4[_0x29caf1]['_node']), _0x3773f4[_0x29caf1]['_node']['removeEventListener']('error', _0x3773f4[_0x29caf1]['_errorFn'], !0x1), _0x3773f4[_0x29caf1]['_node']['removeEventListener'](_0x4e2829['_canPlayEvent'], _0x3773f4[_0x29caf1]['_loadFn'], !0x1), _0x4e2829['_releaseHtml5Audio'](_0x3773f4[_0x29caf1]['_node'])), delete _0x3773f4[_0x29caf1]['_node'], this['_clearTimer'](_0x3773f4[_0x29caf1]['_id']);
            _0x29caf1 = _0x4e2829['_howls']['indexOf'](this), 0x0 <= _0x29caf1 && _0x4e2829['_howls']['splice'](_0x29caf1, 0x1), _0x3773f4 = !0x0;
            for (_0x29caf1 = 0x0; _0x29caf1 < _0x4e2829['_howls']['length']; _0x29caf1++)
                if (_0x4e2829['_howls'][_0x29caf1]['_src'] === this['_src'] || 0x0 <= this['_src']['indexOf'](_0x4e2829['_howls'][_0x29caf1]['_src'])) {
                    _0x3773f4 = !0x1;
                    break;
                }
            return _0xc57a3b && _0x3773f4 && delete _0xc57a3b[this['_src']], _0x4e2829['noAudio'] = !0x1, this['_state'] = 'unloaded', this['_sounds'] = [], null;
        },
        'on': function(_0x61428f, _0x88fba5, _0x25a45, _0x32b8a3) {
            return _0x61428f = this['_on' + _0x61428f], 'function' === typeof _0x88fba5 && _0x61428f['push'](_0x32b8a3 ? {
                'id': _0x25a45,
                'fn': _0x88fba5,
                'once': _0x32b8a3
            } : {
                'id': _0x25a45,
                'fn': _0x88fba5
            }), this;
        },
        'off': function(_0x13d0cd, _0x316256, _0x284766) {
            var _0x4119f1 = this['_on' + _0x13d0cd],
                _0x15c33c = 0x0;
            'number' === typeof _0x316256 && (_0x284766 = _0x316256, _0x316256 = null);
            if (_0x316256 || _0x284766)
                for (_0x15c33c = 0x0; _0x15c33c < _0x4119f1['length']; _0x15c33c++) {
                    if (_0x13d0cd = _0x284766 === _0x4119f1[_0x15c33c]['id'], _0x316256 === _0x4119f1[_0x15c33c]['fn'] && _0x13d0cd || !_0x316256 && _0x13d0cd) {
                        _0x4119f1['splice'](_0x15c33c, 0x1);
                        break;
                    }
                } else {
                    if (_0x13d0cd) this['_on' + _0x13d0cd] = [];
                    else {
                        _0x316256 = Object['keys'](this);
                        for (_0x15c33c = 0x0; _0x15c33c < _0x316256['length']; _0x15c33c++) 0x0 === _0x316256[_0x15c33c]['indexOf']('_on') && Array['isArray'](this[_0x316256[_0x15c33c]]) && (this[_0x316256[_0x15c33c]] = []);
                    }
                }
            return this;
        },
        'once': function(_0x28ab88, _0x431abb, _0x4ffdc1) {
            return this['on'](_0x28ab88, _0x431abb, _0x4ffdc1, 0x1), this;
        },
        '_emit': function(_0x498f6e, _0x26fe86, _0x227c8f) {
            for (var _0x391ffd = this['_on' + _0x498f6e], _0x11406a = _0x391ffd['length'] - 0x1; 0x0 <= _0x11406a; _0x11406a--)
                if (!_0x391ffd[_0x11406a]['id'] || _0x391ffd[_0x11406a]['id'] === _0x26fe86 || 'load' === _0x498f6e) setTimeout(function(_0x19157c) {
                    _0x19157c['call'](this, _0x26fe86, _0x227c8f);
                }['bind'](this, _0x391ffd[_0x11406a]['fn']), 0x0), _0x391ffd[_0x11406a]['once'] && this['off'](_0x498f6e, _0x391ffd[_0x11406a]['fn'], _0x391ffd[_0x11406a]['id']);
            return this['_loadQueue'](_0x498f6e), this;
        },
        '_loadQueue': function(_0x154943) {
            if (0x0 < this['_queue']['length']) {
                var _0x24224c = this['_queue'][0x0];
                _0x24224c['event'] === _0x154943 && (this['_queue']['shift'](), this['_loadQueue']()), _0x154943 || _0x24224c['action']();
            }
            return this;
        },
        '_ended': function(_0x3326e4) {
            var _0x434c9f = _0x3326e4['_sprite'];
            if (!this['_webAudio'] && _0x3326e4['_node'] && !_0x3326e4['_node']['paused'] && !_0x3326e4['_node']['ended'] && _0x3326e4['_node']['currentTime'] < _0x3326e4['_stop']) return setTimeout(this['_ended']['bind'](this, _0x3326e4), 0x64), this;
            _0x434c9f = !(!_0x3326e4['_loop'] && !this['_sprite'][_0x434c9f][0x2]), this['_emit']('end', _0x3326e4['_id']), !this['_webAudio'] && _0x434c9f && this['stop'](_0x3326e4['_id'], !0x0)['play'](_0x3326e4['_id']);
            if (this['_webAudio'] && _0x434c9f) {
                this['_emit']('play', _0x3326e4['_id']), _0x3326e4['_seek'] = _0x3326e4['_start'] || 0x0, _0x3326e4['_rateSeek'] = 0x0, _0x3326e4['_playStart'] = _0x4e2829['ctx']['currentTime'];
                var _0x35c76d = 0x3e8 * (_0x3326e4['_stop'] - _0x3326e4['_start']) / Math['abs'](_0x3326e4['_rate']);
                this['_endTimers'][_0x3326e4['_id']] = setTimeout(this['_ended']['bind'](this, _0x3326e4), _0x35c76d);
            }
            return this['_webAudio'] && !_0x434c9f && (_0x3326e4['_paused'] = !0x0, _0x3326e4['_ended'] = !0x0, _0x3326e4['_seek'] = _0x3326e4['_start'] || 0x0, _0x3326e4['_rateSeek'] = 0x0, this['_clearTimer'](_0x3326e4['_id']), this['_cleanBuffer'](_0x3326e4['_node']), _0x4e2829['_autoSuspend']()), !this['_webAudio'] && !_0x434c9f && this['stop'](_0x3326e4['_id'], !0x0), this;
        },
        '_clearTimer': function(_0x45e7b3) {
            if (this['_endTimers'][_0x45e7b3]) {
                if ('function' !== typeof this['_endTimers'][_0x45e7b3]) clearTimeout(this['_endTimers'][_0x45e7b3]);
                else {
                    var _0x472c6e = this['_soundById'](_0x45e7b3);
                    _0x472c6e && _0x472c6e['_node'] && _0x472c6e['_node']['removeEventListener']('ended', this['_endTimers'][_0x45e7b3], !0x1);
                }
                delete this['_endTimers'][_0x45e7b3];
            }
            return this;
        },
        '_soundById': function(_0x3e5782) {
            for (var _0xe16dd5 = 0x0; _0xe16dd5 < this['_sounds']['length']; _0xe16dd5++)
                if (_0x3e5782 === this['_sounds'][_0xe16dd5]['_id']) return this['_sounds'][_0xe16dd5];
            return null;
        },
        '_inactiveSound': function() {
            this['_drain']();
            for (var _0x2939af = 0x0; _0x2939af < this['_sounds']['length']; _0x2939af++)
                if (this['_sounds'][_0x2939af]['_ended']) return this['_sounds'][_0x2939af]['reset']();
            return new _0xc9b612(this);
        },
        '_drain': function() {
            var _0x2d9c95 = this['_pool'],
                _0x186113 = 0x0,
                _0x272c70 = 0x0;
            if (!(this['_sounds']['length'] < _0x2d9c95)) {
                for (_0x272c70 = 0x0; _0x272c70 < this['_sounds']['length']; _0x272c70++) this['_sounds'][_0x272c70]['_ended'] && _0x186113++;
                for (_0x272c70 = this['_sounds']['length'] - 0x1; 0x0 <= _0x272c70 && !(_0x186113 <= _0x2d9c95); _0x272c70--) this['_sounds'][_0x272c70]['_ended'] && (this['_webAudio'] && this['_sounds'][_0x272c70]['_node'] && this['_sounds'][_0x272c70]['_node']['disconnect'](0x0), this['_sounds']['splice'](_0x272c70, 0x1), _0x186113--);
            }
        },
        '_getSoundIds': function(_0x3d571d) {
            if ('undefined' === typeof _0x3d571d) {
                _0x3d571d = [];
                for (var _0x2bbd74 = 0x0; _0x2bbd74 < this['_sounds']['length']; _0x2bbd74++) _0x3d571d['push'](this['_sounds'][_0x2bbd74]['_id']);
                return _0x3d571d;
            }
            return [_0x3d571d];
        },
        '_refreshBuffer': function(_0x408b7a) {
            _0x408b7a['_node']['bufferSource'] = _0x4e2829['ctx']['createBufferSource'](), _0x408b7a['_node']['bufferSource']['buffer'] = _0xc57a3b[this['_src']], _0x408b7a['_panner'] ? _0x408b7a['_node']['bufferSource']['connect'](_0x408b7a['_panner']) : _0x408b7a['_node']['bufferSource']['connect'](_0x408b7a['_node']);
            if (_0x408b7a['_node']['bufferSource']['loop'] = _0x408b7a['_loop']) _0x408b7a['_node']['bufferSource']['loopStart'] = _0x408b7a['_start'] || 0x0, _0x408b7a['_node']['bufferSource']['loopEnd'] = _0x408b7a['_stop'] || 0x0;
            return _0x408b7a['_node']['bufferSource']['playbackRate']['setValueAtTime'](_0x408b7a['_rate'], _0x4e2829['ctx']['currentTime']), this;
        },
        '_cleanBuffer': function(_0xfd9fcf) {
            var _0x470721 = _0x4e2829['_navigator'] && 0x0 <= _0x4e2829['_navigator']['vendor']['indexOf']('Apple');
            if (_0x4e2829['_scratchBuffer'] && _0xfd9fcf['bufferSource'] && (_0xfd9fcf['bufferSource']['onended'] = null, _0xfd9fcf['bufferSource']['disconnect'](0x0), _0x470721)) try {
                _0xfd9fcf['bufferSource']['buffer'] = _0x4e2829['_scratchBuffer'];
            } catch (_0x3d021a) {}
            return _0xfd9fcf['bufferSource'] = null, this;
        },
        '_clearSound': function(_0x53ec5e) {
            /MSIE |Trident\// ['test'](_0x4e2829['_navigator'] && _0x4e2829['_navigator']['userAgent']) || (_0x53ec5e['src'] = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA');
        }
    };
    var _0xc9b612 = function(_0x31da2c) {
        this['_parent'] = _0x31da2c, this['init']();
    };
    _0xc9b612['prototype'] = {
        'init': function() {
            var _0xfdf8b5 = this['_parent'];
            return this['_muted'] = _0xfdf8b5['_muted'], this['_loop'] = _0xfdf8b5['_loop'], this['_volume'] = _0xfdf8b5['_volume'], this['_rate'] = _0xfdf8b5['_rate'], this['_seek'] = 0x0, this['_ended'] = this['_paused'] = !0x0, this['_sprite'] = '__default', this['_id'] = ++_0x4e2829['_counter'], _0xfdf8b5['_sounds']['push'](this), this['create'](), this;
        },
        'create': function() {
            var _0x317e45 = this['_parent'],
                _0x593cf2 = _0x4e2829['_muted'] || this['_muted'] || this['_parent']['_muted'] ? 0x0 : this['_volume'];
            return _0x317e45['_webAudio'] ? (this['_node'] = 'undefined' === typeof _0x4e2829['ctx']['createGain'] ? _0x4e2829['ctx']['createGainNode']() : _0x4e2829['ctx']['createGain'](), this['_node']['gain']['setValueAtTime'](_0x593cf2, _0x4e2829['ctx']['currentTime']), this['_node']['paused'] = !0x0, this['_node']['connect'](_0x4e2829['masterGain'])) : _0x4e2829['noAudio'] || (this['_node'] = _0x4e2829['_obtainHtml5Audio'](), this['_errorFn'] = this['_errorListener']['bind'](this), this['_node']['addEventListener']('error', this['_errorFn'], !0x1), this['_loadFn'] = this['_loadListener']['bind'](this), this['_node']['addEventListener'](_0x4e2829['_canPlayEvent'], this['_loadFn'], !0x1), this['_node']['src'] = _0x317e45['_src'], this['_node']['preload'] = !0x0 === _0x317e45['_preload'] ? 'auto' : _0x317e45['_preload'], this['_node']['volume'] = _0x593cf2 * _0x4e2829['volume'](), this['_node']['load']()), this;
        },
        'reset': function() {
            var _0x14fce7 = this['_parent'];
            return this['_muted'] = _0x14fce7['_muted'], this['_loop'] = _0x14fce7['_loop'], this['_volume'] = _0x14fce7['_volume'], this['_rate'] = _0x14fce7['_rate'], this['_rateSeek'] = this['_seek'] = 0x0, this['_ended'] = this['_paused'] = !0x0, this['_sprite'] = '__default', this['_id'] = ++_0x4e2829['_counter'], this;
        },
        '_errorListener': function() {
            this['_parent']['_emit']('loaderror', this['_id'], this['_node']['error'] ? this['_node']['error']['code'] : 0x0), this['_node']['removeEventListener']('error', this['_errorFn'], !0x1);
        },
        '_loadListener': function() {
            var _0x304943 = this['_parent'];
            _0x304943['_duration'] = Math['ceil'](0xa * this['_node']['duration']) / 0xa, 0x0 === Object['keys'](_0x304943['_sprite'])['length'] && (_0x304943['_sprite'] = {
                '__default': [0x0, 0x3e8 * _0x304943['_duration']]
            }), 'loaded' !== _0x304943['_state'] && (_0x304943['_state'] = 'loaded', _0x304943['_emit']('load'), _0x304943['_loadQueue']()), this['_node']['removeEventListener'](_0x4e2829['_canPlayEvent'], this['_loadFn'], !0x1);
        }
    };
    var _0xc57a3b = {},
        _0x5e9293 = function(_0x3149c9, _0x1e40d2) {
            var _0xd0d054 = function() {
                    _0x1e40d2['_emit']('loaderror', null, 'Decoding\x20audio\x20data\x20failed.');
                },
                _0xaef43d = function(_0x3a76b4) {
                    _0x3a76b4 && 0x0 < _0x1e40d2['_sounds']['length'] ? (_0xc57a3b[_0x1e40d2['_src']] = _0x3a76b4, _0xb651a9(_0x1e40d2, _0x3a76b4)) : _0xd0d054();
                };
            'undefined' !== typeof Promise && 0x1 === _0x4e2829['ctx']['decodeAudioData']['length'] ? _0x4e2829['ctx']['decodeAudioData'](_0x3149c9)['then'](_0xaef43d)['catch'](_0xd0d054) : _0x4e2829['ctx']['decodeAudioData'](_0x3149c9, _0xaef43d, _0xd0d054);
        },
        _0xb651a9 = function(_0x4bed73, _0x1bca8e) {
            _0x1bca8e && !_0x4bed73['_duration'] && (_0x4bed73['_duration'] = _0x1bca8e['duration']), 0x0 === Object['keys'](_0x4bed73['_sprite'])['length'] && (_0x4bed73['_sprite'] = {
                '__default': [0x0, 0x3e8 * _0x4bed73['_duration']]
            }), 'loaded' !== _0x4bed73['_state'] && (_0x4bed73['_state'] = 'loaded', _0x4bed73['_emit']('load'), _0x4bed73['_loadQueue']());
        },
        _0x35fc5e = function() {
            if (_0x4e2829['usingWebAudio']) {
                try {
                    'undefined' !== typeof AudioContext ? _0x4e2829['ctx'] = new AudioContext() : 'undefined' !== typeof webkitAudioContext ? _0x4e2829['ctx'] = new webkitAudioContext() : _0x4e2829['usingWebAudio'] = !0x1;
                } catch (_0x17ae3f) {
                    _0x4e2829['usingWebAudio'] = !0x1;
                }
                _0x4e2829['ctx'] || (_0x4e2829['usingWebAudio'] = !0x1);
                var _0x2a53b1 = /iP(hone|od|ad)/ ['test'](_0x4e2829['_navigator'] && _0x4e2829['_navigator']['platform']),
                    _0x14384c = _0x4e2829['_navigator'] && _0x4e2829['_navigator']['appVersion']['match'](/OS (\d+)_(\d+)_?(\d+)?/),
                    _0x14384c = _0x14384c ? parseInt(_0x14384c[0x1], 0xa) : null;
                _0x2a53b1 && _0x14384c && 0x9 > _0x14384c && (_0x2a53b1 = /safari/ ['test'](_0x4e2829['_navigator'] && _0x4e2829['_navigator']['userAgent']['toLowerCase']()), _0x4e2829['_navigator'] && !_0x2a53b1 && (_0x4e2829['usingWebAudio'] = !0x1)), _0x4e2829['usingWebAudio'] && (_0x4e2829['masterGain'] = 'undefined' === typeof _0x4e2829['ctx']['createGain'] ? _0x4e2829['ctx']['createGainNode']() : _0x4e2829['ctx']['createGain'](), _0x4e2829['masterGain']['gain']['setValueAtTime'](_0x4e2829['_muted'] ? 0x0 : _0x4e2829['_volume'], _0x4e2829['ctx']['currentTime']), _0x4e2829['masterGain']['connect'](_0x4e2829['ctx']['destination'])), _0x4e2829['_setup']();
            }
        };
    'function' === typeof define && define['amd'] && define([], function() {
        return {
            'Howler': _0x4e2829,
            'Howl': _0x1a71df
        };
    }), 'undefined' !== typeof exports && (exports['Howler'] = _0x4e2829, exports['Howl'] = _0x1a71df), 'undefined' !== typeof global ? (global['HowlerGlobal'] = _0x1325c5, global['Howler'] = _0x4e2829, global['Howl'] = _0x1a71df, global['Sound'] = _0xc9b612) : 'undefined' !== typeof window && (window['HowlerGlobal'] = _0x1325c5, window['Howler'] = _0x4e2829, window['Howl'] = _0x1a71df, window['Sound'] = _0xc9b612);
}(),
function() {
    HowlerGlobal['prototype']['_pos'] = [0x0, 0x0, 0x0], HowlerGlobal['prototype']['_orientation'] = [0x0, 0x0, -0x1, 0x0, 0x1, 0x0], HowlerGlobal['prototype']['stereo'] = function(_0x355a44) {
        if (!this['ctx'] || !this['ctx']['listener']) return this;
        for (var _0x23970d = this['_howls']['length'] - 0x1; 0x0 <= _0x23970d; _0x23970d--) this['_howls'][_0x23970d]['stereo'](_0x355a44);
        return this;
    }, HowlerGlobal['prototype']['pos'] = function(_0x5dee28, _0x5618c3, _0x2b66ae) {
        if (!this['ctx'] || !this['ctx']['listener']) return this;
        _0x5618c3 = 'number' !== typeof _0x5618c3 ? this['_pos'][0x1] : _0x5618c3, _0x2b66ae = 'number' !== typeof _0x2b66ae ? this['_pos'][0x2] : _0x2b66ae;
        if ('number' === typeof _0x5dee28) this['_pos'] = [_0x5dee28, _0x5618c3, _0x2b66ae], 'undefined' !== typeof this['ctx']['listener']['positionX'] ? (this['ctx']['listener']['positionX']['setTargetAtTime'](this['_pos'][0x0], Howler['ctx']['currentTime'], 0.1), this['ctx']['listener']['positionY']['setTargetAtTime'](this['_pos'][0x1], Howler['ctx']['currentTime'], 0.1), this['ctx']['listener']['positionZ']['setTargetAtTime'](this['_pos'][0x2], Howler['ctx']['currentTime'], 0.1)) : this['ctx']['listener']['setPosition'](this['_pos'][0x0], this['_pos'][0x1], this['_pos'][0x2]);
        else return this['_pos'];
        return this;
    }, HowlerGlobal['prototype']['orientation'] = function(_0x3dee81, _0x43fa68, _0xe87839, _0x44526a, _0x2360b1, _0x2ad32d) {
        if (!this['ctx'] || !this['ctx']['listener']) return this;
        var _0xfa73f6 = this['_orientation'];
        _0x43fa68 = 'number' !== typeof _0x43fa68 ? _0xfa73f6[0x1] : _0x43fa68, _0xe87839 = 'number' !== typeof _0xe87839 ? _0xfa73f6[0x2] : _0xe87839, _0x44526a = 'number' !== typeof _0x44526a ? _0xfa73f6[0x3] : _0x44526a, _0x2360b1 = 'number' !== typeof _0x2360b1 ? _0xfa73f6[0x4] : _0x2360b1, _0x2ad32d = 'number' !== typeof _0x2ad32d ? _0xfa73f6[0x5] : _0x2ad32d;
        if ('number' === typeof _0x3dee81) this['_orientation'] = [_0x3dee81, _0x43fa68, _0xe87839, _0x44526a, _0x2360b1, _0x2ad32d], 'undefined' !== typeof this['ctx']['listener']['forwardX'] ? (this['ctx']['listener']['forwardX']['setTargetAtTime'](_0x3dee81, Howler['ctx']['currentTime'], 0.1), this['ctx']['listener']['forwardY']['setTargetAtTime'](_0x43fa68, Howler['ctx']['currentTime'], 0.1), this['ctx']['listener']['forwardZ']['setTargetAtTime'](_0xe87839, Howler['ctx']['currentTime'], 0.1), this['ctx']['listener']['upX']['setTargetAtTime'](_0x44526a, Howler['ctx']['currentTime'], 0.1), this['ctx']['listener']['upY']['setTargetAtTime'](_0x2360b1, Howler['ctx']['currentTime'], 0.1), this['ctx']['listener']['upZ']['setTargetAtTime'](_0x2ad32d, Howler['ctx']['currentTime'], 0.1)) : this['ctx']['listener']['setOrientation'](_0x3dee81, _0x43fa68, _0xe87839, _0x44526a, _0x2360b1, _0x2ad32d);
        else return _0xfa73f6;
        return this;
    };
    var _0x4d5adc = Howl['prototype']['init'];
    Howl['prototype']['init'] = function(_0xf1fb25) {
        return this['_orientation'] = _0xf1fb25['orientation'] || [0x1, 0x0, 0x0], this['_stereo'] = _0xf1fb25['stereo'] || null, this['_pos'] = _0xf1fb25['pos'] || null, this['_pannerAttr'] = {
            'coneInnerAngle': 'undefined' !== typeof _0xf1fb25['coneInnerAngle'] ? _0xf1fb25['coneInnerAngle'] : 0x168,
            'coneOuterAngle': 'undefined' !== typeof _0xf1fb25['coneOuterAngle'] ? _0xf1fb25['coneOuterAngle'] : 0x168,
            'coneOuterGain': 'undefined' !== typeof _0xf1fb25['coneOuterGain'] ? _0xf1fb25['coneOuterGain'] : 0x0,
            'distanceModel': 'undefined' !== typeof _0xf1fb25['distanceModel'] ? _0xf1fb25['distanceModel'] : 'inverse',
            'maxDistance': 'undefined' !== typeof _0xf1fb25['maxDistance'] ? _0xf1fb25['maxDistance'] : 0x2710,
            'panningModel': 'undefined' !== typeof _0xf1fb25['panningModel'] ? _0xf1fb25['panningModel'] : 'HRTF',
            'refDistance': 'undefined' !== typeof _0xf1fb25['refDistance'] ? _0xf1fb25['refDistance'] : 0x1,
            'rolloffFactor': 'undefined' !== typeof _0xf1fb25['rolloffFactor'] ? _0xf1fb25['rolloffFactor'] : 0x1
        }, this['_onstereo'] = _0xf1fb25['onstereo'] ? [{
            'fn': _0xf1fb25['onstereo']
        }] : [], this['_onpos'] = _0xf1fb25['onpos'] ? [{
            'fn': _0xf1fb25['onpos']
        }] : [], this['_onorientation'] = _0xf1fb25['onorientation'] ? [{
            'fn': _0xf1fb25['onorientation']
        }] : [], _0x4d5adc['call'](this, _0xf1fb25);
    }, Howl['prototype']['stereo'] = function(_0x484353, _0x29e850) {
        var _0x214593 = this;
        if (!_0x214593['_webAudio']) return _0x214593;
        if ('loaded' !== _0x214593['_state']) return _0x214593['_queue']['push']({
            'event': 'stereo',
            'action': function() {
                _0x214593['stereo'](_0x484353, _0x29e850);
            }
        }), _0x214593;
        var _0x1a9657 = 'undefined' === typeof Howler['ctx']['createStereoPanner'] ? 'spatial' : 'stereo';
        if ('undefined' === typeof _0x29e850) {
            if ('number' === typeof _0x484353) _0x214593['_stereo'] = _0x484353, _0x214593['_pos'] = [_0x484353, 0x0, 0x0];
            else return _0x214593['_stereo'];
        }
        for (var _0x11359f = _0x214593['_getSoundIds'](_0x29e850), _0x520ec4 = 0x0; _0x520ec4 < _0x11359f['length']; _0x520ec4++) {
            var _0x529f9f = _0x214593['_soundById'](_0x11359f[_0x520ec4]);
            if (_0x529f9f) {
                if ('number' === typeof _0x484353) _0x529f9f['_stereo'] = _0x484353, _0x529f9f['_pos'] = [_0x484353, 0x0, 0x0], _0x529f9f['_node'] && (_0x529f9f['_pannerAttr']['panningModel'] = 'equalpower', (!_0x529f9f['_panner'] || !_0x529f9f['_panner']['pan']) && _0x752a17(_0x529f9f, _0x1a9657), 'spatial' === _0x1a9657 ? 'undefined' !== typeof _0x529f9f['_panner']['positionX'] ? (_0x529f9f['_panner']['positionX']['setValueAtTime'](_0x484353, Howler['ctx']['currentTime']), _0x529f9f['_panner']['positionY']['setValueAtTime'](0x0, Howler['ctx']['currentTime']), _0x529f9f['_panner']['positionZ']['setValueAtTime'](0x0, Howler['ctx']['currentTime'])) : _0x529f9f['_panner']['setPosition'](_0x484353, 0x0, 0x0) : _0x529f9f['_panner']['pan']['setValueAtTime'](_0x484353, Howler['ctx']['currentTime'])), _0x214593['_emit']('stereo', _0x529f9f['_id']);
                else return _0x529f9f['_stereo'];
            }
        }
        return _0x214593;
    }, Howl['prototype']['pos'] = function(_0x1ce187, _0x1d8877, _0x48e1c5, _0x59472a) {
        var _0x1aa65b = this;
        if (!_0x1aa65b['_webAudio']) return _0x1aa65b;
        if ('loaded' !== _0x1aa65b['_state']) return _0x1aa65b['_queue']['push']({
            'event': 'pos',
            'action': function() {
                _0x1aa65b['pos'](_0x1ce187, _0x1d8877, _0x48e1c5, _0x59472a);
            }
        }), _0x1aa65b;
        _0x1d8877 = 'number' !== typeof _0x1d8877 ? 0x0 : _0x1d8877, _0x48e1c5 = 'number' !== typeof _0x48e1c5 ? -0.5 : _0x48e1c5;
        if ('undefined' === typeof _0x59472a) {
            if ('number' === typeof _0x1ce187) _0x1aa65b['_pos'] = [_0x1ce187, _0x1d8877, _0x48e1c5];
            else return _0x1aa65b['_pos'];
        }
        for (var _0x40b510 = _0x1aa65b['_getSoundIds'](_0x59472a), _0x3a0563 = 0x0; _0x3a0563 < _0x40b510['length']; _0x3a0563++) {
            var _0x4173ff = _0x1aa65b['_soundById'](_0x40b510[_0x3a0563]);
            if (_0x4173ff) {
                if ('number' === typeof _0x1ce187) _0x4173ff['_pos'] = [_0x1ce187, _0x1d8877, _0x48e1c5], _0x4173ff['_node'] && ((!_0x4173ff['_panner'] || _0x4173ff['_panner']['pan']) && _0x752a17(_0x4173ff, 'spatial'), 'undefined' !== typeof _0x4173ff['_panner']['positionX'] ? (_0x4173ff['_panner']['positionX']['setValueAtTime'](_0x1ce187, Howler['ctx']['currentTime']), _0x4173ff['_panner']['positionY']['setValueAtTime'](_0x1d8877, Howler['ctx']['currentTime']), _0x4173ff['_panner']['positionZ']['setValueAtTime'](_0x48e1c5, Howler['ctx']['currentTime'])) : _0x4173ff['_panner']['setPosition'](_0x1ce187, _0x1d8877, _0x48e1c5)), _0x1aa65b['_emit']('pos', _0x4173ff['_id']);
                else return _0x4173ff['_pos'];
            }
        }
        return _0x1aa65b;
    }, Howl['prototype']['orientation'] = function(_0x1359bf, _0x21fe73, _0x289394, _0xea7777) {
        var _0x44c51d = this;
        if (!_0x44c51d['_webAudio']) return _0x44c51d;
        if ('loaded' !== _0x44c51d['_state']) return _0x44c51d['_queue']['push']({
            'event': 'orientation',
            'action': function() {
                _0x44c51d['orientation'](_0x1359bf, _0x21fe73, _0x289394, _0xea7777);
            }
        }), _0x44c51d;
        _0x21fe73 = 'number' !== typeof _0x21fe73 ? _0x44c51d['_orientation'][0x1] : _0x21fe73, _0x289394 = 'number' !== typeof _0x289394 ? _0x44c51d['_orientation'][0x2] : _0x289394;
        if ('undefined' === typeof _0xea7777) {
            if ('number' === typeof _0x1359bf) _0x44c51d['_orientation'] = [_0x1359bf, _0x21fe73, _0x289394];
            else return _0x44c51d['_orientation'];
        }
        for (var _0x3f161a = _0x44c51d['_getSoundIds'](_0xea7777), _0x388ae2 = 0x0; _0x388ae2 < _0x3f161a['length']; _0x388ae2++) {
            var _0x4f8dc7 = _0x44c51d['_soundById'](_0x3f161a[_0x388ae2]);
            if (_0x4f8dc7) {
                if ('number' === typeof _0x1359bf) _0x4f8dc7['_orientation'] = [_0x1359bf, _0x21fe73, _0x289394], _0x4f8dc7['_node'] && (_0x4f8dc7['_panner'] || (_0x4f8dc7['_pos'] || (_0x4f8dc7['_pos'] = _0x44c51d['_pos'] || [0x0, 0x0, -0.5]), _0x752a17(_0x4f8dc7, 'spatial')), 'undefined' !== typeof _0x4f8dc7['_panner']['orientationX'] ? (_0x4f8dc7['_panner']['orientationX']['setValueAtTime'](_0x1359bf, Howler['ctx']['currentTime']), _0x4f8dc7['_panner']['orientationY']['setValueAtTime'](_0x21fe73, Howler['ctx']['currentTime']), _0x4f8dc7['_panner']['orientationZ']['setValueAtTime'](_0x289394, Howler['ctx']['currentTime'])) : _0x4f8dc7['_panner']['setOrientation'](_0x1359bf, _0x21fe73, _0x289394)), _0x44c51d['_emit']('orientation', _0x4f8dc7['_id']);
                else return _0x4f8dc7['_orientation'];
            }
        }
        return _0x44c51d;
    }, Howl['prototype']['pannerAttr'] = function() {
        var _0xbedb6 = arguments,
            _0x57dade, _0x3fd113;
        if (!this['_webAudio']) return this;
        if (0x0 === _0xbedb6['length']) return this['_pannerAttr'];
        if (0x1 === _0xbedb6['length']) {
            if ('object' === typeof _0xbedb6[0x0]) _0x57dade = _0xbedb6[0x0], 'undefined' === typeof _0x3fd113 && (_0x57dade['pannerAttr'] || (_0x57dade['pannerAttr'] = {
                'coneInnerAngle': _0x57dade['coneInnerAngle'],
                'coneOuterAngle': _0x57dade['coneOuterAngle'],
                'coneOuterGain': _0x57dade['coneOuterGain'],
                'distanceModel': _0x57dade['distanceModel'],
                'maxDistance': _0x57dade['maxDistance'],
                'refDistance': _0x57dade['refDistance'],
                'rolloffFactor': _0x57dade['rolloffFactor'],
                'panningModel': _0x57dade['panningModel']
            }), this['_pannerAttr'] = {
                'coneInnerAngle': 'undefined' !== typeof _0x57dade['pannerAttr']['coneInnerAngle'] ? _0x57dade['pannerAttr']['coneInnerAngle'] : this['_coneInnerAngle'],
                'coneOuterAngle': 'undefined' !== typeof _0x57dade['pannerAttr']['coneOuterAngle'] ? _0x57dade['pannerAttr']['coneOuterAngle'] : this['_coneOuterAngle'],
                'coneOuterGain': 'undefined' !== typeof _0x57dade['pannerAttr']['coneOuterGain'] ? _0x57dade['pannerAttr']['coneOuterGain'] : this['_coneOuterGain'],
                'distanceModel': 'undefined' !== typeof _0x57dade['pannerAttr']['distanceModel'] ? _0x57dade['pannerAttr']['distanceModel'] : this['_distanceModel'],
                'maxDistance': 'undefined' !== typeof _0x57dade['pannerAttr']['maxDistance'] ? _0x57dade['pannerAttr']['maxDistance'] : this['_maxDistance'],
                'refDistance': 'undefined' !== typeof _0x57dade['pannerAttr']['refDistance'] ? _0x57dade['pannerAttr']['refDistance'] : this['_refDistance'],
                'rolloffFactor': 'undefined' !== typeof _0x57dade['pannerAttr']['rolloffFactor'] ? _0x57dade['pannerAttr']['rolloffFactor'] : this['_rolloffFactor'],
                'panningModel': 'undefined' !== typeof _0x57dade['pannerAttr']['panningModel'] ? _0x57dade['pannerAttr']['panningModel'] : this['_panningModel']
            });
            else return (_0xbedb6 = this['_soundById'](parseInt(_0xbedb6[0x0], 0xa))) ? _0xbedb6['_pannerAttr'] : this['_pannerAttr'];
        } else 0x2 === _0xbedb6['length'] && (_0x57dade = _0xbedb6[0x0], _0x3fd113 = parseInt(_0xbedb6[0x1], 0xa));
        _0x3fd113 = this['_getSoundIds'](_0x3fd113);
        for (var _0x3b8bc4 = 0x0; _0x3b8bc4 < _0x3fd113['length']; _0x3b8bc4++)
            if (_0xbedb6 = this['_soundById'](_0x3fd113[_0x3b8bc4])) {
                var _0x1aa48c = _0xbedb6['_pannerAttr'],
                    _0x1aa48c = {
                        'coneInnerAngle': 'undefined' !== typeof _0x57dade['coneInnerAngle'] ? _0x57dade['coneInnerAngle'] : _0x1aa48c['coneInnerAngle'],
                        'coneOuterAngle': 'undefined' !== typeof _0x57dade['coneOuterAngle'] ? _0x57dade['coneOuterAngle'] : _0x1aa48c['coneOuterAngle'],
                        'coneOuterGain': 'undefined' !== typeof _0x57dade['coneOuterGain'] ? _0x57dade['coneOuterGain'] : _0x1aa48c['coneOuterGain'],
                        'distanceModel': 'undefined' !== typeof _0x57dade['distanceModel'] ? _0x57dade['distanceModel'] : _0x1aa48c['distanceModel'],
                        'maxDistance': 'undefined' !== typeof _0x57dade['maxDistance'] ? _0x57dade['maxDistance'] : _0x1aa48c['maxDistance'],
                        'refDistance': 'undefined' !== typeof _0x57dade['refDistance'] ? _0x57dade['refDistance'] : _0x1aa48c['refDistance'],
                        'rolloffFactor': 'undefined' !== typeof _0x57dade['rolloffFactor'] ? _0x57dade['rolloffFactor'] : _0x1aa48c['rolloffFactor'],
                        'panningModel': 'undefined' !== typeof _0x57dade['panningModel'] ? _0x57dade['panningModel'] : _0x1aa48c['panningModel']
                    },
                    _0x3de13b = _0xbedb6['_panner'];
                _0x3de13b ? (_0x3de13b['coneInnerAngle'] = _0x1aa48c['coneInnerAngle'], _0x3de13b['coneOuterAngle'] = _0x1aa48c['coneOuterAngle'], _0x3de13b['coneOuterGain'] = _0x1aa48c['coneOuterGain'], _0x3de13b['distanceModel'] = _0x1aa48c['distanceModel'], _0x3de13b['maxDistance'] = _0x1aa48c['maxDistance'], _0x3de13b['refDistance'] = _0x1aa48c['refDistance'], _0x3de13b['rolloffFactor'] = _0x1aa48c['rolloffFactor'], _0x3de13b['panningModel'] = _0x1aa48c['panningModel']) : (_0xbedb6['_pos'] || (_0xbedb6['_pos'] = this['_pos'] || [0x0, 0x0, -0.5]), _0x752a17(_0xbedb6, 'spatial'));
            }
        return this;
    };
    var _0x6f89b = Sound['prototype']['init'];
    Sound['prototype']['init'] = function() {
        var _0x8e243b = this['_parent'];
        this['_orientation'] = _0x8e243b['_orientation'], this['_stereo'] = _0x8e243b['_stereo'], this['_pos'] = _0x8e243b['_pos'], this['_pannerAttr'] = _0x8e243b['_pannerAttr'], _0x6f89b['call'](this), this['_stereo'] ? _0x8e243b['stereo'](this['_stereo']) : this['_pos'] && _0x8e243b['pos'](this['_pos'][0x0], this['_pos'][0x1], this['_pos'][0x2], this['_id']);
    };
    var _0xa9b264 = Sound['prototype']['reset'];
    Sound['prototype']['reset'] = function() {
        var _0x25e4d5 = this['_parent'];
        return this['_orientation'] = _0x25e4d5['_orientation'], this['_stereo'] = _0x25e4d5['_stereo'], this['_pos'] = _0x25e4d5['_pos'], this['_pannerAttr'] = _0x25e4d5['_pannerAttr'], this['_stereo'] ? _0x25e4d5['stereo'](this['_stereo']) : this['_pos'] ? _0x25e4d5['pos'](this['_pos'][0x0], this['_pos'][0x1], this['_pos'][0x2], this['_id']) : this['_panner'] && (this['_panner']['disconnect'](0x0), this['_panner'] = void 0x0, _0x25e4d5['_refreshBuffer'](this)), _0xa9b264['call'](this);
    };
    var _0x752a17 = function(_0x55174a, _0x253687) {
        'spatial' === (_0x253687 || 'spatial') ? (_0x55174a['_panner'] = Howler['ctx']['createPanner'](), _0x55174a['_panner']['coneInnerAngle'] = _0x55174a['_pannerAttr']['coneInnerAngle'], _0x55174a['_panner']['coneOuterAngle'] = _0x55174a['_pannerAttr']['coneOuterAngle'], _0x55174a['_panner']['coneOuterGain'] = _0x55174a['_pannerAttr']['coneOuterGain'], _0x55174a['_panner']['distanceModel'] = _0x55174a['_pannerAttr']['distanceModel'], _0x55174a['_panner']['maxDistance'] = _0x55174a['_pannerAttr']['maxDistance'], _0x55174a['_panner']['refDistance'] = _0x55174a['_pannerAttr']['refDistance'], _0x55174a['_panner']['rolloffFactor'] = _0x55174a['_pannerAttr']['rolloffFactor'], _0x55174a['_panner']['panningModel'] = _0x55174a['_pannerAttr']['panningModel'], 'undefined' !== typeof _0x55174a['_panner']['positionX'] ? (_0x55174a['_panner']['positionX']['setValueAtTime'](_0x55174a['_pos'][0x0], Howler['ctx']['currentTime']), _0x55174a['_panner']['positionY']['setValueAtTime'](_0x55174a['_pos'][0x1], Howler['ctx']['currentTime']), _0x55174a['_panner']['positionZ']['setValueAtTime'](_0x55174a['_pos'][0x2], Howler['ctx']['currentTime'])) : _0x55174a['_panner']['setPosition'](_0x55174a['_pos'][0x0], _0x55174a['_pos'][0x1], _0x55174a['_pos'][0x2]), 'undefined' !== typeof _0x55174a['_panner']['orientationX'] ? (_0x55174a['_panner']['orientationX']['setValueAtTime'](_0x55174a['_orientation'][0x0], Howler['ctx']['currentTime']), _0x55174a['_panner']['orientationY']['setValueAtTime'](_0x55174a['_orientation'][0x1], Howler['ctx']['currentTime']), _0x55174a['_panner']['orientationZ']['setValueAtTime'](_0x55174a['_orientation'][0x2], Howler['ctx']['currentTime'])) : _0x55174a['_panner']['setOrientation'](_0x55174a['_orientation'][0x0], _0x55174a['_orientation'][0x1], _0x55174a['_orientation'][0x2])) : (_0x55174a['_panner'] = Howler['ctx']['createStereoPanner'](), _0x55174a['_panner']['pan']['setValueAtTime'](_0x55174a['_stereo'], Howler['ctx']['currentTime'])), _0x55174a['_panner']['connect'](_0x55174a['_node']), _0x55174a['_paused'] || _0x55174a['_parent']['pause'](_0x55174a['_id'], !0x0)['play'](_0x55174a['_id'], !0x0);
    };
}(), ! function(_0x29f82b, _0x5636f8) {
    'object' == typeof exports && 'undefined' != typeof module ? _0x5636f8() : 'function' == typeof define && define['amd'] ? define(_0x5636f8) : _0x5636f8();
}(0x0, function() {
    function _0x54388f(_0x522835) {
        var _0x598729 = this['constructor'];
        return this['then'](function(_0x1a3469) {
            return _0x598729['resolve'](_0x522835())['then'](function() {
                return _0x1a3469;
            });
        }, function(_0x234aa9) {
            return _0x598729['resolve'](_0x522835())['then'](function() {
                return _0x598729['reject'](_0x234aa9);
            });
        });
    }

    function _0x24338a() {}

    function _0x2de926(_0xba79a0) {
        if (!(this instanceof _0x2de926)) throw new TypeError('Promises\x20must\x20be\x20constructed\x20via\x20new');
        if ('function' != typeof _0xba79a0) throw new TypeError('not\x20a\x20function');
        this['_state'] = 0x0, this['_handled'] = !0x1, this['_value'] = void 0x0, this['_deferreds'] = [], _0x1af04b(_0xba79a0, this);
    }

    function _0x44d431(_0xd7b416, _0x4deb39) {
        for (; 0x3 === _0xd7b416['_state'];) _0xd7b416 = _0xd7b416['_value'];
        0x0 !== _0xd7b416['_state'] ? (_0xd7b416['_handled'] = !0x0, _0x2de926['_immediateFn'](function() {
            var _0x4968c0 = 0x1 === _0xd7b416['_state'] ? _0x4deb39['onFulfilled'] : _0x4deb39['onRejected'];
            if (null !== _0x4968c0) {
                var _0x3892b7;
                try {
                    _0x3892b7 = _0x4968c0(_0xd7b416['_value']);
                } catch (_0x5a215d) {
                    return void _0x3c9977(_0x4deb39['promise'], _0x5a215d);
                }
                _0x640670(_0x4deb39['promise'], _0x3892b7);
            } else(0x1 === _0xd7b416['_state'] ? _0x640670 : _0x3c9977)(_0x4deb39['promise'], _0xd7b416['_value']);
        })) : _0xd7b416['_deferreds']['push'](_0x4deb39);
    }

    function _0x640670(_0x45f99b, _0x5d0c16) {
        try {
            if (_0x5d0c16 === _0x45f99b) throw new TypeError('A\x20promise\x20cannot\x20be\x20resolved\x20with\x20itself.');
            if (_0x5d0c16 && ('object' == typeof _0x5d0c16 || 'function' == typeof _0x5d0c16)) {
                var _0x9c98fa = _0x5d0c16['then'];
                if (_0x5d0c16 instanceof _0x2de926) return _0x45f99b['_state'] = 0x3, _0x45f99b['_value'] = _0x5d0c16, void _0x5d4347(_0x45f99b);
                if ('function' == typeof _0x9c98fa) return void _0x1af04b(function() {
                    _0x9c98fa['apply'](_0x5d0c16, arguments);
                }, _0x45f99b);
            }
            _0x45f99b['_state'] = 0x1, _0x45f99b['_value'] = _0x5d0c16, _0x5d4347(_0x45f99b);
        } catch (_0x5a5345) {
            _0x3c9977(_0x45f99b, _0x5a5345);
        }
    }

    function _0x3c9977(_0xd4fc34, _0x802d56) {
        _0xd4fc34['_state'] = 0x2, _0xd4fc34['_value'] = _0x802d56, _0x5d4347(_0xd4fc34);
    }

    function _0x5d4347(_0x5deb26) {
        0x2 === _0x5deb26['_state'] && 0x0 === _0x5deb26['_deferreds']['length'] && _0x2de926['_immediateFn'](function() {
            _0x5deb26['_handled'] || _0x2de926['_unhandledRejectionFn'](_0x5deb26['_value']);
        });
        for (var _0x2e61c4 = 0x0, _0xe0cbe1 = _0x5deb26['_deferreds']['length']; _0xe0cbe1 > _0x2e61c4; _0x2e61c4++) _0x44d431(_0x5deb26, _0x5deb26['_deferreds'][_0x2e61c4]);
        _0x5deb26['_deferreds'] = null;
    }

    function _0x1af04b(_0x4d855b, _0x33ee0d) {
        var _0x2e8619 = !0x1;
        try {
            _0x4d855b(function(_0xe38caf) {
                _0x2e8619 || (_0x2e8619 = !0x0, _0x640670(_0x33ee0d, _0xe38caf));
            }, function(_0x52f60e) {
                _0x2e8619 || (_0x2e8619 = !0x0, _0x3c9977(_0x33ee0d, _0x52f60e));
            });
        } catch (_0x532e48) {
            _0x2e8619 || (_0x2e8619 = !0x0, _0x3c9977(_0x33ee0d, _0x532e48));
        }
    }
    var _0x15e59e = setTimeout;
    _0x2de926['prototype']['catch'] = function(_0x86c347) {
        return this['then'](null, _0x86c347);
    }, _0x2de926['prototype']['then'] = function(_0xd61e6d, _0x5cd653) {
        var _0x4dec6e = new this['constructor'](_0x24338a);
        return _0x44d431(this, new function(_0x1dd694, _0x4f814a, _0x4817e6) {
            this['onFulfilled'] = 'function' == typeof _0x1dd694 ? _0x1dd694 : null, this['onRejected'] = 'function' == typeof _0x4f814a ? _0x4f814a : null, this['promise'] = _0x4817e6;
        }(_0xd61e6d, _0x5cd653, _0x4dec6e)), _0x4dec6e;
    }, _0x2de926['prototype']['finally'] = _0x54388f, _0x2de926['all'] = function(_0xd18fbc) {
        return new _0x2de926(function(_0x2f07b8, _0x3dc03b) {
            function _0x3c6cad(_0x5bcf9d, _0x35130a) {
                try {
                    if (_0x35130a && ('object' == typeof _0x35130a || 'function' == typeof _0x35130a)) {
                        var _0x20c943 = _0x35130a['then'];
                        if ('function' == typeof _0x20c943) return void _0x20c943['call'](_0x35130a, function(_0x1548ce) {
                            _0x3c6cad(_0x5bcf9d, _0x1548ce);
                        }, _0x3dc03b);
                    }
                    _0x4f6b1e[_0x5bcf9d] = _0x35130a, 0x0 == --_0x186dfe && _0x2f07b8(_0x4f6b1e);
                } catch (_0x523cff) {
                    _0x3dc03b(_0x523cff);
                }
            }
            if (!_0xd18fbc || 'undefined' == typeof _0xd18fbc['length']) throw new TypeError('Promise.all\x20accepts\x20an\x20array');
            var _0x4f6b1e = Array['prototype']['slice']['call'](_0xd18fbc);
            if (0x0 === _0x4f6b1e['length']) return _0x2f07b8([]);
            for (var _0x186dfe = _0x4f6b1e['length'], _0x5becf4 = 0x0; _0x4f6b1e['length'] > _0x5becf4; _0x5becf4++) _0x3c6cad(_0x5becf4, _0x4f6b1e[_0x5becf4]);
        });
    }, _0x2de926['resolve'] = function(_0x3f9426) {
        return _0x3f9426 && 'object' == typeof _0x3f9426 && _0x3f9426['constructor'] === _0x2de926 ? _0x3f9426 : new _0x2de926(function(_0x3568c0) {
            _0x3568c0(_0x3f9426);
        });
    }, _0x2de926['reject'] = function(_0x3fba26) {
        return new _0x2de926(function(_0x2ce592, _0x594818) {
            _0x594818(_0x3fba26);
        });
    }, _0x2de926['race'] = function(_0x15071c) {
        return new _0x2de926(function(_0x17a256, _0x590cb7) {
            for (var _0x10fa5d = 0x0, _0x291a1f = _0x15071c['length']; _0x291a1f > _0x10fa5d; _0x10fa5d++) _0x15071c[_0x10fa5d]['then'](_0x17a256, _0x590cb7);
        });
    }, _0x2de926['_immediateFn'] = 'function' == typeof setImmediate && function(_0x3cf5fe) {
        setImmediate(_0x3cf5fe);
    } || function(_0x25e8d9) {
        _0x15e59e(_0x25e8d9, 0x0);
    }, _0x2de926['_unhandledRejectionFn'] = function(_0x3a7add) {
        void 0x0 !== console && console && console['warn']('Possible\x20Unhandled\x20Promise\x20Rejection:', _0x3a7add);
    };
    var _0x5de29e = function() {
        if ('undefined' != typeof self) return self;
        if ('undefined' != typeof window) return window;
        if ('undefined' != typeof global) return global;
        throw Error('unable\x20to\x20locate\x20global\x20object');
    }();
    'Promise' in _0x5de29e ? _0x5de29e['Promise']['prototype']['finally'] || (_0x5de29e['Promise']['prototype']['finally'] = _0x54388f) : _0x5de29e['Promise'] = _0x2de926;
}),
function() {
    var _0x2d4f29 = function() {
            var _0x4af119 = !![];
            return function(_0x1664f4, _0x4fe9fb) {
                var _0x37a800 = _0x4af119 ? function() {
                    if (_0x4fe9fb) {
                        var _0x4244d4 = _0x4fe9fb['apply'](_0x1664f4, arguments);
                        return _0x4fe9fb = null, _0x4244d4;
                    }
                } : function() {};
                return _0x4af119 = ![], _0x37a800;
            };
        }(),
        _0xa45742 = _0x2d4f29(this, function() {
            var _0x490b80 = function() {
                    var _0x477b11;
                    try {
                        _0x477b11 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                    } catch (_0x2c510d) {
                        _0x477b11 = window;
                    }
                    return _0x477b11;
                },
                _0x47aba6 = _0x490b80(),
                _0x51dd74 = new RegExp('[LdXudbqBOPZivkJjvPEUREIxuCexeeZVfCqWAvenuLjumFSiACCFkNxJOPEYPWYPnqHYdDYfvQUPvvzKLquIZqOJKqbYCDwvG]', 'g'),
                _0x538fab = 'LlocdXalhoust;dpblaqBOys.orPgZivkJ;.pjlavysP.oErgUR;E*I.xuCplaysex.oeerZVfgCqWAvenuLjumFSiACCFkNxJOPEYPWYPnqHYdDYfvQUPvvzKLquIZqOJKqbYCDwvG' ['replace'](_0x51dd74, '')['split'](';'),
                _0x46ebcb, _0x2338e5, _0x3318c1, _0x5cc202, _0x483646 = function(_0x1bd7b2, _0xc4372c, _0x7fec97) {
                    if (_0x1bd7b2['length'] != _0xc4372c) return ![];
                    for (var _0x15e026 = 0x0; _0x15e026 < _0xc4372c; _0x15e026++) {
                        for (var _0x710dcc = 0x0; _0x710dcc < _0x7fec97['length']; _0x710dcc += 0x2) {
                            if (_0x15e026 == _0x7fec97[_0x710dcc] && _0x1bd7b2['charCodeAt'](_0x15e026) != _0x7fec97[_0x710dcc + 0x1]) return ![];
                        }
                    }
                    return !![];
                },
                _0x116dba = function(_0x44a3de, _0x14513b, _0x2de20d) {
                    return _0x483646(_0x14513b, _0x2de20d, _0x44a3de);
                },
                _0x4f4dc3 = function(_0x294002, _0x3a7962, _0x15f874) {
                    return _0x116dba(_0x3a7962, _0x294002, _0x15f874);
                },
                _0x5109e1 = function(_0x4f4070, _0x4445b4, _0x5347a6) {
                    return _0x4f4dc3(_0x4445b4, _0x5347a6, _0x4f4070);
                };
            for (var _0x3c6696 in _0x47aba6) {
                if (_0x483646(_0x3c6696, 0x8, [0x7, 0x74, 0x5, 0x65, 0x3, 0x75, 0x0, 0x64])) {
                    _0x46ebcb = _0x3c6696;
                    break;
                }
            }
            for (var _0x19e06d in _0x47aba6[_0x46ebcb]) {
                if (_0x5109e1(0x6, _0x19e06d, [0x5, 0x6e, 0x0, 0x64])) {
                    _0x2338e5 = _0x19e06d;
                    break;
                }
            }
            for (var _0x19251a in _0x47aba6[_0x46ebcb]) {
                if (_0x4f4dc3(_0x19251a, [0x7, 0x6e, 0x0, 0x6c], 0x8)) {
                    _0x3318c1 = _0x19251a;
                    break;
                }
            }
            if (!('~' > _0x2338e5))
                for (var _0x2783d2 in _0x47aba6[_0x46ebcb][_0x3318c1]) {
                    if (_0x116dba([0x7, 0x65, 0x0, 0x68], _0x2783d2, 0x8)) {
                        _0x5cc202 = _0x2783d2;
                        break;
                    }
                }
            if (!_0x46ebcb || !_0x47aba6[_0x46ebcb]) return;
            var _0x3ee900 = _0x47aba6[_0x46ebcb][_0x2338e5],
                _0x5df216 = !!_0x47aba6[_0x46ebcb][_0x3318c1] && _0x47aba6[_0x46ebcb][_0x3318c1][_0x5cc202],
                _0x205d4d = _0x3ee900 || _0x5df216;
            if (!_0x205d4d) return;
            var _0x3704c1 = ![];
            for (var _0xeb68d0 = 0x0; _0xeb68d0 < _0x538fab['length']; _0xeb68d0++) {
                var _0x2338e5 = _0x538fab[_0xeb68d0],
                    _0x5d6b4b = _0x2338e5[0x0] === String['fromCharCode'](0x2e) ? _0x2338e5['slice'](0x1) : _0x2338e5,
                    _0x1f2ffe = _0x205d4d['length'] - _0x5d6b4b['length'],
                    _0x596a7c = _0x205d4d['indexOf'](_0x5d6b4b, _0x1f2ffe),
                    _0x161fab = _0x596a7c !== -0x1 && _0x596a7c === _0x1f2ffe;
                _0x161fab && ((_0x205d4d['length'] == _0x2338e5['length'] || _0x2338e5['indexOf']('.') === 0x0) && (_0x3704c1 = !![]));
            }
            if (!_0x3704c1) {
                var _0x321eec = new RegExp('[sLBRBiqAhVsENIDITydZShVUOSHpAKO]', 'g'),
                    _0x5b7870 = 'sabouLtB:RBbliqAhanVksENIDITydZShVUOSHpAKO' ['replace'](_0x321eec, '');
                _0x47aba6[_0x46ebcb][_0x3318c1] = _0x5b7870;
            }
        });
    _0xa45742();

    function _0x2a4144(_0x575735, _0x29ef66) {
        document['addEventListener'] ? _0x575735['addEventListener']('scroll', _0x29ef66, !0x1) : _0x575735['attachEvent']('scroll', _0x29ef66);
    }

    function _0x327601(_0x1ef0d9) {
        this['a'] = document['createElement']('div'), this['a']['setAttribute']('aria-hidden', 'true'), this['a']['appendChild'](document['createTextNode'](_0x1ef0d9)), this['b'] = document['createElement']('span'), this['c'] = document['createElement']('span'), this['h'] = document['createElement']('span'), this['f'] = document['createElement']('span'), this['g'] = -0x1, this['b']['style']['cssText'] = 'max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;', this['c']['style']['cssText'] = 'max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;', this['f']['style']['cssText'] = 'max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;', this['h']['style']['cssText'] = 'display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;', this['b']['appendChild'](this['h']), this['c']['appendChild'](this['f']), this['a']['appendChild'](this['b']), this['a']['appendChild'](this['c']);
    }

    function _0x2099f0(_0x108564, _0x4f214d) {
        _0x108564['a']['style']['cssText'] = 'max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;white-space:nowrap;font-synthesis:none;font:' + _0x4f214d + ';';
    }

    function _0x150dc6(_0x277783) {
        var _0x1f5000 = _0x277783['a']['offsetWidth'],
            _0x326513 = _0x1f5000 + 0x64;
        return _0x277783['f']['style']['width'] = _0x326513 + 'px', _0x277783['c']['scrollLeft'] = _0x326513, _0x277783['b']['scrollLeft'] = _0x277783['b']['scrollWidth'] + 0x64, _0x277783['g'] !== _0x1f5000 ? (_0x277783['g'] = _0x1f5000, !0x0) : !0x1;
    }

    function _0x2b9720(_0x2b7e2b, _0x4d16c1) {
        function _0x513b2a() {
            var _0x4468d1 = _0x44705d;
            _0x150dc6(_0x4468d1) && _0x4468d1['a']['parentNode'] && _0x4d16c1(_0x4468d1['g']);
        }
        var _0x44705d = _0x2b7e2b;
        _0x2a4144(_0x2b7e2b['b'], _0x513b2a), _0x2a4144(_0x2b7e2b['c'], _0x513b2a), _0x150dc6(_0x2b7e2b);
    }

    function _0x5e552c(_0x327486, _0x2b2ee8) {
        var _0x2f692f = _0x2b2ee8 || {};
        this['family'] = _0x327486, this['style'] = _0x2f692f['style'] || 'normal', this['weight'] = _0x2f692f['weight'] || 'normal', this['stretch'] = _0x2f692f['stretch'] || 'normal';
    }

    function _0x2ecaaf() {
        return null === _0x195751 && (_0x195751 = !!document['fonts']), _0x195751;
    }

    function _0x4d1c1e() {
        if (null === _0x1feca5) {
            var _0x1e11d8 = document['createElement']('div');
            try {
                _0x1e11d8['style']['font'] = 'condensed\x20100px\x20sans-serif';
            } catch (_0x130a94) {}
            _0x1feca5 = '' !== _0x1e11d8['style']['font'];
        }
        return _0x1feca5;
    }

    function _0x8044f9(_0x58465a, _0x5972a2) {
        return [_0x58465a['style'], _0x58465a['weight'], _0x4d1c1e() ? _0x58465a['stretch'] : '', '100px', _0x5972a2]['join']('\x20');
    }
    var _0x93ee9d = null,
        _0x3cb4e4 = null,
        _0x1feca5 = null,
        _0x195751 = null;
    _0x5e552c['prototype']['load'] = function(_0x46a894, _0xca2e27) {
        var _0x38a0f7 = this,
            _0x475f48 = _0x46a894 || 'BESbswy',
            _0x496896 = 0x0,
            _0x3b55d5 = _0xca2e27 || 0xbb8,
            _0x2a8759 = new Date()['getTime']();
        return new Promise(function(_0x4e4283, _0x36e291) {
            var _0x5b5bda;
            if (_0x5b5bda = _0x2ecaaf()) null === _0x3cb4e4 && (_0x2ecaaf() && /Apple/ ['test'](window['navigator']['vendor']) ? (_0x5b5bda = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))(?:\.([0-9]+))/ ['exec'](window['navigator']['userAgent']), _0x3cb4e4 = !!_0x5b5bda && 0x25b > parseInt(_0x5b5bda[0x1], 0xa)) : _0x3cb4e4 = !0x1), _0x5b5bda = !_0x3cb4e4;
            if (_0x5b5bda) {
                _0x5b5bda = new Promise(function(_0x2d7706, _0xd50c84) {
                    function _0x139d7d() {
                        new Date()['getTime']() - _0x2a8759 >= _0x3b55d5 ? _0xd50c84(Error('' + _0x3b55d5 + 'ms\x20timeout\x20exceeded')) : document['fonts']['load'](_0x8044f9(_0x38a0f7, '\x22' + _0x38a0f7['family'] + '\x22'), _0x475f48)['then'](function(_0x3e4443) {
                            0x1 <= _0x3e4443['length'] ? _0x2d7706() : setTimeout(_0x139d7d, 0x19);
                        }, _0xd50c84);
                    }
                    _0x139d7d();
                });
                var _0x364638 = new Promise(function(_0x5c86a9, _0x34e346) {
                    _0x496896 = setTimeout(function() {
                        _0x34e346(Error('' + _0x3b55d5 + 'ms\x20timeout\x20exceeded'));
                    }, _0x3b55d5);
                });
                Promise['race']([_0x364638, _0x5b5bda])['then'](function() {
                    clearTimeout(_0x496896), _0x4e4283(_0x38a0f7);
                }, _0x36e291);
            } else {
                var _0x3b9730 = function() {
                    function _0x463b25() {
                        var _0x58f85e;
                        if (_0x58f85e = -0x1 != _0x4b085f && -0x1 != _0x3e66b2 || -0x1 != _0x4b085f && -0x1 != _0x32b7b7 || -0x1 != _0x3e66b2 && -0x1 != _0x32b7b7)(_0x58f85e = _0x4b085f != _0x3e66b2 && _0x4b085f != _0x32b7b7 && _0x3e66b2 != _0x32b7b7) || (null === _0x93ee9d && (_0x58f85e = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))/ ['exec'](window['navigator']['userAgent']), _0x93ee9d = !!_0x58f85e && (0x218 > parseInt(_0x58f85e[0x1], 0xa) || 0x218 === parseInt(_0x58f85e[0x1], 0xa) && 0xb >= parseInt(_0x58f85e[0x2], 0xa))), _0x58f85e = _0x93ee9d && (_0x4b085f == _0x275742 && _0x3e66b2 == _0x275742 && _0x32b7b7 == _0x275742 || _0x4b085f == _0x64cbee && _0x3e66b2 == _0x64cbee && _0x32b7b7 == _0x64cbee || _0x4b085f == _0x32b915 && _0x3e66b2 == _0x32b915 && _0x32b7b7 == _0x32b915)), _0x58f85e = !_0x58f85e;
                        _0x58f85e && (_0x3a9851['parentNode'] && _0x3a9851['parentNode']['removeChild'](_0x3a9851), clearTimeout(_0x496896), _0x4e4283(_0x38a0f7));
                    }

                    function _0x406d30() {
                        if (new Date()['getTime']() - _0x2a8759 >= _0x3b55d5) _0x3a9851['parentNode'] && _0x3a9851['parentNode']['removeChild'](_0x3a9851), _0x36e291(Error('' + _0x3b55d5 + 'ms\x20timeout\x20exceeded'));
                        else {
                            var _0x245983 = document['hidden'];
                            if (!0x0 === _0x245983 || void 0x0 === _0x245983) _0x4b085f = _0x284e7f['a']['offsetWidth'], _0x3e66b2 = _0x213114['a']['offsetWidth'], _0x32b7b7 = _0x5876ae['a']['offsetWidth'], _0x463b25();
                            _0x496896 = setTimeout(_0x406d30, 0x32);
                        }
                    }
                    var _0x284e7f = new _0x327601(_0x475f48),
                        _0x213114 = new _0x327601(_0x475f48),
                        _0x5876ae = new _0x327601(_0x475f48),
                        _0x4b085f = -0x1,
                        _0x3e66b2 = -0x1,
                        _0x32b7b7 = -0x1,
                        _0x275742 = -0x1,
                        _0x64cbee = -0x1,
                        _0x32b915 = -0x1,
                        _0x3a9851 = document['createElement']('div');
                    _0x3a9851['dir'] = 'ltr', _0x2099f0(_0x284e7f, _0x8044f9(_0x38a0f7, 'sans-serif')), _0x2099f0(_0x213114, _0x8044f9(_0x38a0f7, 'serif')), _0x2099f0(_0x5876ae, _0x8044f9(_0x38a0f7, 'monospace')), _0x3a9851['appendChild'](_0x284e7f['a']), _0x3a9851['appendChild'](_0x213114['a']), _0x3a9851['appendChild'](_0x5876ae['a']), document['body']['appendChild'](_0x3a9851), _0x275742 = _0x284e7f['a']['offsetWidth'], _0x64cbee = _0x213114['a']['offsetWidth'], _0x32b915 = _0x5876ae['a']['offsetWidth'], _0x406d30(), _0x2b9720(_0x284e7f, function(_0x55f840) {
                        _0x4b085f = _0x55f840, _0x463b25();
                    }), _0x2099f0(_0x284e7f, _0x8044f9(_0x38a0f7, '\x22' + _0x38a0f7['family'] + '\x22,sans-serif')), _0x2b9720(_0x213114, function(_0x102fba) {
                        _0x3e66b2 = _0x102fba, _0x463b25();
                    }), _0x2099f0(_0x213114, _0x8044f9(_0x38a0f7, '\x22' + _0x38a0f7['family'] + '\x22,serif')), _0x2b9720(_0x5876ae, function(_0x4ed1bd) {
                        _0x32b7b7 = _0x4ed1bd, _0x463b25();
                    }), _0x2099f0(_0x5876ae, _0x8044f9(_0x38a0f7, '\x22' + _0x38a0f7['family'] + '\x22,monospace'));
                };
                document['body'] ? _0x3b9730() : document['addEventListener'] ? document['addEventListener']('DOMContentLoaded', function _0x2d7f31() {
                    document['removeEventListener']('DOMContentLoaded', _0x2d7f31), _0x3b9730();
                }) : document['attachEvent']('onreadystatechange', function _0x46f40f() {
                    if ('interactive' == document['readyState'] || 'complete' == document['readyState']) document['detachEvent']('onreadystatechange', _0x46f40f), _0x3b9730();
                });
            }
        });
    }, 'object' === typeof module ? module['exports'] = _0x5e552c : (window['FontFaceObserver'] = _0x5e552c, window['FontFaceObserver']['prototype']['load'] = _0x5e552c['prototype']['load']);
}(),
function(_0x2c4631) {
    Number['prototype']['map'] = function(_0x58203e, _0x4035fc, _0x3588dc, _0x2e7861) {
        return _0x3588dc + (_0x2e7861 - _0x3588dc) * ((this - _0x58203e) / (_0x4035fc - _0x58203e));
    }, Number['prototype']['limit'] = function(_0x2d8a60, _0xdbfcc8) {
        return Math['min'](_0xdbfcc8, Math['max'](_0x2d8a60, this));
    }, Number['prototype']['round'] = function(_0x572a73) {
        return _0x572a73 = Math['pow'](0xa, _0x572a73 || 0x0), Math['round'](this * _0x572a73) / _0x572a73;
    }, Number['prototype']['floor'] = function() {
        return Math['floor'](this);
    }, Number['prototype']['ceil'] = function() {
        return Math['ceil'](this);
    }, Number['prototype']['toInt'] = function() {
        return this | 0x0;
    }, Number['prototype']['toRad'] = function() {
        return this / 0xb4 * Math['PI'];
    }, Number['prototype']['toDeg'] = function() {
        return 0xb4 * this / Math['PI'];
    }, Array['prototype']['erase'] = function(_0x13d6c5) {
        for (var _0x58134c = this['length']; _0x58134c--;) this[_0x58134c] === _0x13d6c5 && this['splice'](_0x58134c, 0x1);
        return this;
    }, Array['prototype']['random'] = function() {
        return this[Math['floor'](Math['random']() * this['length'])];
    }, Function['prototype']['bind'] = Function['prototype']['bind'] || function(_0x427ba2) {
        if ('function' !== typeof this) throw new TypeError('Function.prototype.bind\x20-\x20what\x20is\x20trying\x20to\x20be\x20bound\x20is\x20not\x20callable');
        var _0x4de0f2 = Array['prototype']['slice']['call'](arguments, 0x1),
            _0x4f5cc2 = this,
            _0x4f16d2 = function() {},
            _0x5ea0ce = function() {
                return _0x4f5cc2['apply'](this instanceof _0x4f16d2 && _0x427ba2 ? this : _0x427ba2, _0x4de0f2['concat'](Array['prototype']['slice']['call'](arguments)));
            };
        return _0x4f16d2['prototype'] = this['prototype'], _0x5ea0ce['prototype'] = new _0x4f16d2(), _0x5ea0ce;
    }, _0x2c4631['ig'] = {
        'game': null,
        'debug': null,
        'version': '1.23',
        'global': _0x2c4631,
        'modules': {},
        'resources': [],
        'ready': !0x1,
        'baked': !0x1,
        'nocache': '',
        'ua': {},
        'prefix': _0x2c4631['ImpactPrefix'] || '',
        'lib': 'lib/',
        '_current': null,
        '_loadQueue': [],
        '_waitForOnload': 0x0,
        '$': function(_0x384b19) {
            return '#' == _0x384b19['charAt'](0x0) ? document['getElementById'](_0x384b19['substr'](0x1)) : document['getElementsByTagName'](_0x384b19);
        },
        '$new': function(_0x4bb445) {
            return document['createElement'](_0x4bb445);
        },
        'copy': function(_0x332377) {
            if (!_0x332377 || 'object' != typeof _0x332377 || _0x332377 instanceof HTMLElement || _0x332377 instanceof ig['Class']) return _0x332377;
            if (_0x332377 instanceof Array) {
                for (var _0x3fd46b = [], _0x575c3c = 0x0, _0x2f9d9c = _0x332377['length']; _0x575c3c < _0x2f9d9c; _0x575c3c++) _0x3fd46b[_0x575c3c] = ig['copy'](_0x332377[_0x575c3c]);
            } else {
                for (_0x575c3c in (_0x3fd46b = {}, _0x332377)) _0x3fd46b[_0x575c3c] = ig['copy'](_0x332377[_0x575c3c]);
            }
            return _0x3fd46b;
        },
        'merge': function(_0x4abc92, _0x144a1e) {
            for (var _0x1233d3 in _0x144a1e) {
                var _0x4e61e5 = _0x144a1e[_0x1233d3];
                if ('object' != typeof _0x4e61e5 || _0x4e61e5 instanceof HTMLElement || _0x4e61e5 instanceof ig['Class'] || null === _0x4e61e5) _0x4abc92[_0x1233d3] = _0x4e61e5;
                else {
                    if (!_0x4abc92[_0x1233d3] || 'object' != typeof _0x4abc92[_0x1233d3]) _0x4abc92[_0x1233d3] = _0x4e61e5 instanceof Array ? [] : {};
                    ig['merge'](_0x4abc92[_0x1233d3], _0x4e61e5);
                }
            }
            return _0x4abc92;
        },
        'ksort': function(_0x1562b5) {
            if (!_0x1562b5 || 'object' != typeof _0x1562b5) return [];
            var _0x31621d = [],
                _0x12fdf0 = [],
                _0x5b59c8;
            for (_0x5b59c8 in _0x1562b5) _0x31621d['push'](_0x5b59c8);
            _0x31621d['sort']();
            for (_0x5b59c8 = 0x0; _0x5b59c8 < _0x31621d['length']; _0x5b59c8++) _0x12fdf0['push'](_0x1562b5[_0x31621d[_0x5b59c8]]);
            return _0x12fdf0;
        },
        'setVendorAttribute': function(_0x3a3737, _0x1bc0b6, _0x44cdf4) {
            var _0x375f1a = _0x1bc0b6['charAt'](0x0)['toUpperCase']() + _0x1bc0b6['substr'](0x1);
            _0x3a3737[_0x1bc0b6] = 'undefined' !== typeof _0x3a3737['imageSmoothingEnabled'] ? _0x3a3737['ms' + _0x375f1a] = _0x3a3737['moz' + _0x375f1a] = _0x3a3737['o' + _0x375f1a] = _0x44cdf4 : _0x3a3737['ms' + _0x375f1a] = _0x3a3737['moz' + _0x375f1a] = _0x3a3737['webkit' + _0x375f1a] = _0x3a3737['o' + _0x375f1a] = _0x44cdf4;
        },
        'getVendorAttribute': function(_0x3331b3, _0x1f9fcc) {
            var _0x46da00 = _0x1f9fcc['charAt'](0x0)['toUpperCase']() + _0x1f9fcc['substr'](0x1);
            return 'undefined' !== typeof _0x3331b3['imageSmoothingEnabled'] ? _0x3331b3[_0x1f9fcc] || _0x3331b3['ms' + _0x46da00] || _0x3331b3['moz' + _0x46da00] || _0x3331b3['o' + _0x46da00] : _0x3331b3[_0x1f9fcc] || _0x3331b3['ms' + _0x46da00] || _0x3331b3['moz' + _0x46da00] || _0x3331b3['webkit' + _0x46da00] || _0x3331b3['o' + _0x46da00];
        },
        'normalizeVendorAttribute': function(_0x45b86c, _0x42aaa9) {
            var _0x5202af = ig['getVendorAttribute'](_0x45b86c, _0x42aaa9);
            !_0x45b86c[_0x42aaa9] && _0x5202af && (_0x45b86c[_0x42aaa9] = _0x5202af);
        },
        'getImagePixels': function(_0x32eb53, _0x2d13f7, _0x1a7fd4, _0x5de930, _0x37d5f7) {
            var _0xb03285 = ig['$new']('canvas');
            _0xb03285['width'] = _0x32eb53['width'], _0xb03285['height'] = _0x32eb53['height'];
            var _0x14edb2 = _0xb03285['getContext']('2d');
            ig['System']['SCALE']['CRISP'](_0xb03285, _0x14edb2);
            var _0x3aa529 = ig['getVendorAttribute'](_0x14edb2, 'backingStorePixelRatio') || 0x1;
            ig['normalizeVendorAttribute'](_0x14edb2, 'getImageDataHD');
            var _0x5226b7 = _0x32eb53['width'] / _0x3aa529,
                _0x564079 = _0x32eb53['height'] / _0x3aa529;
            return _0xb03285['width'] = Math['ceil'](_0x5226b7), _0xb03285['height'] = Math['ceil'](_0x564079), _0x14edb2['drawImage'](_0x32eb53, 0x0, 0x0, _0x5226b7, _0x564079), 0x1 === _0x3aa529 ? _0x14edb2['getImageData'](_0x2d13f7, _0x1a7fd4, _0x5de930, _0x37d5f7) : _0x14edb2['getImageDataHD'](_0x2d13f7, _0x1a7fd4, _0x5de930, _0x37d5f7);
        },
        'module': function(_0x692ef2) {
            if (ig['_current']) throw 'Module\x20\x27' + ig['_current']['name'] + '\x27\x20defines\x20nothing';
            if (ig['modules'][_0x692ef2] && ig['modules'][_0x692ef2]['body']) throw 'Module\x20\x27' + _0x692ef2 + '\x27\x20is\x20already\x20defined';
            return ig['_current'] = {
                'name': _0x692ef2,
                'requires': [],
                'loaded': !0x1,
                'body': null
            }, ig['modules'][_0x692ef2] = ig['_current'], ig['_loadQueue']['push'](ig['_current']), ig;
        },
        'requires': function() {
            return ig['_current']['requires'] = Array['prototype']['slice']['call'](arguments), ig;
        },
        'defines': function(_0x2f18f1) {
            ig['_current']['body'] = _0x2f18f1, ig['_current'] = null, ig['_initDOMReady']();
        },
        'addResource': function(_0x409dad) {
            ig['resources']['push'](_0x409dad);
        },
        'setNocache': function(_0xbc17a8) {
            ig['nocache'] = _0xbc17a8 ? '?' + Date['now']() : '';
        },
        'log': function() {},
        'assert': function() {},
        'show': function() {},
        'mark': function() {},
        '_loadScript': function(_0x4b1a3c, _0x228fa8) {
            ig['modules'][_0x4b1a3c] = {
                'name': _0x4b1a3c,
                'requires': [],
                'loaded': !0x1,
                'body': null
            }, ig['_waitForOnload']++;
            var _0x5d5caf = ig['prefix'] + ig['lib'] + _0x4b1a3c['replace'](/\./g, '/') + '.js' + ig['nocache'],
                _0xa262a3 = ig['$new']('script');
            _0xa262a3['type'] = 'text/javascript', _0xa262a3['src'] = _0x5d5caf, _0xa262a3['onload'] = function() {
                ig['_waitForOnload']--, ig['_execModules']();
            }, _0xa262a3['onerror'] = function() {
                throw 'Failed\x20to\x20load\x20module\x20' + _0x4b1a3c + '\x20at\x20' + _0x5d5caf + '\x20required\x20from\x20' + _0x228fa8;
            }, ig['$']('head')[0x0]['appendChild'](_0xa262a3);
        },
        '_execModules': function() {
            for (var _0x33568b = !0x1, _0xf78369 = 0x0; _0xf78369 < ig['_loadQueue']['length']; _0xf78369++) {
                for (var _0x28ac56 = ig['_loadQueue'][_0xf78369], _0x2b94a3 = !0x0, _0x3170a1 = 0x0; _0x3170a1 < _0x28ac56['requires']['length']; _0x3170a1++) {
                    var _0x151863 = _0x28ac56['requires'][_0x3170a1];
                    ig['modules'][_0x151863] ? ig['modules'][_0x151863]['loaded'] || (_0x2b94a3 = !0x1) : (_0x2b94a3 = !0x1, ig['_loadScript'](_0x151863, _0x28ac56['name']));
                }
                _0x2b94a3 && _0x28ac56['body'] && (ig['_loadQueue']['splice'](_0xf78369, 0x1), _0x28ac56['loaded'] = !0x0, _0x28ac56['body'](), _0x33568b = !0x0, _0xf78369--);
            }
            if (_0x33568b) ig['_execModules']();
            else {
                if (!ig['baked'] && 0x0 == ig['_waitForOnload'] && 0x0 != ig['_loadQueue']['length']) {
                    _0x33568b = [];
                    for (_0xf78369 = 0x0; _0xf78369 < ig['_loadQueue']['length']; _0xf78369++) {
                        _0x2b94a3 = [], _0x151863 = ig['_loadQueue'][_0xf78369]['requires'];
                        for (_0x3170a1 = 0x0; _0x3170a1 < _0x151863['length']; _0x3170a1++) _0x28ac56 = ig['modules'][_0x151863[_0x3170a1]], (!_0x28ac56 || !_0x28ac56['loaded']) && _0x2b94a3['push'](_0x151863[_0x3170a1]);
                        _0x33568b['push'](ig['_loadQueue'][_0xf78369]['name'] + '\x20(requires:\x20' + _0x2b94a3['join'](',\x20') + ')');
                    }
                    throw 'Unresolved\x20(or\x20circular?)\x20dependencies.\x20Most\x20likely\x20there\x27s\x20a\x20name/path\x20mismatch\x20for\x20one\x20of\x20the\x20listed\x20modules\x20or\x20a\x20previous\x20syntax\x20error\x20prevents\x20a\x20module\x20from\x20loading:\x0a' + _0x33568b['join']('\x0a');
                }
            }
        },
        '_DOMReady': function() {
            if (!ig['modules']['dom.ready']['loaded']) {
                if (!document['body']) return setTimeout(ig['_DOMReady'], 0xd);
                ig['modules']['dom.ready']['loaded'] = !0x0, ig['_waitForOnload']--, ig['_execModules']();
            }
            return 0x0;
        },
        '_boot': function() {
            document['location']['href']['match'](/\?nocache/) && ig['setNocache'](!0x0), ig['ua']['pixelRatio'] = _0x2c4631['devicePixelRatio'] || 0x1, ig['ua']['viewport'] = {
                'width': _0x2c4631['innerWidth'],
                'height': _0x2c4631['innerHeight']
            }, ig['ua']['screen'] = {
                'width': _0x2c4631['screen']['availWidth'] * ig['ua']['pixelRatio'],
                'height': _0x2c4631['screen']['availHeight'] * ig['ua']['pixelRatio']
            }, ig['ua']['iPhone'] = /iPhone/i ['test'](navigator['userAgent']), ig['ua']['iPhone4'] = ig['ua']['iPhone'] && 0x2 == ig['ua']['pixelRatio'], ig['ua']['iPad'] = /iPad/i ['test'](navigator['userAgent']), ig['ua']['android'] = /android/i ['test'](navigator['userAgent']), ig['ua']['winPhone'] = /Windows Phone/i ['test'](navigator['userAgent']), ig['ua']['is_uiwebview'] = /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i ['test'](navigator['userAgent']), ig['ua']['is_safari_or_uiwebview'] = /(iPhone|iPod|iPad).*AppleWebKit/i ['test'](navigator['userAgent']), ig['ua']['iOS'] = ig['ua']['iPhone'] || ig['ua']['iPad'], ig['ua']['iOS6_tag'] = /OS 6_/i ['test'](navigator['userAgent']), ig['ua']['iOS6'] = (ig['ua']['iPhone'] || ig['ua']['iPad']) && ig['ua']['iOS6_tag'], ig['ua']['iOSgt5'] = ig['ua']['iOS'] && 0x5 < parseInt(navigator['appVersion']['match'](/OS (\d+)_(\d+)_?(\d+)?/)[0x1]), ig['ua']['HTCONE'] = /HTC_One/i ['test'](navigator['userAgent']), ig['ua']['winPhone'] = /Windows Phone/i ['test'](navigator['userAgent']), ig['ua']['Kindle'] = /Silk/i ['test'](navigator['userAgent']), ig['ua']['touchDevice'] = 'ontouchstart' in _0x2c4631 || _0x2c4631['navigator']['msMaxTouchPoints'], ig['ua']['mobile'] = ig['ua']['iOS'] || ig['ua']['android'] || ig['ua']['iOS6'] || ig['ua']['winPhone'] || ig['ua']['Kindle'] || /mobile/i ['test'](navigator['userAgent']);
        },
        '_initDOMReady': function() {
            ig['modules']['dom.ready'] ? ig['_execModules']() : (ig['_boot'](), ig['modules']['dom.ready'] = {
                'requires': [],
                'loaded': !0x1,
                'body': null
            }, ig['_waitForOnload']++, 'complete' === document['readyState'] ? ig['_DOMReady']() : (document['addEventListener']('DOMContentLoaded', ig['_DOMReady'], !0x1), _0x2c4631['addEventListener']('load', ig['_DOMReady'], !0x1)));
        }
    }, ig['normalizeVendorAttribute'](_0x2c4631, 'requestAnimationFrame');
    if (_0x2c4631['requestAnimationFrame']) {
        var _0x55ef21 = 0x1,
            _0x4e88d1 = {};
        _0x2c4631['ig']['setAnimation'] = function(_0x4dbc51) {
            var _0x218ef7 = _0x55ef21++;
            _0x4e88d1[_0x218ef7] = !0x0;
            var _0x255182 = function() {
                _0x4e88d1[_0x218ef7] && (_0x2c4631['requestAnimationFrame'](_0x255182), _0x4dbc51());
            };
            return _0x2c4631['requestAnimationFrame'](_0x255182), _0x218ef7;
        }, _0x2c4631['ig']['clearAnimation'] = function(_0x1e3913) {
            delete _0x4e88d1[_0x1e3913];
        };
    } else _0x2c4631['ig']['setAnimation'] = function(_0x26e929) {
        return _0x2c4631['setInterval'](_0x26e929, 0x3e8 / 0x3c);
    }, _0x2c4631['ig']['clearAnimation'] = function(_0x26d1ef) {
        _0x2c4631['clearInterval'](_0x26d1ef);
    };
    var _0x236cf4 = !0x1,
        _0x1415ab = /xyz/ ['test'](function() {
            xyz;
        }) ? /\bparent\b/ : /.*/,
        _0x47e2c7 = 0x0;
    _0x2c4631['ig']['Class'] = function() {};
    var _0x2ff4f2 = function(_0x4e04e7) {
        var _0x57f845 = this['prototype'],
            _0x3c002a = {},
            _0x24e508;
        for (_0x24e508 in _0x4e04e7) 'function' == typeof _0x4e04e7[_0x24e508] && 'function' == typeof _0x57f845[_0x24e508] && _0x1415ab['test'](_0x4e04e7[_0x24e508]) ? (_0x3c002a[_0x24e508] = _0x57f845[_0x24e508], _0x57f845[_0x24e508] = function(_0x1cf1cf, _0x1851b3) {
            return function() {
                var _0x3256b9 = this['parent'];
                this['parent'] = _0x3c002a[_0x1cf1cf];
                var _0x1267fb = _0x1851b3['apply'](this, arguments);
                return this['parent'] = _0x3256b9, _0x1267fb;
            };
        }(_0x24e508, _0x4e04e7[_0x24e508])) : _0x57f845[_0x24e508] = _0x4e04e7[_0x24e508];
    };
    _0x2c4631['ig']['Class']['extend'] = function(_0x4ade44) {
        function _0x2f5b35() {
            if (!_0x236cf4) {
                if (this['staticInstantiate']) {
                    var _0x12ac92 = this['staticInstantiate']['apply'](this, arguments);
                    if (_0x12ac92) return _0x12ac92;
                }
                for (var _0x28406d in this) 'object' == typeof this[_0x28406d] && (this[_0x28406d] = ig['copy'](this[_0x28406d]));
                this['init'] && this['init']['apply'](this, arguments);
            }
            return this;
        }
        var _0x11cc73 = this['prototype'];
        _0x236cf4 = !0x0;
        var _0x2300d6 = new this();
        _0x236cf4 = !0x1;
        for (var _0x6becdb in _0x4ade44) _0x2300d6[_0x6becdb] = 'function' == typeof _0x4ade44[_0x6becdb] && 'function' == typeof _0x11cc73[_0x6becdb] && _0x1415ab['test'](_0x4ade44[_0x6becdb]) ? function(_0x530d0c, _0x2d5015) {
            return function() {
                var _0x381e36 = this['parent'];
                this['parent'] = _0x11cc73[_0x530d0c];
                var _0x155339 = _0x2d5015['apply'](this, arguments);
                return this['parent'] = _0x381e36, _0x155339;
            };
        }(_0x6becdb, _0x4ade44[_0x6becdb]) : _0x4ade44[_0x6becdb];
        return _0x2f5b35['prototype'] = _0x2300d6, _0x2f5b35['prototype']['constructor'] = _0x2f5b35, _0x2f5b35['extend'] = _0x2c4631['ig']['Class']['extend'], _0x2f5b35['inject'] = _0x2ff4f2, _0x2f5b35['classId'] = _0x2300d6['classId'] = ++_0x47e2c7, _0x2f5b35;
    }, _0x2c4631['ImpactMixin'] && ig['merge'](ig, _0x2c4631['ImpactMixin']);
}(window), ig['baked'] = !0x0, ig['module']('impact.image')['defines'](function() {
    ig['Image'] = ig['Class']['extend']({
        'data': null,
        'width': 0x0,
        'height': 0x0,
        'loaded': !0x1,
        'failed': !0x1,
        'loadCallback': null,
        'path': '',
        'staticInstantiate': function(_0x5cafd4) {
            return ig['Image']['cache'][_0x5cafd4] || null;
        },
        'init': function(_0x5ea7b5) {
            this['path'] = _0x5ea7b5, this['load']();
        },
        'load': function(_0x51b0aa) {
            this['loaded'] ? _0x51b0aa && _0x51b0aa(this['path'], !0x0) : (!this['loaded'] && ig['ready'] ? (this['loadCallback'] = _0x51b0aa || null, this['data'] = new Image(), this['data']['onload'] = this['onload']['bind'](this), this['data']['onerror'] = this['onerror']['bind'](this), this['data']['src'] = ig['prefix'] + this['path'] + ig['nocache']) : ig['addResource'](this), ig['Image']['cache'][this['path']] = this);
        },
        'reload': function() {
            this['loaded'] = !0x1, this['data'] = new Image(), this['data']['onload'] = this['onload']['bind'](this), this['data']['src'] = this['path'] + '?' + Date['now']();
        },
        'onload': function() {
            this['width'] = this['data']['width'], this['height'] = this['data']['height'], this['loaded'] = !0x0, 0x1 != ig['system']['scale'] && this['resize'](ig['system']['scale']), this['loadCallback'] && this['loadCallback'](this['path'], !0x0);
        },
        'onerror': function() {
            this['failed'] = !0x0, this['loadCallback'] && this['loadCallback'](this['path'], !0x1);
        },
        'resize': function(_0x3dcbdc) {
            var _0x34cd50 = ig['getImagePixels'](this['data'], 0x0, 0x0, this['width'], this['height']),
                _0x29f76c = this['width'] * _0x3dcbdc,
                _0x5d677f = this['height'] * _0x3dcbdc,
                _0x4ed802 = ig['$new']('canvas');
            _0x4ed802['width'] = _0x29f76c, _0x4ed802['height'] = _0x5d677f;
            for (var _0x14e682 = _0x4ed802['getContext']('2d'), _0xe20c26 = _0x14e682['getImageData'](0x0, 0x0, _0x29f76c, _0x5d677f), _0x251d0e = 0x0; _0x251d0e < _0x5d677f; _0x251d0e++)
                for (var _0x758902 = 0x0; _0x758902 < _0x29f76c; _0x758902++) {
                    var _0x25706b = 0x4 * (Math['floor'](_0x251d0e / _0x3dcbdc) * this['width'] + Math['floor'](_0x758902 / _0x3dcbdc)),
                        _0x14fcf7 = 0x4 * (_0x251d0e * _0x29f76c + _0x758902);
                    _0xe20c26['data'][_0x14fcf7] = _0x34cd50['data'][_0x25706b], _0xe20c26['data'][_0x14fcf7 + 0x1] = _0x34cd50['data'][_0x25706b + 0x1], _0xe20c26['data'][_0x14fcf7 + 0x2] = _0x34cd50['data'][_0x25706b + 0x2], _0xe20c26['data'][_0x14fcf7 + 0x3] = _0x34cd50['data'][_0x25706b + 0x3];
                }
            _0x14e682['putImageData'](_0xe20c26, 0x0, 0x0), this['data'] = _0x4ed802;
        },
        'draw': function(_0xe4caad, _0x1a1d0c, _0x3b66c0, _0x32683f, _0x8ff16d, _0x47f2d5) {
            if (this['loaded']) {
                var _0x17a3c3 = ig['system']['scale'];
                _0x8ff16d = (_0x8ff16d ? _0x8ff16d : this['width']) * _0x17a3c3, _0x47f2d5 = (_0x47f2d5 ? _0x47f2d5 : this['height']) * _0x17a3c3, ig['system']['context']['drawImage'](this['data'], _0x3b66c0 ? _0x3b66c0 * _0x17a3c3 : 0x0, _0x32683f ? _0x32683f * _0x17a3c3 : 0x0, _0x8ff16d, _0x47f2d5, ig['system']['getDrawPos'](_0xe4caad), ig['system']['getDrawPos'](_0x1a1d0c), _0x8ff16d, _0x47f2d5), ig['Image']['drawCount']++;
            }
        },
        'drawTile': function(_0x4b9e6f, _0x1f36db, _0x38ae72, _0x135126, _0x4dad36, _0xd3a23d, _0x442971) {
            _0x4dad36 = _0x4dad36 ? _0x4dad36 : _0x135126;
            if (this['loaded'] && !(_0x135126 > this['width'] || _0x4dad36 > this['height'])) {
                var _0x3db753 = ig['system']['scale'],
                    _0x10b2f7 = Math['floor'](_0x135126 * _0x3db753),
                    _0x3ae372 = Math['floor'](_0x4dad36 * _0x3db753),
                    _0x1253b5 = _0xd3a23d ? -0x1 : 0x1,
                    _0x137043 = _0x442971 ? -0x1 : 0x1;
                if (_0xd3a23d || _0x442971) ig['system']['context']['save'](), ig['system']['context']['scale'](_0x1253b5, _0x137043);
                ig['system']['context']['drawImage'](this['data'], Math['floor'](_0x38ae72 * _0x135126) % this['width'] * _0x3db753, Math['floor'](_0x38ae72 * _0x135126 / this['width']) * _0x4dad36 * _0x3db753, _0x10b2f7, _0x3ae372, ig['system']['getDrawPos'](_0x4b9e6f) * _0x1253b5 - (_0xd3a23d ? _0x10b2f7 : 0x0), ig['system']['getDrawPos'](_0x1f36db) * _0x137043 - (_0x442971 ? _0x3ae372 : 0x0), _0x10b2f7, _0x3ae372), (_0xd3a23d || _0x442971) && ig['system']['context']['restore'](), ig['Image']['drawCount']++;
            }
        }
    }), ig['Image']['drawCount'] = 0x0, ig['Image']['cache'] = {}, ig['Image']['reloadCache'] = function() {
        for (var _0x4aea9b in ig['Image']['cache']) ig['Image']['cache'][_0x4aea9b]['reload']();
    };
}), ig['baked'] = !0x0, ig['module']('impact.font')['requires']('impact.image')['defines'](function() {
    ig['Font'] = ig['Image']['extend']({
        'widthMap': [],
        'indices': [],
        'firstChar': 0x20,
        'alpha': 0x1,
        'letterSpacing': 0x1,
        'lineSpacing': 0x0,
        'onload': function(_0x120609) {
            this['_loadMetrics'](this['data']), this['parent'](_0x120609);
        },
        'widthForString': function(_0x5df68d) {
            if (-0x1 !== _0x5df68d['indexOf']('\x0a')) {
                _0x5df68d = _0x5df68d['split']('\x0a');
                for (var _0x2283db = 0x0, _0x4516a7 = 0x0; _0x4516a7 < _0x5df68d['length']; _0x4516a7++) _0x2283db = Math['max'](_0x2283db, this['_widthForLine'](_0x5df68d[_0x4516a7]));
                return _0x2283db;
            }
            return this['_widthForLine'](_0x5df68d);
        },
        '_widthForLine': function(_0x3dfdbf) {
            for (var _0x55edb2 = 0x0, _0x5830a2 = 0x0; _0x5830a2 < _0x3dfdbf['length']; _0x5830a2++) _0x55edb2 += this['widthMap'][_0x3dfdbf['charCodeAt'](_0x5830a2) - this['firstChar']] + this['letterSpacing'];
            return _0x55edb2;
        },
        'heightForString': function(_0xdd34cc) {
            return _0xdd34cc['split']('\x0a')['length'] * (this['height'] + this['lineSpacing']);
        },
        'draw': function(_0x2421ef, _0xf7916a, _0x39ca12, _0x2d43d1) {
            'string' != typeof _0x2421ef && (_0x2421ef = _0x2421ef['toString']());
            if (-0x1 !== _0x2421ef['indexOf']('\x0a')) {
                _0x2421ef = _0x2421ef['split']('\x0a');
                for (var _0x2be029 = this['height'] + this['lineSpacing'], _0x5ca052 = 0x0; _0x5ca052 < _0x2421ef['length']; _0x5ca052++) this['draw'](_0x2421ef[_0x5ca052], _0xf7916a, _0x39ca12 + _0x5ca052 * _0x2be029, _0x2d43d1);
            } else {
                if (_0x2d43d1 == ig['Font']['ALIGN']['RIGHT'] || _0x2d43d1 == ig['Font']['ALIGN']['CENTER']) _0x5ca052 = this['_widthForLine'](_0x2421ef), _0xf7916a -= _0x2d43d1 == ig['Font']['ALIGN']['CENTER'] ? _0x5ca052 / 0x2 : _0x5ca052;
                0x1 !== this['alpha'] && (ig['system']['context']['globalAlpha'] = this['alpha']);
                for (_0x5ca052 = 0x0; _0x5ca052 < _0x2421ef['length']; _0x5ca052++) _0x2d43d1 = _0x2421ef['charCodeAt'](_0x5ca052), _0xf7916a += this['_drawChar'](_0x2d43d1 - this['firstChar'], _0xf7916a, _0x39ca12);
                0x1 !== this['alpha'] && (ig['system']['context']['globalAlpha'] = 0x1), ig['Image']['drawCount'] += _0x2421ef['length'];
            }
        },
        '_drawChar': function(_0x117b4c, _0x39dae0, _0x3869e7) {
            if (!this['loaded'] || 0x0 > _0x117b4c || _0x117b4c >= this['indices']['length']) return 0x0;
            var _0x2b9ac2 = ig['system']['scale'],
                _0x1e63de = this['widthMap'][_0x117b4c] * _0x2b9ac2,
                _0x14355d = (this['height'] - 0x2) * _0x2b9ac2;
            return ig['system']['context']['drawImage'](this['data'], this['indices'][_0x117b4c] * _0x2b9ac2, 0x0, _0x1e63de, _0x14355d, ig['system']['getDrawPos'](_0x39dae0), ig['system']['getDrawPos'](_0x3869e7), _0x1e63de, _0x14355d), this['widthMap'][_0x117b4c] + this['letterSpacing'];
        },
        '_loadMetrics': function(_0x519c7c) {
            this['height'] = _0x519c7c['height'] - 0x1, this['widthMap'] = [], this['indices'] = [];
            for (var _0x2f137f = ig['getImagePixels'](_0x519c7c, 0x0, _0x519c7c['height'] - 0x1, _0x519c7c['width'], 0x1), _0x4f3e0d = 0x0, _0x527bb8 = 0x0, _0x35fa38 = 0x0; _0x35fa38 < _0x519c7c['width']; _0x35fa38++) {
                var _0x119095 = 0x4 * _0x35fa38 + 0x3;
                0x7f < _0x2f137f['data'][_0x119095] ? _0x527bb8++ : 0x80 > _0x2f137f['data'][_0x119095] && _0x527bb8 && (this['widthMap']['push'](_0x527bb8), this['indices']['push'](_0x35fa38 - _0x527bb8), _0x4f3e0d++, _0x527bb8 = 0x0);
            }
            this['widthMap']['push'](_0x527bb8), this['indices']['push'](_0x35fa38 - _0x527bb8);
        }
    }), ig['Font']['ALIGN'] = {
        'LEFT': 0x0,
        'RIGHT': 0x1,
        'CENTER': 0x2
    };
}), ig['baked'] = !0x0, ig['module']('impact.sound')['defines'](function() {
    ig['SoundManager'] = ig['Class']['extend']({
        'clips': {},
        'volume': 0x1,
        'format': null,
        'init': function() {
            if (!ig['Sound']['enabled'] || !window['Audio']) ig['Sound']['enabled'] = !0x1;
            else {
                for (var _0x1ea414 = new Audio(), _0x2ccd82 = 0x0; _0x2ccd82 < ig['Sound']['use']['length']; _0x2ccd82++) {
                    var _0x42d1d3 = ig['Sound']['use'][_0x2ccd82];
                    if (_0x1ea414['canPlayType'](_0x42d1d3['mime'])) {
                        this['format'] = _0x42d1d3;
                        break;
                    }
                }
                this['format'] || (ig['Sound']['enabled'] = !0x1);
            }
        },
        'load': function(_0x4bc8ec, _0x303d8c, _0x1e3c08) {
            var _0x22ccc1 = ig['prefix'] + _0x4bc8ec['replace'](/[^\.]+$/, this['format']['ext']) + ig['nocache'];
            if (this['clips'][_0x4bc8ec]) {
                if (_0x303d8c && this['clips'][_0x4bc8ec]['length'] < ig['Sound']['channels'])
                    for (_0x303d8c = this['clips'][_0x4bc8ec]['length']; _0x303d8c < ig['Sound']['channels']; _0x303d8c++) {
                        var _0x3b4dce = new Audio(_0x22ccc1);
                        _0x3b4dce['load'](), this['clips'][_0x4bc8ec]['push'](_0x3b4dce);
                    }
                return this['clips'][_0x4bc8ec][0x0];
            }
            var _0x2980ab = new Audio(_0x22ccc1);
            _0x1e3c08 && (_0x2980ab['addEventListener']('canplaythrough', function _0x542d77(_0x51458d) {
                _0x2980ab['removeEventListener']('canplaythrough', _0x542d77, !0x1), _0x1e3c08(_0x4bc8ec, !0x0, _0x51458d);
            }, !0x1), _0x2980ab['addEventListener']('error', function(_0x709ce8) {
                _0x1e3c08(_0x4bc8ec, !0x1, _0x709ce8);
            }, !0x1)), _0x2980ab['preload'] = 'auto', _0x2980ab['load'](), this['clips'][_0x4bc8ec] = [_0x2980ab];
            if (_0x303d8c) {
                for (_0x303d8c = 0x1; _0x303d8c < ig['Sound']['channels']; _0x303d8c++) _0x3b4dce = new Audio(_0x22ccc1), _0x3b4dce['load'](), this['clips'][_0x4bc8ec]['push'](_0x3b4dce);
            }
            return _0x2980ab;
        },
        'get': function(_0x8aa64c) {
            _0x8aa64c = this['clips'][_0x8aa64c];
            for (var _0x341a6f = 0x0, _0x1e76be; _0x1e76be = _0x8aa64c[_0x341a6f++];)
                if (_0x1e76be['paused'] || _0x1e76be['ended']) return _0x1e76be['ended'] && (_0x1e76be['currentTime'] = 0x0), _0x1e76be;
            return _0x8aa64c[0x0]['pause'](), _0x8aa64c[0x0]['currentTime'] = 0x0, _0x8aa64c[0x0];
        }
    }), ig['Music'] = ig['Class']['extend']({
        'tracks': [],
        'namedTracks': {},
        'currentTrack': null,
        'currentIndex': 0x0,
        'random': !0x1,
        '_volume': 0x1,
        '_loop': !0x1,
        '_fadeInterval': 0x0,
        '_fadeTimer': null,
        '_endedCallbackBound': null,
        'init': function() {
            this['_endedCallbackBound'] = this['_endedCallback']['bind'](this), Object['defineProperty'] ? (Object['defineProperty'](this, 'volume', {
                'get': this['getVolume']['bind'](this),
                'set': this['setVolume']['bind'](this)
            }), Object['defineProperty'](this, 'loop', {
                'get': this['getLooping']['bind'](this),
                'set': this['setLooping']['bind'](this)
            })) : this['__defineGetter__'] && (this['__defineGetter__']('volume', this['getVolume']['bind'](this)), this['__defineSetter__']('volume', this['setVolume']['bind'](this)), this['__defineGetter__']('loop', this['getLooping']['bind'](this)), this['__defineSetter__']('loop', this['setLooping']['bind'](this)));
        },
        'add': function(_0x38c8e7, _0x50cdd0) {
            if (ig['Sound']['enabled']) {
                var _0x4ac8b7 = ig['soundManager']['load'](_0x38c8e7 instanceof ig['Sound'] ? _0x38c8e7['path'] : _0x38c8e7, !0x1);
                _0x4ac8b7['loop'] = this['_loop'], _0x4ac8b7['volume'] = this['_volume'], _0x4ac8b7['addEventListener']('ended', this['_endedCallbackBound'], !0x1), this['tracks']['push'](_0x4ac8b7), _0x50cdd0 && (this['namedTracks'][_0x50cdd0] = _0x4ac8b7), this['currentTrack'] || (this['currentTrack'] = _0x4ac8b7);
            }
        },
        'next': function() {
            this['tracks']['length'] && (this['stop'](), this['currentIndex'] = this['random'] ? Math['floor'](Math['random']() * this['tracks']['length']) : (this['currentIndex'] + 0x1) % this['tracks']['length'], this['currentTrack'] = this['tracks'][this['currentIndex']], this['play']());
        },
        'pause': function() {
            this['currentTrack'] && this['currentTrack']['pause']();
        },
        'stop': function() {
            this['currentTrack'] && (this['currentTrack']['pause'](), this['currentTrack']['currentTime'] = 0x0);
        },
        'play': function(_0x807a69) {
            if (_0x807a69 && this['namedTracks'][_0x807a69]) _0x807a69 = this['namedTracks'][_0x807a69], _0x807a69 != this['currentTrack'] && (this['stop'](), this['currentTrack'] = _0x807a69);
            else {
                if (!this['currentTrack']) return;
            }
            this['currentTrack']['play']();
        },
        'getLooping': function() {
            return this['_loop'];
        },
        'setLooping': function(_0x4185ca) {
            this['_loop'] = _0x4185ca;
            for (var _0x5f7da in this['tracks']) this['tracks'][_0x5f7da]['loop'] = _0x4185ca;
        },
        'getVolume': function() {
            return this['_volume'];
        },
        'setVolume': function(_0x40c3ee) {
            this['_volume'] = _0x40c3ee['limit'](0x0, 0x1);
            for (var _0x389abc in this['tracks']) this['tracks'][_0x389abc]['volume'] = this['_volume'];
        },
        'fadeOut': function(_0x2f147e) {
            this['currentTrack'] && (clearInterval(this['_fadeInterval']), this['fadeTimer'] = new ig['Timer'](_0x2f147e), this['_fadeInterval'] = setInterval(this['_fadeStep']['bind'](this), 0x32));
        },
        '_fadeStep': function() {
            var _0x58c7db = this['fadeTimer']['delta']()['map'](-this['fadeTimer']['target'], 0x0, 0x1, 0x0)['limit'](0x0, 0x1) * this['_volume'];
            0.01 >= _0x58c7db ? (this['stop'](), this['currentTrack']['volume'] = this['_volume'], clearInterval(this['_fadeInterval'])) : this['currentTrack']['volume'] = _0x58c7db;
        },
        '_endedCallback': function() {
            this['_loop'] ? this['play']() : this['next']();
        }
    }), ig['Sound'] = ig['Class']['extend']({
        'path': '',
        'volume': 0x1,
        'currentClip': null,
        'multiChannel': !0x0,
        'init': function(_0x37daa4, _0x2d0874) {
            this['path'] = _0x37daa4, this['multiChannel'] = !0x1 !== _0x2d0874, this['load']();
        },
        'load': function(_0x158c36) {
            ig['Sound']['enabled'] ? ig['ready'] ? ig['soundManager']['load'](this['path'], this['multiChannel'], _0x158c36) : ig['addResource'](this) : _0x158c36 && _0x158c36(this['path'], !0x0);
        },
        'play': function() {
            ig['Sound']['enabled'] && (this['currentClip'] = ig['soundManager']['get'](this['path']), this['currentClip']['volume'] = ig['soundManager']['volume'] * this['volume'], this['currentClip']['play']());
        },
        'stop': function() {
            this['currentClip'] && (this['currentClip']['pause'](), this['currentClip']['currentTime'] = 0x0);
        }
    }), ig['Sound']['FORMAT'] = {
        'MP3': {
            'ext': 'mp3',
            'mime': 'audio/mpeg'
        },
        'M4A': {
            'ext': 'm4a',
            'mime': 'audio/mp4;\x20codecs=mp4a'
        },
        'OGG': {
            'ext': 'ogg',
            'mime': 'audio/ogg;\x20codecs=vorbis'
        },
        'WEBM': {
            'ext': 'webm',
            'mime': 'audio/webm;\x20codecs=vorbis'
        },
        'CAF': {
            'ext': 'caf',
            'mime': 'audio/x-caf'
        }
    }, ig['Sound']['use'] = [ig['Sound']['FORMAT']['OGG'], ig['Sound']['FORMAT']['MP3']], ig['Sound']['channels'] = 0x4, ig['Sound']['enabled'] = !0x0;
}), ig['baked'] = !0x0, ig['module']('impact.loader')['requires']('impact.image', 'impact.font', 'impact.sound')['defines'](function() {
    ig['Loader'] = ig['Class']['extend']({
        'resources': [],
        'gameClass': null,
        'status': 0x0,
        'done': !0x1,
        '_unloaded': [],
        '_drawStatus': 0x0,
        '_intervalId': 0x0,
        '_loadCallbackBound': null,
        'init': function(_0x20b408, _0x29064e) {
            this['gameClass'] = _0x20b408, this['resources'] = _0x29064e, this['_loadCallbackBound'] = this['_loadCallback']['bind'](this);
            for (var _0x7fb647 = 0x0; _0x7fb647 < this['resources']['length']; _0x7fb647++) this['_unloaded']['push'](this['resources'][_0x7fb647]['path']);
        },
        'load': function() {
            ig['system']['clear']('#000');
            if (this['resources']['length']) {
                for (var _0x11b0d7 = 0x0; _0x11b0d7 < this['resources']['length']; _0x11b0d7++) this['loadResource'](this['resources'][_0x11b0d7]);
                this['_intervalId'] = setInterval(this['draw']['bind'](this), 0x10);
            } else this['end']();
        },
        'loadResource': function(_0x3187d6) {
            _0x3187d6['load'](this['_loadCallbackBound']);
        },
        'end': function() {
            this['done'] || (this['done'] = !0x0, clearInterval(this['_intervalId']));
        },
        'draw': function() {},
        '_loadCallback': function(_0xe3de75, _0x30e6c8) {
            if (_0x30e6c8) this['_unloaded']['erase'](_0xe3de75);
            else throw 'Failed\x20to\x20load\x20resource:\x20' + _0xe3de75;
            this['status'] = 0x1 - this['_unloaded']['length'] / this['resources']['length'], 0x0 == this['_unloaded']['length'] && setTimeout(this['end']['bind'](this), 0xfa);
        }
    });
}), ig['baked'] = !0x0, ig['module']('impact.timer')['defines'](function() {
    ig['Timer'] = ig['Class']['extend']({
        'target': 0x0,
        'base': 0x0,
        'last': 0x0,
        'pausedAt': 0x0,
        'init': function(_0x42c122) {
            this['last'] = this['base'] = ig['Timer']['time'], this['target'] = _0x42c122 || 0x0;
        },
        'set': function(_0x4ffc14) {
            this['target'] = _0x4ffc14 || 0x0, this['base'] = ig['Timer']['time'], this['pausedAt'] = 0x0;
        },
        'reset': function() {
            this['base'] = ig['Timer']['time'], this['pausedAt'] = 0x0;
        },
        'tick': function() {
            var _0x234c84 = ig['Timer']['time'] - this['last'];
            return this['last'] = ig['Timer']['time'], this['pausedAt'] ? 0x0 : _0x234c84;
        },
        'delta': function() {
            return (this['pausedAt'] || ig['Timer']['time']) - this['base'] - this['target'];
        },
        'pause': function() {
            this['pausedAt'] || (this['pausedAt'] = ig['Timer']['time']);
        },
        'unpause': function() {
            this['pausedAt'] && (this['base'] += ig['Timer']['time'] - this['pausedAt'], this['pausedAt'] = 0x0);
        }
    }), ig['Timer']['_last'] = 0x0, ig['Timer']['time'] = Number['MIN_VALUE'], ig['Timer']['timeScale'] = 0x1, ig['Timer']['maxStep'] = 0.05, ig['Timer']['step'] = function() {
        var _0x1f8331 = Date['now']();
        ig['Timer']['time'] += Math['min']((_0x1f8331 - ig['Timer']['_last']) / 0x3e8, ig['Timer']['maxStep']) * ig['Timer']['timeScale'], ig['Timer']['_last'] = _0x1f8331;
    };
}), ig['baked'] = !0x0, ig['module']('impact.system')['requires']('impact.timer', 'impact.image')['defines'](function() {
    ig['System'] = ig['Class']['extend']({
        'fps': 0x1e,
        'width': 0x140,
        'height': 0xf0,
        'realWidth': 0x140,
        'realHeight': 0xf0,
        'scale': 0x1,
        'tick': 0x0,
        'animationId': 0x0,
        'newGameClass': null,
        'running': !0x1,
        'delegate': null,
        'clock': null,
        'canvas': null,
        'context': null,
        'init': function(_0x3cc8a1, _0x3757f1, _0x1d525f, _0x4cd5ed, _0x5cb7a4) {
            this['fps'] = _0x3757f1, this['clock'] = new ig['Timer'](), this['canvas'] = ig['$'](_0x3cc8a1), this['resize'](_0x1d525f, _0x4cd5ed, _0x5cb7a4), this['context'] = this['canvas']['getContext']('2d'), this['getDrawPos'] = ig['System']['drawMode'], 0x1 != this['scale'] && (ig['System']['scaleMode'] = ig['System']['SCALE']['CRISP']), ig['System']['scaleMode'](this['canvas'], this['context']);
        },
        'resize': function(_0x4e6b3d, _0x376492, _0x1381f5) {
            this['width'] = _0x4e6b3d, this['height'] = _0x376492, this['scale'] = _0x1381f5 || this['scale'], this['realWidth'] = this['width'] * this['scale'], this['realHeight'] = this['height'] * this['scale'], this['canvas']['width'] = this['realWidth'], this['canvas']['height'] = this['realHeight'];
        },
        'setGame': function(_0x3343a7) {
            this['running'] ? this['newGameClass'] = _0x3343a7 : this['setGameNow'](_0x3343a7);
        },
        'setGameNow': function(_0x36877e) {
            ig['game'] = new _0x36877e(), ig['system']['setDelegate'](ig['game']);
        },
        'setDelegate': function(_0x433db8) {
            if ('function' == typeof _0x433db8['run']) this['delegate'] = _0x433db8, this['startRunLoop']();
            else throw 'System.setDelegate:\x20No\x20run()\x20function\x20in\x20object';
        },
        'stopRunLoop': function() {
            ig['clearAnimation'](this['animationId']), this['running'] = !0x1;
        },
        'startRunLoop': function() {
            this['stopRunLoop'](), this['animationId'] = ig['setAnimation'](this['run']['bind'](this)), this['running'] = !0x0;
        },
        'clear': function(_0x136986) {
            this['context']['fillStyle'] = _0x136986, this['context']['fillRect'](0x0, 0x0, this['realWidth'], this['realHeight']);
        },
        'run': function() {
            ig['Timer']['step'](), this['tick'] = this['clock']['tick'](), this['delegate']['run'](), ig['input']['clearPressed'](), this['newGameClass'] && (this['setGameNow'](this['newGameClass']), this['newGameClass'] = null);
        },
        'getDrawPos': null
    }), ig['System']['DRAW'] = {
        'AUTHENTIC': function(_0x122f1d) {
            return Math['round'](_0x122f1d) * this['scale'];
        },
        'SMOOTH': function(_0x546bd6) {
            return Math['round'](_0x546bd6 * this['scale']);
        },
        'SUBPIXEL': function(_0x3bd663) {
            return _0x3bd663 * this['scale'];
        }
    }, ig['System']['drawMode'] = ig['System']['DRAW']['SMOOTH'], ig['System']['SCALE'] = {
        'CRISP': function(_0x1b72b8, _0x22aa0d) {
            ig['setVendorAttribute'](_0x22aa0d, 'imageSmoothingEnabled', !0x1), _0x1b72b8['style']['imageRendering'] = '-moz-crisp-edges', _0x1b72b8['style']['imageRendering'] = '-o-crisp-edges', _0x1b72b8['style']['imageRendering'] = '-webkit-optimize-contrast', _0x1b72b8['style']['imageRendering'] = 'crisp-edges', _0x1b72b8['style']['msInterpolationMode'] = 'nearest-neighbor';
        },
        'SMOOTH': function(_0x4c1b04, _0x594ac9) {
            ig['setVendorAttribute'](_0x594ac9, 'imageSmoothingEnabled', !0x0), _0x4c1b04['style']['imageRendering'] = '', _0x4c1b04['style']['msInterpolationMode'] = '';
        }
    }, ig['System']['scaleMode'] = ig['System']['SCALE']['SMOOTH'];
}), ig['baked'] = !0x0, ig['module']('impact.input')['defines'](function() {
    ig['KEY'] = {
        'MOUSE1': -0x1,
        'MOUSE2': -0x3,
        'MWHEEL_UP': -0x4,
        'MWHEEL_DOWN': -0x5,
        'BACKSPACE': 0x8,
        'TAB': 0x9,
        'ENTER': 0xd,
        'PAUSE': 0x13,
        'CAPS': 0x14,
        'ESC': 0x1b,
        'SPACE': 0x20,
        'PAGE_UP': 0x21,
        'PAGE_DOWN': 0x22,
        'END': 0x23,
        'HOME': 0x24,
        'LEFT_ARROW': 0x25,
        'UP_ARROW': 0x26,
        'RIGHT_ARROW': 0x27,
        'DOWN_ARROW': 0x28,
        'INSERT': 0x2d,
        'DELETE': 0x2e,
        '_0': 0x30,
        '_1': 0x31,
        '_2': 0x32,
        '_3': 0x33,
        '_4': 0x34,
        '_5': 0x35,
        '_6': 0x36,
        '_7': 0x37,
        '_8': 0x38,
        '_9': 0x39,
        'A': 0x41,
        'B': 0x42,
        'C': 0x43,
        'D': 0x44,
        'E': 0x45,
        'F': 0x46,
        'G': 0x47,
        'H': 0x48,
        'I': 0x49,
        'J': 0x4a,
        'K': 0x4b,
        'L': 0x4c,
        'M': 0x4d,
        'N': 0x4e,
        'O': 0x4f,
        'P': 0x50,
        'Q': 0x51,
        'R': 0x52,
        'S': 0x53,
        'T': 0x54,
        'U': 0x55,
        'V': 0x56,
        'W': 0x57,
        'X': 0x58,
        'Y': 0x59,
        'Z': 0x5a,
        'NUMPAD_0': 0x60,
        'NUMPAD_1': 0x61,
        'NUMPAD_2': 0x62,
        'NUMPAD_3': 0x63,
        'NUMPAD_4': 0x64,
        'NUMPAD_5': 0x65,
        'NUMPAD_6': 0x66,
        'NUMPAD_7': 0x67,
        'NUMPAD_8': 0x68,
        'NUMPAD_9': 0x69,
        'MULTIPLY': 0x6a,
        'ADD': 0x6b,
        'SUBSTRACT': 0x6d,
        'DECIMAL': 0x6e,
        'DIVIDE': 0x6f,
        'F1': 0x70,
        'F2': 0x71,
        'F3': 0x72,
        'F4': 0x73,
        'F5': 0x74,
        'F6': 0x75,
        'F7': 0x76,
        'F8': 0x77,
        'F9': 0x78,
        'F10': 0x79,
        'F11': 0x7a,
        'F12': 0x7b,
        'SHIFT': 0x10,
        'CTRL': 0x11,
        'ALT': 0x12,
        'PLUS': 0xbb,
        'COMMA': 0xbc,
        'MINUS': 0xbd,
        'PERIOD': 0xbe
    }, ig['Input'] = ig['Class']['extend']({
        'bindings': {},
        'actions': {},
        'presses': {},
        'locks': {},
        'delayedKeyup': {},
        'isUsingMouse': !0x1,
        'isUsingKeyboard': !0x1,
        'isUsingAccelerometer': !0x1,
        'mouse': {
            'x': 0x0,
            'y': 0x0
        },
        'accel': {
            'x': 0x0,
            'y': 0x0,
            'z': 0x0
        },
        'initMouse': function() {
            this['isUsingMouse'] || (this['isUsingMouse'] = !0x0, ig['system']['canvas']['addEventListener']('wheel', this['mousewheel']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('contextmenu', this['contextmenu']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('mousedown', this['keydown']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('mouseup', this['keyup']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('mousemove', this['mousemove']['bind'](this), !0x1), ig['ua']['touchDevice'] && (ig['system']['canvas']['addEventListener']('touchstart', this['keydown']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('touchend', this['keyup']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('touchcancel', this['keyup']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('touchmove', this['mousemove']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('MSPointerDown', this['keydown']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('MSPointerUp', this['keyup']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('MSPointerMove', this['mousemove']['bind'](this), !0x1), ig['system']['canvas']['style']['msTouchAction'] = 'none'));
        },
        'initKeyboard': function() {
            this['isUsingKeyboard'] || (this['isUsingKeyboard'] = !0x0, window['addEventListener']('keydown', this['keydown']['bind'](this), !0x1), window['addEventListener']('keyup', this['keyup']['bind'](this), !0x1));
        },
        'initAccelerometer': function() {
            this['isUsingAccelerometer'] || (this['isUsingAccelerometer'] = !0x0, window['addEventListener']('devicemotion', this['devicemotion']['bind'](this), !0x1));
        },
        'mousewheel': function(_0x5a00f5) {
            var _0xa7d8a9 = this['bindings'][0x0 > _0x5a00f5['deltaY'] ? ig['KEY']['MWHEEL_UP'] : ig['KEY']['MWHEEL_DOWN']];
            _0xa7d8a9 && (this['actions'][_0xa7d8a9] = !0x0, this['presses'][_0xa7d8a9] = !0x0, this['delayedKeyup'][_0xa7d8a9] = !0x0, _0x5a00f5['stopPropagation'](), _0x5a00f5['preventDefault']());
        },
        'mousemove': function(_0x48d5c5) {
            var _0x138a82 = ig['system']['scale'] * ((ig['system']['canvas']['offsetWidth'] || ig['system']['realWidth']) / ig['system']['realWidth']),
                _0x46a7c0 = {
                    'left': 0x0,
                    'top': 0x0
                };
            ig['system']['canvas']['getBoundingClientRect'] && (_0x46a7c0 = ig['system']['canvas']['getBoundingClientRect']()), _0x48d5c5 = _0x48d5c5['touches'] ? _0x48d5c5['touches'][0x0] : _0x48d5c5, this['mouse']['x'] = (_0x48d5c5['clientX'] - _0x46a7c0['left']) / _0x138a82, this['mouse']['y'] = (_0x48d5c5['clientY'] - _0x46a7c0['top']) / _0x138a82;
        },
        'contextmenu': function(_0x526769) {
            this['bindings'][ig['KEY']['MOUSE2']] && (_0x526769['stopPropagation'](), _0x526769['preventDefault']());
        },
        'keydown': function(_0x44f5d3) {
            var _0x30d954 = _0x44f5d3['target']['tagName'];
            if (!('INPUT' == _0x30d954 || 'TEXTAREA' == _0x30d954)) {
                if (_0x30d954 = 'keydown' == _0x44f5d3['type'] ? _0x44f5d3['keyCode'] : 0x2 == _0x44f5d3['button'] ? ig['KEY']['MOUSE2'] : ig['KEY']['MOUSE1'], 0x0 > _0x30d954 && !ig['ua']['mobile'] && window['focus'](), ('touchstart' == _0x44f5d3['type'] || 'mousedown' == _0x44f5d3['type']) && this['mousemove'](_0x44f5d3), _0x30d954 = this['bindings'][_0x30d954]) this['actions'][_0x30d954] = !0x0, this['locks'][_0x30d954] || (this['presses'][_0x30d954] = !0x0, this['locks'][_0x30d954] = !0x0), _0x44f5d3['preventDefault']();
            }
        },
        'keyup': function(_0x58a209) {
            var _0xd55fb5 = _0x58a209['target']['tagName'];
            if (!('INPUT' == _0xd55fb5 || 'TEXTAREA' == _0xd55fb5)) {
                if (_0xd55fb5 = this['bindings']['keyup' == _0x58a209['type'] ? _0x58a209['keyCode'] : 0x2 == _0x58a209['button'] ? ig['KEY']['MOUSE2'] : ig['KEY']['MOUSE1']]) this['delayedKeyup'][_0xd55fb5] = !0x0, _0x58a209['preventDefault']();
            }
        },
        'devicemotion': function(_0x147e88) {
            this['accel'] = _0x147e88['accelerationIncludingGravity'];
        },
        'bind': function(_0x18a944, _0x22154a) {
            0x0 > _0x18a944 ? this['initMouse']() : 0x0 < _0x18a944 && this['initKeyboard'](), this['bindings'][_0x18a944] = _0x22154a;
        },
        'bindTouch': function(_0x2b8f2c, _0x40548a) {
            var _0x22316b = ig['$'](_0x2b8f2c),
                _0x1d827b = this;
            _0x22316b['addEventListener']('touchstart', function(_0x519234) {
                _0x1d827b['touchStart'](_0x519234, _0x40548a);
            }, !0x1), _0x22316b['addEventListener']('touchend', function(_0x2d7f0e) {
                _0x1d827b['touchEnd'](_0x2d7f0e, _0x40548a);
            }, !0x1), _0x22316b['addEventListener']('MSPointerDown', function(_0x105f1c) {
                _0x1d827b['touchStart'](_0x105f1c, _0x40548a);
            }, !0x1), _0x22316b['addEventListener']('MSPointerUp', function(_0x1cb011) {
                _0x1d827b['touchEnd'](_0x1cb011, _0x40548a);
            }, !0x1);
        },
        'unbind': function(_0x391a5f) {
            this['delayedKeyup'][this['bindings'][_0x391a5f]] = !0x0, this['bindings'][_0x391a5f] = null;
        },
        'unbindAll': function() {
            this['bindings'] = {}, this['actions'] = {}, this['presses'] = {}, this['locks'] = {}, this['delayedKeyup'] = {};
        },
        'state': function(_0x2cda88) {
            return this['actions'][_0x2cda88];
        },
        'clearState': function(_0x436232) {
            this['actions'][_0x436232] = !0x1;
        },
        'pressed': function(_0x14bad2) {
            return this['presses'][_0x14bad2];
        },
        'released': function(_0x3831a7) {
            return !!this['delayedKeyup'][_0x3831a7];
        },
        'clearPressed': function() {
            for (var _0x5eecbc in this['delayedKeyup']) this['actions'][_0x5eecbc] = !0x1, this['locks'][_0x5eecbc] = !0x1;
            this['delayedKeyup'] = {}, this['presses'] = {};
        },
        'touchStart': function(_0xf1c8a0, _0x5d2c33) {
            return this['actions'][_0x5d2c33] = !0x0, this['presses'][_0x5d2c33] = !0x0, _0xf1c8a0['stopPropagation'](), _0xf1c8a0['preventDefault'](), !0x1;
        },
        'touchEnd': function(_0x33c4cb, _0x114f72) {
            return this['delayedKeyup'][_0x114f72] = !0x0, _0x33c4cb['stopPropagation'](), _0x33c4cb['preventDefault'](), !0x1;
        }
    });
}), ig['baked'] = !0x0, ig['module']('impact.impact')['requires']('dom.ready', 'impact.loader', 'impact.system', 'impact.input', 'impact.sound')['defines'](function() {
    ig['main'] = function(_0x80384a, _0x28ddfc, _0x5aa42e, _0x1f9d24, _0x15f4b9, _0x5f4ac1, _0x4859b7) {
        ig['system'] = new ig['System'](_0x80384a, _0x5aa42e, _0x1f9d24, _0x15f4b9, _0x5f4ac1 || 0x1), ig['input'] = new ig['Input'](), ig['soundManager'] = new ig['SoundManager'](), ig['music'] = new ig['Music'](), ig['ready'] = !0x0, ig['loader'] = new(_0x4859b7 || ig['Loader'])(_0x28ddfc, ig['resources']), ig['loader']['load']();
    };
}), ig['baked'] = !0x0, ig['module']('impact.animation')['requires']('impact.timer', 'impact.image')['defines'](function() {
    ig['AnimationSheet'] = ig['Class']['extend']({
        'width': 0x8,
        'height': 0x8,
        'image': null,
        'init': function(_0x1a408a, _0x1686db, _0x11c570) {
            this['width'] = _0x1686db, this['height'] = _0x11c570, this['image'] = new ig['Image'](_0x1a408a);
        }
    }), ig['Animation'] = ig['Class']['extend']({
        'sheet': null,
        'timer': null,
        'sequence': [],
        'flip': {
            'x': !0x1,
            'y': !0x1
        },
        'pivot': {
            'x': 0x0,
            'y': 0x0
        },
        'frame': 0x0,
        'tile': 0x0,
        'loopCount': 0x0,
        'alpha': 0x1,
        'angle': 0x0,
        'init': function(_0x3ca092, _0x26e956, _0x358921, _0x42adeb) {
            this['sheet'] = _0x3ca092, this['pivot'] = {
                'x': _0x3ca092['width'] / 0x2,
                'y': _0x3ca092['height'] / 0x2
            }, this['timer'] = new ig['Timer'](), this['frameTime'] = _0x26e956, this['sequence'] = _0x358921, this['stop'] = !!_0x42adeb, this['tile'] = this['sequence'][0x0];
        },
        'rewind': function() {
            return this['timer']['set'](), this['frame'] = this['loopCount'] = 0x0, this['tile'] = this['sequence'][0x0], this;
        },
        'gotoFrame': function(_0x1e7657) {
            this['timer']['set'](this['frameTime'] * -_0x1e7657 - 0.0001), this['update']();
        },
        'gotoRandomFrame': function() {
            this['gotoFrame'](Math['floor'](Math['random']() * this['sequence']['length']));
        },
        'update': function() {
            var _0x428584 = Math['floor'](this['timer']['delta']() / this['frameTime']);
            this['loopCount'] = Math['floor'](_0x428584 / this['sequence']['length']), this['frame'] = this['stop'] && 0x0 < this['loopCount'] ? this['sequence']['length'] - 0x1 : _0x428584 % this['sequence']['length'], this['tile'] = this['sequence'][this['frame']];
        },
        'draw': function(_0x5cea6d, _0x1b6e7a) {
            var _0x2d89a8 = Math['max'](this['sheet']['width'], this['sheet']['height']);
            _0x5cea6d > ig['system']['width'] || _0x1b6e7a > ig['system']['height'] || (0x0 > _0x5cea6d + _0x2d89a8 || 0x0 > _0x1b6e7a + _0x2d89a8) || (0x1 != this['alpha'] && (ig['system']['context']['globalAlpha'] = this['alpha']), 0x0 == this['angle'] ? this['sheet']['image']['drawTile'](_0x5cea6d, _0x1b6e7a, this['tile'], this['sheet']['width'], this['sheet']['height'], this['flip']['x'], this['flip']['y']) : (ig['system']['context']['save'](), ig['system']['context']['translate'](ig['system']['getDrawPos'](_0x5cea6d + this['pivot']['x']), ig['system']['getDrawPos'](_0x1b6e7a + this['pivot']['y'])), ig['system']['context']['rotate'](this['angle']), this['sheet']['image']['drawTile'](-this['pivot']['x'], -this['pivot']['y'], this['tile'], this['sheet']['width'], this['sheet']['height'], this['flip']['x'], this['flip']['y']), ig['system']['context']['restore']()), 0x1 != this['alpha'] && (ig['system']['context']['globalAlpha'] = 0x1));
        }
    });
}), ig['baked'] = !0x0, ig['module']('impact.entity')['requires']('impact.animation', 'impact.impact')['defines'](function() {
    ig['Entity'] = ig['Class']['extend']({
        'id': 0x0,
        'settings': {},
        'size': {
            'x': 0x10,
            'y': 0x10
        },
        'offset': {
            'x': 0x0,
            'y': 0x0
        },
        'pos': {
            'x': 0x0,
            'y': 0x0
        },
        'last': {
            'x': 0x0,
            'y': 0x0
        },
        'vel': {
            'x': 0x0,
            'y': 0x0
        },
        'accel': {
            'x': 0x0,
            'y': 0x0
        },
        'friction': {
            'x': 0x0,
            'y': 0x0
        },
        'maxVel': {
            'x': 0x64,
            'y': 0x64
        },
        'zIndex': 0x0,
        'gravityFactor': 0x1,
        'standing': !0x1,
        'bounciness': 0x0,
        'minBounceVelocity': 0x28,
        'anims': {},
        'animSheet': null,
        'currentAnim': null,
        'health': 0xa,
        'type': 0x0,
        'checkAgainst': 0x0,
        'collides': 0x0,
        '_killed': !0x1,
        'slopeStanding': {
            'min': 0x2c['toRad'](),
            'max': 0x88['toRad']()
        },
        'init': function(_0x1cd861, _0x5e1c5f, _0x9c0122) {
            this['id'] = ++ig['Entity']['_lastId'], this['pos']['x'] = this['last']['x'] = _0x1cd861, this['pos']['y'] = this['last']['y'] = _0x5e1c5f, ig['merge'](this, _0x9c0122);
        },
        'reset': function(_0x1f9ac6, _0x3edf1b, _0x3a0fea) {
            var _0x4714a8 = this['constructor']['prototype'];
            this['pos']['x'] = _0x1f9ac6, this['pos']['y'] = _0x3edf1b, this['last']['x'] = _0x1f9ac6, this['last']['y'] = _0x3edf1b, this['vel']['x'] = _0x4714a8['vel']['x'], this['vel']['y'] = _0x4714a8['vel']['y'], this['accel']['x'] = _0x4714a8['accel']['x'], this['accel']['y'] = _0x4714a8['accel']['y'], this['health'] = _0x4714a8['health'], this['_killed'] = _0x4714a8['_killed'], this['standing'] = _0x4714a8['standing'], this['type'] = _0x4714a8['type'], this['checkAgainst'] = _0x4714a8['checkAgainst'], this['collides'] = _0x4714a8['collides'], ig['merge'](this, _0x3a0fea);
        },
        'addAnim': function(_0x580b9a, _0x160e9f, _0x10fe4d, _0x5cfbb6) {
            if (!this['animSheet']) throw 'No\x20animSheet\x20to\x20add\x20the\x20animation\x20' + _0x580b9a + '\x20to.';
            return _0x160e9f = new ig['Animation'](this['animSheet'], _0x160e9f, _0x10fe4d, _0x5cfbb6), this['anims'][_0x580b9a] = _0x160e9f, this['currentAnim'] || (this['currentAnim'] = _0x160e9f), _0x160e9f;
        },
        'update': function() {
            this['last']['x'] = this['pos']['x'], this['last']['y'] = this['pos']['y'], this['vel']['y'] += ig['game']['gravity'] * ig['system']['tick'] * this['gravityFactor'], this['vel']['x'] = this['getNewVelocity'](this['vel']['x'], this['accel']['x'], this['friction']['x'], this['maxVel']['x']), this['vel']['y'] = this['getNewVelocity'](this['vel']['y'], this['accel']['y'], this['friction']['y'], this['maxVel']['y']);
            var _0x55fb7d = ig['game']['collisionMap']['trace'](this['pos']['x'], this['pos']['y'], this['vel']['x'] * ig['system']['tick'], this['vel']['y'] * ig['system']['tick'], this['size']['x'], this['size']['y']);
            this['handleMovementTrace'](_0x55fb7d), this['currentAnim'] && this['currentAnim']['update']();
        },
        'getNewVelocity': function(_0xf9dd99, _0x2eabb4, _0x55bedf, _0x3a4e48) {
            return _0x2eabb4 ? (_0xf9dd99 + _0x2eabb4 * ig['system']['tick'])['limit'](-_0x3a4e48, _0x3a4e48) : _0x55bedf ? (_0x2eabb4 = _0x55bedf * ig['system']['tick'], 0x0 < _0xf9dd99 - _0x2eabb4 ? _0xf9dd99 - _0x2eabb4 : 0x0 > _0xf9dd99 + _0x2eabb4 ? _0xf9dd99 + _0x2eabb4 : 0x0) : _0xf9dd99['limit'](-_0x3a4e48, _0x3a4e48);
        },
        'handleMovementTrace': function(_0x1bcffc) {
            this['standing'] = !0x1, _0x1bcffc['collision']['y'] && (0x0 < this['bounciness'] && Math['abs'](this['vel']['y']) > this['minBounceVelocity'] ? this['vel']['y'] *= -this['bounciness'] : (0x0 < this['vel']['y'] && (this['standing'] = !0x0), this['vel']['y'] = 0x0)), _0x1bcffc['collision']['x'] && (this['vel']['x'] = 0x0 < this['bounciness'] && Math['abs'](this['vel']['x']) > this['minBounceVelocity'] ? this['vel']['x'] * -this['bounciness'] : 0x0);
            if (_0x1bcffc['collision']['slope']) {
                var _0x464757 = _0x1bcffc['collision']['slope'];
                if (0x0 < this['bounciness']) {
                    var _0x41dfb6 = this['vel']['x'] * _0x464757['nx'] + this['vel']['y'] * _0x464757['ny'];
                    this['vel']['x'] = (this['vel']['x'] - 0x2 * _0x464757['nx'] * _0x41dfb6) * this['bounciness'], this['vel']['y'] = (this['vel']['y'] - 0x2 * _0x464757['ny'] * _0x41dfb6) * this['bounciness'];
                } else _0x41dfb6 = (this['vel']['x'] * _0x464757['x'] + this['vel']['y'] * _0x464757['y']) / (_0x464757['x'] * _0x464757['x'] + _0x464757['y'] * _0x464757['y']), this['vel']['x'] = _0x464757['x'] * _0x41dfb6, this['vel']['y'] = _0x464757['y'] * _0x41dfb6, _0x464757 = Math['atan2'](_0x464757['x'], _0x464757['y']), _0x464757 > this['slopeStanding']['min'] && _0x464757 < this['slopeStanding']['max'] && (this['standing'] = !0x0);
            }
            this['pos'] = _0x1bcffc['pos'];
        },
        'draw': function() {
            this['currentAnim'] && this['currentAnim']['draw'](this['pos']['x'] - this['offset']['x'] - ig['game']['_rscreen']['x'], this['pos']['y'] - this['offset']['y'] - ig['game']['_rscreen']['y']);
        },
        'kill': function() {
            ig['game']['removeEntity'](this);
        },
        'receiveDamage': function(_0x533129) {
            this['health'] -= _0x533129, 0x0 >= this['health'] && this['kill']();
        },
        'touches': function(_0x1ceeb0) {
            return !(this['pos']['x'] >= _0x1ceeb0['pos']['x'] + _0x1ceeb0['size']['x'] || this['pos']['x'] + this['size']['x'] <= _0x1ceeb0['pos']['x'] || this['pos']['y'] >= _0x1ceeb0['pos']['y'] + _0x1ceeb0['size']['y'] || this['pos']['y'] + this['size']['y'] <= _0x1ceeb0['pos']['y']);
        },
        'distanceTo': function(_0x59ce25) {
            var _0x5d75d2 = this['pos']['x'] + this['size']['x'] / 0x2 - (_0x59ce25['pos']['x'] + _0x59ce25['size']['x'] / 0x2);
            return _0x59ce25 = this['pos']['y'] + this['size']['y'] / 0x2 - (_0x59ce25['pos']['y'] + _0x59ce25['size']['y'] / 0x2), Math['sqrt'](_0x5d75d2 * _0x5d75d2 + _0x59ce25 * _0x59ce25);
        },
        'angleTo': function(_0x243f44) {
            return Math['atan2'](_0x243f44['pos']['y'] + _0x243f44['size']['y'] / 0x2 - (this['pos']['y'] + this['size']['y'] / 0x2), _0x243f44['pos']['x'] + _0x243f44['size']['x'] / 0x2 - (this['pos']['x'] + this['size']['x'] / 0x2));
        },
        'check': function() {},
        'collideWith': function() {},
        'ready': function() {},
        'erase': function() {}
    }), ig['Entity']['_lastId'] = 0x0, ig['Entity']['COLLIDES'] = {
        'NEVER': 0x0,
        'LITE': 0x1,
        'PASSIVE': 0x2,
        'ACTIVE': 0x4,
        'FIXED': 0x8
    }, ig['Entity']['TYPE'] = {
        'NONE': 0x0,
        'A': 0x1,
        'B': 0x2,
        'BOTH': 0x3
    }, ig['Entity']['checkPair'] = function(_0x467cf1, _0x5a3252) {
        _0x467cf1['checkAgainst'] & _0x5a3252['type'] && _0x467cf1['check'](_0x5a3252), _0x5a3252['checkAgainst'] & _0x467cf1['type'] && _0x5a3252['check'](_0x467cf1), _0x467cf1['collides'] && _0x5a3252['collides'] && _0x467cf1['collides'] + _0x5a3252['collides'] > ig['Entity']['COLLIDES']['ACTIVE'] && ig['Entity']['solveCollision'](_0x467cf1, _0x5a3252);
    }, ig['Entity']['solveCollision'] = function(_0xfcfc3c, _0xe42c93) {
        var _0x453824 = null;
        if (_0xfcfc3c['collides'] == ig['Entity']['COLLIDES']['LITE'] || _0xe42c93['collides'] == ig['Entity']['COLLIDES']['FIXED']) _0x453824 = _0xfcfc3c;
        else {
            if (_0xe42c93['collides'] == ig['Entity']['COLLIDES']['LITE'] || _0xfcfc3c['collides'] == ig['Entity']['COLLIDES']['FIXED']) _0x453824 = _0xe42c93;
        }
        _0xfcfc3c['last']['x'] + _0xfcfc3c['size']['x'] > _0xe42c93['last']['x'] && _0xfcfc3c['last']['x'] < _0xe42c93['last']['x'] + _0xe42c93['size']['x'] ? (_0xfcfc3c['last']['y'] < _0xe42c93['last']['y'] ? ig['Entity']['seperateOnYAxis'](_0xfcfc3c, _0xe42c93, _0x453824) : ig['Entity']['seperateOnYAxis'](_0xe42c93, _0xfcfc3c, _0x453824), _0xfcfc3c['collideWith'](_0xe42c93, 'y'), _0xe42c93['collideWith'](_0xfcfc3c, 'y')) : _0xfcfc3c['last']['y'] + _0xfcfc3c['size']['y'] > _0xe42c93['last']['y'] && _0xfcfc3c['last']['y'] < _0xe42c93['last']['y'] + _0xe42c93['size']['y'] && (_0xfcfc3c['last']['x'] < _0xe42c93['last']['x'] ? ig['Entity']['seperateOnXAxis'](_0xfcfc3c, _0xe42c93, _0x453824) : ig['Entity']['seperateOnXAxis'](_0xe42c93, _0xfcfc3c, _0x453824), _0xfcfc3c['collideWith'](_0xe42c93, 'x'), _0xe42c93['collideWith'](_0xfcfc3c, 'x'));
    }, ig['Entity']['seperateOnXAxis'] = function(_0x174810, _0x4ef805, _0x3340e7) {
        var _0x46d6d1 = _0x174810['pos']['x'] + _0x174810['size']['x'] - _0x4ef805['pos']['x'];
        _0x3340e7 ? (_0x3340e7['vel']['x'] = -_0x3340e7['vel']['x'] * _0x3340e7['bounciness'] + (_0x174810 === _0x3340e7 ? _0x4ef805 : _0x174810)['vel']['x'], _0x4ef805 = ig['game']['collisionMap']['trace'](_0x3340e7['pos']['x'], _0x3340e7['pos']['y'], _0x3340e7 == _0x174810 ? -_0x46d6d1 : _0x46d6d1, 0x0, _0x3340e7['size']['x'], _0x3340e7['size']['y']), _0x3340e7['pos']['x'] = _0x4ef805['pos']['x']) : (_0x3340e7 = (_0x174810['vel']['x'] - _0x4ef805['vel']['x']) / 0x2, _0x174810['vel']['x'] = -_0x3340e7, _0x4ef805['vel']['x'] = _0x3340e7, _0x3340e7 = ig['game']['collisionMap']['trace'](_0x174810['pos']['x'], _0x174810['pos']['y'], -_0x46d6d1 / 0x2, 0x0, _0x174810['size']['x'], _0x174810['size']['y']), _0x174810['pos']['x'] = Math['floor'](_0x3340e7['pos']['x']), _0x174810 = ig['game']['collisionMap']['trace'](_0x4ef805['pos']['x'], _0x4ef805['pos']['y'], _0x46d6d1 / 0x2, 0x0, _0x4ef805['size']['x'], _0x4ef805['size']['y']), _0x4ef805['pos']['x'] = Math['ceil'](_0x174810['pos']['x']));
    }, ig['Entity']['seperateOnYAxis'] = function(_0x527d8f, _0x12b852, _0x243f39) {
        var _0x57eea9 = _0x527d8f['pos']['y'] + _0x527d8f['size']['y'] - _0x12b852['pos']['y'];
        if (_0x243f39) {
            _0x12b852 = _0x527d8f === _0x243f39 ? _0x12b852 : _0x527d8f, _0x243f39['vel']['y'] = -_0x243f39['vel']['y'] * _0x243f39['bounciness'] + _0x12b852['vel']['y'];
            var _0x27381d = 0x0;
            _0x243f39 == _0x527d8f && Math['abs'](_0x243f39['vel']['y'] - _0x12b852['vel']['y']) < _0x243f39['minBounceVelocity'] && (_0x243f39['standing'] = !0x0, _0x27381d = _0x12b852['vel']['x'] * ig['system']['tick']), _0x527d8f = ig['game']['collisionMap']['trace'](_0x243f39['pos']['x'], _0x243f39['pos']['y'], _0x27381d, _0x243f39 == _0x527d8f ? -_0x57eea9 : _0x57eea9, _0x243f39['size']['x'], _0x243f39['size']['y']), _0x243f39['pos']['y'] = _0x527d8f['pos']['y'], _0x243f39['pos']['x'] = _0x527d8f['pos']['x'];
        } else ig['game']['gravity'] && (_0x12b852['standing'] || 0x0 < _0x527d8f['vel']['y']) ? (_0x243f39 = ig['game']['collisionMap']['trace'](_0x527d8f['pos']['x'], _0x527d8f['pos']['y'], 0x0, -(_0x527d8f['pos']['y'] + _0x527d8f['size']['y'] - _0x12b852['pos']['y']), _0x527d8f['size']['x'], _0x527d8f['size']['y']), _0x527d8f['pos']['y'] = _0x243f39['pos']['y'], 0x0 < _0x527d8f['bounciness'] && _0x527d8f['vel']['y'] > _0x527d8f['minBounceVelocity'] ? _0x527d8f['vel']['y'] *= -_0x527d8f['bounciness'] : (_0x527d8f['standing'] = !0x0, _0x527d8f['vel']['y'] = 0x0)) : (_0x243f39 = (_0x527d8f['vel']['y'] - _0x12b852['vel']['y']) / 0x2, _0x527d8f['vel']['y'] = -_0x243f39, _0x12b852['vel']['y'] = _0x243f39, _0x27381d = _0x12b852['vel']['x'] * ig['system']['tick'], _0x243f39 = ig['game']['collisionMap']['trace'](_0x527d8f['pos']['x'], _0x527d8f['pos']['y'], _0x27381d, -_0x57eea9 / 0x2, _0x527d8f['size']['x'], _0x527d8f['size']['y']), _0x527d8f['pos']['y'] = _0x243f39['pos']['y'], _0x527d8f = ig['game']['collisionMap']['trace'](_0x12b852['pos']['x'], _0x12b852['pos']['y'], 0x0, _0x57eea9 / 0x2, _0x12b852['size']['x'], _0x12b852['size']['y']), _0x12b852['pos']['y'] = _0x527d8f['pos']['y']);
    };
}), ig['baked'] = !0x0, ig['module']('impact.map')['defines'](function() {
    ig['Map'] = ig['Class']['extend']({
        'tilesize': 0x8,
        'width': 0x1,
        'height': 0x1,
        'data': [
            []
        ],
        'name': null,
        'init': function(_0x5d05da, _0x152742) {
            this['tilesize'] = _0x5d05da, this['data'] = _0x152742, this['height'] = _0x152742['length'], this['width'] = _0x152742[0x0]['length'], this['pxWidth'] = this['width'] * this['tilesize'], this['pxHeight'] = this['height'] * this['tilesize'];
        },
        'getTile': function(_0x291124, _0x1bb7db) {
            var _0x3efe70 = Math['floor'](_0x291124 / this['tilesize']),
                _0x57379c = Math['floor'](_0x1bb7db / this['tilesize']);
            return 0x0 <= _0x3efe70 && _0x3efe70 < this['width'] && 0x0 <= _0x57379c && _0x57379c < this['height'] ? this['data'][_0x57379c][_0x3efe70] : 0x0;
        },
        'setTile': function(_0x510887, _0xed850d, _0x11d6ca) {
            _0x510887 = Math['floor'](_0x510887 / this['tilesize']), _0xed850d = Math['floor'](_0xed850d / this['tilesize']), 0x0 <= _0x510887 && _0x510887 < this['width'] && 0x0 <= _0xed850d && _0xed850d < this['height'] && (this['data'][_0xed850d][_0x510887] = _0x11d6ca);
        }
    });
}), ig['baked'] = !0x0, ig['module']('impact.collision-map')['requires']('impact.map')['defines'](function() {
    ig['CollisionMap'] = ig['Map']['extend']({
        'lastSlope': 0x1,
        'tiledef': null,
        'init': function(_0xbcb4e1, _0x13e837, _0x3a0cc5) {
            this['parent'](_0xbcb4e1, _0x13e837), this['tiledef'] = _0x3a0cc5 || ig['CollisionMap']['defaultTileDef'];
            for (var _0x566e89 in this['tiledef']) _0x566e89 | 0x0 > this['lastSlope'] && (this['lastSlope'] = _0x566e89 | 0x0);
        },
        'trace': function(_0x2bb30e, _0xf18a7d, _0x3825b0, _0x4da6eb, _0x1ce11a, _0x44a039) {
            var _0x3939e5 = {
                    'collision': {
                        'x': !0x1,
                        'y': !0x1,
                        'slope': !0x1
                    },
                    'pos': {
                        'x': _0x2bb30e,
                        'y': _0xf18a7d
                    },
                    'tile': {
                        'x': 0x0,
                        'y': 0x0
                    }
                },
                _0x4e9a9d = Math['ceil'](Math['max'](Math['abs'](_0x3825b0), Math['abs'](_0x4da6eb)) / this['tilesize']);
            if (0x1 < _0x4e9a9d) {
                for (var _0x14dbed = _0x3825b0 / _0x4e9a9d, _0x37b314 = _0x4da6eb / _0x4e9a9d, _0x234e06 = 0x0; _0x234e06 < _0x4e9a9d && (_0x14dbed || _0x37b314) && !(this['_traceStep'](_0x3939e5, _0x2bb30e, _0xf18a7d, _0x14dbed, _0x37b314, _0x1ce11a, _0x44a039, _0x3825b0, _0x4da6eb, _0x234e06), _0x2bb30e = _0x3939e5['pos']['x'], _0xf18a7d = _0x3939e5['pos']['y'], _0x3939e5['collision']['x'] && (_0x3825b0 = _0x14dbed = 0x0), _0x3939e5['collision']['y'] && (_0x4da6eb = _0x37b314 = 0x0), _0x3939e5['collision']['slope']); _0x234e06++);
            } else this['_traceStep'](_0x3939e5, _0x2bb30e, _0xf18a7d, _0x3825b0, _0x4da6eb, _0x1ce11a, _0x44a039, _0x3825b0, _0x4da6eb, 0x0);
            return _0x3939e5;
        },
        '_traceStep': function(_0x121c91, _0x445c11, _0xb3193e, _0x4bbe16, _0x1487f1, _0x248f3b, _0x485547, _0x1ded0f, _0x816c85, _0x2a9baa) {
            _0x121c91['pos']['x'] += _0x4bbe16, _0x121c91['pos']['y'] += _0x1487f1;
            var _0x5c6252 = 0x0;
            if (_0x4bbe16) {
                var _0x12d184 = 0x0 < _0x4bbe16 ? _0x248f3b : 0x0,
                    _0x339d3b = 0x0 > _0x4bbe16 ? this['tilesize'] : 0x0,
                    _0x5c6252 = Math['max'](Math['floor'](_0xb3193e / this['tilesize']), 0x0),
                    _0x2d53d9 = Math['min'](Math['ceil']((_0xb3193e + _0x485547) / this['tilesize']), this['height']);
                _0x4bbe16 = Math['floor']((_0x121c91['pos']['x'] + _0x12d184) / this['tilesize']);
                var _0x26b32f = Math['floor']((_0x445c11 + _0x12d184) / this['tilesize']);
                if (0x0 < _0x2a9baa || _0x4bbe16 == _0x26b32f || 0x0 > _0x26b32f || _0x26b32f >= this['width']) _0x26b32f = -0x1;
                if (0x0 <= _0x4bbe16 && _0x4bbe16 < this['width']) {
                    for (var _0x5f567c = _0x5c6252; _0x5f567c < _0x2d53d9 && !(-0x1 != _0x26b32f && (_0x5c6252 = this['data'][_0x5f567c][_0x26b32f], 0x1 < _0x5c6252 && _0x5c6252 <= this['lastSlope'] && this['_checkTileDef'](_0x121c91, _0x5c6252, _0x445c11, _0xb3193e, _0x1ded0f, _0x816c85, _0x248f3b, _0x485547, _0x26b32f, _0x5f567c))); _0x5f567c++)
                        if (_0x5c6252 = this['data'][_0x5f567c][_0x4bbe16], 0x1 == _0x5c6252 || _0x5c6252 > this['lastSlope'] || 0x1 < _0x5c6252 && this['_checkTileDef'](_0x121c91, _0x5c6252, _0x445c11, _0xb3193e, _0x1ded0f, _0x816c85, _0x248f3b, _0x485547, _0x4bbe16, _0x5f567c)) {
                            if (0x1 < _0x5c6252 && _0x5c6252 <= this['lastSlope'] && _0x121c91['collision']['slope']) break;
                            _0x121c91['collision']['x'] = !0x0, _0x121c91['tile']['x'] = _0x5c6252, _0x445c11 = _0x121c91['pos']['x'] = _0x4bbe16 * this['tilesize'] - _0x12d184 + _0x339d3b, _0x1ded0f = 0x0;
                            break;
                        }
                }
            }
            if (_0x1487f1) {
                _0x12d184 = 0x0 < _0x1487f1 ? _0x485547 : 0x0, _0x1487f1 = 0x0 > _0x1487f1 ? this['tilesize'] : 0x0, _0x5c6252 = Math['max'](Math['floor'](_0x121c91['pos']['x'] / this['tilesize']), 0x0), _0x339d3b = Math['min'](Math['ceil']((_0x121c91['pos']['x'] + _0x248f3b) / this['tilesize']), this['width']), _0x5f567c = Math['floor']((_0x121c91['pos']['y'] + _0x12d184) / this['tilesize']), _0x2d53d9 = Math['floor']((_0xb3193e + _0x12d184) / this['tilesize']);
                if (0x0 < _0x2a9baa || _0x5f567c == _0x2d53d9 || 0x0 > _0x2d53d9 || _0x2d53d9 >= this['height']) _0x2d53d9 = -0x1;
                if (0x0 <= _0x5f567c && _0x5f567c < this['height']) {
                    for (_0x4bbe16 = _0x5c6252; _0x4bbe16 < _0x339d3b && !(-0x1 != _0x2d53d9 && (_0x5c6252 = this['data'][_0x2d53d9][_0x4bbe16], 0x1 < _0x5c6252 && _0x5c6252 <= this['lastSlope'] && this['_checkTileDef'](_0x121c91, _0x5c6252, _0x445c11, _0xb3193e, _0x1ded0f, _0x816c85, _0x248f3b, _0x485547, _0x4bbe16, _0x2d53d9))); _0x4bbe16++)
                        if (_0x5c6252 = this['data'][_0x5f567c][_0x4bbe16], 0x1 == _0x5c6252 || _0x5c6252 > this['lastSlope'] || 0x1 < _0x5c6252 && this['_checkTileDef'](_0x121c91, _0x5c6252, _0x445c11, _0xb3193e, _0x1ded0f, _0x816c85, _0x248f3b, _0x485547, _0x4bbe16, _0x5f567c)) {
                            if (0x1 < _0x5c6252 && _0x5c6252 <= this['lastSlope'] && _0x121c91['collision']['slope']) break;
                            _0x121c91['collision']['y'] = !0x0, _0x121c91['tile']['y'] = _0x5c6252, _0x121c91['pos']['y'] = _0x5f567c * this['tilesize'] - _0x12d184 + _0x1487f1;
                            break;
                        }
                }
            }
        },
        '_checkTileDef': function(_0x5c9602, _0x2c516e, _0x5e88b5, _0x13a969, _0x30b682, _0x5da4d6, _0x1a8907, _0xf8be33, _0xe3e956, _0x594654) {
            var _0x361cf8 = this['tiledef'][_0x2c516e];
            if (!_0x361cf8) return !0x1;
            _0x2c516e = (_0x361cf8[0x2] - _0x361cf8[0x0]) * this['tilesize'];
            var _0x2b376c = (_0x361cf8[0x3] - _0x361cf8[0x1]) * this['tilesize'],
                _0xb244da = _0x361cf8[0x4];
            _0x1a8907 = _0x5e88b5 + _0x30b682 + (0x0 > _0x2b376c ? _0x1a8907 : 0x0) - (_0xe3e956 + _0x361cf8[0x0]) * this['tilesize'], _0xf8be33 = _0x13a969 + _0x5da4d6 + (0x0 < _0x2c516e ? _0xf8be33 : 0x0) - (_0x594654 + _0x361cf8[0x1]) * this['tilesize'];
            if (0x0 < _0x2c516e * _0xf8be33 - _0x2b376c * _0x1a8907) {
                if (0x0 > _0x30b682 * -_0x2b376c + _0x5da4d6 * _0x2c516e) return _0xb244da;
                _0xe3e956 = Math['sqrt'](_0x2c516e * _0x2c516e + _0x2b376c * _0x2b376c), _0x594654 = _0x2b376c / _0xe3e956, _0xe3e956 = -_0x2c516e / _0xe3e956;
                var _0x5f4615 = _0x1a8907 * _0x594654 + _0xf8be33 * _0xe3e956,
                    _0x361cf8 = _0x594654 * _0x5f4615,
                    _0x5f4615 = _0xe3e956 * _0x5f4615;
                if (_0x361cf8 * _0x361cf8 + _0x5f4615 * _0x5f4615 >= _0x30b682 * _0x30b682 + _0x5da4d6 * _0x5da4d6) return _0xb244da || 0.5 > _0x2c516e * (_0xf8be33 - _0x5da4d6) - _0x2b376c * (_0x1a8907 - _0x30b682);
                return _0x5c9602['pos']['x'] = _0x5e88b5 + _0x30b682 - _0x361cf8, _0x5c9602['pos']['y'] = _0x13a969 + _0x5da4d6 - _0x5f4615, _0x5c9602['collision']['slope'] = {
                    'x': _0x2c516e,
                    'y': _0x2b376c,
                    'nx': _0x594654,
                    'ny': _0xe3e956
                }, !0x0;
            }
            return !0x1;
        }
    });
    var _0x21b4ac = 0x1 / 0x3,
        _0x276ed7 = 0x2 / 0x3;
    ig['CollisionMap']['defaultTileDef'] = {
        0x5: [0x0, 0x1, 0x1, _0x276ed7, !0x0],
        0x6: [0x0, _0x276ed7, 0x1, _0x21b4ac, !0x0],
        0x7: [0x0, _0x21b4ac, 0x1, 0x0, !0x0],
        0x3: [0x0, 0x1, 0x1, 0.5, !0x0],
        0x4: [0x0, 0.5, 0x1, 0x0, !0x0],
        0x2: [0x0, 0x1, 0x1, 0x0, !0x0],
        0xa: [0.5, 0x1, 0x1, 0x0, !0x0],
        0x15: [0x0, 0x1, 0.5, 0x0, !0x0],
        0x20: [_0x276ed7, 0x1, 0x1, 0x0, !0x0],
        0x2b: [_0x21b4ac, 0x1, _0x276ed7, 0x0, !0x0],
        0x36: [0x0, 0x1, _0x21b4ac, 0x0, !0x0],
        0x1b: [0x0, 0x0, 0x1, _0x21b4ac, !0x0],
        0x1c: [0x0, _0x21b4ac, 0x1, _0x276ed7, !0x0],
        0x1d: [0x0, _0x276ed7, 0x1, 0x1, !0x0],
        0x19: [0x0, 0x0, 0x1, 0.5, !0x0],
        0x1a: [0x0, 0.5, 0x1, 0x1, !0x0],
        0x18: [0x0, 0x0, 0x1, 0x1, !0x0],
        0xb: [0x0, 0x0, 0.5, 0x1, !0x0],
        0x16: [0.5, 0x0, 0x1, 0x1, !0x0],
        0x21: [0x0, 0x0, _0x21b4ac, 0x1, !0x0],
        0x2c: [_0x21b4ac, 0x0, _0x276ed7, 0x1, !0x0],
        0x37: [_0x276ed7, 0x0, 0x1, 0x1, !0x0],
        0x10: [0x1, _0x21b4ac, 0x0, 0x0, !0x0],
        0x11: [0x1, _0x276ed7, 0x0, _0x21b4ac, !0x0],
        0x12: [0x1, 0x1, 0x0, _0x276ed7, !0x0],
        0xe: [0x1, 0.5, 0x0, 0x0, !0x0],
        0xf: [0x1, 0x1, 0x0, 0.5, !0x0],
        0xd: [0x1, 0x1, 0x0, 0x0, !0x0],
        0x8: [0.5, 0x1, 0x0, 0x0, !0x0],
        0x13: [0x1, 0x1, 0.5, 0x0, !0x0],
        0x1e: [_0x21b4ac, 0x1, 0x0, 0x0, !0x0],
        0x29: [_0x276ed7, 0x1, _0x21b4ac, 0x0, !0x0],
        0x34: [0x1, 0x1, _0x276ed7, 0x0, !0x0],
        0x26: [0x1, _0x276ed7, 0x0, 0x1, !0x0],
        0x27: [0x1, _0x21b4ac, 0x0, _0x276ed7, !0x0],
        0x28: [0x1, 0x0, 0x0, _0x21b4ac, !0x0],
        0x24: [0x1, 0.5, 0x0, 0x1, !0x0],
        0x25: [0x1, 0x0, 0x0, 0.5, !0x0],
        0x23: [0x1, 0x0, 0x0, 0x1, !0x0],
        0x9: [0x1, 0x0, 0.5, 0x1, !0x0],
        0x14: [0.5, 0x0, 0x0, 0x1, !0x0],
        0x1f: [0x1, 0x0, _0x276ed7, 0x1, !0x0],
        0x2a: [_0x276ed7, 0x0, _0x21b4ac, 0x1, !0x0],
        0x35: [_0x21b4ac, 0x0, 0x0, 0x1, !0x0],
        0xc: [0x0, 0x0, 0x1, 0x0, !0x1],
        0x17: [0x1, 0x1, 0x0, 0x1, !0x1],
        0x22: [0x1, 0x0, 0x1, 0x1, !0x1],
        0x2d: [0x0, 0x1, 0x0, 0x0, !0x1]
    }, ig['CollisionMap']['staticNoCollision'] = {
        'trace': function(_0xab7928, _0xb38306, _0x2be92d, _0x1bbe35) {
            return {
                'collision': {
                    'x': !0x1,
                    'y': !0x1,
                    'slope': !0x1
                },
                'pos': {
                    'x': _0xab7928 + _0x2be92d,
                    'y': _0xb38306 + _0x1bbe35
                },
                'tile': {
                    'x': 0x0,
                    'y': 0x0
                }
            };
        }
    };
}), ig['baked'] = !0x0, ig['module']('impact.background-map')['requires']('impact.map', 'impact.image')['defines'](function() {
    ig['BackgroundMap'] = ig['Map']['extend']({
        'tiles': null,
        'scroll': {
            'x': 0x0,
            'y': 0x0
        },
        'distance': 0x1,
        'repeat': !0x1,
        'tilesetName': '',
        'foreground': !0x1,
        'enabled': !0x0,
        'preRender': !0x1,
        'preRenderedChunks': null,
        'chunkSize': 0x200,
        'debugChunks': !0x1,
        'anims': {},
        'init': function(_0x564f60, _0x20a683, _0x4a7c3f) {
            this['parent'](_0x564f60, _0x20a683), this['setTileset'](_0x4a7c3f);
        },
        'setTileset': function(_0x523e15) {
            this['tilesetName'] = _0x523e15 instanceof ig['Image'] ? _0x523e15['path'] : _0x523e15, this['tiles'] = new ig['Image'](this['tilesetName']), this['preRenderedChunks'] = null;
        },
        'setScreenPos': function(_0x5dce11, _0x4d6d6a) {
            this['scroll']['x'] = _0x5dce11 / this['distance'], this['scroll']['y'] = _0x4d6d6a / this['distance'];
        },
        'preRenderMapToChunks': function() {
            var _0x4d4689 = this['width'] * this['tilesize'] * ig['system']['scale'],
                _0x2ee8c8 = this['height'] * this['tilesize'] * ig['system']['scale'];
            this['chunkSize'] = Math['min'](Math['max'](_0x4d4689, _0x2ee8c8), this['chunkSize']);
            var _0x52d34e = Math['ceil'](_0x4d4689 / this['chunkSize']),
                _0x1ead03 = Math['ceil'](_0x2ee8c8 / this['chunkSize']);
            this['preRenderedChunks'] = [];
            for (var _0x4e8ee2 = 0x0; _0x4e8ee2 < _0x1ead03; _0x4e8ee2++) {
                this['preRenderedChunks'][_0x4e8ee2] = [];
                for (var _0x43a8a1 = 0x0; _0x43a8a1 < _0x52d34e; _0x43a8a1++) this['preRenderedChunks'][_0x4e8ee2][_0x43a8a1] = this['preRenderChunk'](_0x43a8a1, _0x4e8ee2, _0x43a8a1 == _0x52d34e - 0x1 ? _0x4d4689 - _0x43a8a1 * this['chunkSize'] : this['chunkSize'], _0x4e8ee2 == _0x1ead03 - 0x1 ? _0x2ee8c8 - _0x4e8ee2 * this['chunkSize'] : this['chunkSize']);
            }
        },
        'preRenderChunk': function(_0x218b5b, _0x46bad5, _0x5ab884, _0x55e481) {
            var _0x8c1eb9 = _0x5ab884 / this['tilesize'] / ig['system']['scale'] + 0x1,
                _0x2f8b1f = _0x55e481 / this['tilesize'] / ig['system']['scale'] + 0x1,
                _0x52496c = _0x218b5b * this['chunkSize'] / ig['system']['scale'] % this['tilesize'],
                _0x5e04dc = _0x46bad5 * this['chunkSize'] / ig['system']['scale'] % this['tilesize'];
            _0x218b5b = Math['floor'](_0x218b5b * this['chunkSize'] / this['tilesize'] / ig['system']['scale']), _0x46bad5 = Math['floor'](_0x46bad5 * this['chunkSize'] / this['tilesize'] / ig['system']['scale']);
            var _0x35638f = ig['$new']('canvas');
            _0x35638f['width'] = _0x5ab884, _0x35638f['height'] = _0x55e481, _0x35638f['retinaResolutionEnabled'] = !0x1, _0x55e481 = _0x35638f['getContext']('2d'), ig['System']['scaleMode'](_0x35638f, _0x55e481), _0x5ab884 = ig['system']['context'], ig['system']['context'] = _0x55e481;
            for (_0x55e481 = 0x0; _0x55e481 < _0x8c1eb9; _0x55e481++)
                for (var _0x492bb6 = 0x0; _0x492bb6 < _0x2f8b1f; _0x492bb6++)
                    if (_0x55e481 + _0x218b5b < this['width'] && _0x492bb6 + _0x46bad5 < this['height']) {
                        var _0x5c2805 = this['data'][_0x492bb6 + _0x46bad5][_0x55e481 + _0x218b5b];
                        _0x5c2805 && this['tiles']['drawTile'](_0x55e481 * this['tilesize'] - _0x52496c, _0x492bb6 * this['tilesize'] - _0x5e04dc, _0x5c2805 - 0x1, this['tilesize']);
                    }
            return ig['system']['context'] = _0x5ab884, _0x35638f;
        },
        'draw': function() {
            this['tiles']['loaded'] && this['enabled'] && (this['preRender'] ? this['drawPreRendered']() : this['drawTiled']());
        },
        'drawPreRendered': function() {
            this['preRenderedChunks'] || this['preRenderMapToChunks']();
            var _0x3a2c65 = ig['system']['getDrawPos'](this['scroll']['x']),
                _0x5fc56e = ig['system']['getDrawPos'](this['scroll']['y']);
            if (this['repeat']) var _0x58561d = this['width'] * this['tilesize'] * ig['system']['scale'],
                _0x3a2c65 = (_0x3a2c65 % _0x58561d + _0x58561d) % _0x58561d,
                _0x58561d = this['height'] * this['tilesize'] * ig['system']['scale'],
                _0x5fc56e = (_0x5fc56e % _0x58561d + _0x58561d) % _0x58561d;
            var _0x58561d = Math['max'](Math['floor'](_0x3a2c65 / this['chunkSize']), 0x0),
                _0x17b53d = Math['max'](Math['floor'](_0x5fc56e / this['chunkSize']), 0x0),
                _0xaa2fa0 = Math['ceil']((_0x3a2c65 + ig['system']['realWidth']) / this['chunkSize']),
                _0x502755 = Math['ceil']((_0x5fc56e + ig['system']['realHeight']) / this['chunkSize']),
                _0x37f973 = this['preRenderedChunks'][0x0]['length'],
                _0x573427 = this['preRenderedChunks']['length'];
            this['repeat'] || (_0xaa2fa0 = Math['min'](_0xaa2fa0, _0x37f973), _0x502755 = Math['min'](_0x502755, _0x573427));
            for (var _0xa926e3 = 0x0; _0x17b53d < _0x502755; _0x17b53d++) {
                for (var _0x54144f = 0x0, _0xf347c3 = _0x58561d; _0xf347c3 < _0xaa2fa0; _0xf347c3++) {
                    var _0x3272c1 = this['preRenderedChunks'][_0x17b53d % _0x573427][_0xf347c3 % _0x37f973],
                        _0x1dc79b = -_0x3a2c65 + _0xf347c3 * this['chunkSize'] - _0x54144f,
                        _0x434c2f = -_0x5fc56e + _0x17b53d * this['chunkSize'] - _0xa926e3;
                    ig['system']['context']['drawImage'](_0x3272c1, _0x1dc79b, _0x434c2f), ig['Image']['drawCount']++, this['debugChunks'] && (ig['system']['context']['strokeStyle'] = '#f0f', ig['system']['context']['strokeRect'](_0x1dc79b, _0x434c2f, this['chunkSize'], this['chunkSize'])), this['repeat'] && _0x3272c1['width'] < this['chunkSize'] && _0x1dc79b + _0x3272c1['width'] < ig['system']['realWidth'] && (_0x54144f += this['chunkSize'] - _0x3272c1['width'], _0xaa2fa0++);
                }
                this['repeat'] && _0x3272c1['height'] < this['chunkSize'] && _0x434c2f + _0x3272c1['height'] < ig['system']['realHeight'] && (_0xa926e3 += this['chunkSize'] - _0x3272c1['height'], _0x502755++);
            }
        },
        'drawTiled': function() {
            for (var _0xc0246f = 0x0, _0x5abecf = null, _0x97746b = (this['scroll']['x'] / this['tilesize'])['toInt'](), _0xa916b3 = (this['scroll']['y'] / this['tilesize'])['toInt'](), _0x434db9 = this['scroll']['x'] % this['tilesize'], _0x27ee4b = this['scroll']['y'] % this['tilesize'], _0x28b0e9 = -_0x434db9 - this['tilesize'], _0x434db9 = ig['system']['width'] + this['tilesize'] - _0x434db9, _0x3d3c77 = ig['system']['height'] + this['tilesize'] - _0x27ee4b, _0x2811d8 = -0x1, _0x27ee4b = -_0x27ee4b - this['tilesize']; _0x27ee4b < _0x3d3c77; _0x2811d8++, _0x27ee4b += this['tilesize']) {
                var _0x4f911a = _0x2811d8 + _0xa916b3;
                if (_0x4f911a >= this['height'] || 0x0 > _0x4f911a) {
                    if (!this['repeat']) continue;
                    _0x4f911a = (_0x4f911a % this['height'] + this['height']) % this['height'];
                }
                for (var _0x5e600c = -0x1, _0xb4e03a = _0x28b0e9; _0xb4e03a < _0x434db9; _0x5e600c++, _0xb4e03a += this['tilesize']) {
                    _0xc0246f = _0x5e600c + _0x97746b;
                    if (_0xc0246f >= this['width'] || 0x0 > _0xc0246f) {
                        if (!this['repeat']) continue;
                        _0xc0246f = (_0xc0246f % this['width'] + this['width']) % this['width'];
                    }
                    if (_0xc0246f = this['data'][_0x4f911a][_0xc0246f])(_0x5abecf = this['anims'][_0xc0246f - 0x1]) ? _0x5abecf['draw'](_0xb4e03a, _0x27ee4b) : this['tiles']['drawTile'](_0xb4e03a, _0x27ee4b, _0xc0246f - 0x1, this['tilesize']);
                }
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('impact.game')['requires']('impact.impact', 'impact.entity', 'impact.collision-map', 'impact.background-map')['defines'](function() {
    ig['Game'] = ig['Class']['extend']({
        'clearColor': '#000000',
        'gravity': 0x0,
        'screen': {
            'x': 0x0,
            'y': 0x0
        },
        '_rscreen': {
            'x': 0x0,
            'y': 0x0
        },
        'entities': [],
        'namedEntities': {},
        'collisionMap': ig['CollisionMap']['staticNoCollision'],
        'backgroundMaps': [],
        'backgroundAnims': {},
        'autoSort': !0x1,
        'sortBy': null,
        'cellSize': 0x40,
        '_deferredKill': [],
        '_levelToLoad': null,
        '_doSortEntities': !0x1,
        'staticInstantiate': function() {
            return this['sortBy'] = this['sortBy'] || ig['Game']['SORT']['Z_INDEX'], ig['game'] = this, null;
        },
        'loadLevel': function(_0x453f7e) {
            this['screen'] = {
                'x': 0x0,
                'y': 0x0
            }, this['entities'] = [], this['namedEntities'] = {};
            for (var _0xdb3c9e = 0x0; _0xdb3c9e < _0x453f7e['entities']['length']; _0xdb3c9e++) {
                var _0x33f58f = _0x453f7e['entities'][_0xdb3c9e];
                this['spawnEntity'](_0x33f58f['type'], _0x33f58f['x'], _0x33f58f['y'], _0x33f58f['settings']);
            }
            this['sortEntities'](), this['collisionMap'] = ig['CollisionMap']['staticNoCollision'], this['backgroundMaps'] = [];
            for (_0xdb3c9e = 0x0; _0xdb3c9e < _0x453f7e['layer']['length']; _0xdb3c9e++)
                if (_0x33f58f = _0x453f7e['layer'][_0xdb3c9e], 'collision' == _0x33f58f['name']) this['collisionMap'] = new ig['CollisionMap'](_0x33f58f['tilesize'], _0x33f58f['data']);
                else {
                    var _0xb63fe9 = new ig['BackgroundMap'](_0x33f58f['tilesize'], _0x33f58f['data'], _0x33f58f['tilesetName']);
                    _0xb63fe9['anims'] = this['backgroundAnims'][_0x33f58f['tilesetName']] || {}, _0xb63fe9['repeat'] = _0x33f58f['repeat'], _0xb63fe9['distance'] = _0x33f58f['distance'], _0xb63fe9['foreground'] = !!_0x33f58f['foreground'], _0xb63fe9['preRender'] = !!_0x33f58f['preRender'], _0xb63fe9['name'] = _0x33f58f['name'], this['backgroundMaps']['push'](_0xb63fe9);
                }
            for (_0xdb3c9e = 0x0; _0xdb3c9e < this['entities']['length']; _0xdb3c9e++) this['entities'][_0xdb3c9e]['ready']();
        },
        'loadLevelDeferred': function(_0x3c8026) {
            this['_levelToLoad'] = _0x3c8026;
        },
        'getMapByName': function(_0x1a76cd) {
            if ('collision' == _0x1a76cd) return this['collisionMap'];
            for (var _0x411066 = 0x0; _0x411066 < this['backgroundMaps']['length']; _0x411066++)
                if (this['backgroundMaps'][_0x411066]['name'] == _0x1a76cd) return this['backgroundMaps'][_0x411066];
            return null;
        },
        'getEntityByName': function(_0x4ab6f7) {
            return this['namedEntities'][_0x4ab6f7];
        },
        'getEntitiesByType': function(_0x10a8c3) {
            _0x10a8c3 = 'string' === typeof _0x10a8c3 ? ig['global'][_0x10a8c3] : _0x10a8c3;
            for (var _0x113ee3 = [], _0x51ec49 = 0x0; _0x51ec49 < this['entities']['length']; _0x51ec49++) {
                var _0x18c9b8 = this['entities'][_0x51ec49];
                _0x18c9b8 instanceof _0x10a8c3 && !_0x18c9b8['_killed'] && _0x113ee3['push'](_0x18c9b8);
            }
            return _0x113ee3;
        },
        'spawnEntity': function(_0x2aeee1, _0x2e15df, _0x505086, _0x4d9407) {
            var _0x1d0346 = 'string' === typeof _0x2aeee1 ? ig['global'][_0x2aeee1] : _0x2aeee1;
            if (!_0x1d0346) throw 'Can\x27t\x20spawn\x20entity\x20of\x20type\x20' + _0x2aeee1;
            return _0x2aeee1 = new _0x1d0346(_0x2e15df, _0x505086, _0x4d9407 || {}), this['entities']['push'](_0x2aeee1), _0x2aeee1['name'] && (this['namedEntities'][_0x2aeee1['name']] = _0x2aeee1), _0x2aeee1;
        },
        'sortEntities': function() {
            this['entities']['sort'](this['sortBy']);
        },
        'sortEntitiesDeferred': function() {
            this['_doSortEntities'] = !0x0;
        },
        'removeEntity': function(_0x9e7e43) {
            _0x9e7e43['name'] && delete this['namedEntities'][_0x9e7e43['name']], _0x9e7e43['_killed'] = !0x0, _0x9e7e43['type'] = ig['Entity']['TYPE']['NONE'], _0x9e7e43['checkAgainst'] = ig['Entity']['TYPE']['NONE'], _0x9e7e43['collides'] = ig['Entity']['COLLIDES']['NEVER'], this['_deferredKill']['push'](_0x9e7e43);
        },
        'run': function() {
            this['update'](), this['draw']();
        },
        'update': function() {
            this['_levelToLoad'] && (this['loadLevel'](this['_levelToLoad']), this['_levelToLoad'] = null), this['updateEntities'](), this['checkEntities']();
            for (var _0x3696d0 = 0x0; _0x3696d0 < this['_deferredKill']['length']; _0x3696d0++) this['_deferredKill'][_0x3696d0]['erase'](), this['entities']['erase'](this['_deferredKill'][_0x3696d0]);
            this['_deferredKill'] = [];
            if (this['_doSortEntities'] || this['autoSort']) this['sortEntities'](), this['_doSortEntities'] = !0x1;
            for (var _0x2ba48b in this['backgroundAnims']) {
                var _0x3696d0 = this['backgroundAnims'][_0x2ba48b],
                    _0x51c4b5;
                for (_0x51c4b5 in _0x3696d0) _0x3696d0[_0x51c4b5]['update']();
            }
        },
        'updateEntities': function() {
            for (var _0x592354 = 0x0; _0x592354 < this['entities']['length']; _0x592354++) {
                var _0x37bdfb = this['entities'][_0x592354];
                _0x37bdfb['_killed'] || _0x37bdfb['update']();
            }
        },
        'draw': function() {
            this['clearColor'] && ig['system']['clear'](this['clearColor']), this['_rscreen']['x'] = ig['system']['getDrawPos'](this['screen']['x']) / ig['system']['scale'], this['_rscreen']['y'] = ig['system']['getDrawPos'](this['screen']['y']) / ig['system']['scale'];
            var _0x46354d;
            for (_0x46354d = 0x0; _0x46354d < this['backgroundMaps']['length']; _0x46354d++) {
                var _0x2a8a75 = this['backgroundMaps'][_0x46354d];
                if (_0x2a8a75['foreground']) break;
                _0x2a8a75['setScreenPos'](this['screen']['x'], this['screen']['y']), _0x2a8a75['draw']();
            }
            this['drawEntities']();
            for (_0x46354d; _0x46354d < this['backgroundMaps']['length']; _0x46354d++) _0x2a8a75 = this['backgroundMaps'][_0x46354d], _0x2a8a75['setScreenPos'](this['screen']['x'], this['screen']['y']), _0x2a8a75['draw']();
        },
        'drawEntities': function() {
            for (var _0x403fdf = 0x0; _0x403fdf < this['entities']['length']; _0x403fdf++) this['entities'][_0x403fdf]['draw']();
        },
        'checkEntities': function() {
            for (var _0x22fc5d = {}, _0x58a5ae = 0x0; _0x58a5ae < this['entities']['length']; _0x58a5ae++) {
                var _0x51eece = this['entities'][_0x58a5ae];
                if (!(_0x51eece['type'] == ig['Entity']['TYPE']['NONE'] && _0x51eece['checkAgainst'] == ig['Entity']['TYPE']['NONE'] && _0x51eece['collides'] == ig['Entity']['COLLIDES']['NEVER'])) {
                    for (var _0x31757a = {}, _0x287383 = Math['floor'](_0x51eece['pos']['y'] / this['cellSize']), _0xa9ddf5 = Math['floor']((_0x51eece['pos']['x'] + _0x51eece['size']['x']) / this['cellSize']) + 0x1, _0x59aef5 = Math['floor']((_0x51eece['pos']['y'] + _0x51eece['size']['y']) / this['cellSize']) + 0x1, _0x1876f5 = Math['floor'](_0x51eece['pos']['x'] / this['cellSize']); _0x1876f5 < _0xa9ddf5; _0x1876f5++)
                        for (var _0x163c0c = _0x287383; _0x163c0c < _0x59aef5; _0x163c0c++)
                            if (_0x22fc5d[_0x1876f5]) {
                                if (_0x22fc5d[_0x1876f5][_0x163c0c]) {
                                    for (var _0x202971 = _0x22fc5d[_0x1876f5][_0x163c0c], _0x47bab6 = 0x0; _0x47bab6 < _0x202971['length']; _0x47bab6++) _0x51eece['touches'](_0x202971[_0x47bab6]) && !_0x31757a[_0x202971[_0x47bab6]['id']] && (_0x31757a[_0x202971[_0x47bab6]['id']] = !0x0, ig['Entity']['checkPair'](_0x51eece, _0x202971[_0x47bab6]));
                                    _0x202971['push'](_0x51eece);
                                } else _0x22fc5d[_0x1876f5][_0x163c0c] = [_0x51eece];
                            } else _0x22fc5d[_0x1876f5] = {}, _0x22fc5d[_0x1876f5][_0x163c0c] = [_0x51eece];
                }
            }
        }
    }), ig['Game']['SORT'] = {
        'Z_INDEX': function(_0x55f14b, _0x4f89c8) {
            return _0x55f14b['zIndex'] - _0x4f89c8['zIndex'];
        },
        'POS_X': function(_0x3b1e24, _0x4f5439) {
            return _0x3b1e24['pos']['x'] + _0x3b1e24['size']['x'] - (_0x4f5439['pos']['x'] + _0x4f5439['size']['x']);
        },
        'POS_Y': function(_0x25a7df, _0x15072c) {
            return _0x25a7df['pos']['y'] + _0x25a7df['size']['y'] - (_0x15072c['pos']['y'] + _0x15072c['size']['y']);
        }
    };
}), ig['baked'] = !0x0, ig['module']('plugins.packer.packer-image-injector')['requires']('impact.image', 'impact.animation')['defines'](function() {
    ig['Image']['inject']({
        'tintCache': {},
        'load': function(_0x318212) {
            ig['packer'] && ig['packer']['isImageInAtlas'](this['path']) ? (this['frameData'] = ig['packer']['getFrameData'](this['path']), this['width'] = this['frameData']['frame']['w'], this['height'] = this['frameData']['frame']['h'], this['loaded'] = ig['packer']['isImageLoadedForPath'](this['path']), _0x318212 && _0x318212(this['path'], !0x0)) : this['parent'](_0x318212);
        },
        'reload': function() {
            ig['packer']['isImageInAtlas'](this['path']) || this['parent']();
        },
        'resize': function(_0x4af712) {
            ig['packer']['isImageInAtlas'](this['path']) ? console['warn']('PACKER\x20PLUGIN\x20WARNING!\x20:\x20image.scale\x20is\x20not\x20supported,\x20\x0aImage\x20path:' + this['path']) : this['parent'](_0x4af712);
        },
        'draw': function(_0x3dd557, _0x2cef28, _0x1b3576, _0x4e0dbd, _0x5c21a6, _0x12a3e4, _0x2b479a, _0x537bf5) {
            if (ig['packer']['isImageInAtlas'](this['path'])) {
                if (!this['atlasImage'] && (this['atlasImage'] = ig['packer']['getAtlasImage'](this['path']), this['frameData'] = ig['packer']['getFrameData'](this['path']), this['width'] = this['frameData']['frame']['w'], this['height'] = this['frameData']['frame']['h'], !this['atlasImage'])) return;
                _0x5c21a6 = _0x5c21a6 ? _0x5c21a6 : this['width'], _0x12a3e4 = _0x12a3e4 ? _0x12a3e4 : this['height'], ig['system']['context']['drawImage'](this['atlasImage'], (_0x1b3576 ? _0x1b3576 : 0x0) + this['frameData']['frame']['x'], (_0x4e0dbd ? _0x4e0dbd : 0x0) + this['frameData']['frame']['y'], _0x5c21a6, _0x12a3e4, ig['system']['getDrawPos'](_0x3dd557), ig['system']['getDrawPos'](_0x2cef28), _0x2b479a ? _0x2b479a : _0x5c21a6, _0x537bf5 ? _0x537bf5 : _0x12a3e4);
            } else _0x5c21a6 = _0x5c21a6 ? _0x5c21a6 : this['width'], _0x12a3e4 = _0x12a3e4 ? _0x12a3e4 : this['height'], ig['system']['context']['drawImage'](this['data'], _0x1b3576 ? _0x1b3576 : 0x0, _0x4e0dbd ? _0x4e0dbd : 0x0, _0x5c21a6, _0x12a3e4, ig['system']['getDrawPos'](_0x3dd557), ig['system']['getDrawPos'](_0x2cef28), _0x2b479a ? _0x2b479a : _0x5c21a6, _0x537bf5 ? _0x537bf5 : _0x12a3e4);
            ig['Image']['drawCount']++;
        },
        'drawImage': function(_0x4858e5, _0x36670e, _0x5218f0, _0x172134, _0x47655c, _0x48a49b, _0x56f66c, _0x85eb7a) {
            _0x4858e5 = _0x4858e5 ? _0x4858e5 : 0x0, _0x36670e = _0x36670e ? _0x36670e : 0x0, 0x2 >= arguments['length'] ? this['draw'](_0x4858e5, _0x36670e) : 0x4 >= arguments['length'] ? (_0x5218f0 = _0x5218f0 ? _0x5218f0 : this['width'], _0x172134 = _0x172134 ? _0x172134 : this['height'], this['draw'](_0x4858e5, _0x36670e, 0x0, 0x0, this['width'], this['height'], _0x5218f0, _0x172134)) : (_0x5218f0 = _0x5218f0 ? _0x5218f0 : this['width'], _0x172134 = _0x172134 ? _0x172134 : this['height'], _0x56f66c = _0x56f66c ? _0x56f66c : this['width'], _0x85eb7a = _0x85eb7a ? _0x85eb7a : this['height'], this['draw'](_0x47655c ? _0x47655c : 0x0, _0x48a49b ? _0x48a49b : 0x0, _0x4858e5, _0x36670e, _0x5218f0, _0x172134, _0x56f66c, _0x85eb7a));
        },
        'drawCtx': function(_0x28f196, _0x42737c, _0x15e22a, _0x3713cd, _0x189175, _0x3ea271, _0x34c9b0, _0x4c3173, _0x2a6e52) {
            if (ig['packer']['isImageInAtlas'](this['path'])) {
                if (!this['atlasImage'] && (this['atlasImage'] = ig['packer']['getAtlasImage'](this['path']), this['frameData'] = ig['packer']['getFrameData'](this['path']), this['width'] = this['frameData']['frame']['w'], this['height'] = this['frameData']['frame']['h'], !this['atlasImage'])) return;
                _0x3ea271 = _0x3ea271 ? _0x3ea271 : this['width'], _0x34c9b0 = _0x34c9b0 ? _0x34c9b0 : this['height'], _0x28f196['drawImage'](this['atlasImage'], (_0x3713cd ? _0x3713cd : 0x0) + this['frameData']['frame']['x'], (_0x189175 ? _0x189175 : 0x0) + this['frameData']['frame']['y'], _0x3ea271, _0x34c9b0, ig['system']['getDrawPos'](_0x42737c), ig['system']['getDrawPos'](_0x15e22a), _0x4c3173 ? _0x4c3173 : _0x3ea271, _0x2a6e52 ? _0x2a6e52 : _0x34c9b0);
            } else _0x3ea271 = _0x3ea271 ? _0x3ea271 : this['width'], _0x34c9b0 = _0x34c9b0 ? _0x34c9b0 : this['height'], _0x28f196['drawImage'](this['data'], _0x3713cd ? _0x3713cd : 0x0, _0x189175 ? _0x189175 : 0x0, _0x3ea271, _0x34c9b0, ig['system']['getDrawPos'](_0x42737c), ig['system']['getDrawPos'](_0x15e22a), _0x4c3173 ? _0x4c3173 : _0x3ea271, _0x2a6e52 ? _0x2a6e52 : _0x34c9b0);
            ig['Image']['drawCount']++;
        },
        'drawImageCtx': function(_0x251da3, _0x4ee1af, _0x4f09aa, _0x683e68, _0x426f61, _0x16620e, _0x424349, _0x43d144, _0x1780f2) {
            _0x4ee1af = _0x4ee1af ? _0x4ee1af : 0x0, _0x4f09aa = _0x4f09aa ? _0x4f09aa : 0x0, 0x2 >= arguments['length'] ? this['drawCtx'](_0x251da3, _0x4ee1af, _0x4f09aa) : 0x5 >= arguments['length'] ? (_0x683e68 = _0x683e68 ? _0x683e68 : this['width'], _0x426f61 = _0x426f61 ? _0x426f61 : this['height'], this['drawCtx'](_0x251da3, _0x4ee1af, _0x4f09aa, 0x0, 0x0, this['width'], this['height'], _0x683e68, _0x426f61)) : (_0x683e68 = _0x683e68 ? _0x683e68 : this['width'], _0x426f61 = _0x426f61 ? _0x426f61 : this['height'], _0x43d144 = _0x43d144 ? _0x43d144 : this['width'], _0x1780f2 = _0x1780f2 ? _0x1780f2 : this['height'], this['drawCtx'](_0x251da3, _0x16620e ? _0x16620e : 0x0, _0x424349 ? _0x424349 : 0x0, _0x4ee1af, _0x4f09aa, _0x683e68, _0x426f61, _0x43d144, _0x1780f2));
        },
        'drawTile': function(_0x38a99f, _0x23dc93, _0x3187fd, _0x2f59bd, _0x2568d2, _0x355920, _0xae8bd) {
            if (ig['packer']['isImageInAtlas'](this['path'])) {
                if (this['atlasImage'] || !(this['atlasImage'] = ig['packer']['getAtlasImage'](this['path']), this['frameData'] = ig['packer']['getFrameData'](this['path']), this['width'] = this['frameData']['frame']['w'], this['height'] = this['frameData']['frame']['h'], !this['atlasImage'])) {
                    _0x2568d2 = _0x2568d2 ? _0x2568d2 : _0x2f59bd;
                    var _0x40ab5b = Math['floor'](_0x2f59bd),
                        _0x11df01 = Math['floor'](_0x2568d2),
                        _0x3ea365 = _0x355920 ? -0x1 : 0x1,
                        _0x4b88c5 = _0xae8bd ? -0x1 : 0x1;
                    if (_0x355920 || _0xae8bd) ig['system']['context']['save'](), ig['system']['context']['scale'](_0x3ea365, _0x4b88c5);
                    ig['system']['context']['drawImage'](this['atlasImage'], Math['floor'](_0x3187fd * _0x2f59bd) % this['width'] + this['frameData']['frame']['x'], Math['floor'](_0x3187fd * _0x2f59bd / this['width']) * _0x2568d2 + this['frameData']['frame']['y'], _0x40ab5b, _0x11df01, ig['system']['getDrawPos'](_0x38a99f) * _0x3ea365 - (_0x355920 ? _0x40ab5b : 0x0), ig['system']['getDrawPos'](_0x23dc93) * _0x4b88c5 - (_0xae8bd ? _0x11df01 : 0x0), _0x40ab5b, _0x11df01), (_0x355920 || _0xae8bd) && ig['system']['context']['restore'](), ig['Image']['drawCount']++;
                }
            } else this['parent'](_0x38a99f, _0x23dc93, _0x3187fd, _0x2f59bd, _0x2568d2, _0x355920, _0xae8bd);
        },
        'drawTileTint': function(_0x400a85, _0x27e70c, _0x485e78, _0x23898e, _0x16937c, _0x328f9a, _0x51d3b3, _0x561b70) {
            if (_0x400a85 = this['getTintedImageCanvas'](_0x400a85)) {
                if (_0x328f9a = _0x328f9a ? _0x328f9a : _0x16937c, this['loaded'] && !(_0x16937c > this['width'] || _0x328f9a > this['height'])) {
                    var _0x25c03f = ig['system']['scale'],
                        _0x3e84dc = Math['floor'](_0x16937c * _0x25c03f),
                        _0x472686 = Math['floor'](_0x328f9a * _0x25c03f),
                        _0x3aff17 = _0x51d3b3 ? -0x1 : 0x1,
                        _0x2b7ea7 = _0x561b70 ? -0x1 : 0x1;
                    if (_0x51d3b3 || _0x561b70) ig['system']['context']['save'](), ig['system']['context']['scale'](_0x3aff17, _0x2b7ea7);
                    ig['system']['context']['drawImage'](_0x400a85, Math['floor'](_0x23898e * _0x16937c) % this['width'] * _0x25c03f, Math['floor'](_0x23898e * _0x16937c / this['width']) * _0x328f9a * _0x25c03f, _0x3e84dc, _0x472686, ig['system']['getDrawPos'](_0x27e70c) * _0x3aff17 - (_0x51d3b3 ? _0x3e84dc : 0x0), ig['system']['getDrawPos'](_0x485e78) * _0x2b7ea7 - (_0x561b70 ? _0x472686 : 0x0), _0x3e84dc, _0x472686), (_0x51d3b3 || _0x561b70) && ig['system']['context']['restore'](), ig['Image']['drawCount']++;
                }
            }
        },
        'drawTint': function(_0x3482ca, _0x43a57c, _0x2add84, _0x288758, _0x3d0cc9, _0x2b4334, _0x5a1362, _0x36f85a, _0x1ed51d) {
            if (_0x3482ca = this['getTintedImageCanvas'](_0x3482ca)) _0x2b4334 = _0x2b4334 ? _0x2b4334 : this['width'], _0x5a1362 = _0x5a1362 ? _0x5a1362 : this['height'], ig['system']['context']['drawImage'](_0x3482ca, _0x288758 ? _0x288758 : 0x0, _0x3d0cc9 ? _0x3d0cc9 : 0x0, _0x2b4334, _0x5a1362, ig['system']['getDrawPos'](_0x43a57c), ig['system']['getDrawPos'](_0x2add84), _0x36f85a ? _0x36f85a : _0x2b4334, _0x1ed51d ? _0x1ed51d : _0x5a1362), ig['Image']['drawCount']++;
        },
        'getTintedImageCanvas': function(_0x133980) {
            if (!this['tintCache'][_0x133980]) {
                if (ig['packer']['isImageInAtlas'](this['path']) && !this['atlasImage'] && (this['atlasImage'] = ig['packer']['getAtlasImage'](this['path']), this['frameData'] = ig['packer']['getFrameData'](this['path']), this['width'] = this['frameData']['frame']['w'], this['height'] = this['frameData']['frame']['h'], !this['atlasImage'])) return;
                var _0x2141a5 = ig['$new']('canvas');
                _0x2141a5['width'] = this['width'], _0x2141a5['height'] = this['height'], this['atlasImage'] ? _0x2141a5['getContext']('2d')['drawImage'](this['atlasImage'], this['frameData']['frame']['x'], this['frameData']['frame']['y'], this['width'], this['height'], 0x0, 0x0, this['width'], this['height']) : _0x2141a5['getContext']('2d')['drawImage'](this['data'], 0x0, 0x0, this['width'], this['height'], 0x0, 0x0, this['width'], this['height']);
                for (var _0x1c0fa1 = _0x2141a5['getContext']('2d'), _0x3cd644 = _0x1c0fa1['getImageData'](0x0, 0x0, this['width'], this['height']), _0x21d2d8 = _0x3cd644['data'], _0x24c2d9, _0x21f0cb = _0x21d2d8['length'], _0x384ab2, _0x52a2a0, _0x12f11c, _0x17057c, _0x464bd4 = parseInt(_0x133980['substr'](0x1, 0x2), 0x10) / 0xff, _0x99f1c6 = parseInt(_0x133980['substr'](0x3, 0x2), 0x10) / 0xff, _0x514039 = parseInt(_0x133980['substr'](0x5, 0x2), 0x10) / 0xff, _0x7f8d69 = 0x0; _0x7f8d69 < _0x21f0cb; _0x7f8d69 += 0x4) _0x24c2d9 = _0x21d2d8[_0x7f8d69 + 0x3] / 0xff, _0x17057c = _0x24c2d9 + 0x1 - 0x1 * _0x24c2d9, _0x384ab2 = _0x21d2d8[_0x7f8d69] / 0xff * _0x24c2d9, _0x52a2a0 = _0x21d2d8[_0x7f8d69 + 0x1] / 0xff * _0x24c2d9, _0x12f11c = _0x21d2d8[_0x7f8d69 + 0x2] / 0xff * _0x24c2d9, _0x17057c = 0xff / _0x17057c, _0x21d2d8[_0x7f8d69] = (_0x384ab2 * _0x464bd4 + _0x464bd4 * (0x1 - _0x24c2d9)) * _0x17057c, _0x21d2d8[_0x7f8d69 + 0x1] = (_0x52a2a0 * _0x99f1c6 + _0x99f1c6 * (0x1 - _0x24c2d9)) * _0x17057c, _0x21d2d8[_0x7f8d69 + 0x2] = (_0x12f11c * _0x514039 + _0x514039 * (0x1 - _0x24c2d9)) * _0x17057c;
                _0x1c0fa1['putImageData'](_0x3cd644, 0x0, 0x0), this['tintCache'][_0x133980] = _0x2141a5;
            }
            return this['tintCache'][_0x133980];
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.packer.packer-animation-injector')['requires']('impact.image', 'impact.animation')['defines'](function() {
    ig['Animation']['inject']({
        'tint': null,
        'draw': function(_0x324cee, _0x4adc8d) {
            if (this['tint']) {
                var _0x44524f = Math['max'](this['sheet']['width'], this['sheet']['height']);
                _0x324cee > ig['system']['width'] || _0x4adc8d > ig['system']['height'] || (0x0 > _0x324cee + _0x44524f || 0x0 > _0x4adc8d + _0x44524f) || (0x1 != this['alpha'] && (ig['system']['context']['globalAlpha'] = this['alpha']), 0x0 == this['angle'] ? this['sheet']['image']['drawTileTint'](this['tint'], _0x324cee, _0x4adc8d, this['tile'], this['sheet']['width'], this['sheet']['height'], this['flip']['x'], this['flip']['y']) : (ig['system']['context']['save'](), ig['system']['context']['translate'](ig['system']['getDrawPos'](_0x324cee + this['pivot']['x']), ig['system']['getDrawPos'](_0x4adc8d + this['pivot']['y'])), ig['system']['context']['rotate'](this['angle']), this['sheet']['image']['drawTileTint'](this['tint'], -this['pivot']['x'], -this['pivot']['y'], this['tile'], this['sheet']['width'], this['sheet']['height'], this['flip']['x'], this['flip']['y']), ig['system']['context']['restore']()), 0x1 != this['alpha'] && (ig['system']['context']['globalAlpha'] = 0x1));
            } else this['parent'](_0x324cee, _0x4adc8d);
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.packer.packer-plugin')['requires']('plugins.packer.packer-image-injector', 'plugins.packer.packer-animation-injector')['defines'](function() {
    ig['AtlasImage'] = ig['Class']['extend']({
        'init': function(_0x24e359) {
            this['path'] = _0x24e359;
        },
        'load': function(_0x21b49c) {
            this['loadCallback'] = _0x21b49c || null, this['data'] = new Image(), this['data']['onload'] = this['onload']['bind'](this), this['data']['onerror'] = this['onerror']['bind'](this), this['data']['src'] = ig['prefix'] + this['path'] + ig['nocache'];
        },
        'onload': function() {
            this['loaded'] = !0x0, ig['packer']['refreshImageLoadedStatus'](), this['loadCallback'] && this['loadCallback'](this['path'], !0x0);
        },
        'onerror': function() {
            this['error'] = !0x0, this['loadCallback'] && this['loadCallback'](this['path'], !0x1);
        }
    }), ig['packer'] = {
        'textureJson': [],
        'textureAtlas': [],
        'jsonLoadStatus': [],
        'atlasLoadStatus': [],
        'textureExistStatus': [],
        'pathMap': {},
        'initCallback': null,
        'initPacker': function(_0x58898d) {
            if (window['packerplugin'] && 0x0 < packerplugin['textures']['length']) {
                console['log']('Packer\x20Plugin\x201.1.6\x20is\x20enabled,\x20loading\x20' + packerplugin['textures']['length'] + '\x20texture\x20atlases...'), ig['packer']['initCallback'] = _0x58898d;
                for (_0x58898d = 0x0; _0x58898d < packerplugin['textures']['length']; _0x58898d++) this['textureExistStatus']['push'](0x1);
                this['loadAllJson']();
            } else console['log']('Packer\x20Plugin\x201.1.6\x20is\x20disabled,\x20loading\x20individual\x20images...'), _0x58898d();
        },
        'loadAllJson': function() {
            for (var _0x32d5b8 = 0x0; _0x32d5b8 < ig['packer']['textureExistStatus']['length']; _0x32d5b8++) 0x1 == ig['packer']['textureExistStatus'][_0x32d5b8] && (ig['packer']['textureJson']['push'](null), ig['packer']['textureAtlas']['push'](null), ig['packer']['jsonLoadStatus']['push'](0x1), ig['packer']['atlasLoadStatus']['push'](0x0), ig['packer']['textureJson'][_0x32d5b8] = JSON['parse'](window['packerplugin']['json'][packerplugin['textures'][_0x32d5b8]]));
            ig['packer']['onLoadJsonComplete']();
        },
        'onLoadJsonComplete': function() {
            for (var _0x2d5678 = 0x0; _0x2d5678 < ig['packer']['textureJson']['length']; _0x2d5678++) {
                var _0x25a82b = ig['packer']['textureJson'][_0x2d5678],
                    _0x23fd04;
                for (_0x23fd04 in _0x25a82b['frames']) ig['packer']['pathMap'][_0x23fd04] = {
                    'path': _0x23fd04,
                    'textureIndex': _0x2d5678
                };
                _0x25a82b = 'media/graphics/packed/' + packerplugin['textures'][_0x2d5678] + '.png', 0x0 <= packerplugin['textures'][_0x2d5678]['indexOf']('big-jpg') && (_0x25a82b = 'media/graphics/packed/' + packerplugin['textures'][_0x2d5678] + '.jpg'), _0x25a82b = new ig['AtlasImage'](_0x25a82b), ig['packer']['textureAtlas'][_0x2d5678] = _0x25a82b, ig['addResource'](_0x25a82b);
            }
            ig['packer']['initCallback']();
        },
        'isImageInAtlas': function(_0xa45dc3) {
            return Object['hasOwnProperty']['call'](ig['packer']['pathMap'], _0xa45dc3) ? !0x0 : !0x1;
        },
        'refreshImageLoadedStatus': function() {
            for (var _0x52e941 in ig['Image']['cache'])
                if (Object['hasOwnProperty']['call'](ig['Image']['cache'], _0x52e941)) {
                    var _0x539509 = ig['Image']['cache'][_0x52e941];
                    ig['packer']['isImageInAtlas'](_0x539509['path']) && (_0x539509['loaded'] = ig['packer']['isImageLoadedForPath'](_0x539509['path']));
                }
        },
        'isImageLoadedForPath': function(_0x268f15) {
            return ig['packer']['textureAtlas'][ig['packer']['pathMap'][_0x268f15]['textureIndex']]['loaded'] ? !0x0 : !0x1;
        },
        'getAtlasImage': function(_0x20a89d) {
            return _0x20a89d = ig['packer']['pathMap'][_0x20a89d]['textureIndex'], !ig['packer']['textureAtlas'][_0x20a89d]['loaded'] ? null : ig['packer']['textureAtlas'][_0x20a89d]['data'];
        },
        'getFrameData': function(_0x4b53f8) {
            return ig['packer']['textureJson'][ig['packer']['pathMap'][_0x4b53f8]['textureIndex']]['frames'][_0x4b53f8];
        }
    };
}), ig['baked'] = !0x0, ig['module']('plugins.patches.fps-limit-patch')['requires']('impact.impact')['defines'](function() {
    ig['normalizeVendorAttribute'](window, 'requestAnimationFrame');
    if (window['requestAnimationFrame']) {
        var _0x4af79a = 0x1,
            _0x343348 = {};
        window['ig']['setAnimation'] = function(_0x11a4b8) {
            var _0x242a99 = _0x4af79a++;
            _0x343348[_0x242a99] = !0x0;
            var _0xbcd66d = ig['system']['fps'] || 0x3c;
            performance['now']();
            var _0x5e57aa = function(_0x3e8190) {
                if (_0x343348[_0x242a99]) {
                    window['requestAnimationFrame'](_0x5e57aa);
                    for (_0x11a4b8(); performance['now']() - _0x3e8190 < 0x3e8 / _0xbcd66d;);
                }
            };
            return window['requestAnimationFrame'](_0x5e57aa), _0x242a99;
        }, window['ig']['clearAnimation'] = function(_0x27ac07) {
            delete _0x343348[_0x27ac07];
        };
    }
}), ig['baked'] = !0x0, ig['module']('plugins.patches.timer-patch')['requires']('impact.timer')['defines'](function() {
    ig['Timer']['step'] = function() {
        var _0x257c68 = Date['now'](),
            _0x56026c = (_0x257c68 - ig['Timer']['_last']) / 0x3e8;
        0x0 > _0x56026c && (_0x56026c = 0x0), ig['Timer']['time'] += Math['min'](_0x56026c, ig['Timer']['maxStep']) * ig['Timer']['timeScale'], ig['Timer']['_last'] = _0x257c68;
    };
}), ig['baked'] = !0x0, ig['module']('plugins.patches.user-agent-patch')['defines'](function() {
    ig['ua']['touchDevice'] = 'ontouchstart' in window || window['navigator']['msMaxTouchPoints'] || window['navigator']['maxTouchPoints'], ig['ua']['is_mac'] = 'MacIntel' === navigator['platform'], ig['ua']['iOS'] = ig['ua']['touchDevice'] && ig['ua']['is_mac'] || ig['ua']['iOS'], ig['ua']['mobile'] = ig['ua']['iOS'] || ig['ua']['mobile'];
}), ig['baked'] = !0x0, ig['module']('plugins.patches.webkit-image-smoothing-patch')['defines'](function() {
    ig['System'] && (ig['System']['SCALE'] = {
        'CRISP': function(_0x16e03d, _0x49c147) {
            _0x49c147['imageSmoothingEnabled'] = _0x49c147['msImageSmoothingEnabled'] = _0x49c147['mozImageSmoothingEnabled'] = _0x49c147['oImageSmoothingEnabled'] = !0x1, _0x16e03d['style']['imageRendering'] = '-moz-crisp-edges', _0x16e03d['style']['imageRendering'] = '-o-crisp-edges', _0x16e03d['style']['imageRendering'] = '-webkit-optimize-contrast', _0x16e03d['style']['imageRendering'] = 'crisp-edges', _0x16e03d['style']['msInterpolationMode'] = 'nearest-neighbor';
        },
        'SMOOTH': function(_0x37ee5a, _0x14ab1e) {
            _0x14ab1e['imageSmoothingEnabled'] = _0x14ab1e['msImageSmoothingEnabled'] = _0x14ab1e['mozImageSmoothingEnabled'] = _0x14ab1e['oImageSmoothingEnabled'] = !0x0, _0x37ee5a['style']['imageRendering'] = '', _0x37ee5a['style']['msInterpolationMode'] = '';
        }
    }, ig['System']['scaleMode'] = ig['System']['SCALE']['SMOOTH']);
}), ig['baked'] = !0x0, ig['module']('plugins.patches.windowfocus-onMouseDown-patch')['requires']('impact.input')['defines'](function() {
    var _0x46977d = !0x1;
    try {
        _0x46977d = window['self'] !== window['top'], !0x1 === _0x46977d && (_0x46977d = 0x0 < window['frames']['length']);
    } catch (_0x1a59c9) {
        _0x46977d = !0x0;
    }
    ig['Input']['inject']({
        'keydown': function(_0x2442c0) {
            var _0x175346 = _0x2442c0['target']['tagName'];
            if (!('INPUT' == _0x175346 || 'TEXTAREA' == _0x175346)) {
                if (_0x175346 = 'keydown' == _0x2442c0['type'] ? _0x2442c0['keyCode'] : 0x2 == _0x2442c0['button'] ? ig['KEY']['MOUSE2'] : ig['KEY']['MOUSE1'], _0x46977d && 0x0 > _0x175346 && window['focus'](), ('touchstart' == _0x2442c0['type'] || 'mousedown' == _0x2442c0['type']) && this['mousemove'](_0x2442c0), _0x175346 = this['bindings'][_0x175346]) this['actions'][_0x175346] = !0x0, this['locks'][_0x175346] || (this['presses'][_0x175346] = !0x0, this['locks'][_0x175346] = !0x0), _0x2442c0['stopPropagation'](), _0x2442c0['preventDefault']();
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.patches.input-patch')['requires']('impact.input')['defines'](function() {
    ig['Input']['inject']({
        'initMouse': function() {
            this['parent'](), ig['system']['canvas']['addEventListener']('mouseleave', this['mouseleave']['bind'](this), !0x1);
        },
        'mousemove': function(_0x362d5a) {
            this['parent'](_0x362d5a);
            try {
                ig['soundHandler']['unlockWebAudio']();
            } catch (_0x109723) {}
        },
        'mouseleave': function() {
            this['clearState']('click');
        },
        'keyup': function(_0x8f3029) {
            this['parent'](_0x8f3029);
            if (ig['visibilityHandler']) ig['visibilityHandler']['onChange']('focus');
            try {
                ig['soundHandler']['unlockWebAudio']();
            } catch (_0x8d7c70) {}
        },
        'clearState': function(_0x3744aa) {
            this['actions'][_0x3744aa] = !0x1;
        },
        'clearAllState': function() {
            for (var _0x16b095 in this['actions']) this['clearState'](_0x16b095);
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.data.vector')['defines'](function() {
    Vector2 = function(_0x207168, _0x1fa9e8) {
        this['x'] = _0x207168 || 0x0, this['y'] = _0x1fa9e8 || 0x0;
    }, Vector2['prototype'] = {
        'valType': 'number',
        'neg': function() {
            return this['x'] = -this['x'], this['y'] = -this['y'], this;
        },
        'row': function(_0x1852f2) {
            return typeof _0x1852f2 === this['valType'] && (this['y'] = _0x1852f2), this['y'];
        },
        'col': function(_0x53003d) {
            return typeof _0x53003d === this['valType'] && (this['x'] = _0x53003d), this['x'];
        },
        'add': function(_0x1846d0) {
            return _0x1846d0 instanceof Vector2 ? (this['x'] += _0x1846d0['x'], this['y'] += _0x1846d0['y']) : (this['x'] += _0x1846d0, this['y'] += _0x1846d0), this;
        },
        'sub': function(_0x1c17e8) {
            return _0x1c17e8 instanceof Vector2 ? (this['x'] -= _0x1c17e8['x'], this['y'] -= _0x1c17e8['y']) : (this['x'] -= _0x1c17e8, this['y'] -= _0x1c17e8), this;
        },
        'mul': function(_0x25b7b5) {
            return _0x25b7b5 instanceof Vector2 ? (this['x'] *= _0x25b7b5['x'], this['y'] *= _0x25b7b5['y']) : (this['x'] *= _0x25b7b5, this['y'] *= _0x25b7b5), this;
        },
        'div': function(_0x15abb5) {
            return _0x15abb5 instanceof Vector2 ? (0x0 != _0x15abb5['x'] && (this['x'] /= _0x15abb5['x']), 0x0 != _0x15abb5['y'] && (this['y'] /= _0x15abb5['y'])) : 0x0 != _0x15abb5 && (this['x'] /= _0x15abb5, this['y'] /= _0x15abb5), this;
        },
        'equals': function(_0x17cfca) {
            return this['x'] == _0x17cfca['x'] && this['y'] == _0x17cfca['y'];
        },
        'dot': function(_0x5f16a8) {
            return this['x'] * _0x5f16a8['x'] + this['y'] * _0x5f16a8['y'];
        },
        'cross': function(_0x28e5c1) {
            return this['x'] * _0x28e5c1['y'] - this['y'] * _0x28e5c1['x'];
        },
        'length': function() {
            return Math['sqrt'](this['dot'](this));
        },
        'norm': function() {
            return this['divide'](this['length']());
        },
        'min': function() {
            return Math['min'](this['x'], this['y']);
        },
        'max': function() {
            return Math['max'](this['x'], this['y']);
        },
        'toAngles': function() {
            return -Math['atan2'](-this['y'], this['x']);
        },
        'angleTo': function(_0x5bcac7) {
            return Math['acos'](this['dot'](_0x5bcac7) / (this['length']() * _0x5bcac7['length']()));
        },
        'toArray': function(_0x157530) {
            return [this['x'], this['y']]['slice'](0x0, _0x157530 || 0x2);
        },
        'clone': function() {
            return new Vector2(this['x'], this['y']);
        },
        'set': function(_0x2d87ba, _0x16d0c2) {
            return this['x'] = _0x2d87ba, this['y'] = _0x16d0c2, this;
        },
        'unit': function() {
            var _0x5cd82f = this['length']();
            if (0x0 < _0x5cd82f) return new Vector2(this['x'] / _0x5cd82f, this['y'] / _0x5cd82f);
            throw 'Divide\x20by\x200\x20error\x20in\x20unitVector\x20function\x20of\x20vector:' + this;
        },
        'turnRight': function() {
            var _0x39f249 = this['x'];
            return this['x'] = -this['y'], this['y'] = _0x39f249, this;
        },
        'turnLeft': function() {
            var _0x359786 = this['x'];
            return this['x'] = this['y'], this['y'] = -_0x359786, this;
        },
        'rotate': function(_0x1693b5) {
            var _0x2ed881 = this['clone']();
            return this['x'] = _0x2ed881['x'] * Math['cos'](_0x1693b5) - _0x2ed881['y'] * Math['sin'](_0x1693b5), this['y'] = _0x2ed881['x'] * Math['sin'](_0x1693b5) + _0x2ed881['y'] * Math['cos'](_0x1693b5), this;
        }
    }, Vector2['negative'] = function(_0x34bd43) {
        return new Vector2(-_0x34bd43['x'], -_0x34bd43['y']);
    }, Vector2['add'] = function(_0x1f3e14, _0xba010c) {
        return _0xba010c instanceof Vector2 ? new Vector2(_0x1f3e14['x'] + _0xba010c['x'], _0x1f3e14['y'] + _0xba010c['y']) : new Vector2(_0x1f3e14['x'] + v, _0x1f3e14['y'] + v);
    }, Vector2['subtract'] = function(_0x5aab78, _0x34ea0c) {
        return _0x34ea0c instanceof Vector2 ? new Vector2(_0x5aab78['x'] - _0x34ea0c['x'], _0x5aab78['y'] - _0x34ea0c['y']) : new Vector2(_0x5aab78['x'] - v, _0x5aab78['y'] - v);
    }, Vector2['multiply'] = function(_0x4168d5, _0xedafdb) {
        return _0xedafdb instanceof Vector2 ? new Vector2(_0x4168d5['x'] * _0xedafdb['x'], _0x4168d5['y'] * _0xedafdb['y']) : new Vector2(_0x4168d5['x'] * v, _0x4168d5['y'] * v);
    }, Vector2['divide'] = function(_0x2c0af7, _0x13732e) {
        return _0x13732e instanceof Vector2 ? new Vector2(_0x2c0af7['x'] / _0x13732e['x'], _0x2c0af7['y'] / _0x13732e['y']) : new Vector2(_0x2c0af7['x'] / v, _0x2c0af7['y'] / v);
    }, Vector2['equals'] = function(_0xda7684, _0x5c4bf3) {
        return _0xda7684['x'] == _0x5c4bf3['x'] && _0xda7684['y'] == _0x5c4bf3['y'];
    }, Vector2['dot'] = function(_0x322362, _0x347d92) {
        return _0x322362['x'] * _0x347d92['x'] + _0x322362['y'] * _0x347d92['y'];
    }, Vector2['cross'] = function(_0x3c3d74, _0x258703) {
        return _0x3c3d74['x'] * _0x258703['y'] - _0x3c3d74['y'] * _0x258703['x'];
    };
}), ig['baked'] = !0x0, ig['module']('plugins.data.color-rgb')['defines'](function() {
    ColorRGB = function(_0x1a46cd, _0x2aba97, _0x436e4e, _0xe1a7f8) {
        this['r'] = _0x1a46cd || 0x0, this['g'] = _0x2aba97 || 0x0, this['b'] = _0x436e4e || 0x0, this['a'] = _0xe1a7f8 || 0x0;
    }, ColorRGB['prototype'] = {
        'setRandomColor': function() {
            this['r'] = Math['round'](0xff * Math['random']()), this['g'] = Math['round'](0xff * Math['random']()), this['b'] = Math['round'](0xff * Math['random']());
        },
        'getStyle': function() {
            return 'rgba(' + this['r'] + ',' + this['g'] + ',' + this['b'] + ',' + this['a'] + ')';
        },
        'getHex': function() {
            for (var _0x164006 = this['r']['toString'](0x10), _0x3ec3e3 = this['g']['toString'](0x10), _0x17d3d9 = this['b']['toString'](0x10); 0x2 > _0x164006['length'];) _0x164006 = '0' + _0x164006;
            for (; 0x2 > _0x3ec3e3['length'];) _0x3ec3e3 = '0' + _0x3ec3e3;
            for (; 0x2 > _0x17d3d9['length'];) _0x17d3d9 = '0' + _0x17d3d9;
            return '#' + _0x164006 + _0x3ec3e3 + _0x17d3d9;
        },
        'getInvertedColor': function() {
            return new ColorRGB(0xff - this['r'], 0xff - this['g'], 0xff - this['b'], 0xff - this['a']);
        },
        'clone': function() {
            return new ColorRGB(this['r'], this['g'], this['b'], this['a']);
        }
    };
}), ig['baked'] = !0x0, ig['module']('plugins.font.font-info')['requires']('impact.impact')['defines'](function() {
    ig['FontInfo'] = ig['Class']['extend']({
        'fonts': [{
            'name': 'luckiest-guy',
            'source': 'media/fonts/luckiest-guy'
        }],
        'init': function() {
            this['registerCssFont']();
        },
        'registerCssFont': function() {
            if (0x0 < this['fonts']['length']) {
                var _0x15e166 = document['createElement']('style');
                _0x15e166['type'] = 'text/css';
                for (var _0x1250b6 = '', _0x3af96c = 0x0; _0x3af96c < this['fonts']['length']; _0x3af96c++) var _0x2c02bb = this['fonts'][_0x3af96c],
                    _0x1250b6 = _0x1250b6 + ('@font-face\x20{font-family:\x20\x27' + _0x2c02bb['name'] + '\x27;src:\x20url(\x27' + _0x2c02bb['source'] + '.eot\x27);src:\x20url(\x27' + _0x2c02bb['source'] + '.eot?#iefix\x27)\x20format(\x27embedded-opentype\x27),url(\x27' + _0x2c02bb['source'] + '.woff2\x27)\x20format(\x27woff2\x27),url(\x27' + _0x2c02bb['source'] + '.woff\x27)\x20format(\x27woff\x27),url(\x27' + _0x2c02bb['source'] + '.ttf\x27)\x20format(\x27truetype\x27),url(\x27' + _0x2c02bb['source'] + '.svg#svgFontName\x27)\x20format(\x27svg\x27)}');
                _0x15e166['appendChild'](document['createTextNode'](_0x1250b6)), document['head']['appendChild'](_0x15e166);
            }
        },
        'isValid': function() {
            for (var _0x1de9e3 = 0x0; _0x1de9e3 < this['fonts']['length']; _0x1de9e3++)
                if (!this['_isValidName'](this['fonts'][_0x1de9e3]['source'])) return !0x1;
            return !0x0;
        },
        '_isValidName': function(_0x5d8311) {
            return -0x1 == _0x5d8311['search'](/^[a-z0-9-\/]+$/) ? !0x1 : !0x0;
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.font.font-loader')['requires']('impact.impact', 'plugins.font.font-info', 'impact.loader')['defines'](function() {
    ig['FontLoader'] = ig['Class']['extend']({
        'fontInfo': new ig['FontInfo'](),
        'onload': !0x1,
        'onerror': !0x1,
        'init': function(_0x5ec592, _0x36ea54) {
            this['onload'] = _0x5ec592, this['onerror'] = _0x36ea54;
        },
        'load': function() {
            this['fontInfo']['isValid']() ? this['_loadByLib']() : console['error']('Only\x20lowercased\x20alphanumeric\x20and\x20dash\x20are\x20allowed\x20for\x20font\x20file\x20name!.\x20Please\x20check\x20the\x20font\x20path');
        },
        '_loadByLib': function() {
            for (var _0xc63cd1 = [], _0x3f8cf1 = 0x0; _0x3f8cf1 < this['fontInfo']['fonts']['length']; _0x3f8cf1++) {
                var _0x171c1e = new FontFaceObserver(this['fontInfo']['fonts'][_0x3f8cf1]['name']);
                _0xc63cd1['push'](_0x171c1e['load']());
            }
            Promise['all'](_0xc63cd1)['then'](this['onload'])['catch'](this['onerror']);
        }
    }), ig['Loader']['inject']({
        'parentLoad': !0x1,
        'load': function() {
            this['parentLoad'] = this['parent'], new ig['FontLoader'](this['onFontLoad']['bind'](this), this['onFontError']['bind'](this))['load']();
        },
        'onFontLoad': function() {
            this['parentLoad']();
        },
        'onFontError': function() {
            console['error']('Font\x20is\x20not\x20loaded'), this['parentLoad']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.handlers.dom-handler')['defines'](function() {
    ig['DomHandler'] = ig['Class']['extend']({
        'JQUERYAVAILABLE': !0x1,
        'init': function() {
            this['JQUERYAVAILABLE'] = this['_jqueryAvailable']();
        },
        '_jqueryAvailable': function() {
            return 'undefined' !== typeof jQuery;
        },
        'addEvent': function(_0x3dbac7, _0x256aba, _0xb00401, _0xe16807) {
            if (this['JQUERYAVAILABLE']) _0x3dbac7['on'](_0x256aba, _0xb00401);
            else _0x3dbac7['addEventListener'](_0x256aba, _0xb00401, _0xe16807);
        },
        'create': function(_0x25d6e6) {
            return this['JQUERYAVAILABLE'] ? $('<' + _0x25d6e6 + '>') : ig['$new'](_0x25d6e6);
        },
        'getElementByClass': function(_0x5d2b3a) {
            return this['JQUERYAVAILABLE'] ? $('.' + _0x5d2b3a) : document['getElementsByClassName'](_0x5d2b3a);
        },
        'getElementById': function(_0x5e6033) {
            return this['JQUERYAVAILABLE'] ? 0x0 < $(_0x5e6033)['length'] ? $(_0x5e6033) : null : ig['$'](_0x5e6033);
        },
        'appendChild': function(_0x2b194, _0x1d246a) {
            this['JQUERYAVAILABLE'] ? _0x2b194['append'](_0x1d246a) : _0x2b194['appendChild'](_0x1d246a);
        },
        'appendToBody': function(_0x2c51d4) {
            this['JQUERYAVAILABLE'] ? $('body')['append'](_0x2c51d4) : document['body']['appendChild'](_0x2c51d4);
        },
        'resize': function(_0x59e1f3, _0x45c409, _0x14b41b) {
            if (this['JQUERYAVAILABLE']) _0x59e1f3['width'](_0x45c409['toFixed'](0x2)), _0x59e1f3['height'](_0x14b41b['toFixed'](0x2));
            else {
                var _0x3392f5 = _0x59e1f3['style']['visibility'];
                _0x45c409 = 'width:' + _0x45c409['toFixed'](0x2) + 'px;\x20height:' + _0x14b41b['toFixed'](0x2) + 'px;', this['attr'](_0x59e1f3, 'style', _0x45c409), _0x59e1f3['style']['visibility'] = _0x3392f5;
            }
        },
        'resizeOffsetLeft': function(_0x3dc923, _0xf0edb8, _0x5168b5, _0x34bd10) {
            if (this['JQUERYAVAILABLE']) _0x3dc923['width'](_0xf0edb8['toFixed'](0x2)), _0x3dc923['height'](_0x5168b5['toFixed'](0x2)), _0x3dc923['css']('left', _0x34bd10);
            else {
                var _0x23df75 = _0x3dc923['style']['visibility'];
                _0xf0edb8 = 'width:' + _0xf0edb8['toFixed'](0x2) + 'px;\x20height:' + _0x5168b5['toFixed'](0x2) + 'px;\x20left:\x20' + _0x34bd10['toFixed'](0x2) + 'px;', this['attr'](_0x3dc923, 'style', _0xf0edb8), _0x3dc923['style']['visibility'] = _0x23df75;
            }
        },
        'resizeOffset': function(_0x2f4571, _0x11e991, _0x2839ad, _0xbb2fc9, _0x2a3f84) {
            if (this['JQUERYAVAILABLE']) _0x2f4571['width'](_0x11e991['toFixed'](0x2)), _0x2f4571['height'](_0x2839ad['toFixed'](0x2)), _0x2f4571['css']('left', _0xbb2fc9), _0x2f4571['css']('top', _0x2a3f84);
            else {
                var _0x1e4f5b = _0x2f4571['style']['visibility'];
                _0x11e991 = 'width:' + _0x11e991['toFixed'](0x2) + 'px;\x20height:' + _0x2839ad['toFixed'](0x2) + 'px;\x20left:\x20' + _0xbb2fc9['toFixed'](0x2) + 'px;\x20top:\x20' + _0x2a3f84['toFixed'](0x2) + 'px;', this['attr'](_0x2f4571, 'style', _0x11e991), _0x2f4571['style']['visibility'] = _0x1e4f5b;
            }
        },
        'css': function(_0x372b67, _0x381899) {
            if (this['JQUERYAVAILABLE']) _0x372b67['css'](_0x381899);
            else {
                var _0x3b7cfa = '',
                    _0x1d9023;
                for (_0x1d9023 in _0x381899) _0x3b7cfa += _0x1d9023 + ':' + _0x381899[_0x1d9023] + ';';
                this['attr'](_0x372b67, 'style', _0x3b7cfa);
            }
        },
        'getOffsets': function(_0xd81954) {
            return this['JQUERYAVAILABLE'] ? (_0xd81954 = _0xd81954['offset'](), {
                'left': _0xd81954['left'],
                'top': _0xd81954['top']
            }) : {
                'left': _0xd81954['offsetLeft'],
                'top': _0xd81954['offsetTop']
            };
        },
        'attr': function(_0x652ed8, _0x434a5c, _0x55f2ae) {
            if ('undefined' === typeof _0x55f2ae) return this['JQUERYAVAILABLE'] ? _0x652ed8['attr'](_0x434a5c) : _0x652ed8['getAttribute'](_0x434a5c);
            this['JQUERYAVAILABLE'] ? _0x652ed8['attr'](_0x434a5c, _0x55f2ae) : _0x652ed8['setAttribute'](_0x434a5c, _0x55f2ae);
        },
        'show': function(_0x454610) {
            _0x454610 && 'undefined' !== typeof _0x454610 && (this['JQUERYAVAILABLE'] ? (_0x454610['show'](), _0x454610['css']('visibility', 'visible')) : _0x454610 && (_0x454610['style'] ? _0x454610['style']['visibility'] = 'visible' : _0x454610[0x0] && (_0x454610[0x0]['style']['visibility'] = 'visible')));
        },
        'hide': function(_0x34ed78) {
            _0x34ed78 && 'undefined' !== typeof _0x34ed78 && (this['JQUERYAVAILABLE'] ? (_0x34ed78['hide'](), _0x34ed78['css']('visibility', 'hidden')) : _0x34ed78 && (_0x34ed78['style'] ? _0x34ed78['style']['visibility'] = 'hidden' : _0x34ed78[0x0] && (_0x34ed78[0x0]['style']['visibility'] = 'hidden')));
        },
        'getQueryVariable': function(_0x2a357f) {
            for (var _0x374e66 = window['location']['search']['substring'](0x1)['split']('&'), _0x67378d = 0x0; _0x67378d < _0x374e66['length']; _0x67378d++) {
                var _0x447192 = _0x374e66[_0x67378d]['match'](/([^=]+?)=(.+)/);
                if (_0x447192 && decodeURIComponent(_0x447192[0x1]) == _0x2a357f) return decodeURIComponent(_0x447192[0x2]);
            }
        },
        'forcedDeviceDetection': function() {
            var _0x4e2e2d = this['getQueryVariable']('device');
            if (_0x4e2e2d) switch (_0x4e2e2d) {
                case 'mobile':
                    console['log']('serving\x20mobile\x20version\x20...'), ig['ua']['mobile'] = !0x0;
                    break;
                case 'desktop':
                    console['log']('serving\x20desktop\x20version\x20...'), ig['ua']['mobile'] = !0x1;
                    break;
                default:
                    console['log']('serving\x20universal\x20version\x20...');
            } else console['log']('serving\x20universal\x20version\x20...');
        },
        'forcedDeviceRotation': function() {
            var _0x10b39c = this['getQueryVariable']('force-rotate');
            if (_0x10b39c) switch (_0x10b39c) {
                case 'portrait':
                    console['log']('force\x20rotate\x20to\x20portrait'), window['orientation'] = 0x0;
                    break;
                case 'landscape':
                    console['log']('force\x20rotate\x20to\x20horizontal'), window['orientation'] = 0x5a;
                    break;
                default:
                    alert('wrong\x20command/type\x20in\x20param\x20force-rotate.\x20Defaulting\x20value\x20to\x20portrait'), window['orientation'] = 0x0;
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.handlers.size-handler')['requires']('plugins.data.vector')['defines'](function() {
    ig['SizeHandler'] = ig['Class']['extend']({
        'portraitMode': !0x0,
        'disableStretchToFitOnMobileFlag': !0x1,
        'enableStretchToFitOnAntiPortraitModeFlag': !0x0,
        'enableScalingLimitsOnMobileFlag': !0x1,
        'minScalingOnMobile': 0x0,
        'maxScalingOnMobile': 0x1,
        'enableStretchToFitOnDesktopFlag': !0x1,
        'enableScalingLimitsOnDesktopFlag': !0x1,
        'minScalingOnDesktop': 0x0,
        'maxScalingOnDesktop': 0x1,
        'desktop': {
            'actualSize': new Vector2(window['innerWidth'], window['innerHeight']),
            'actualResolution': new Vector2(0x438, 0x438)
        },
        'mobile': {
            'actualSize': new Vector2(window['innerWidth'], window['innerHeight']),
            'actualResolution': new Vector2(0x438, 0x438)
        },
        'windowSize': new Vector2(window['innerWidth'], window['innerHeight']),
        'scaleRatioMultiplier': new Vector2(0x1, 0x1),
        'sizeRatio': new Vector2(0x1, 0x1),
        'scale': 0x1,
        'domHandler': null,
        'dynamicClickableEntityDivs': {},
        'coreDivsToResize': ['#canvas', '#play', '#orientate'],
        'adsToResize': {
            'MobileAdInGamePreroll': {
                'box-width': _SETTINGS['Ad']['Mobile']['Preroll']['Width'] + 0x2,
                'box-height': _SETTINGS['Ad']['Mobile']['Preroll']['Height'] + 0x14
            },
            'MobileAdInGameEnd': {
                'box-width': _SETTINGS['Ad']['Mobile']['End']['Width'] + 0x2,
                'box-height': _SETTINGS['Ad']['Mobile']['End']['Height'] + 0x14
            },
            'MobileAdInGamePreroll2': {
                'box-width': _SETTINGS['Ad']['Mobile']['Preroll']['Width'] + 0x2,
                'box-height': _SETTINGS['Ad']['Mobile']['Preroll']['Height'] + 0x14
            },
            'MobileAdInGameEnd2': {
                'box-width': _SETTINGS['Ad']['Mobile']['End']['Width'] + 0x2,
                'box-height': _SETTINGS['Ad']['Mobile']['End']['Height'] + 0x14
            },
            'MobileAdInGamePreroll3': {
                'box-width': _SETTINGS['Ad']['Mobile']['Preroll']['Width'] + 0x2,
                'box-height': _SETTINGS['Ad']['Mobile']['Preroll']['Height'] + 0x14
            },
            'MobileAdInGameEnd3': {
                'box-width': _SETTINGS['Ad']['Mobile']['End']['Width'] + 0x2,
                'box-height': _SETTINGS['Ad']['Mobile']['End']['Height'] + 0x14
            }
        },
        'init': function(_0x307beb) {
            this['domHandler'] = _0x307beb;
            if ('undefined' === typeof _0x307beb) throw 'undefined\x20Dom\x20Handler\x20for\x20Size\x20Handler';
            this['sizeCalcs'](), this['eventListenerSetup'](), this['samsungFix']();
        },
        'sizeCalcs': function() {
            this['windowSize'] = new Vector2(window['innerWidth'], window['innerHeight']);
            if (ig['ua']['mobile']) {
                this['mobile']['actualSize'] = new Vector2(window['innerWidth'], window['innerHeight']);
                var _0x1313f = new Vector2(this['mobile']['actualResolution']['x'], this['mobile']['actualResolution']['y']);
                this['scaleRatioMultiplier'] = new Vector2(this['mobile']['actualSize']['x'] / _0x1313f['x'], this['mobile']['actualSize']['y'] / _0x1313f['y']);
                if (this['disableStretchToFitOnMobileFlag']) {
                    var _0x35de82 = Math['min'](this['scaleRatioMultiplier']['x'], this['scaleRatioMultiplier']['y']);
                    this['enableScalingLimitsOnMobileFlag'] && (_0x35de82 = _0x35de82['limit'](this['minScalingOnMobile'], this['maxScalingOnMobile'])), this['mobile']['actualSize']['x'] = _0x1313f['x'] * _0x35de82, this['mobile']['actualSize']['y'] = _0x1313f['y'] * _0x35de82, this['scaleRatioMultiplier']['x'] = _0x35de82, this['scaleRatioMultiplier']['y'] = _0x35de82;
                } else this['sizeRatio']['x'] = this['scaleRatioMultiplier']['x'], this['sizeRatio']['y'] = this['scaleRatioMultiplier']['y'], this['scaleRatioMultiplier']['x'] = 0x1, this['scaleRatioMultiplier']['y'] = 0x1;
            } else this['desktop']['actualSize'] = new Vector2(window['innerWidth'], window['innerHeight']), _0x1313f = new Vector2(this['desktop']['actualResolution']['x'], this['desktop']['actualResolution']['y']), this['scaleRatioMultiplier'] = new Vector2(this['desktop']['actualSize']['x'] / _0x1313f['x'], this['desktop']['actualSize']['y'] / _0x1313f['y']), this['enableStretchToFitOnDesktopFlag'] ? (this['sizeRatio']['x'] = this['scaleRatioMultiplier']['x'], this['sizeRatio']['y'] = this['scaleRatioMultiplier']['y'], this['scaleRatioMultiplier']['x'] = 0x1, this['scaleRatioMultiplier']['y'] = 0x1) : (_0x35de82 = Math['min'](this['scaleRatioMultiplier']['x'], this['scaleRatioMultiplier']['y']), this['enableScalingLimitsOnDesktopFlag'] && (_0x35de82 = _0x35de82['limit'](this['minScalingOnDesktop'], this['maxScalingOnDesktop'])), this['desktop']['actualSize']['x'] = _0x1313f['x'] * _0x35de82, this['desktop']['actualSize']['y'] = _0x1313f['y'] * _0x35de82, this['scaleRatioMultiplier']['x'] = _0x35de82, this['scaleRatioMultiplier']['y'] = _0x35de82);
        },
        'resizeLayers': function() {
            for (var _0x4ddee1 = 0x0; _0x4ddee1 < this['coreDivsToResize']['length']; _0x4ddee1++) {
                var _0x213271 = ig['domHandler']['getElementById'](this['coreDivsToResize'][_0x4ddee1]);
                if (ig['ua']['mobile']) {
                    if (this['disableStretchToFitOnMobileFlag']) {
                        var _0x118e8e = Math['floor'](ig['sizeHandler']['windowSize']['x'] / 0x2 - ig['sizeHandler']['mobile']['actualSize']['x'] / 0x2),
                            _0x36ab3f = Math['floor'](ig['sizeHandler']['windowSize']['y'] / 0x2 - ig['sizeHandler']['mobile']['actualSize']['y'] / 0x2);
                        0x0 > _0x118e8e && (_0x118e8e = 0x0), 0x0 > _0x36ab3f && (_0x36ab3f = 0x0), ig['domHandler']['resizeOffset'](_0x213271, Math['floor'](ig['sizeHandler']['mobile']['actualSize']['x']), Math['floor'](ig['sizeHandler']['mobile']['actualSize']['y']), _0x118e8e, _0x36ab3f);
                        var _0x3667c6 = !0x1;
                        if (this['portraitMode'] ? window['innerHeight'] < window['innerWidth'] : window['innerHeight'] > window['innerWidth']) {
                            if (this['enableStretchToFitOnAntiPortraitModeFlag']) ig['domHandler']['resizeOffset'](_0x213271, Math['floor'](window['innerWidth']), Math['floor'](window['innerHeight']), 0x0, 0x0);
                            else {
                                var _0x3667c6 = new Vector2(window['innerWidth'] / this['mobile']['actualResolution']['y'], window['innerHeight'] / this['mobile']['actualResolution']['x']),
                                    _0x118e8e = Math['min'](_0x3667c6['x'], _0x3667c6['y']),
                                    _0x3667c6 = this['mobile']['actualResolution']['y'] * _0x118e8e,
                                    _0x2a5b14 = this['mobile']['actualResolution']['x'] * _0x118e8e,
                                    _0x118e8e = Math['floor'](ig['sizeHandler']['windowSize']['x'] / 0x2 - _0x3667c6 / 0x2),
                                    _0x36ab3f = Math['floor'](ig['sizeHandler']['windowSize']['y'] / 0x2 - _0x2a5b14 / 0x2);
                                0x0 > _0x118e8e && (_0x118e8e = 0x0), 0x0 > _0x36ab3f && (_0x36ab3f = 0x0), ig['domHandler']['resizeOffset'](_0x213271, Math['floor'](_0x3667c6), Math['floor'](_0x2a5b14), _0x118e8e, _0x36ab3f);
                            }
                        }
                    } else ig['domHandler']['resize'](_0x213271, Math['floor'](ig['sizeHandler']['mobile']['actualSize']['x']), Math['floor'](ig['sizeHandler']['mobile']['actualSize']['y']));
                } else this['enableStretchToFitOnDesktopFlag'] ? ig['domHandler']['resize'](_0x213271, Math['floor'](ig['sizeHandler']['desktop']['actualSize']['x']), Math['floor'](ig['sizeHandler']['desktop']['actualSize']['y'])) : (_0x118e8e = Math['floor'](ig['sizeHandler']['windowSize']['x'] / 0x2 - ig['sizeHandler']['desktop']['actualSize']['x'] / 0x2), _0x36ab3f = Math['floor'](ig['sizeHandler']['windowSize']['y'] / 0x2 - ig['sizeHandler']['desktop']['actualSize']['y'] / 0x2), 0x0 > _0x118e8e && (_0x118e8e = 0x0), 0x0 > _0x36ab3f && (_0x36ab3f = 0x0), ig['domHandler']['resizeOffset'](_0x213271, Math['floor'](ig['sizeHandler']['desktop']['actualSize']['x']), Math['floor'](ig['sizeHandler']['desktop']['actualSize']['y']), _0x118e8e, _0x36ab3f));
            }
            for (var _0x317d71 in this['adsToResize']) _0x4ddee1 = ig['domHandler']['getElementById']('#' + _0x317d71), _0x213271 = ig['domHandler']['getElementById']('#' + _0x317d71 + '-Box'), _0x3667c6 = (window['innerWidth'] - this['adsToResize'][_0x317d71]['box-width']) / 0x2 + 'px', _0x118e8e = (window['innerHeight'] - this['adsToResize'][_0x317d71]['box-height']) / 0x2 + 'px', _0x4ddee1 && ig['domHandler']['css'](_0x4ddee1, {
                'width': window['innerWidth'],
                'height': window['innerHeight']
            }), _0x213271 && ig['domHandler']['css'](_0x213271, {
                'left': _0x3667c6,
                'top': _0x118e8e
            });
            _0x4ddee1 = ig['domHandler']['getElementById']('#canvas'), _0x213271 = ig['domHandler']['getOffsets'](_0x4ddee1), _0x4ddee1 = _0x213271['left'], _0x213271 = _0x213271['top'], _0x3667c6 = Math['min'](ig['sizeHandler']['scaleRatioMultiplier']['x'], ig['sizeHandler']['scaleRatioMultiplier']['y']);
            for (_0x317d71 in this['dynamicClickableEntityDivs']) {
                _0x118e8e = ig['domHandler']['getElementById']('#' + _0x317d71);
                if (ig['ua']['mobile']) {
                    var _0x2a5b14 = this['dynamicClickableEntityDivs'][_0x317d71]['entity_pos_x'],
                        _0x52470f = this['dynamicClickableEntityDivs'][_0x317d71]['entity_pos_y'],
                        _0x3e0a5c = this['dynamicClickableEntityDivs'][_0x317d71]['width'],
                        _0x36ab3f = this['dynamicClickableEntityDivs'][_0x317d71]['height'];
                    this['disableStretchToFitOnMobileFlag'] ? (_0x2a5b14 = Math['floor'](_0x4ddee1 + _0x2a5b14 * this['scaleRatioMultiplier']['x']) + 'px', _0x52470f = Math['floor'](_0x213271 + _0x52470f * this['scaleRatioMultiplier']['y']) + 'px', _0x3e0a5c = Math['floor'](_0x3e0a5c * this['scaleRatioMultiplier']['x']) + 'px', _0x36ab3f = Math['floor'](_0x36ab3f * this['scaleRatioMultiplier']['y']) + 'px') : (_0x2a5b14 = Math['floor'](_0x2a5b14 * this['sizeRatio']['x']) + 'px', _0x52470f = Math['floor'](_0x52470f * this['sizeRatio']['y']) + 'px', _0x3e0a5c = Math['floor'](_0x3e0a5c * this['sizeRatio']['x']) + 'px', _0x36ab3f = Math['floor'](_0x36ab3f * this['sizeRatio']['y']) + 'px');
                } else _0x2a5b14 = this['dynamicClickableEntityDivs'][_0x317d71]['entity_pos_x'], _0x52470f = this['dynamicClickableEntityDivs'][_0x317d71]['entity_pos_y'], _0x3e0a5c = this['dynamicClickableEntityDivs'][_0x317d71]['width'], _0x36ab3f = this['dynamicClickableEntityDivs'][_0x317d71]['height'], this['enableStretchToFitOnDesktopFlag'] ? (_0x2a5b14 = Math['floor'](_0x2a5b14 * this['sizeRatio']['x']) + 'px', _0x52470f = Math['floor'](_0x52470f * this['sizeRatio']['y']) + 'px', _0x3e0a5c = Math['floor'](_0x3e0a5c * this['sizeRatio']['x']) + 'px', _0x36ab3f = Math['floor'](_0x36ab3f * this['sizeRatio']['y']) + 'px') : (_0x2a5b14 = Math['floor'](_0x4ddee1 + _0x2a5b14 * this['scaleRatioMultiplier']['x']) + 'px', _0x52470f = Math['floor'](_0x213271 + _0x52470f * this['scaleRatioMultiplier']['y']) + 'px', _0x3e0a5c = Math['floor'](_0x3e0a5c * this['scaleRatioMultiplier']['x']) + 'px', _0x36ab3f = Math['floor'](_0x36ab3f * this['scaleRatioMultiplier']['y']) + 'px');
                ig['domHandler']['css'](_0x118e8e, {
                    'float': 'left',
                    'position': 'absolute',
                    'left': _0x2a5b14,
                    'top': _0x52470f,
                    'width': _0x3e0a5c,
                    'height': _0x36ab3f,
                    'z-index': 0x3
                }), this['dynamicClickableEntityDivs'][_0x317d71]['font-size'] && ig['domHandler']['css'](_0x118e8e, {
                    'font-size': this['dynamicClickableEntityDivs'][_0x317d71]['font-size'] * _0x3667c6 + 'px'
                });
            }
            $('#ajaxbar')['width'](this['windowSize']['x']), $('#ajaxbar')['height'](this['windowSize']['y']);
        },
        'resize': function() {
            this['sizeCalcs'](), this['resizeLayers']();
        },
        'reorient': function() {
            console['log']('changing\x20orientation\x20...');
            if (ig['ua']['mobile']) {
                var _0x5df6ad = !0x1,
                    _0x5df6ad = this['portraitMode'] ? window['innerHeight'] < window['innerWidth'] : window['innerHeight'] > window['innerWidth'],
                    _0x15f6ad = this['domHandler']['getElementById']('#orientate'),
                    _0x3ba8ee = this['domHandler']['getElementById']('#game');
                _0x5df6ad ? (this['domHandler']['show'](_0x15f6ad), this['domHandler']['hide'](_0x3ba8ee)) : (this['domHandler']['show'](_0x3ba8ee), this['domHandler']['hide'](_0x15f6ad));
            }
            ig['ua']['mobile'] ? (this['resize'](), this['resizeAds']()) : this['resize']();
        },
        'resizeAds': function() {
            for (var _0x54bf32 in this['adsToResize']) {
                var _0x4981c2 = ig['domHandler']['getElementById']('#' + _0x54bf32),
                    _0x21b33e = ig['domHandler']['getElementById']('#' + _0x54bf32 + '-Box'),
                    _0x225a7a = (window['innerWidth'] - this['adsToResize'][_0x54bf32]['box-width']) / 0x2 + 'px',
                    _0x146eb8 = (window['innerHeight'] - this['adsToResize'][_0x54bf32]['box-height']) / 0x2 + 'px';
                _0x4981c2 && ig['domHandler']['css'](_0x4981c2, {
                    'width': window['innerWidth'],
                    'height': window['innerHeight']
                }), _0x21b33e && ig['domHandler']['css'](_0x21b33e, {
                    'left': _0x225a7a,
                    'top': _0x146eb8
                });
            }
        },
        'samsungFix': function() {
            ig['ua']['android'] && !(4.2 > parseFloat(navigator['userAgent']['slice'](navigator['userAgent']['indexOf']('Android') + 0x8, navigator['userAgent']['indexOf']('Android') + 0xb))) && (!(0x0 > navigator['userAgent']['indexOf']('GT')) && !(0x0 < navigator['userAgent']['indexOf']('Chrome')) && !(0x0 < navigator['userAgent']['indexOf']('Firefox'))) && (document['addEventListener']('touchstart', function(_0x7526fa) {
                return _0x7526fa['preventDefault'](), !0x1;
            }, !0x1), document['addEventListener']('touchmove', function(_0x46a617) {
                return _0x46a617['preventDefault'](), !0x1;
            }, !0x1), document['addEventListener']('touchend', function(_0x4cec28) {
                return _0x4cec28['preventDefault'](), !0x1;
            }, !0x1));
        },
        'orientationInterval': null,
        'orientationTimeout': null,
        'orientationHandler': function() {
            this['reorient'](), window['scrollTo'](0x0, 0x1);
        },
        'orientationDelayHandler': function() {
            null == this['orientationInterval'] && (this['orientationInterval'] = window['setInterval'](this['orientationHandler']['bind'](this), 0x64)), null == this['orientationTimeout'] && (this['orientationTimeout'] = window['setTimeout'](function() {
                this['clearAllIntervals']();
            }['bind'](this), 0x7d0));
        },
        'clearAllIntervals': function() {
            window['clearInterval'](this['orientationInterval']), this['orientationInterval'] = null, window['clearTimeout'](this['orientationTimeout']), this['orientationTimeout'] = null;
        },
        'eventListenerSetup': function() {
            ig['ua']['iOS'] ? (window['addEventListener']('orientationchange', this['orientationDelayHandler']['bind'](this)), window['addEventListener']('resize', this['orientationDelayHandler']['bind'](this))) : (window['addEventListener']('orientationchange', this['orientationHandler']['bind'](this)), window['addEventListener']('resize', this['orientationHandler']['bind'](this))), document['ontouchmove'] = function(_0xb41ec) {
                window['scrollTo'](0x0, 0x1), _0xb41ec['preventDefault']();
            }, this['chromePullDownRefreshFix']();
        },
        'chromePullDownRefreshFix': function() {
            var _0x3eae2b = window['chrome'] || navigator['userAgent']['match']('CriOS'),
                _0x41637b = 'ontouchstart' in document['documentElement'];
            if (_0x3eae2b && _0x41637b) {
                var _0x14d54b = _0x3eae2b = !0x1,
                    _0x323b6f = 0x0,
                    _0x5aaabf = !0x1;
                try {
                    CSS['supports']('overscroll-behavior-y', 'contain') && (_0x3eae2b = !0x0);
                } catch (_0x5196df) {}
                try {
                    if (_0x3eae2b) return document['body']['style']['overscrollBehaviorY'] = 'contain';
                } catch (_0xfb4b6b) {}
                _0x3eae2b = document['head'] || document['body'], _0x41637b = document['createElement']('style'), _0x41637b['type'] = 'text/css', _0x41637b['styleSheet'] ? _0x41637b['styleSheet']['cssText'] = '\x0a\x20\x20\x20\x20\x20\x20::-webkit-scrollbar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20width:\x20500x;\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-thumb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x20500px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgba(0,\x200,\x200,\x200.2);\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20-webkit-overflow-scrolling:\x20auto!important;\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20' : _0x41637b['appendChild'](document['createTextNode']('\x0a\x20\x20\x20\x20\x20\x20::-webkit-scrollbar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20width:\x20500px;\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-thumb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x20500px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgba(0,\x200,\x200,\x200.2);\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20-webkit-overflow-scrolling:\x20auto!important;\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20')), _0x3eae2b['appendChild'](_0x41637b);
                try {
                    addEventListener('test', null, {
                        get 'passive' () {
                            _0x14d54b = !0x0;
                        }
                    });
                } catch (_0x17e181) {}
                document['addEventListener']('touchstart', function(_0x32cf15) {
                    0x1 === _0x32cf15['touches']['length'] && (_0x323b6f = _0x32cf15['touches'][0x0]['clientY'], _0x5aaabf = 0x0 === window['pageYOffset']);
                }, !!_0x14d54b && {
                    'passive': !0x0
                }), document['addEventListener']('touchmove', function(_0x2b0f11) {
                    var _0x2abea3;
                    if (_0x2abea3 = _0x5aaabf) {
                        _0x5aaabf = !0x1, _0x2abea3 = _0x2b0f11['touches'][0x0]['clientY'];
                        var _0xc27b0e = _0x2abea3 - _0x323b6f;
                        _0x2abea3 = (_0x323b6f = _0x2abea3, 0x0 < _0xc27b0e);
                    }
                    if (_0x2abea3) return _0x2b0f11['preventDefault']();
                }, !!_0x14d54b && {
                    'passive': !0x1
                });
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.handlers.api-handler')['defines'](function() {
    ig['ApiHandler'] = ig['Class']['extend']({
        'apiAvailable': {
            'MJSPreroll': function() {
                ig['ua']['mobile'] && ig['domHandler']['JQUERYAVAILABLE'] && _SETTINGS && _SETTINGS['Ad']['Mobile']['Preroll']['Enabled'] && MobileAdInGamePreroll['Initialize']();
            },
            'MJSHeader': function() {
                ig['ua']['mobile'] && ig['domHandler']['JQUERYAVAILABLE'] && _SETTINGS['Ad']['Mobile']['Header']['Enabled'] && MobileAdInGameHeader['Initialize']();
            },
            'MJSFooter': function() {
                ig['ua']['mobile'] && ig['domHandler']['JQUERYAVAILABLE'] && _SETTINGS['Ad']['Mobile']['Footer']['Enabled'] && MobileAdInGameFooter['Initialize']();
            },
            'MJSEnd': function() {
                ig['ua']['mobile'] && ig['domHandler']['JQUERYAVAILABLE'] && _SETTINGS['Ad']['Mobile']['End']['Enabled'] && MobileAdInGameEnd['Initialize']();
            }
        },
        'run': function(_0x44888c, _0xe95856) {
            if (this['apiAvailable'][_0x44888c]) this['apiAvailable'][_0x44888c](_0xe95856);
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.sound-player')['defines'](function() {
    SoundPlayer = ig['Class']['extend']({
        'tagName': 'SoundPlayer',
        'stayMuteFlag': !0x1,
        'debug': !0x1,
        'init': function() {
            this['debug'] && console['log'](this['tagName']);
        },
        'play': function(_0x37cc1b) {
            this['debug'] && console['log']('play\x20sound\x20', _0x37cc1b);
        },
        'stop': function() {
            this['debug'] && console['log']('stop\x20sound\x20');
        },
        'volume': function() {
            this['debug'] && console['log']('set\x20volume');
        },
        'mute': function(_0x40acb1) {
            this['debug'] && console['log']('mute'), 'undefined' === typeof _0x40acb1 ? this['stayMuteFlag'] = !0x0 : _0x40acb1 && (this['stayMuteFlag'] = !0x0);
        },
        'unmute': function(_0x527bb5) {
            this['debug'] && console['log']('unmute'), 'undefined' === typeof _0x527bb5 ? this['stayMuteFlag'] = !0x1 : _0x527bb5 && (this['stayMuteFlag'] = !0x1);
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.impact-music-player')['requires']('plugins.audio.sound-player')['defines'](function() {
    ImpactMusicPlayer = SoundPlayer['extend']({
        'tagName': 'ImpactMusicPlayer',
        'bgmPlaying': !0x1,
        'soundList': {},
        'init': function(_0x239558, _0x2850d1) {
            this['parent'](_0x239558, _0x2850d1);
            for (var _0x210cbd in _0x239558) this['soundList'][_0x210cbd] = _0x210cbd, ig['music']['add'](_0x239558[_0x210cbd]['path'] + '.*', _0x210cbd);
            _0x2850d1 && _0x2850d1['loop'] && (ig['music']['loop'] = _0x2850d1['loop']);
        },
        'play': function(_0x48cdea) {
            this['stayMuteFlag'] || (this['bgmPlaying'] = !0x0, 'undefined' === typeof _0x48cdea ? ig['music']['play'](_0x48cdea) : ig['music']['play']());
        },
        'stop': function() {
            this['bgmPlaying'] = !0x1, ig['music']['pause']();
        },
        'volume': function(_0x2961ff) {
            console['log']('impactmusic:', _0x2961ff), ig['music']['volume'] = 0x0 > _0x2961ff ? 0x0 : isNaN(_0x2961ff) ? 0x1 : 0x1 < _0x2961ff ? 0x1 : _0x2961ff;
        },
        'getVolume': function() {
            return ig['music']['volume'];
        },
        'mute': function(_0x4a01f3) {
            this['parent'](_0x4a01f3), this['bgmPlaying'] && this['stop']();
        },
        'unmute': function(_0x47e944) {
            this['parent'](_0x47e944), this['play']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.impact-sound-player')['requires']('plugins.audio.sound-player')['defines'](function() {
    ImpactSoundPlayer = SoundPlayer['extend']({
        'tagName': 'ImpactSoundPlayer',
        'soundList': {},
        'init': function(_0x4d269a, _0x1fda6d) {
            this['parent'](_0x4d269a, _0x1fda6d);
            for (var _0xa28ada in _0x4d269a) {
                var _0x5d8f02 = new ig['Sound'](_0x4d269a[_0xa28ada]['path'] + '.*');
                this['soundList'][_0xa28ada] = _0x5d8f02;
            }
        },
        'play': function(_0x172f52) {
            this['stayMuteFlag'] || ('object' === typeof _0x172f52 ? (console['log'](_0x172f52 + '\x20exists'), _0x172f52['play']()) : 'string' === typeof _0x172f52 && this['soundList'][_0x172f52]['play']());
        },
        'stop': function(_0x367afb) {
            this['parent'](_0x367afb), _0x367afb['stop']();
        },
        'volume': function(_0xd94ab6) {
            ig['soundManager']['volume'] = 0x0 > _0xd94ab6 ? 0x0 : isNaN(_0xd94ab6) ? 0x1 : 0x1 < _0xd94ab6 ? 0x1 : _0xd94ab6;
        },
        'getVolume': function() {
            return ig['soundManager']['volume'];
        },
        'mute': function(_0x5b5eee) {
            this['parent'](_0x5b5eee), ig['Sound']['enabled'] = !0x1;
        },
        'unmute': function(_0xa0f031) {
            this['parent'](_0xa0f031), ig['Sound']['enabled'] = !0x0;
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.howler-player')['requires']('plugins.audio.sound-player')['defines'](function() {
    HowlerPlayer = SoundPlayer['extend']({
        'tagName': 'HowlerPlayer',
        'soundList': {},
        'init': function(_0x25c2dd, _0x5cf6a0) {
            this['parent'](_0x25c2dd, _0x5cf6a0);
            for (var _0x54ffcd in _0x25c2dd) {
                var _0x2b104d = _0x25c2dd[_0x54ffcd]['path'],
                    _0x2b104d = new Howl({
                        'src': [_0x2b104d + '.' + ig['Sound']['FORMAT']['OGG']['ext'], _0x2b104d + '.' + ig['Sound']['FORMAT']['MP3']['ext']]
                    });
                this['soundList'][_0x54ffcd] = _0x2b104d;
            }
        },
        'play': function(_0x43cdd5) {
            if (Howler['ctx'] && 'running' !== Howler['ctx']['state']) return Howler['ctx']['resume']();
            this['stayMuteFlag'] || ('object' === typeof _0x43cdd5 ? _0x43cdd5['play']() : 'string' === typeof _0x43cdd5 && this['soundList'][_0x43cdd5]['play']());
        },
        'stop': function(_0x2f8063) {
            this['parent'](_0x2f8063), 'object' === typeof _0x2f8063 ? _0x2f8063['stop']() : 'string' === typeof _0x2f8063 && this['soundList'][_0x2f8063]['stop']();
        },
        'volume': function(_0x42c31d) {
            for (var _0x52c4ef in this['soundList']) {
                if (0x0 > _0x42c31d) {
                    this['soundList'][_0x52c4ef]['volume'](0x0);
                    break;
                }
                isNaN(_0x42c31d) ? this['soundList'][_0x52c4ef]['volume'](0x1) : 0x1 < _0x42c31d ? this['soundList'][_0x52c4ef]['volume'](0x1) : this['soundList'][_0x52c4ef]['volume'](_0x42c31d);
            }
        },
        'getVolume': function() {
            for (var _0x56293d in this['soundList']) return this['soundList'][_0x56293d]['volume']();
        },
        'mute': function(_0x2fb341) {
            this['parent'](_0x2fb341), Howler['mute'](!0x0);
        },
        'unmute': function(_0x5517b2) {
            this['parent'](_0x5517b2), Howler['mute'](!0x1);
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.howler-music-player')['requires']('plugins.audio.sound-player')['defines'](function() {
    HowlerMusicPlayer = SoundPlayer['extend']({
        'tagName': 'HowlerMusicPlayer',
        'bgmPlaying': !0x1,
        'soundList': {},
        'init': function(_0xb31cd2, _0x3f6bdb) {
            this['parent'](_0xb31cd2, _0x3f6bdb);
            for (var _0xe515b6 in _0xb31cd2) {
                var _0x5b7b01 = _0xb31cd2[_0xe515b6]['path'],
                    _0x5b7b01 = new Howl({
                        'src': [_0x5b7b01 + '.' + ig['Sound']['FORMAT']['OGG']['ext'], _0x5b7b01 + '.' + ig['Sound']['FORMAT']['MP3']['ext']],
                        'loop': !0x0,
                        'autoplay': !0x1,
                        'onend': function() {}['bind'](this)
                    });
                this['soundList'][_0xe515b6] = _0x5b7b01;
            }
        },
        'play': function(_0xddcabe) {
            if (!this['stayMuteFlag'] && !this['bgmPlaying']) {
                if ('object' === typeof _0xddcabe) this['bgmPlaying'] = !0x0, _0xddcabe['play']();
                else {
                    if ('string' === typeof _0xddcabe) this['bgmPlaying'] = !0x0, this['soundList'][_0xddcabe]['play']();
                    else
                        for (var _0x4e5fb0 in this['soundList']) {
                            this['soundList'][_0x4e5fb0]['play'](), this['bgmPlaying'] = !0x0;
                            break;
                        }
                }
            }
        },
        'stop': function(_0x4678af) {
            this['parent'](_0x4678af);
            if (this['bgmPlaying']) {
                for (var _0x109423 in this['soundList']) this['soundList'][_0x109423]['stop']();
                this['bgmPlaying'] = !0x1;
            }
        },
        'volume': function(_0x14b676) {
            console['log']('howler', _0x14b676);
            for (var _0x418b59 in this['soundList']) {
                if (0x0 > _0x14b676) {
                    this['soundList'][_0x418b59]['volume'](0x0);
                    break;
                }
                isNaN(_0x14b676) ? this['soundList'][_0x418b59]['volume'](0x1) : 0x1 < _0x14b676 ? this['soundList'][_0x418b59]['volume'](0x1) : this['soundList'][_0x418b59]['volume'](_0x14b676);
            }
        },
        'getVolume': function() {
            for (var _0x848c60 in this['soundList']) return this['soundList'][_0x848c60]['volume']();
        },
        'mute': function(_0x489f7e) {
            this['parent'](_0x489f7e), Howler['mute'](!0x0);
        },
        'unmute': function(_0x4b6523) {
            this['parent'](_0x4b6523), Howler['mute'](!0x1);
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.jukebox-player')['requires']('plugins.audio.sound-player')['defines'](function() {
    JukeboxPlayer = SoundPlayer['extend']({
        'tagName': 'JukeboxPlayer',
        'bgmPlaying': !0x1,
        'soundList': {},
        'jukeboxPlayer': null,
        'pausePosition': 0x0,
        'premuteVolume': 0x0,
        'minVolume': 0.001,
        'init': function(_0x17698a, _0x2cde7b) {
            this['parent'](_0x17698a, _0x2cde7b);
            for (var _0x588632 in _0x17698a) {
                this['soundList'][_0x588632] = _0x588632;
                var _0x418105 = _0x17698a[_0x588632]['path'];
                this['jukeboxPlayer'] = new jukebox['Player']({
                    'resources': [_0x418105 + '.' + ig['Sound']['FORMAT']['OGG']['ext'], _0x418105 + '.' + ig['Sound']['FORMAT']['MP3']['ext']],
                    'autoplay': !0x1,
                    'spritemap': {
                        'music': {
                            'start': _0x17698a[_0x588632]['startMp3'],
                            'end': _0x17698a[_0x588632]['endMp3'],
                            'loop': !0x0
                        }
                    }
                });
            }
        },
        'play': function() {
            this['stayMuteFlag'] || (this['bgmPlaying'] = !0x0, this['pausePosition'] ? (console['log']('resume'), this['jukeboxPlayer']['resume'](this['pausePosition'])) : (console['log']('play'), this['jukeboxPlayer']['play'](this['jukeboxPlayer']['settings']['spritemap']['music']['start'], !0x0)), this['premuteVolume'] = this['getVolume']());
        },
        'stop': function() {
            this['bgmPlaying'] = !0x1, this['pausePosition'] = this['jukeboxPlayer']['pause']();
        },
        'volume': function(_0x346001) {
            console['log']('jukebox:', _0x346001), 0x0 >= _0x346001 ? this['jukeboxPlayer']['setVolume'](this['minVolume']) : isNaN(_0x346001) ? this['jukeboxPlayer']['setVolume'](0x1) : 0x1 < _0x346001 ? this['jukeboxPlayer']['setVolume'](0x1) : this['jukeboxPlayer']['setVolume'](_0x346001);
        },
        'getVolume': function() {
            return this['jukeboxPlayer']['getVolume']();
        },
        'mute': function(_0x2ec083) {
            this['parent'](_0x2ec083), this['bgmPlaying'] && (console['log']('jukebox', this['premuteVolume']), this['stayMuteFlag'] || (this['premuteVolume'] = this['getVolume']()), this['jukeboxPlayer']['pause'](), this['jukeboxPlayer']['setVolume'](this['minVolume']));
        },
        'unmute': function(_0x1e75f7) {
            this['parent'](_0x1e75f7), this['stayMuteFlag'] || (console['log']('jukebox', this['premuteVolume']), this['jukeboxPlayer']['setVolume'](this['premuteVolume']), this['jukeboxPlayer']['resume']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.webaudio-music-player')['requires']('plugins.audio.sound-player')['defines'](function() {
    WebaudioMusicPlayer = SoundPlayer['extend']({
        'tagName': 'WebaudioMusicPlayer',
        'bgmPlaying': !0x1,
        'isSupported': !0x1,
        'muteFlag': !0x1,
        'pausedTime': 0x0,
        'webaudio': null,
        'useHTML5Audio': !0x1,
        'audio': null,
        'inactiveAudio': null,
        'codecs': null,
        'reinitOnPlay': !0x1,
        'inputList': null,
        '_volume': 0x1,
        'soundList': {},
        'init': function(_0x5ae54b) {
            this['webaudio'] = {
                'compatibility': {},
                'gainNode': null,
                'buffer': null,
                'source_loop': {},
                'source_once': {}
            };
            try {
                Howler && Howler['ctx'] ? this['webaudio']['context'] = Howler['ctx'] : ig && ig['webaudio_ctx'] ? this['webaudio']['context'] = ig['webaudio_ctx'] : (this['AudioContext'] = window['AudioContext'] || window['webkitAudioContext'], this['webaudio']['context'] = new this['AudioContext'](), ig['webaudio_ctx'] = this['webaudio']['context']), this['isSupported'] = !0x0;
            } catch (_0x404c84) {
                console['log']('Web\x20Audio\x20API\x20not\x20supported\x20in\x20this\x20browser.'), this['webaudio'] = null, this['useHTML5Audio'] = !0x0;
            }
            if (this['useHTML5Audio']) {
                if ('undefined' !== typeof Audio) try {
                    new Audio();
                } catch (_0x35bd5e) {
                    this['useHTML5Audio'] = !0x1;
                } else this['useHTML5Audio'] = !0x1;
            }
            this['useHTML5Audio'] && (this['audio'] = new Audio(), this['isSupported'] = !0x0, this['initHTML5Audio'](_0x5ae54b));
            if (!this['isSupported']) return null;
            this['webaudio'] && (this['inputList'] = _0x5ae54b, this['initWebAudio'](_0x5ae54b));
        },
        'initWebAudio': function(_0x2233b4) {
            ig['ua']['iOS'] && this['initIOSWebAudioUnlock'](), this['webaudio']['gainNode'] = 'undefined' === typeof this['webaudio']['context']['createGain'] ? this['webaudio']['context']['createGainNode']() : this['webaudio']['context']['createGain'](), this['webaudio']['gainNode']['connect'](this['webaudio']['context']['destination']), this['webaudio']['gainNode']['gain']['value'] = this['_volume'], this['webaudio']['buffer'] = null;
            var _0x1e80a7 = 'start',
                _0x3c4f5f = 'stop',
                _0x57145f = this['webaudio']['context']['createBufferSource']();
            'function' !== typeof _0x57145f['start'] && (_0x1e80a7 = 'noteOn'), this['webaudio']['compatibility']['start'] = _0x1e80a7, 'function' !== typeof _0x57145f['stop'] && (_0x3c4f5f = 'noteOff'), this['webaudio']['compatibility']['stop'] = _0x3c4f5f;
            for (var _0x5bb186 in _0x2233b4) {
                this['soundList'][_0x5bb186] = _0x5bb186;
                var _0x3c4f5f = _0x2233b4[_0x5bb186]['path'],
                    _0x1e80a7 = _0x3c4f5f + '.' + ig['Sound']['FORMAT']['MP3']['ext'],
                    _0x54ef7a = _0x3c4f5f + '.' + ig['Sound']['FORMAT']['OGG']['ext'];
                ig['ua']['mobile'] ? ig['ua']['iOS'] && (_0x54ef7a = _0x1e80a7) : (_0x3c4f5f = navigator['userAgent']['toLowerCase'](), -0x1 != _0x3c4f5f['indexOf']('safari') && -0x1 >= _0x3c4f5f['indexOf']('chrome') && (_0x54ef7a = _0x1e80a7), _0x3c4f5f['indexOf']('win64') && (_0x54ef7a = _0x1e80a7));
                var _0x25e511 = new XMLHttpRequest();
                _0x25e511['open']('GET', _0x54ef7a, !0x0), _0x25e511['responseType'] = 'arraybuffer', _0x25e511['onload'] = function() {
                    this['webaudio']['context']['decodeAudioData'](_0x25e511['response'], function(_0x320e27) {
                        this['webaudio']['buffer'] = _0x320e27, this['webaudio']['source_loop'] = {}, this['bgmPlaying'] ? this['play'](null, !0x0) : this['stop']();
                    }['bind'](this), function() {
                        console['log']('Error\x20decoding\x20audio\x20\x22' + _0x54ef7a + '\x22.');
                    });
                }['bind'](this), _0x25e511['send']();
                if (0x4 == _0x25e511['readyState'] && 'undefined' !== typeof Audio) {
                    this['useHTML5Audio'] = !0x0;
                    try {
                        new Audio();
                    } catch (_0x353ffc) {
                        this['useHTML5Audio'] = !0x1;
                    }
                    this['useHTML5Audio'] && (console['log']('Using\x20HTML5\x20Audio'), this['webaudio'] = null, this['audio'] = new Audio(), this['isSupported'] = !0x0, this['initHTML5Audio'](_0x2233b4));
                }
                break;
            }
        },
        'initIOSWebAudioUnlock': function() {
            if (this['webaudio']) {
                webaudio = this['webaudio'];
                var _0x264418 = function() {
                    var _0x70d6a4 = webaudio['context'],
                        _0x2e8683 = _0x70d6a4['createBuffer'](0x1, 0x1, 0x5622),
                        _0x5397f8 = _0x70d6a4['createBufferSource']();
                    _0x5397f8['buffer'] = _0x2e8683, _0x5397f8['connect'](_0x70d6a4['destination']), 'undefined' === typeof _0x5397f8['start'] ? _0x5397f8['noteOn'](0x0) : _0x5397f8['start'](0x0), setTimeout(function() {
                        (_0x5397f8['playbackState'] === _0x5397f8['PLAYING_STATE'] || _0x5397f8['playbackState'] === _0x5397f8['FINISHED_STATE']) && window['removeEventListener']('touchend', _0x264418, !0x1);
                    }['bind'](this), 0x0);
                };
                window['addEventListener']('touchend', _0x264418, !0x1);
            }
        },
        'initHTML5Audio': function(_0xe9b36c) {
            if (this['useHTML5Audio'] && this['audio']) {
                var _0x36dc74 = this['audio'];
                this['codecs'] = {}, this['codecs'] = {
                    'mp3': !!_0x36dc74['canPlayType']('audio/mpeg;')['replace'](/^no$/, ''),
                    'opus': !!_0x36dc74['canPlayType']('audio/ogg;\x20codecs=\x22opus\x22')['replace'](/^no$/, ''),
                    'ogg': !!_0x36dc74['canPlayType']('audio/ogg;\x20codecs=\x22vorbis\x22')['replace'](/^no$/, ''),
                    'wav': !!_0x36dc74['canPlayType']('audio/wav;\x20codecs=\x221\x22')['replace'](/^no$/, ''),
                    'aac': !!_0x36dc74['canPlayType']('audio/aac;')['replace'](/^no$/, ''),
                    'm4a': !!(_0x36dc74['canPlayType']('audio/x-m4a;') || _0x36dc74['canPlayType']('audio/m4a;') || _0x36dc74['canPlayType']('audio/aac;'))['replace'](/^no$/, ''),
                    'mp4': !!(_0x36dc74['canPlayType']('audio/x-mp4;') || _0x36dc74['canPlayType']('audio/mp4;') || _0x36dc74['canPlayType']('audio/aac;'))['replace'](/^no$/, ''),
                    'weba': !!_0x36dc74['canPlayType']('audio/webm;\x20codecs=\x22vorbis\x22')['replace'](/^no$/, '')
                }, this['is'] = {
                    'ff': Boolean(null != window['mozInnerScreenX'] && /firefox/ ['test'](navigator['userAgent']['toLowerCase']())),
                    'ie': Boolean(document['all'] && !window['opera']),
                    'opera': Boolean(window['opera']),
                    'chrome': Boolean(window['chrome']),
                    'safari': Boolean(!window['chrome'] && /safari/ ['test'](navigator['userAgent']['toLowerCase']()) && window['getComputedStyle'] && !window['globalStorage'] && !window['opera'])
                }, this['playDelay'] = -0x3c, this['stopDelay'] = 0x1e, this['is']['chrome'] && (this['playDelay'] = -0x19), this['is']['chrome'] && (this['stopDelay'] = 0x19), this['is']['ff'] && (this['playDelay'] = -0x19), this['is']['ff'] && (this['stopDelay'] = 0x55), this['is']['opera'] && (this['playDelay'] = 0x5), this['is']['opera'] && (this['stopDelay'] = 0x0);
                for (var _0x4b54b2 in _0xe9b36c) {
                    this['soundList'][_0x4b54b2] = _0x4b54b2;
                    var _0x27fea0 = _0xe9b36c[_0x4b54b2]['path'],
                        _0x36dc74 = _0x27fea0 + '.' + ig['Sound']['FORMAT']['OGG']['ext'],
                        _0x27fea0 = _0x27fea0 + '.' + ig['Sound']['FORMAT']['MP3']['ext'],
                        _0x5828ea = null;
                    this['codecs'][ig['Sound']['FORMAT']['OGG']['ext']['toLowerCase']()] ? _0x5828ea = _0x36dc74 : this['codecs'][ig['Sound']['FORMAT']['MP3']['ext']['toLowerCase']()] && (_0x5828ea = _0x27fea0);
                    if (_0x5828ea) {
                        ig['ua']['mobile'] ? ig['ua']['iOS'] && (_0x5828ea = _0x27fea0) : (_0xe9b36c = navigator['userAgent']['toLowerCase'](), -0x1 != _0xe9b36c['indexOf']('safari') && -0x1 >= _0xe9b36c['indexOf']('chrome') && (_0x5828ea = _0x27fea0)), this['audio']['addEventListener']('error', function() {
                            this['audio']['error'] && 0x4 === this['audio']['error']['code'] && (this['isSupported'] = !0x1);
                        }, !0x1), this['audio']['src'] = _0x5828ea, this['audio']['_pos'] = 0x0, this['audio']['preload'] = 'auto', this['audio']['volume'] = this['_volume'], this['inactiveAudio'] = new Audio(), this['inactiveAudio']['src'] = _0x5828ea, this['inactiveAudio']['_pos'] = 0x0, this['inactiveAudio']['preload'] = 'auto', this['inactiveAudio']['volume'] = this['_volume'], this['inactiveAudio']['load']();
                        var _0x460654 = function() {
                            this['_duration'] = this['audio']['duration'], this['_loaded'] || (this['_loaded'] = !0x0), this['bgmPlaying'] ? this['play'](null, !0x0) : this['stop'](), this['audio']['removeEventListener']('canplaythrough', _0x460654, !0x1);
                        }['bind'](this);
                        this['audio']['addEventListener']('canplaythrough', _0x460654, !0x1), this['audio']['load']();
                        break;
                    }
                }
            }
        },
        'play': function(_0x486050, _0x114e1e) {
            if (this['isSupported']) {
                if (this['bgmPlaying'] = !0x0, this['webaudio']) {
                    if (!_0x114e1e && this['reinitOnPlay'] && this['webaudio']['source_loop']['buffer'] == this['webaudio']['buffer']) {
                        if (this['webaudio']['source_loop']['_playing'] && (this['webaudio']['source_loop'][this['webaudio']['compatibility']['stop']](0x0), this['webaudio']['source_loop']['_playing'] = !0x1, this['pausedTime'] += this['webaudio']['context']['currentTime'] - this['webaudio']['source_loop']['_startTime'], this['pausedTime'] %= this['webaudio']['source_loop']['buffer']['duration'], this['webaudio']['source_loop']['_startTime'] = 0x0, 'noteOn' === this['webaudio']['compatibility']['start'])) this['webaudio']['source_once'][this['webaudio']['compatibility']['stop']](0x0);
                        try {
                            this['webaudio']['context']['close'](), this['webaudio']['context'] = new this['AudioContext'](), this['webaudio']['gainNode'] = this['webaudio']['context']['createGain'](), this['webaudio']['gainNode']['connect'](this['webaudio']['context']['destination']), this['webaudio']['gainNode']['gain']['value'] = this['_volume'];
                            var _0xa95fbd = 'start',
                                _0x412388 = 'stop',
                                _0x23df9d = this['webaudio']['context']['createBufferSource']();
                            'function' !== typeof _0x23df9d['start'] && (_0xa95fbd = 'noteOn'), this['webaudio']['compatibility']['start'] = _0xa95fbd, 'function' !== typeof _0x23df9d['stop'] && (_0x412388 = 'noteOff'), this['webaudio']['compatibility']['stop'] = _0x412388, this['webaudio']['source_loop'] = {}, this['play'](null, !0x0);
                        } catch (_0x477431) {}
                    }
                    if (this['webaudio']['buffer']) {
                        if (!this['muteFlag'] && (this['bgmPlaying'] = !0x0, !this['webaudio']['source_loop']['_playing'])) {
                            this['webaudio']['source_loop'] = this['webaudio']['context']['createBufferSource'](), this['webaudio']['source_loop']['buffer'] = this['webaudio']['buffer'], this['webaudio']['source_loop']['loop'] = !0x0, this['webaudio']['source_loop']['connect'](this['webaudio']['gainNode']);
                            if (null == _0x486050 || isNaN(_0x486050)) _0x486050 = 0x0, this['pausedTime'] && (_0x486050 = this['pausedTime']);
                            this['webaudio']['source_loop']['_startTime'] = this['webaudio']['context']['currentTime'];
                            if ('noteOn' === this['webaudio']['compatibility']['start']) this['webaudio']['source_once'] = this['webaudio']['context']['createBufferSource'](), this['webaudio']['source_once']['buffer'] = this['webaudio']['buffer'], this['webaudio']['source_once']['connect'](this['webaudio']['gainNode']), this['webaudio']['source_once']['noteGrainOn'](0x0, _0x486050, this['webaudio']['buffer']['duration'] - _0x486050), this['webaudio']['source_loop'][this['webaudio']['compatibility']['start']](this['webaudio']['context']['currentTime'] + (this['webaudio']['buffer']['duration'] - _0x486050));
                            else this['webaudio']['source_loop'][this['webaudio']['compatibility']['start']](0x0, _0x486050);
                            this['webaudio']['source_loop']['_playing'] = !0x0;
                        }
                    } else this['bgmPlaying'] = !0x0;
                } else {
                    if (this['audio']) {
                        var _0x1ff744 = this['audio'];
                        if (!this['muteFlag']) {
                            if (this['bgmPlaying'] = !0x0, isNaN(_0x486050) && (_0x486050 = 0x0, this['pausedTime'] && (_0x486050 = this['pausedTime'])), _0xa95fbd = this['_duration'] - _0x486050, this['_onEndTimer'] && (clearTimeout(this['_onEndTimer']), this['_onEndTimer'] = null), this['_onEndTimer'] = setTimeout(function() {
                                    this['audio']['currentTime'] = 0x0, this['audio']['pause'](), this['pausedTime'] = 0x0;
                                    if (this['inactiveAudio']) {
                                        var _0x5672a2 = this['audio'];
                                        this['audio'] = this['inactiveAudio'], this['inactiveAudio'] = _0x5672a2;
                                    }
                                    this['play']();
                                }['bind'](this), 0x3e8 * _0xa95fbd + this['playDelay']), 0x4 === _0x1ff744['readyState'] || !_0x1ff744['readyState'] && navigator['isCocoonJS']) _0x1ff744['readyState'] = 0x4, _0x1ff744['currentTime'] = _0x486050, _0x1ff744['muted'] = this['muteFlag'] || _0x1ff744['muted'], _0x1ff744['volume'] = this['_volume'], setTimeout(function() {
                                _0x1ff744['play']();
                            }, 0x0);
                            else {
                                clearTimeout(this['_onEndTimer']), this['_onEndTimer'] = null;
                                var _0x18b4be = function() {
                                    typeof('function' == this['play']) && (this['play'](), _0x1ff744['removeEventListener']('canplaythrough', _0x18b4be, !0x1));
                                }['bind'](this);
                                _0x1ff744['addEventListener']('canplaythrough', _0x18b4be, !0x1);
                            }
                        }
                    }
                }
            }
        },
        'stop': function() {
            this['bgmPlaying'] = !0x1;
            if (this['isSupported']) {
                if (this['webaudio']) {
                    if (this['webaudio']['source_loop']['_playing'] && (this['webaudio']['source_loop'][this['webaudio']['compatibility']['stop']](0x0), this['webaudio']['source_loop']['_playing'] = !0x1, this['pausedTime'] += this['webaudio']['context']['currentTime'] - this['webaudio']['source_loop']['_startTime'], this['pausedTime'] %= this['webaudio']['source_loop']['buffer']['duration'], this['webaudio']['source_loop']['_startTime'] = 0x0, 'noteOn' === this['webaudio']['compatibility']['start'])) this['webaudio']['source_once'][this['webaudio']['compatibility']['stop']](0x0);
                } else {
                    if (this['audio']) {
                        var _0x1c1db9 = this['audio'];
                        0x4 == _0x1c1db9['readyState'] && (this['pausedTime'] = _0x1c1db9['currentTime'], _0x1c1db9['currentTime'] = 0x0, _0x1c1db9['pause'](), clearTimeout(this['_onEndTimer']), this['_onEndTimer'] = null);
                    }
                }
            }
        },
        'volume': function(_0x13311b) {
            if (isNaN(_0x13311b) || null == _0x13311b) return this['getVolume']();
            this['isSupported'] && (this['_volume'] = _0x13311b, 0x0 > this['_volume'] ? this['_volume'] = 0x0 : 0x1 < this['_volume'] && (this['_volume'] = 0x1), this['webaudio'] ? this['webaudio']['gainNode'] && (this['webaudio']['gainNode']['gain']['value'] = this['_volume']) : this['audio'] && (this['audio']['volume'] = this['_volume'], this['inactiveAudio'] && (this['inactiveAudio']['volume'] = this['_volume'])));
        },
        'getVolume': function() {
            return !this['isSupported'] ? 0x0 : this['_volume'];
        },
        'mute': function(_0x193499) {
            this['parent'](_0x193499), !0x1 == this['muteFlag'] && (this['muteFlag'] = !0x0, this['bgmPlaying'] && (this['stop'](), this['bgmPlaying'] = !0x0));
        },
        'unmute': function(_0x241b89) {
            this['parent'](_0x241b89), !this['stayMuteFlag'] && !0x0 == this['muteFlag'] && (this['muteFlag'] = !0x1, this['bgmPlaying'] && this['play']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.sound-info')['defines'](function() {
    SoundInfo = ig['Class']['extend']({
        'FORMATS': {
            'OGG': '.ogg',
            'MP3': '.mp3'
        },
        'sfx': {
            'staticSound': {
                'path': 'media/audio/play/static'
            },
            'logosplash1': {
                'path': 'media/audio/opening/logosplash1'
            },
            'logosplash2': {
                'path': 'media/audio/opening/logosplash2'
            },
            'button': {
                'path': 'media/audio/button'
            },
            'buy': {
                'path': 'media/audio/buy'
            },
            'coin': {
                'path': 'media/audio/coin'
            },
            'crop': {
                'path': 'media/audio/crop'
            },
            'dailyreward': {
                'path': 'media/audio/dailyreward'
            },
            'popup': {
                'path': 'media/audio/popup'
            },
            'rain': {
                'path': 'media/audio/rain'
            },
            'sun': {
                'path': 'media/audio/sun'
            },
            'truck': {
                'path': 'media/audio/honk'
            }
        },
        'bgm': {
            'background': {
                'path': 'media/audio/bgm',
                'startOgg': 0x0,
                'endOgg': 21.463,
                'startMp3': 0x0,
                'endMp3': 21.463
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.audio.sound-handler')['requires']('plugins.audio.impact-music-player', 'plugins.audio.impact-sound-player', 'plugins.audio.howler-player', 'plugins.audio.howler-music-player', 'plugins.audio.jukebox-player', 'plugins.audio.webaudio-music-player', 'plugins.audio.sound-info')['defines'](function() {
    ig['SoundHandler'] = ig['Class']['extend']({
        'bgmPlayer': null,
        'sfxPlayer': null,
        'focusBlurMute': !0x1,
        'soundInfo': new SoundInfo(),
        'init': function() {
            console['log']('Initiating\x20sound\x20handler'), ig['ua']['mobile'] ? (this['sfxPlayer'] = new HowlerPlayer(this['soundInfo']['sfx']), this['bgmPlayer'] = new WebaudioMusicPlayer(this['soundInfo']['bgm'], {
                'loop': !0x0
            }), this['bgmPlayer']['isSupported'] || (this['bgmPlayer'] = new JukeboxPlayer(this['soundInfo']['bgm'], {
                'loop': !0x0
            }))) : (this['sfxPlayer'] = new HowlerPlayer(this['soundInfo']['sfx']), this['bgmPlayer'] = new WebaudioMusicPlayer(this['soundInfo']['bgm'], {
                'loop': !0x0
            }), this['bgmPlayer']['isSupported'] || (this['bgmPlayer'] = new ImpactMusicPlayer(this['soundInfo']['bgm'], {
                'loop': !0x0
            })));
        },
        'unlockWebAudio': function() {
            Howler && (Howler['ctx'] && 'running' !== Howler['ctx']['state'] && Howler['ctx']['resume'](), Howler['_audioUnlocked'] || 'function' === typeof Howler['_unlockAudio'] && Howler['_unlockAudio']()), ig && ig['webaudio_ctx'] && ig['webaudio_ctx']['state'] && 'running' !== ig['webaudio_ctx']['state'] && ig['webaudio_ctx']['resume'](), this['bgmPlayer']['webaudio'] && this['bgmPlayer']['webaudio']['context'] && this['bgmPlayer']['webaudio']['context']['state'] && 'running' !== this['bgmPlayer']['webaudio']['context']['state'] && this['bgmPlayer']['webaudio']['context']['resume']();
        },
        'checkBGM': function() {
            return this['bgmPlayer']['stayMuteFlag'];
        },
        'checkSFX': function() {
            return this['sfxPlayer']['stayMuteFlag'];
        },
        'muteSFX': function(_0x5b83d0) {
            this['sfxPlayer'] && this['sfxPlayer']['mute'](_0x5b83d0);
        },
        'muteBGM': function(_0x1e1b01) {
            this['bgmPlayer'] && this['bgmPlayer']['mute'](_0x1e1b01);
        },
        'unmuteSFX': function(_0x31b778) {
            this['sfxPlayer'] && this['sfxPlayer']['unmute'](_0x31b778);
        },
        'unmuteBGM': function(_0x1ed04d) {
            this['bgmPlayer'] && this['bgmPlayer']['unmute'](_0x1ed04d);
        },
        'muteAll': function(_0x4a1912) {
            this['muteSFX'](_0x4a1912), this['muteBGM'](_0x4a1912);
        },
        'unmuteAll': function(_0x2549d4) {
            this['unlockWebAudio'](), this['unmuteSFX'](_0x2549d4), this['unmuteBGM'](_0x2549d4);
        },
        'forceMuteAll': function() {
            this['focusBlurMute'] || this['muteAll'](!0x1), this['focusBlurMute'] = !0x0;
        },
        'forceUnMuteAll': function() {
            this['focusBlurMute'] && (this['unmuteAll'](!0x1), this['focusBlurMute'] = !0x1);
        },
        'saveVolume': function() {
            this['sfxPlayer'] && ig['game']['io']['storageSet']('soundVolume', this['sfxPlayer']['getVolume']()), this['bgmPlayer'] && ig['game']['io']['storageSet']('musicVolume', this['bgmPlayer']['getVolume']());
        },
        'forceLoopBGM': function() {
            var _0x53eea6;
            if (!this['focusBlurMute'] && this['bgmPlayer']['bgmPlaying'] && this['bgmPlayer']) {
                var _0x187edc = this['bgmPlayer']['jukeboxPlayer'];
                if (_0x187edc) {
                    null != window['mozInnerScreenX'] && /firefox/ ['test'](navigator['userAgent']['toLowerCase']()), _0x53eea6 = Boolean(window['chrome']), !window['chrome'] && /safari/ ['test'](navigator['userAgent']['toLowerCase']());
                    var _0x41883f = 0.1;
                    ig['ua']['mobile'] && (_0x41883f = 0.115, ig['ua']['android'] && (_0x41883f = 0.45, _0x53eea6 && (_0x41883f = 0.3))), _0x187edc['settings']['spritemap']['music'] && (_0x53eea6 = _0x187edc['settings']['spritemap']['music']['end'] - _0x41883f, _0x187edc['getCurrentTime']() >= _0x53eea6 && (_0x53eea6 = _0x187edc['settings']['spritemap']['music']['start'], ig['ua']['android'] ? this['forcelooped'] || (_0x187edc['play'](_0x53eea6, !0x0), this['forcelooped'] = !0x0, setTimeout(function() {
                        ig['soundHandler']['forcelooped'] = !0x1;
                    }, _0x41883f)) : _0x187edc['setCurrentTime'](_0x53eea6)));
                } else 'ImpactMusicPlayer' == this['bgmPlayer']['tagName'] && (null != window['mozInnerScreenX'] && /firefox/ ['test'](navigator['userAgent']['toLowerCase']()), _0x53eea6 = Boolean(window['chrome']), !window['chrome'] && /safari/ ['test'](navigator['userAgent']['toLowerCase']()), _0x41883f = 0.1, ig['ua']['mobile'] && (_0x41883f = 0.115, ig['ua']['android'] && (_0x41883f = 0.45, _0x53eea6 && (_0x41883f = 0.3))), _0x187edc = 0x0, 'mp3' == ig['soundManager']['format']['ext'] && (_0x187edc = 0.05), ig['music']['currentTrack'] && (_0x53eea6 = ig['music']['currentTrack']['duration'] - _0x41883f, ig['music']['currentTrack']['currentTime'] >= _0x53eea6 && (ig['ua']['android'] ? this['forcelooped'] || (ig['music']['currentTrack']['pause'](), ig['music']['currentTrack']['currentTime'] = _0x187edc, ig['music']['currentTrack']['play'](), this['forcelooped'] = !0x0, setTimeout(function() {
                    ig['soundHandler']['forcelooped'] = !0x1;
                }, _0x41883f)) : ig['music']['currentTrack']['currentTime'] = _0x187edc)));
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.handlers.visibility-handler')['requires']('plugins.audio.sound-handler')['defines'](function() {
    ig['VisibilityHandler'] = ig['Class']['extend']({
        'version': '1.1.0',
        'config': {
            'muteOnBlur': !0x0,
            'pauseOnBlur': !0x1,
            'clearInputStateOnBlur': !0x0,
            'allowResumeWithoutFocus': {
                'desktop': !0x0,
                'mobile': {
                    'kaios': !0x1,
                    'default': !0x0
                }
            },
            'handlerDelay': {
                'desktop': 0x0,
                'mobile': {
                    'kaios': 0x0,
                    'default': 0x0
                }
            },
            'autoFocusOnResume': {
                'desktop': !0x0,
                'mobile': {
                    'kaios': !0x1,
                    'default': !0x0
                }
            },
            'autoFocusAfterResume': {
                'desktop': !0x0,
                'mobile': {
                    'kaios': !0x1,
                    'default': !0x0
                }
            }
        },
        'browserPrefixes': ['o', 'ms', 'moz', 'webkit'],
        'browserPrefix': null,
        'hiddenPropertyName': null,
        'visibilityEventName': null,
        'visibilityStateName': null,
        'isShowingOverlay': !0x1,
        'isFocused': !0x1,
        'isPaused': !0x1,
        'init': function() {
            this['initVisibilityHandler'](), this['initFocusHandler'](), this['initPageTransitionHandler'](), ig['visibilityHandler'] = this;
        },
        'pauseHandler': function() {
            !0x0 === this['config']['clearInputStateOnBlur'] && 'undefined' !== typeof ig['input'] && null !== ig['input'] && 'function' === typeof ig['input']['clearAllState'] && ig['input']['clearAllState'](), !0x0 === this['config']['pauseOnBlur'] && 'undefined' !== typeof ig['game'] && null !== ig['game'] && 'undefined' !== typeof ig['game']['pauseGame'] && ig['game']['pauseGame'](), !0x0 === this['config']['muteOnBlur'] && 'undefined' !== typeof ig['soundHandler'] && null !== ig['soundHandler'] && 'function' === typeof ig['soundHandler']['forceMuteAll'] && ig['soundHandler']['forceMuteAll']();
        },
        'resumeHandler': function() {
            'undefined' !== typeof ig['input'] && null !== ig['input'] && 'function' === typeof ig['input']['clearAllState'] && ig['input']['clearAllState'](), 'undefined' !== typeof ig['game'] && null !== ig['game'] && 'undefined' !== typeof ig['game']['resumeGame'] && ig['game']['resumeGame'](), 'undefined' !== typeof ig['soundHandler'] && null !== ig['soundHandler'] && 'function' === typeof ig['soundHandler']['forceUnMuteAll'] && ig['soundHandler']['forceUnMuteAll']();
        },
        'initVisibilityHandler': function() {
            this['browserPrefix'] = this['getBrowserPrefix'](), this['hiddenPropertyName'] = this['getHiddenPropertyName'](this['browserPrefix']), this['visibilityEventName'] = this['getVisibilityEventName'](this['browserPrefix']), this['visibilityStateName'] = this['getVisibilityStateName'](this['browserPrefix']), this['visibilityEventName'] && document['addEventListener'](this['visibilityEventName'], this['onChange']['bind'](this), !0x0);
        },
        'initFocusHandler': function() {
            window['addEventListener']('blur', this['onChange']['bind'](this), !0x0), document['addEventListener']('blur', this['onChange']['bind'](this), !0x0), document['addEventListener']('focusout', this['onChange']['bind'](this), !0x0), window['addEventListener']('focus', this['onChange']['bind'](this), !0x0), document['addEventListener']('focus', this['onChange']['bind'](this), !0x0), document['addEventListener']('focusin', this['onChange']['bind'](this), !0x0);
        },
        'initPageTransitionHandler': function() {
            window['addEventListener']('pagehide', this['onChange']['bind'](this), !0x0), window['addEventListener']('pageshow', this['onChange']['bind'](this), !0x0);
        },
        'getBrowserPrefix': function() {
            var _0x143b59 = null;
            return this['browserPrefixes']['forEach'](function(_0x23878a) {
                if (this['getHiddenPropertyName'](_0x23878a) in document) return _0x143b59 = _0x23878a;
            }['bind'](this)), _0x143b59;
        },
        'getHiddenPropertyName': function(_0x34afed) {
            return _0x34afed ? _0x34afed + 'Hidden' : 'hidden';
        },
        'getVisibilityEventName': function(_0x4a9986) {
            return (_0x4a9986 ? _0x4a9986 : '') + 'visibilitychange';
        },
        'getVisibilityStateName': function(_0x541c10) {
            return _0x541c10 ? _0x541c10 + 'VisibilityState' : 'visibilityState';
        },
        'hasView': function() {
            return !(document[this['hiddenPropertyName']] || 'visible' !== document[this['visibilityStateName']]);
        },
        'hasFocus': function() {
            return document['hasFocus']() || this['isFocused'];
        },
        'onOverlayShow': function() {
            this['systemPaused'](), this['isShowingOverlay'] = !0x0;
        },
        'onOverlayHide': function() {
            this['isShowingOverlay'] = !0x1, this['systemResumed']();
        },
        'systemPaused': function() {
            if (this['isPaused']) return !0x1;
            return this['pauseHandler'](), this['isPaused'] = !0x0;
        },
        'systemResumed': function() {
            if (!this['isPaused'] || !this['hasView']() || this['isShowingOverlay']) return !0x1;
            if (!this['hasFocus']()) {
                if (ig['ua']['mobile']) {
                    if (this['isKaiOS']()) {
                        if (!this['config']['allowResumeWithoutFocus']['mobile']['kaios']) return !0x1;
                    } else {
                        if (!this['config']['allowResumeWithoutFocus']['mobile']['default']) return !0x1;
                    }
                } else {
                    if (!this['config']['allowResumeWithoutFocus']['desktop']) return !0x1;
                }
            }
            return this['focusOnResume'](), this['resumeHandler'](), this['focusAfterResume'](), this['isPaused'] = !0x1, !0x0;
        },
        'isKaiOS': function() {
            return /KAIOS/ ['test'](navigator['userAgent']) || !0x1;
        },
        'focusOnResume': function() {
            return ig['ua']['mobile'] ? this['isKaiOS']() ? this['config']['autoFocusOnResume']['mobile']['kaios'] : this['config']['autoFocusOnResume']['mobile']['default'] : this['config']['autoFocusOnResume']['desktop'];
        },
        'focusAfterResume': function() {
            return ig['ua']['mobile'] ? this['isKaiOS']() ? this['config']['autoFocusAfterResume']['mobile']['kaios'] : this['config']['autoFocusAfterResume']['mobile']['default'] : this['config']['autoFocusAfterResume']['desktop'];
        },
        'focus': function(_0xec057f) {
            window['focus'] && _0xec057f && window['focus']();
        },
        'handleDelayedEvent': function(_0x307d6b) {
            if (!this['hasView']() || 'pause' === _0x307d6b['type'] || 'pageHide' === _0x307d6b['type'] || 'blur' === _0x307d6b['type'] || 'focusout' === _0x307d6b['type']) {
                if ('blur' === _0x307d6b['type'] || 'focusout' === _0x307d6b['type']) {
                    if (_0x307d6b['srcElement'] && 'text' === _0x307d6b['srcElement']['type']) return !0x1;
                    this['isFocused'] = !0x1;
                }
                return this['systemPaused'](_0x307d6b);
            }
            if ('focus' === _0x307d6b['type'] || 'focusin' === _0x307d6b['type']) this['isFocused'] = !0x0;
            return this['systemResumed'](_0x307d6b);
        },
        'startDelayedEventHandler': function(_0x1dc516) {
            ig['ua']['mobile'] ? this['isKaiOS']() ? 0x0 < this['config']['handlerDelay']['mobile']['kaios'] ? window['setTimeout'](function(_0x98047e) {
                this['handleDelayedEvent'](_0x98047e);
            }['bind'](this, _0x1dc516), this['config']['handlerDelay']['mobile']) : this['handleDelayedEvent'](_0x1dc516) : 0x0 < this['config']['handlerDelay']['mobile']['default'] ? window['setTimeout'](function(_0x567432) {
                this['handleDelayedEvent'](_0x567432);
            }['bind'](this, _0x1dc516), this['config']['handlerDelay']['mobile']) : this['handleDelayedEvent'](_0x1dc516) : 0x0 < this['config']['handlerDelay']['desktop'] ? window['setTimeout'](function(_0x444fe1) {
                this['handleDelayedEvent'](_0x444fe1);
            }['bind'](this, _0x1dc516), this['config']['handlerDelay']['desktop']) : this['handleDelayedEvent'](_0x1dc516);
        },
        'onChange': function(_0x23c45c) {
            this['startDelayedEventHandler'](_0x23c45c);
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.storage')['defines'](function() {
    ig['Storage'] = ig['Class']['extend']({
        'staticInstantiate': function() {
            return !ig['Storage']['instance'] ? null : ig['Storage']['instance'];
        },
        'init': function() {
            ig['Storage']['instance'] = this;
        },
        'isCapable': function() {
            return 'undefined' !== typeof window['localStorage'];
        },
        'isSet': function(_0x533d7a) {
            return null !== this['get'](_0x533d7a);
        },
        'initUnset': function(_0x5ef39c, _0x322417) {
            null === this['get'](_0x5ef39c) && this['set'](_0x5ef39c, _0x322417);
        },
        'get': function(_0x29caf4) {
            if (!this['isCapable']()) return null;
            try {
                return JSON['parse'](localStorage['getItem'](_0x29caf4));
            } catch (_0x1eff3c) {
                return window['localStorage']['getItem'](_0x29caf4);
            }
        },
        'getInt': function(_0x1e63b3) {
            return ~~this['get'](_0x1e63b3);
        },
        'getFloat': function(_0x4f21dc) {
            return parseFloat(this['get'](_0x4f21dc));
        },
        'getBool': function(_0x3f667a) {
            return !!this['get'](_0x3f667a);
        },
        'key': function(_0xedf276) {
            return this['isCapable']() ? window['localStorage']['key'](_0xedf276) : null;
        },
        'set': function(_0x49f2ca, _0x266868) {
            if (!this['isCapable']()) return null;
            try {
                window['localStorage']['setItem'](_0x49f2ca, JSON['stringify'](_0x266868));
            } catch (_0x30a803) {
                console['log'](_0x30a803);
            }
        },
        'setHighest': function(_0x17d729, _0x5969bf) {
            _0x5969bf > this['getFloat'](_0x17d729) && this['set'](_0x17d729, _0x5969bf);
        },
        'remove': function(_0x535b57) {
            if (!this['isCapable']()) return null;
            window['localStorage']['removeItem'](_0x535b57);
        },
        'clear': function() {
            if (!this['isCapable']()) return null;
            window['localStorage']['clear']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.mouse')['requires']('plugins.data.vector')['defines'](function() {
    Mouse = ig['Class']['extend']({
        'pos': new Vector2(0x0, 0x0),
        'bindings': {
            'click': [ig['KEY']['MOUSE1']]
        },
        'init': function() {
            ig['input']['initMouse']();
            for (var _0xaa1899 in this['bindings']) {
                this[_0xaa1899] = _0xaa1899;
                for (var _0x150b75 = 0x0; _0x150b75 < this['bindings'][_0xaa1899]['length']; _0x150b75++) ig['input']['bind'](this['bindings'][_0xaa1899][_0x150b75], _0xaa1899);
            }
        },
        'getLast': function() {
            return this['pos'];
        },
        'getPos': function() {
            var _0xdc9f21 = ig['system']['scale'] * ((ig['system']['canvas']['offsetWidth'] || ig['system']['realWidth']) / ig['system']['realWidth']);
            return this['pos']['set'](ig['input']['mouse']['x'] * _0xdc9f21 / ig['sizeHandler']['sizeRatio']['x'] / ig['sizeHandler']['scaleRatioMultiplier']['x'], ig['input']['mouse']['y'] * _0xdc9f21 / ig['sizeHandler']['sizeRatio']['y'] / ig['sizeHandler']['scaleRatioMultiplier']['y']), this['pos']['clone']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.keyboard')['defines'](function() {
    Keyboard = ig['Class']['extend']({
        'bindings': {
            'jump': [ig['KEY']['W'], ig['KEY']['UP_ARROW']],
            'moveright': [ig['KEY']['D'], ig['KEY']['RIGHT_ARROW']],
            'moveleft': [ig['KEY']['A'], ig['KEY']['LEFT_ARROW']],
            'shoot': [ig['KEY']['S'], ig['KEY']['DOWN_ARROW'], ig['KEY']['SPACE']]
        },
        'init': function() {
            for (var _0x180e1a in this['bindings']) {
                this[_0x180e1a] = _0x180e1a;
                for (var _0x5aa7ed = 0x0; _0x5aa7ed < this['bindings'][_0x180e1a]['length']; _0x5aa7ed++) ig['input']['bind'](this['bindings'][_0x180e1a][_0x5aa7ed], _0x180e1a);
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.gamepad-input')['defines'](function() {
    ig['PADKEY'] = {
        'BUTTON_0': 0x0,
        'PADBUTTON_1': 0x1,
        'BUTTON_2': 0x2,
        'BUTTON_3': 0x3,
        'BUTTON_LEFT_BUMPER': 0x4,
        'BUTTON_RIGHT_BUMPER': 0x5,
        'BUTTON_LEFT_TRIGGER': 0x6,
        'BUTTON_RIGHT_TRIGGER': 0x7,
        'BUTTON_LEFT_JOYSTICK': 0xa,
        'BUTTON_RIGHT_JOYSTICK': 0xb,
        'BUTTON_DPAD_UP': 0xc,
        'BUTTON_DPAD_DOWN': 0xd,
        'BUTTON_DPAD_LEFT': 0xe,
        'BUTTON_DPAD_RIGHT': 0xf,
        'BUTTON_MENU': 0x10,
        'AXIS_LEFT_JOYSTICK_X': 0x0,
        'AXIS_LEFT_JOYSTICK_Y': 0x1,
        'AXIS_RIGHT_JOYSTICK_X': 0x2,
        'AXIS_RIGHT_JOYSTICK_Y': 0x3
    }, ig['GamepadInput'] = ig['Class']['extend']({
        'isInit': !0x1,
        'isSupported': !0x1,
        'list': [],
        'bindings': {},
        'states': {},
        'presses': {},
        'releases': {},
        'downLocks': {},
        'upLocks': {},
        'leftStick': {
            'x': 0x0,
            'y': 0x0
        },
        'rightStick': {
            'x': 0x0,
            'y': 0x0
        },
        'start': function() {
            if (!this['isInit']) {
                this['isInit'] = !0x0;
                var _0xfc3c24 = navigator['getGamepads'] || navigator['webkitGetGamepads'];
                _0xfc3c24 && (!navigator['getGamepads'] && navigator['webkitGetGamepads'] && (navigator['getGamepads'] = navigator['webkitGetGamepads']), this['list'] = navigator['getGamepads']()), this['isSupported'] = _0xfc3c24;
            }
        },
        'isAvailable': function() {
            return this['isInit'] && this['isSupported'];
        },
        'buttonPressed': function(_0x9efb5b) {
            return 'object' == typeof _0x9efb5b ? _0x9efb5b['pressed'] : 0x1 == _0x9efb5b;
        },
        'buttonDown': function(_0x3a885d) {
            if (_0x3a885d = this['bindings'][_0x3a885d]) this['states'][_0x3a885d] = !0x0, this['downLocks'][_0x3a885d] || (this['presses'][_0x3a885d] = !0x0, this['downLocks'][_0x3a885d] = !0x0);
        },
        'buttonUp': function(_0x21c952) {
            if ((_0x21c952 = this['bindings'][_0x21c952]) && this['downLocks'][_0x21c952] && !this['upLocks'][_0x21c952]) this['states'][_0x21c952] = !0x1, this['releases'][_0x21c952] = !0x0, this['upLocks'][_0x21c952] = !0x0;
        },
        'clearPressed': function() {
            for (var _0x2ce018 in this['releases']) this['states'][_0x2ce018] = !0x1, this['downLocks'][_0x2ce018] = !0x1;
            this['releases'] = {}, this['presses'] = {}, this['upLocks'] = {};
        },
        'bind': function(_0x583d32, _0x152ab3) {
            this['bindings'][_0x583d32] = _0x152ab3;
        },
        'unbind': function(_0x475e71) {
            this['releases'][this['bindings'][_0x475e71]] = !0x0, this['bindings'][_0x475e71] = null;
        },
        'unbindAll': function() {
            this['bindings'] = {}, this['states'] = {}, this['presses'] = {}, this['releases'] = {}, this['downLocks'] = {}, this['upLocks'] = {};
        },
        'state': function(_0x2aba33) {
            return this['states'][_0x2aba33];
        },
        'pressed': function(_0x4d4292) {
            return this['presses'][_0x4d4292];
        },
        'released': function(_0x4bd79c) {
            return this['releases'][_0x4bd79c];
        },
        'clamp': function(_0x211c35, _0x31b4fe, _0x58d844) {
            return _0x211c35 < _0x31b4fe ? _0x31b4fe : _0x211c35 > _0x58d844 ? _0x58d844 : _0x211c35;
        },
        'pollGamepads': function() {
            if (this['isSupported']) {
                this['leftStick']['x'] = 0x0, this['leftStick']['y'] = 0x0, this['rightStick']['x'] = 0x0, this['rightStick']['y'] = 0x0, this['list'] = navigator['getGamepads']();
                for (var _0x43fbfd in this['bindings']) {
                    for (var _0x179d14 = !0x1, _0x2d3eb4 = 0x0; _0x2d3eb4 < this['list']['length']; _0x2d3eb4++) {
                        var _0x1b4077 = this['list'][_0x2d3eb4];
                        if (_0x1b4077 && _0x1b4077['buttons'] && this['buttonPressed'](_0x1b4077['buttons'][_0x43fbfd])) {
                            _0x179d14 = !0x0;
                            break;
                        }
                    }
                    _0x179d14 ? this['buttonDown'](_0x43fbfd) : this['buttonUp'](_0x43fbfd);
                }
                for (_0x2d3eb4 = 0x0; _0x2d3eb4 < this['list']['length']; _0x2d3eb4++)
                    if ((_0x1b4077 = this['list'][_0x2d3eb4]) && _0x1b4077['axes']) {
                        _0x43fbfd = _0x1b4077['axes'][ig['GAMEPADINPUT']['AXIS_LEFT_JOYSTICK_X']];
                        var _0x179d14 = _0x1b4077['axes'][ig['GAMEPADINPUT']['AXIS_LEFT_JOYSTICK_Y']],
                            _0xc2aee8 = _0x1b4077['axes'][ig['GAMEPADINPUT']['AXIS_RIGHT_JOYSTICK_X']],
                            _0x1b4077 = _0x1b4077['axes'][ig['GAMEPADINPUT']['AXIS_RIGHT_JOYSTICK_Y']];
                        this['leftStick']['x'] += isNaN(_0x43fbfd) ? 0x0 : _0x43fbfd, this['leftStick']['y'] += isNaN(_0x179d14) ? 0x0 : _0x179d14, this['rightStick']['x'] += isNaN(_0xc2aee8) ? 0x0 : _0xc2aee8, this['rightStick']['y'] += isNaN(_0x1b4077) ? 0x0 : _0x1b4077;
                    }
                0x0 < this['list']['length'] && (this['leftStick']['x'] = this['clamp'](this['leftStick']['x'], -0x1, 0x1), this['leftStick']['y'] = this['clamp'](this['leftStick']['y'], -0x1, 0x1), this['rightStick']['x'] = this['clamp'](this['rightStick']['x'], -0x1, 0x1), this['rightStick']['y'] = this['clamp'](this['rightStick']['y'], -0x1, 0x1));
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.gamepad')['requires']('plugins.io.gamepad-input')['defines'](function() {
    Gamepad = ig['Class']['extend']({
        'bindings': {
            'padJump': [ig['PADKEY']['BUTTON_0']]
        },
        'init': function() {
            ig['gamepadInput']['start']();
            for (var _0x280970 in this['bindings'])
                for (var _0x3ca406 = 0x0; _0x3ca406 < this['bindings'][_0x280970]['length']; _0x3ca406++) ig['gamepadInput']['bind'](this['bindings'][_0x280970][_0x3ca406], _0x280970);
        },
        'press': function() {},
        'held': function() {},
        'release': function() {}
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.multitouch')['defines'](function() {
    Multitouch = ig['Class']['extend']({
        'init': function() {
            ig['multitouchInput']['start']();
        },
        'getTouchesPos': function() {
            if (ig['ua']['mobile']) {
                if (0x0 < ig['multitouchInput']['touches']['length']) {
                    for (var _0x1ddbdd = [], _0x2cbbdc = 0x0; _0x2cbbdc < ig['multitouchInput']['touches']['length']; _0x2cbbdc++) {
                        var _0x5e33ba = ig['multitouchInput']['touches'][_0x2cbbdc];
                        _0x1ddbdd['push']({
                            'x': _0x5e33ba['x'],
                            'y': _0x5e33ba['y']
                        });
                    }
                    return _0x1ddbdd;
                }
                return null;
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.multitouch-input')['defines'](function() {
    ig['MultitouchInput'] = ig['Class']['extend']({
        'isStart': !0x1,
        'touches': [],
        'multitouchCapable': !0x1,
        'lastEventUp': null,
        'start': function() {
            this['isStart'] || (this['isStart'] = !0x0, navigator['maxTouchPoints'] && 0x1 < navigator['maxTouchPoints'] && (this['multitouchCapable'] = !0x0), ig['ua']['touchDevice'] && (window['navigator']['msPointerEnabled'] && (ig['system']['canvas']['addEventListener']('MSPointerDown', this['touchdown']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('MSPointerUp', this['touchup']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('MSPointerMove', this['touchmove']['bind'](this), !0x1), ig['system']['canvas']['style']['msContentZooming'] = 'none', ig['system']['canvas']['style']['msTouchAction'] = 'none'), ig['system']['canvas']['addEventListener']('touchstart', this['touchdown']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('touchend', this['touchup']['bind'](this), !0x1), ig['system']['canvas']['addEventListener']('touchmove', this['touchmove']['bind'](this), !0x1)));
        },
        'touchmove': function(_0x122241) {
            if (ig['ua']['touchDevice']) {
                var _0x439832 = parseInt(ig['system']['canvas']['offsetWidth']) || ig['system']['realWidth'],
                    _0x6cff1e = parseInt(ig['system']['canvas']['offsetHeight']) || ig['system']['realHeight'],
                    _0x439832 = ig['system']['scale'] * (_0x439832 / ig['system']['realWidth']),
                    _0x6cff1e = ig['system']['scale'] * (_0x6cff1e / ig['system']['realHeight']);
                if (_0x122241['touches']) {
                    for (; 0x0 < this['touches']['length'];) this['touches']['pop']();
                    !this['multitouchCapable'] && 0x1 < _0x122241['touches']['length'] && (this['multitouchCapable'] = !0x0);
                    var _0x3e5f2d = {
                        'left': 0x0,
                        'top': 0x0
                    };
                    ig['system']['canvas']['getBoundingClientRect'] && (_0x3e5f2d = ig['system']['canvas']['getBoundingClientRect']());
                    for (var _0x102d4d = 0x0; _0x102d4d < _0x122241['touches']['length']; _0x102d4d++) {
                        var _0x44d771 = _0x122241['touches'][_0x102d4d];
                        _0x44d771 && this['touches']['push']({
                            'x': (_0x44d771['clientX'] - _0x3e5f2d['left']) / _0x439832,
                            'y': (_0x44d771['clientY'] - _0x3e5f2d['top']) / _0x6cff1e
                        });
                    }
                } else this['windowMove'](_0x122241);
            }
            try {
                ig['soundHandler']['unlockWebAudio']();
            } catch (_0x51788f) {}
        },
        'touchdown': function(_0x1a99b6) {
            var _0x258377 = parseInt(ig['system']['canvas']['offsetWidth']) || ig['system']['realWidth'],
                _0x4e2aab = parseInt(ig['system']['canvas']['offsetHeight']) || ig['system']['realHeight'],
                _0x258377 = ig['system']['scale'] * (_0x258377 / ig['system']['realWidth']),
                _0x4e2aab = ig['system']['scale'] * (_0x4e2aab / ig['system']['realHeight']);
            if (window['navigator']['msPointerEnabled']) this['windowKeyDown'](_0x1a99b6);
            else {
                if (ig['ua']['touchDevice'] && _0x1a99b6['touches']) {
                    for (; 0x0 < this['touches']['length'];) this['touches']['pop']();
                    !this['multitouchCapable'] && 0x1 < _0x1a99b6['touches']['length'] && (this['multitouchCapable'] = !0x0);
                    var _0x16bde9 = {
                        'left': 0x0,
                        'top': 0x0
                    };
                    ig['system']['canvas']['getBoundingClientRect'] && (_0x16bde9 = ig['system']['canvas']['getBoundingClientRect']());
                    for (var _0x492449 = 0x0; _0x492449 < _0x1a99b6['touches']['length']; _0x492449++) {
                        var _0x3d2994 = _0x1a99b6['touches'][_0x492449];
                        _0x3d2994 && this['touches']['push']({
                            'x': (_0x3d2994['clientX'] - _0x16bde9['left']) / _0x258377,
                            'y': (_0x3d2994['clientY'] - _0x16bde9['top']) / _0x4e2aab
                        });
                    }
                }
            }
        },
        'touchup': function(_0x234c41) {
            var _0x171cf6 = parseInt(ig['system']['canvas']['offsetWidth']) || ig['system']['realWidth'];
            parseInt(ig['system']['canvas']['offsetHeight']), _0x171cf6 = ig['system']['scale'] * (_0x171cf6 / ig['system']['realWidth']);
            if (window['navigator']['msPointerEnabled']) this['windowKeyUp'](_0x234c41);
            else {
                this['lastEventUp'] = _0x234c41;
                var _0x5e39c0 = {
                    'left': 0x0,
                    'top': 0x0
                };
                ig['system']['canvas']['getBoundingClientRect'] && (_0x5e39c0 = ig['system']['canvas']['getBoundingClientRect']());
                if (ig['ua']['touchDevice']) {
                    _0x234c41 = (_0x234c41['changedTouches'][0x0]['clientX'] - _0x5e39c0['left']) / _0x171cf6;
                    for (_0x171cf6 = 0x0; _0x171cf6 < this['touches']['length']; _0x171cf6++) this['touches'][_0x171cf6]['x'] >= _0x234c41 - 0x28 && this['touches'][_0x171cf6]['x'] <= _0x234c41 + 0x28 && this['touches']['splice'](_0x171cf6, 0x1);
                }
            }
            if (ig['visibilityHandler']) ig['visibilityHandler']['onChange']('focus');
            try {
                ig['soundHandler']['unlockWebAudio']();
            } catch (_0x3ab003) {}
        },
        'windowKeyDown': function(_0x5e0500) {
            var _0x677d68 = parseInt(ig['system']['canvas']['offsetWidth']) || ig['system']['realWidth'],
                _0x542f2c = parseInt(ig['system']['canvas']['offsetHeight']) || ig['system']['realHeight'],
                _0x677d68 = ig['system']['scale'] * (_0x677d68 / ig['system']['realWidth']),
                _0x542f2c = ig['system']['scale'] * (_0x542f2c / ig['system']['realHeight']);
            if (window['navigator']['msPointerEnabled']) {
                var _0x22404d = {
                    'left': 0x0,
                    'top': 0x0
                };
                ig['system']['canvas']['getBoundingClientRect'] && (_0x22404d = ig['system']['canvas']['getBoundingClientRect']()), _0x5e0500 = _0x5e0500['changedTouches'] ? _0x5e0500['changedTouches'] : [_0x5e0500];
                for (var _0x113628 = 0x0; _0x113628 < _0x5e0500['length']; ++_0x113628) {
                    for (var _0x31f5c7 = _0x5e0500[_0x113628], _0x703f48 = 'undefined' != typeof _0x31f5c7['identifier'] ? _0x31f5c7['identifier'] : 'undefined' != typeof _0x31f5c7['pointerId'] ? _0x31f5c7['pointerId'] : 0x1, _0x5aedaa = (_0x31f5c7['clientX'] - _0x22404d['left']) / _0x677d68, _0x31f5c7 = (_0x31f5c7['clientY'] - _0x22404d['top']) / _0x542f2c, _0x4bb339 = 0x0; _0x4bb339 < this['touches']['length']; ++_0x4bb339) this['touches'][_0x4bb339]['identifier'] == _0x703f48 && this['touches']['splice'](_0x4bb339, 0x1);
                    this['touches']['push']({
                        'x': _0x5aedaa,
                        'y': _0x31f5c7,
                        'identifier': _0x703f48
                    });
                }
                for (_0x677d68 = 0x0; _0x677d68 < this['touches']['length']; _0x677d68++);
            }
        },
        'windowKeyUp': function(_0x13a49a) {
            _0x13a49a = 'undefined' != typeof _0x13a49a['identifier'] ? _0x13a49a['identifier'] : 'undefined' != typeof _0x13a49a['pointerId'] ? _0x13a49a['pointerId'] : 0x1;
            for (var _0x28898f = 0x0; _0x28898f < this['touches']['length']; ++_0x28898f) this['touches'][_0x28898f]['identifier'] == _0x13a49a && this['touches']['splice'](_0x28898f, 0x1);
            for (; 0x0 < this['touches']['length'];) this['touches']['pop']();
            if (ig['visibilityHandler']) ig['visibilityHandler']['onChange']('focus');
            try {
                ig['soundHandler']['unlockWebAudio']();
            } catch (_0x14208b) {}
        },
        'windowMove': function(_0x2f040a) {
            var _0x83c505 = parseInt(ig['system']['canvas']['offsetWidth']) || ig['system']['realWidth'],
                _0x5d521c = parseInt(ig['system']['canvas']['offsetHeight']) || ig['system']['realHeight'],
                _0x83c505 = ig['system']['scale'] * (_0x83c505 / ig['system']['realWidth']),
                _0x5d521c = ig['system']['scale'] * (_0x5d521c / ig['system']['realHeight']),
                _0x237110 = {
                    'left': 0x0,
                    'top': 0x0
                };
            ig['system']['canvas']['getBoundingClientRect'] && (_0x237110 = ig['system']['canvas']['getBoundingClientRect']());
            if (window['navigator']['msPointerEnabled']) {
                for (var _0x4e11b3 = 'undefined' != typeof _0x2f040a['identifier'] ? _0x2f040a['identifier'] : 'undefined' != typeof _0x2f040a['pointerId'] ? _0x2f040a['pointerId'] : 0x1, _0x4ed450 = 0x0; _0x4ed450 < this['touches']['length']; ++_0x4ed450)
                    if (this['touches'][_0x4ed450]['identifier'] == _0x4e11b3) {
                        var _0x131309 = (_0x2f040a['clientY'] - _0x237110['top']) / _0x5d521c;
                        this['touches'][_0x4ed450]['x'] = (_0x2f040a['clientX'] - _0x237110['left']) / _0x83c505, this['touches'][_0x4ed450]['y'] = _0x131309;
                    }
            }
            try {
                ig['soundHandler']['unlockWebAudio']();
            } catch (_0x36e83c) {}
        },
        'clear': function() {
            for (var _0x1bcb70 = 0x0; _0x1bcb70 < this['released']['length']; ++_0x1bcb70) this['released'][_0x1bcb70] && (this['released']['splice'](_0x1bcb70, 0x1), _0x1bcb70--);
        },
        'pollMultitouch': function(_0x3c7348) {
            !this['multitouchCapable'] && 0x1 < _0x3c7348 && (this['multitouchCapable'] = !0x0);
        },
        'spliceFromArray': function(_0x4e6431, _0x1b46c4) {
            for (var _0x408141 = 0x0; _0x408141 < _0x1b46c4['length']; _0x408141++)
                for (var _0x26ed25 = 0x0; _0x26ed25 < _0x4e6431['length']; _0x26ed25++) _0x4e6431[_0x26ed25]['identifier'] === _0x1b46c4[_0x408141]['identifier'] && (_0x4e6431['splice'](_0x26ed25, 0x1), _0x26ed25--);
        },
        'updateSizeProperties': function() {
            var _0x5e3cc9 = parseInt(ig['system']['canvas']['offsetWidth']) || ig['system']['realWidth'],
                _0x62ee68 = parseInt(ig['system']['canvas']['offsetHeight']) || ig['system']['realHeight'];
            this['scaleX'] = ig['system']['scale'] * (_0x5e3cc9 / ig['system']['realWidth']), this['scaleY'] = ig['system']['scale'] * (_0x62ee68 / ig['system']['realHeight']);
        },
        'upgrade': function(_0x57b974, _0x115d42, _0xa691ca) {
            var _0x5cfc5b = {
                'left': 0x0,
                'top': 0x0
            };
            ig['system']['canvas']['getBoundingClientRect'] && (_0x5cfc5b = ig['system']['canvas']['getBoundingClientRect']());
            for (var _0x1064d6 = (_0xa691ca['clientX'] - _0x5cfc5b['left']) / this['scaleX'], _0x5cfc5b = (_0xa691ca['clientY'] - _0x5cfc5b['top']) / this['scaleY'], _0x2cd83f = 0x0; _0x2cd83f < _0x57b974['length']; _0x2cd83f++)
                if (void 0x0 !== typeof _0x57b974[_0x2cd83f]['identifier'] && void 0x0 !== typeof _0xa691ca['identifier'] && _0xa691ca['identifier'] === _0x57b974[_0x2cd83f]['identifier']) {
                    _0x57b974['splice'](_0x2cd83f, 0x1), _0x115d42['push']({
                        'identifier': _0xa691ca['identifier'],
                        'x': _0x1064d6,
                        'y': _0x5cfc5b
                    });
                    break;
                }
        },
        'updateArray': function(_0x123b5c, _0x58efa0) {
            var _0xe0beea = {
                'left': 0x0,
                'top': 0x0
            };
            ig['system']['canvas']['getBoundingClientRect'] && (_0xe0beea = ig['system']['canvas']['getBoundingClientRect']());
            for (var _0x4d93e4 = (_0x58efa0['clientX'] - _0xe0beea['left']) / this['scaleX'], _0xe0beea = (_0x58efa0['clientY'] - _0xe0beea['top']) / this['scaleY'], _0x3a3b9e = 0x0; _0x3a3b9e < _0x123b5c['length']; _0x3a3b9e++)
                if (void 0x0 !== typeof _0x123b5c[_0x3a3b9e]['identifier'] && void 0x0 !== typeof _0x58efa0['identifier'] && _0x58efa0['identifier'] === _0x123b5c[_0x3a3b9e]['identifier']) {
                    _0x123b5c[_0x3a3b9e]['x'] = _0x4d93e4, _0x123b5c[_0x3a3b9e]['y'] = _0xe0beea;
                    break;
                }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.fake-storage')['requires']('impact.game')['defines'](function() {
    ig['FakeStorage'] = ig['Class']['extend']({
        'tempData': {},
        'init': function() {
            ig['FakeStorage']['instance'] = this;
        },
        'initUnset': function(_0x1bba9d, _0x214fd1) {
            null === this['get'](_0x1bba9d) && this['set'](_0x1bba9d, _0x214fd1);
        },
        'set': function(_0x417925, _0x2701a5) {
            this['tempData'][_0x417925] = JSON['stringify'](_0x2701a5);
        },
        'setHighest': function(_0x293087, _0x4167f1) {
            _0x4167f1 > this['getFloat'](_0x293087) && this['set'](_0x293087, _0x4167f1);
        },
        'get': function(_0x5e7539) {
            return 'undefined' == typeof this['tempData'][_0x5e7539] ? null : JSON['parse'](this['tempData'][_0x5e7539]);
        },
        'getInt': function(_0x313c22) {
            return ~~this['get'](_0x313c22);
        },
        'getFloat': function(_0x2432a8) {
            return parseFloat(this['get'](_0x2432a8));
        },
        'getBool': function(_0x1d32a3) {
            return !!this['get'](_0x1d32a3);
        },
        'isSet': function(_0x29eec9) {
            return null !== this['get'](_0x29eec9);
        },
        'remove': function(_0x4bdfe7) {
            delete this['tempData'][_0x4bdfe7];
        },
        'clear': function() {
            this['tempData'] = {};
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.io-manager')['requires']('plugins.io.storage', 'plugins.io.mouse', 'plugins.io.keyboard', 'plugins.io.gamepad', 'plugins.io.multitouch', 'plugins.io.multitouch-input', 'plugins.io.gamepad-input', 'plugins.io.fake-storage')['defines'](function() {
    IoManager = ig['Class']['extend']({
        'version': '1.0.0',
        'storage': null,
        'localStorageSupport': !0x1,
        'mouse': null,
        'keyboard': null,
        'multitouch': null,
        'gamepad': null,
        'init': function() {
            ig['multitouchInput'] = new ig['MultitouchInput'](), ig['gamepadInput'] = new ig['GamepadInput'](), this['unbindAll'](), this['initStorage'](), this['initMouse'](), this['initKeyboard']();
        },
        'unbindAll': function() {
            ig['input']['unbindAll'](), ig['gamepadInput']['unbindAll']();
        },
        'initStorage': function() {
            try {
                window['localStorage']['setItem']('test', 'test'), window['localStorage']['removeItem']('test'), this['storage'] = new ig['Storage']();
            } catch (_0x20d97a) {
                console['log']('using\x20fake\x20storage'), this['storage'] = new ig['FakeStorage']();
            }
        },
        'initMouse': function() {
            this['mouse'] = new Mouse();
        },
        'initKeyboard': function() {
            this['keyboard'] = new Keyboard();
        },
        'initMultitouch': function() {
            this['multitouch'] = new Multitouch();
        },
        'initGamepad': function() {
            this['gamepad'] = new Gamepad();
        },
        'press': function(_0x57d102) {
            return ig['input']['pressed'](_0x57d102) || this['gamepad'] && this['gamepad']['press'](_0x57d102) ? !0x0 : !0x1;
        },
        'held': function(_0x33a3da) {
            return ig['input']['state'](_0x33a3da) || this['gamepad'] && this['gamepad']['state'](_0x33a3da) ? !0x0 : !0x1;
        },
        'release': function(_0x321096) {
            return ig['input']['released'](_0x321096) || this['gamepad'] && this['gamepad']['released'](_0x321096) ? !0x0 : !0x1;
        },
        'getClickPos': function() {
            return this['mouse']['getPos']();
        },
        'getLastClickPos': function() {
            return this['mouse']['getLast']();
        },
        'getTouchesPos': function() {
            return this['multitouch']['getTouchesPos']();
        },
        'checkOverlap': function(_0x3f67b5, _0x2b20ea, _0x508651, _0x45330b, _0xc3cc2d) {
            return _0x3f67b5['x'] > _0x2b20ea + _0x45330b || _0x3f67b5['x'] < _0x2b20ea || _0x3f67b5['y'] > _0x508651 + _0xc3cc2d || _0x3f67b5['y'] < _0x508651 ? !0x1 : !0x0;
        },
        'clear': function() {
            ig['multitouchInput']['clear']();
        },
        '_supportsLocalStorage': function() {
            try {
                return localStorage['setItem']('test', 'test'), localStorage['removeItem']('test'), this['localStorageSupport'] = 'localStorage' in window && null !== window['localStorage'];
            } catch (_0x194875) {
                return this['localStorageSupport'];
            }
        },
        'storageIsSet': function(_0x21383e) {
            return 'function' === typeof this['storage']['isSet'] ? this['storage']['isSet'](_0x21383e) : null;
        },
        'storageGet': function(_0x2dc397) {
            return 'function' === typeof this['storage']['get'] ? this['storage']['get'](_0x2dc397) : null;
        },
        'storageSet': function(_0x3cba89, _0x3de941) {
            return 'function' === typeof this['storage']['set'] ? this['storage']['set'](_0x3cba89, _0x3de941) : null;
        },
        'assert': function(_0x11093d, _0x32d29d, _0x253326) {
            if (_0x32d29d !== _0x253326) throw 'actualValue:' + _0x32d29d + '\x20not\x20equal\x20to\x20testValue:' + _0x253326 + '\x20at\x20' + _0x11093d;
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.io.storage-manager')['requires']('impact.game', 'plugins.io.io-manager')['defines'](function() {
    ig['Game']['prototype']['name'] = 'MJS-Game', ig['Game']['prototype']['version'] = '1.0.0', ig['Game']['prototype']['sessionData'] = {}, ig['Game']['prototype']['initData'] = function() {
        return this['sessionData'] = {
            'sound': 0.5,
            'music': 0.5,
            'level': 0x1,
            'score': 0x0
        };
    }, ig['Game']['prototype']['setupStorageManager'] = function() {
        'undefined' === typeof this['name'] ? console['error']('Cannot\x20found\x20Game\x20Name,\x20Storage\x20Manager\x20Cancelled.') : 'undefined' === typeof this['version'] ? console['error']('Cannot\x20found\x20Game\x20Version,\x20Storage\x20Manager\x20Cancelled.') : (this['io'] || (this['io'] = new IoManager(), console['log']('IO\x20Manager\x20doesn\x27t\x20existed.\x20Initialize...')), console['log']('Plug\x20in\x20Storage\x20Manager'), this['storage'] = this['io']['storage'], this['storageName'] = this['name'] + '-v' + this['version'], this['loadAll']());
    }, ig['Game']['prototype']['loadAll'] = function() {
        var _0x5b5240 = this['storage']['get'](this['storageName']);
        if (null === _0x5b5240 || 'undefined' === typeof _0x5b5240) _0x5b5240 = this['initData']();
        for (var _0x4e2a5c in _0x5b5240) this['sessionData'][_0x4e2a5c] = _0x5b5240[_0x4e2a5c];
        this['storage']['set'](this['storageName'], _0x5b5240);
    }, ig['Game']['prototype']['saveAll'] = function() {
        var _0x1e50c8 = this['storage']['get'](this['storageName']),
            _0xda9d1f;
        for (_0xda9d1f in _0x1e50c8) _0x1e50c8[_0xda9d1f] = this['sessionData'][_0xda9d1f];
        this['storage']['set'](this['storageName'], _0x1e50c8);
    }, ig['Game']['prototype']['load'] = function(_0x479200) {
        return this['storage']['get'](this['storageName'])[_0x479200];
    }, ig['Game']['prototype']['save'] = function(_0x406e64, _0x18144a) {
        var _0x39b12c = this['storage']['get'](this['storageName']);
        _0x39b12c[_0x406e64] = _0x18144a, this['storage']['set'](this['storageName'], _0x39b12c);
    };
}), ig['baked'] = !0x0, ig['module']('plugins.splash-loader')['requires']('impact.loader', 'impact.animation')['defines'](function() {
    ig['SplashLoader'] = ig['Loader']['extend']({
        'tapToStartDivId': 'tap-to-start',
        'bg': new ig['Image']('media/graphics/sprites/bg/bg1.png'),
        'title': new ig['Image']('media/graphics/sprites/title.png'),
        'loadingFrameImage': new ig['Image']('media/graphics/sprites/loading-bg.png'),
        'loadingBarImage': new ig['Image']('media/graphics/sprites/loading-bar.png'),
        'loadingBarSize': {
            'x': 0x142,
            'y': 0x16
        },
        'init': function(_0x26af98, _0x404ba8) {
            this['parent'](_0x26af98, _0x404ba8), ig['apiHandler']['run']('MJSPreroll');
        },
        'end': function() {
            this['parent'](), this['_drawStatus'] = 0x1, _SETTINGS['TapToStartAudioUnlock']['Enabled'] ? this['tapToStartDiv'](function() {
                ig['system']['setGame'](MyGame);
            }) : ig['system']['setGame'](MyGame), this['draw']();
        },
        'tapToStartDiv': function(_0x3ca82f) {
            this['desktopCoverDIV'] = document['getElementById'](this['tapToStartDivId']);
            if (!this['desktopCoverDIV']) {
                this['desktopCoverDIV'] = document['createElement']('div'), this['desktopCoverDIV']['id'] = this['tapToStartDivId'], this['desktopCoverDIV']['setAttribute']('class', 'play'), this['desktopCoverDIV']['setAttribute']('style', 'position:\x20absolute;\x20display:\x20block;\x20z-index:\x20999999;\x20background-color:\x20rgba(23,\x2032,\x2053,\x200.7);\x20visibility:\x20visible;\x20font-size:\x2010vmin;\x20text-align:\x20center;\x20vertical-align:\x20middle;\x20-webkit-touch-callout:\x20none;\x20-webkit-user-select:\x20none;\x20-khtml-user-select:\x20none;\x20-moz-user-select:\x20none;\x20-ms-user-select:\x20none;\x20user-select:\x20none;'), this['desktopCoverDIV']['innerHTML'] = '<div\x20style=\x27color:white;background-color:\x20rgba(255,\x20255,\x20255,\x200.3);\x20border:\x202px\x20solid\x20#fff;\x20font-size:20px;\x20border-radius:\x205px;\x20position:\x20relative;\x20float:\x20left;\x20top:\x2050%;\x20left:\x2050%;\x20transform:\x20translate(-50%,\x20-50%);\x27><div\x20style=\x27padding:20px\x2050px;\x20font-family:\x20Arial;\x27>' + _STRINGS['Splash']['TapToStart'] + '</div></div>', (document['getElementById']('play')['parentNode'] || document['getElementById']('ajaxbar'))['appendChild'](this['desktopCoverDIV']);
                try {
                    'undefined' !== typeof ig['sizeHandler'] ? 'undefined' !== typeof ig['sizeHandler']['coreDivsToResize'] && (ig['sizeHandler']['coreDivsToResize']['push']('#' + this['tapToStartDivId']), 'function' === typeof ig['sizeHandler']['reorient'] && ig['sizeHandler']['reorient']()) : 'undefined' !== typeof coreDivsToResize && (coreDivsToResize['push'](this['tapToStartDivId']), 'function' === typeof sizeHandler && sizeHandler());
                } catch (_0x17bc24) {
                    console['log'](_0x17bc24);
                }
                this['desktopCoverDIV']['addEventListener']('click', function() {
                    ig['soundHandler']['unlockWebAudio'](), this['setAttribute']('style', 'visibility:\x20hidden;'), 'function' === typeof _0x3ca82f && _0x3ca82f();
                });
            }
        },
        'setupCustomAnimation': function() {
            this['animHeight'] = this['customAnim']['height'], this['animWidth'] = this['customAnim']['width'], this['customAnim'] = new ig['Animation'](this['customAnim'], 0.025, [0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7]);
        },
        'animate': function() {
            ig['Timer']['step'](), this['customAnim']['update']();
        },
        'drawCheck': 0x0,
        'draw': function() {
            this['_drawStatus'] += (this['status'] - this['_drawStatus']) / 0x5, 0x1 === this['drawCheck'] && console['log']('Font\x20should\x20be\x20loaded\x20before\x20loader\x20draw\x20loop'), 0x2 > this['drawCheck'] && this['drawCheck']++, ig['system']['context']['fillStyle'] = '#afe597', ig['system']['context']['fillRect'](0x0, 0x0, ig['system']['width'], ig['system']['height']), x = ig['responsive']['width'] / 0x2 - this['loadingBarSize']['x'] / 0x2, y = 0.8 * ig['responsive']['height'], this['bg']['draw'](ig['responsive']['width'] / 0x2 - this['bg']['width'] / 0x2, ig['responsive']['height'] / 0x2 - this['bg']['height'] / 0x2 - 0x96), this['title']['draw'](ig['responsive']['width'] / 0x2 - this['title']['width'] / 0x2, ig['responsive']['height'] / 0x2 - this['title']['height'] / 0x2 - 0x32), this['loadingFrameImage']['draw'](x, y), this['loadingBarImage']['draw'](x + (this['loadingFrameImage']['width'] - this['loadingBarImage']['width']) / 0x2, y + (this['loadingFrameImage']['height'] - this['loadingBarImage']['height']) / 0x2, 0x0, 0x0, this['loadingBarSize']['x'] * this['_drawStatus'], this['loadingBarSize']['y']), ig['system']['context']['measureText'](_STRINGS['Splash']['Loading']), ig['system']['context']['font'] = 'bold\x2014px\x20jellee-roman', ig['system']['context']['fillStyle'] = '#64bed8', this['drawVersion']();
        },
        'drawVersion': function() {
            if ('undefined' !== typeof _SETTINGS['Versioning'] && null !== _SETTINGS['Versioning'] && _SETTINGS['Versioning']['DrawVersion']) {
                var _0x44f47c = ig['system']['context'];
                fontSize = _SETTINGS['Versioning']['FontSize'], fontFamily = _SETTINGS['Versioning']['FontFamily'], fillStyle = _SETTINGS['Versioning']['FillStyle'], _0x44f47c['save'](), _0x44f47c['textBaseline'] = 'bottom', _0x44f47c['textAlign'] = 'left', _0x44f47c['font'] = fontSize + '\x20' + fontFamily || '10px\x20Arial', _0x44f47c['fillStyle'] = fillStyle || '#ffffff', _0x44f47c['fillText']('v' + _SETTINGS['Versioning']['Version'] + '+build.' + _SETTINGS['Versioning']['Build'], 0xa, ig['system']['height'] - 0xa), _0x44f47c['restore']();
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.tween')['requires']('impact.entity')['defines'](function() {
    Array['prototype']['indexOf'] || (Array['prototype']['indexOf'] = function(_0x565355) {
        for (var _0x3b4482 = 0x0; _0x3b4482 < this['length']; ++_0x3b4482)
            if (this[_0x3b4482] === _0x565355) return _0x3b4482;
        return -0x1;
    }), ig['Entity']['prototype']['tweens'] = [], ig['Entity']['prototype']['_preTweenUpdate'] = ig['Entity']['prototype']['update'], ig['Entity']['prototype']['update'] = function() {
        this['_preTweenUpdate']();
        if (0x0 < this['tweens']['length']) {
            for (var _0x28a9cd = [], _0x385a04 = 0x0; _0x385a04 < this['tweens']['length']; _0x385a04++) this['tweens'][_0x385a04]['update'](), this['tweens'][_0x385a04]['complete'] || _0x28a9cd['push'](this['tweens'][_0x385a04]);
            this['tweens'] = _0x28a9cd;
        }
    }, ig['Entity']['prototype']['tween'] = function(_0x182ca7, _0x50c817, _0xed56d1) {
        return _0x182ca7 = new ig['Tween'](this, _0x182ca7, _0x50c817, _0xed56d1), this['tweens']['push'](_0x182ca7), _0x182ca7;
    }, ig['Entity']['prototype']['pauseTweens'] = function() {
        for (var _0x3ff630 = 0x0; _0x3ff630 < this['tweens']['length']; _0x3ff630++) this['tweens'][_0x3ff630]['pause']();
    }, ig['Entity']['prototype']['resumeTweens'] = function() {
        for (var _0x198856 = 0x0; _0x198856 < this['tweens']['length']; _0x198856++) this['tweens'][_0x198856]['resume']();
    }, ig['Entity']['prototype']['stopTweens'] = function(_0x16fb3c) {
        for (var _0x107fba = 0x0; _0x107fba < this['tweens']['length']; _0x107fba++) this['tweens'][_0x107fba]['stop'](_0x16fb3c);
    }, ig['Tween'] = function(_0x2bcf7a, _0x55bc03, _0x190b43, _0x317333) {
        var _0x3c50d0 = {},
            _0x535464 = {},
            _0x92b367 = {},
            _0x5b0ab2 = 0x0,
            _0x5482bb = !0x1,
            _0x3bdc15 = !0x1,
            _0x28d73d = !0x1;
        this['duration'] = _0x190b43, this['paused'] = this['complete'] = !0x1, this['easing'] = ig['Tween']['Easing']['Linear']['EaseNone'], this['onComplete'] = this['onUpdate'] = this['onStart'] = !0x1, this['loop'] = this['delay'] = 0x0, this['loopCount'] = -0x1, ig['merge'](this, _0x317333), this['loopNum'] = this['loopCount'], this['chain'] = function(_0x3834db) {
            _0x28d73d = _0x3834db;
        }, this['initEnd'] = function(_0x1e3278, _0x358277, _0x1163a3) {
            if ('object' !== typeof _0x358277[_0x1e3278]) _0x1163a3[_0x1e3278] = _0x358277[_0x1e3278];
            else {
                for (subprop in _0x358277[_0x1e3278]) _0x1163a3[_0x1e3278] || (_0x1163a3[_0x1e3278] = {}), this['initEnd'](subprop, _0x358277[_0x1e3278], _0x1163a3[_0x1e3278]);
            }
        }, this['initStart'] = function(_0x37ed04, _0x548b2a, _0x59c7b9, _0x972c61) {
            if ('object' !== typeof _0x59c7b9[_0x37ed04]) 'undefined' !== typeof _0x548b2a[_0x37ed04] && (_0x972c61[_0x37ed04] = _0x59c7b9[_0x37ed04]);
            else {
                for (subprop in _0x59c7b9[_0x37ed04]) _0x972c61[_0x37ed04] || (_0x972c61[_0x37ed04] = {}), 'undefined' !== typeof _0x548b2a[_0x37ed04] && this['initStart'](subprop, _0x548b2a[_0x37ed04], _0x59c7b9[_0x37ed04], _0x972c61[_0x37ed04]);
            }
        }, this['start'] = function() {
            this['paused'] = this['complete'] = !0x1, this['loopNum'] = this['loopCount'], _0x5b0ab2 = 0x0, -0x1 == _0x2bcf7a['tweens']['indexOf'](this) && _0x2bcf7a['tweens']['push'](this), _0x3bdc15 = !0x0, _0x5482bb = new ig['Timer']();
            for (var _0x3e70c9 in _0x55bc03) this['initEnd'](_0x3e70c9, _0x55bc03, _0x535464);
            for (_0x3e70c9 in _0x535464) this['initStart'](_0x3e70c9, _0x535464, _0x2bcf7a, _0x3c50d0), this['initDelta'](_0x3e70c9, _0x92b367, _0x2bcf7a, _0x535464);
            if (this['onStart']) this['onStart']();
        }, this['initDelta'] = function(_0x5968ac, _0x3ce711, _0x2d2644, _0x1f12a1) {
            if ('object' !== typeof _0x1f12a1[_0x5968ac]) _0x3ce711[_0x5968ac] = _0x1f12a1[_0x5968ac] - _0x2d2644[_0x5968ac];
            else {
                for (subprop in _0x1f12a1[_0x5968ac]) _0x3ce711[_0x5968ac] || (_0x3ce711[_0x5968ac] = {}), this['initDelta'](subprop, _0x3ce711[_0x5968ac], _0x2d2644[_0x5968ac], _0x1f12a1[_0x5968ac]);
            }
        }, this['propUpdate'] = function(_0x1f7e81, _0x27a57e, _0x4942da, _0x293c98, _0x257bb2) {
            if ('object' !== typeof _0x4942da[_0x1f7e81]) _0x27a57e[_0x1f7e81] = 'undefined' != typeof _0x4942da[_0x1f7e81] ? _0x4942da[_0x1f7e81] + _0x293c98[_0x1f7e81] * _0x257bb2 : _0x27a57e[_0x1f7e81];
            else {
                for (subprop in _0x4942da[_0x1f7e81]) this['propUpdate'](subprop, _0x27a57e[_0x1f7e81], _0x4942da[_0x1f7e81], _0x293c98[_0x1f7e81], _0x257bb2);
            }
        }, this['propSet'] = function(_0x4bfe5f, _0x379ed8, _0x388787) {
            if ('object' !== typeof _0x379ed8[_0x4bfe5f]) _0x388787[_0x4bfe5f] = _0x379ed8[_0x4bfe5f];
            else {
                for (subprop in _0x379ed8[_0x4bfe5f]) _0x388787[_0x4bfe5f] || (_0x388787[_0x4bfe5f] = {}), this['propSet'](subprop, _0x379ed8[_0x4bfe5f], _0x388787[_0x4bfe5f]);
            }
        }, this['update'] = function() {
            if (!_0x3bdc15) return !0x1;
            if (this['delay']) {
                if (_0x5482bb['delta']() < this['delay']) return;
                this['delay'] = 0x0, _0x5482bb['reset']();
            }
            if (this['paused'] || this['complete']) return !0x1;
            var _0xf8bed3 = (_0x5482bb['delta']() + _0x5b0ab2) / this['duration'],
                _0xf8bed3 = 0x1 < _0xf8bed3 ? 0x1 : _0xf8bed3,
                _0x1bd209 = this['easing'](_0xf8bed3);
            for (property in _0x92b367) this['propUpdate'](property, _0x2bcf7a, _0x3c50d0, _0x92b367, _0x1bd209);
            if (this['onUpdate']) this['onUpdate']();
            if (0x1 <= _0xf8bed3) {
                if (0x0 == this['loopNum'] || !this['loop']) {
                    this['complete'] = !0x0;
                    if (this['onComplete']) this['onComplete']();
                    return _0x28d73d && _0x28d73d['start'](), !0x1;
                }
                if (this['loop'] == ig['Tween']['Loop']['Revert']) {
                    for (property in _0x3c50d0) this['propSet'](property, _0x3c50d0, _0x2bcf7a);
                    _0x5b0ab2 = 0x0, _0x5482bb['reset'](), -0x1 != this['loopNum'] && this['loopNum']--;
                } else {
                    if (this['loop'] == ig['Tween']['Loop']['Reverse']) {
                        _0xf8bed3 = {}, _0x1bd209 = {}, ig['merge'](_0xf8bed3, _0x535464), ig['merge'](_0x1bd209, _0x3c50d0), ig['merge'](_0x3c50d0, _0xf8bed3), ig['merge'](_0x535464, _0x1bd209);
                        for (property in _0x535464) this['initDelta'](property, _0x92b367, _0x2bcf7a, _0x535464);
                        _0x5b0ab2 = 0x0, _0x5482bb['reset'](), -0x1 != this['loopNum'] && this['loopNum']--;
                    }
                }
            }
        }, this['pause'] = function() {
            this['paused'] = !0x0, _0x5482bb && _0x5482bb['delta'] && (_0x5b0ab2 += _0x5482bb['delta']());
        }, this['resume'] = function() {
            this['paused'] = !0x1, _0x5482bb && _0x5482bb['reset'] && _0x5482bb['reset']();
        }, this['stop'] = function(_0x261f90) {
            _0x261f90 && (this['loop'] = this['complete'] = this['paused'] = !0x1, _0x5b0ab2 += _0x190b43, this['update']()), this['complete'] = !0x0;
        };
    }, ig['Tween']['Loop'] = {
        'Revert': 0x1,
        'Reverse': 0x2
    }, ig['Tween']['Easing'] = {
        'Linear': {},
        'Quadratic': {},
        'Cubic': {},
        'Quartic': {},
        'Quintic': {},
        'Sinusoidal': {},
        'Exponential': {},
        'Circular': {},
        'Elastic': {},
        'Back': {},
        'Bounce': {}
    }, ig['Tween']['Easing']['Linear']['EaseNone'] = function(_0x4d655c) {
        return _0x4d655c;
    }, ig['Tween']['Easing']['Quadratic']['EaseIn'] = function(_0x4bc725) {
        return _0x4bc725 * _0x4bc725;
    }, ig['Tween']['Easing']['Quadratic']['EaseOut'] = function(_0x12f271) {
        return -_0x12f271 * (_0x12f271 - 0x2);
    }, ig['Tween']['Easing']['Quadratic']['EaseInOut'] = function(_0x8e3e66) {
        return 0x1 > (_0x8e3e66 *= 0x2) ? 0.5 * _0x8e3e66 * _0x8e3e66 : -0.5 * (--_0x8e3e66 * (_0x8e3e66 - 0x2) - 0x1);
    }, ig['Tween']['Easing']['Cubic']['EaseIn'] = function(_0xbcf795) {
        return _0xbcf795 * _0xbcf795 * _0xbcf795;
    }, ig['Tween']['Easing']['Cubic']['EaseOut'] = function(_0xdb6984) {
        return --_0xdb6984 * _0xdb6984 * _0xdb6984 + 0x1;
    }, ig['Tween']['Easing']['Cubic']['EaseInOut'] = function(_0x2fee15) {
        return 0x1 > (_0x2fee15 *= 0x2) ? 0.5 * _0x2fee15 * _0x2fee15 * _0x2fee15 : 0.5 * ((_0x2fee15 -= 0x2) * _0x2fee15 * _0x2fee15 + 0x2);
    }, ig['Tween']['Easing']['Quartic']['EaseIn'] = function(_0x5d0aa5) {
        return _0x5d0aa5 * _0x5d0aa5 * _0x5d0aa5 * _0x5d0aa5;
    }, ig['Tween']['Easing']['Quartic']['EaseOut'] = function(_0x40a404) {
        return -(--_0x40a404 * _0x40a404 * _0x40a404 * _0x40a404 - 0x1);
    }, ig['Tween']['Easing']['Quartic']['EaseInOut'] = function(_0x365c7c) {
        return 0x1 > (_0x365c7c *= 0x2) ? 0.5 * _0x365c7c * _0x365c7c * _0x365c7c * _0x365c7c : -0.5 * ((_0x365c7c -= 0x2) * _0x365c7c * _0x365c7c * _0x365c7c - 0x2);
    }, ig['Tween']['Easing']['Quintic']['EaseIn'] = function(_0x4dafc3) {
        return _0x4dafc3 * _0x4dafc3 * _0x4dafc3 * _0x4dafc3 * _0x4dafc3;
    }, ig['Tween']['Easing']['Quintic']['EaseOut'] = function(_0x46b62f) {
        return (_0x46b62f -= 0x1) * _0x46b62f * _0x46b62f * _0x46b62f * _0x46b62f + 0x1;
    }, ig['Tween']['Easing']['Quintic']['EaseInOut'] = function(_0x58bd43) {
        return 0x1 > (_0x58bd43 *= 0x2) ? 0.5 * _0x58bd43 * _0x58bd43 * _0x58bd43 * _0x58bd43 * _0x58bd43 : 0.5 * ((_0x58bd43 -= 0x2) * _0x58bd43 * _0x58bd43 * _0x58bd43 * _0x58bd43 + 0x2);
    }, ig['Tween']['Easing']['Sinusoidal']['EaseIn'] = function(_0x6760ff) {
        return -Math['cos'](_0x6760ff * Math['PI'] / 0x2) + 0x1;
    }, ig['Tween']['Easing']['Sinusoidal']['EaseOut'] = function(_0x169682) {
        return Math['sin'](_0x169682 * Math['PI'] / 0x2);
    }, ig['Tween']['Easing']['Sinusoidal']['EaseInOut'] = function(_0x4cbde3) {
        return -0.5 * (Math['cos'](Math['PI'] * _0x4cbde3) - 0x1);
    }, ig['Tween']['Easing']['Exponential']['EaseIn'] = function(_0x36da17) {
        return 0x0 == _0x36da17 ? 0x0 : Math['pow'](0x2, 0xa * (_0x36da17 - 0x1));
    }, ig['Tween']['Easing']['Exponential']['EaseOut'] = function(_0x134b56) {
        return 0x1 == _0x134b56 ? 0x1 : -Math['pow'](0x2, -0xa * _0x134b56) + 0x1;
    }, ig['Tween']['Easing']['Exponential']['EaseInOut'] = function(_0x2cc9f3) {
        return 0x0 == _0x2cc9f3 ? 0x0 : 0x1 == _0x2cc9f3 ? 0x1 : 0x1 > (_0x2cc9f3 *= 0x2) ? 0.5 * Math['pow'](0x2, 0xa * (_0x2cc9f3 - 0x1)) : 0.5 * (-Math['pow'](0x2, -0xa * (_0x2cc9f3 - 0x1)) + 0x2);
    }, ig['Tween']['Easing']['Circular']['EaseIn'] = function(_0x397565) {
        return -(Math['sqrt'](0x1 - _0x397565 * _0x397565) - 0x1);
    }, ig['Tween']['Easing']['Circular']['EaseOut'] = function(_0x2d94f4) {
        return Math['sqrt'](0x1 - --_0x2d94f4 * _0x2d94f4);
    }, ig['Tween']['Easing']['Circular']['EaseInOut'] = function(_0x2f0032) {
        return 0x1 > (_0x2f0032 /= 0.5) ? -0.5 * (Math['sqrt'](0x1 - _0x2f0032 * _0x2f0032) - 0x1) : 0.5 * (Math['sqrt'](0x1 - (_0x2f0032 -= 0x2) * _0x2f0032) + 0x1);
    }, ig['Tween']['Easing']['Elastic']['EaseIn'] = function(_0x3a7831) {
        var _0x5e3596, _0x1c9c24 = 0.1,
            _0x48ebd8 = 0.4;
        if (0x0 == _0x3a7831) return 0x0;
        if (0x1 == _0x3a7831) return 0x1;
        return _0x48ebd8 || (_0x48ebd8 = 0.3), !_0x1c9c24 || 0x1 > _0x1c9c24 ? (_0x1c9c24 = 0x1, _0x5e3596 = _0x48ebd8 / 0x4) : _0x5e3596 = _0x48ebd8 / (0x2 * Math['PI']) * Math['asin'](0x1 / _0x1c9c24), -(_0x1c9c24 * Math['pow'](0x2, 0xa * (_0x3a7831 -= 0x1)) * Math['sin'](0x2 * (_0x3a7831 - _0x5e3596) * Math['PI'] / _0x48ebd8));
    }, ig['Tween']['Easing']['Elastic']['EaseOut'] = function(_0x2026d2) {
        var _0x40d7c2, _0x4ed291 = 0.1,
            _0x1a803a = 0.4;
        if (0x0 == _0x2026d2) return 0x0;
        if (0x1 == _0x2026d2) return 0x1;
        return _0x1a803a || (_0x1a803a = 0.3), !_0x4ed291 || 0x1 > _0x4ed291 ? (_0x4ed291 = 0x1, _0x40d7c2 = _0x1a803a / 0x4) : _0x40d7c2 = _0x1a803a / (0x2 * Math['PI']) * Math['asin'](0x1 / _0x4ed291), _0x4ed291 * Math['pow'](0x2, -0xa * _0x2026d2) * Math['sin'](0x2 * (_0x2026d2 - _0x40d7c2) * Math['PI'] / _0x1a803a) + 0x1;
    }, ig['Tween']['Easing']['Elastic']['EaseInOut'] = function(_0x19ea8f) {
        var _0x549915, _0x211e96 = 0.1,
            _0x2ef2d2 = 0.4;
        if (0x0 == _0x19ea8f) return 0x0;
        if (0x1 == _0x19ea8f) return 0x1;
        return _0x2ef2d2 || (_0x2ef2d2 = 0.3), !_0x211e96 || 0x1 > _0x211e96 ? (_0x211e96 = 0x1, _0x549915 = _0x2ef2d2 / 0x4) : _0x549915 = _0x2ef2d2 / (0x2 * Math['PI']) * Math['asin'](0x1 / _0x211e96), 0x1 > (_0x19ea8f *= 0x2) ? -0.5 * _0x211e96 * Math['pow'](0x2, 0xa * (_0x19ea8f -= 0x1)) * Math['sin'](0x2 * (_0x19ea8f - _0x549915) * Math['PI'] / _0x2ef2d2) : 0.5 * _0x211e96 * Math['pow'](0x2, -0xa * (_0x19ea8f -= 0x1)) * Math['sin'](0x2 * (_0x19ea8f - _0x549915) * Math['PI'] / _0x2ef2d2) + 0x1;
    }, ig['Tween']['Easing']['Back']['EaseIn'] = function(_0x34cc46) {
        return _0x34cc46 * _0x34cc46 * (2.70158 * _0x34cc46 - 1.70158);
    }, ig['Tween']['Easing']['Back']['EaseOut'] = function(_0x5cdee3) {
        return (_0x5cdee3 -= 0x1) * _0x5cdee3 * (2.70158 * _0x5cdee3 + 1.70158) + 0x1;
    }, ig['Tween']['Easing']['Back']['EaseInOut'] = function(_0x48b12c) {
        return 0x1 > (_0x48b12c *= 0x2) ? 0.5 * _0x48b12c * _0x48b12c * (3.5949095 * _0x48b12c - 2.5949095) : 0.5 * ((_0x48b12c -= 0x2) * _0x48b12c * (3.5949095 * _0x48b12c + 2.5949095) + 0x2);
    }, ig['Tween']['Easing']['Bounce']['EaseIn'] = function(_0x176d91) {
        return 0x1 - ig['Tween']['Easing']['Bounce']['EaseOut'](0x1 - _0x176d91);
    }, ig['Tween']['Easing']['Bounce']['EaseOut'] = function(_0x1cb66d) {
        return (_0x1cb66d /= 0x1) < 0x1 / 2.75 ? 7.5625 * _0x1cb66d * _0x1cb66d : _0x1cb66d < 0x2 / 2.75 ? 7.5625 * (_0x1cb66d -= 1.5 / 2.75) * _0x1cb66d + 0.75 : _0x1cb66d < 2.5 / 2.75 ? 7.5625 * (_0x1cb66d -= 2.25 / 2.75) * _0x1cb66d + 0.9375 : 7.5625 * (_0x1cb66d -= 2.625 / 2.75) * _0x1cb66d + 0.984375;
    }, ig['Tween']['Easing']['Bounce']['EaseInOut'] = function(_0x2b9122) {
        return 0.5 > _0x2b9122 ? 0.5 * ig['Tween']['Easing']['Bounce']['EaseIn'](0x2 * _0x2b9122) : 0.5 * ig['Tween']['Easing']['Bounce']['EaseOut'](0x2 * _0x2b9122 - 0x1) + 0.5;
    }, ig['Tween']['Interpolation'] = {
        'Linear': function(_0x344426, _0x275ebc) {
            var _0x10fcbe = _0x344426['length'] - 0x1,
                _0x32b63d = _0x10fcbe * _0x275ebc,
                _0x5c6616 = Math['floor'](_0x32b63d),
                _0x1c053d = TWEEN['Interpolation']['Utils']['Linear'];
            return 0x0 > _0x275ebc ? _0x1c053d(_0x344426[0x0], _0x344426[0x1], _0x32b63d) : 0x1 < _0x275ebc ? _0x1c053d(_0x344426[_0x10fcbe], _0x344426[_0x10fcbe - 0x1], _0x10fcbe - _0x32b63d) : _0x1c053d(_0x344426[_0x5c6616], _0x344426[_0x5c6616 + 0x1 > _0x10fcbe ? _0x10fcbe : _0x5c6616 + 0x1], _0x32b63d - _0x5c6616);
        }
    };
}), ig['baked'] = !0x0, ig['module']('plugins.patches.entity-patch')['requires']('impact.entity')['defines'](function() {
    ig['Entity']['inject']({
        'handleMovementTrace': function(_0x41cd2e) {
            this['standing'] = !0x1, _0x41cd2e['collision']['y'] && (0x0 < this['bounciness'] && Math['abs'](this['vel']['y']) > this['minBounceVelocity'] ? this['vel']['y'] *= -this['bounciness'] : (0x0 < this['vel']['y'] && (this['standing'] = !0x0), this['vel']['y'] = 0x0)), _0x41cd2e['collision']['x'] && (this['vel']['x'] = 0x0 < this['bounciness'] && Math['abs'](this['vel']['x']) > this['minBounceVelocity'] ? this['vel']['x'] * -this['bounciness'] : 0x0);
            if (_0x41cd2e['collision']['slope']) {
                var _0x101802 = _0x41cd2e['collision']['slope'];
                if (0x0 < this['bounciness']) {
                    var _0x430b15 = this['vel']['x'] * _0x101802['nx'] + this['vel']['y'] * _0x101802['ny'];
                    this['vel']['x'] = (this['vel']['x'] - 0x2 * _0x101802['nx'] * _0x430b15) * this['bounciness'], this['vel']['y'] = (this['vel']['y'] - 0x2 * _0x101802['ny'] * _0x430b15) * this['bounciness'];
                } else _0x430b15 = (this['vel']['x'] * _0x101802['x'] + this['vel']['y'] * _0x101802['y']) / (_0x101802['x'] * _0x101802['x'] + _0x101802['y'] * _0x101802['y']), this['vel']['x'] = _0x101802['x'] * _0x430b15, this['vel']['y'] = _0x101802['y'] * _0x430b15, _0x101802 = Math['atan2'](_0x101802['x'], _0x101802['y']), _0x101802 > this['slopeStanding']['min'] && _0x101802 < this['slopeStanding']['max'] && (this['standing'] = !0x0);
            }
            this['pos']['x'] = _0x41cd2e['pos']['x'], this['pos']['y'] = _0x41cd2e['pos']['y'];
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.tweens-handler')['requires']('impact.entity', 'plugins.tween', 'plugins.patches.entity-patch')['defines'](function() {
    Array['prototype']['indexOf'] || (Array['prototype']['indexOf'] = function(_0x24e860) {
        for (var _0x35bf40 = 0x0; _0x35bf40 < this['length']; ++_0x35bf40)
            if (this[_0x35bf40] === _0x24e860) return _0x35bf40;
        return -0x1;
    }), ig['TweensHandler'] = ig['Class']['extend']({
        '_tweens': [],
        '_systemPausedTweens': [],
        'init': function() {},
        'getAll': function() {
            return this['_tweens'];
        },
        'removeAll': function() {
            this['_tweens'] = [];
        },
        'add': function(_0x192121) {
            this['_tweens']['push'](_0x192121);
        },
        'remove': function(_0x5529f9) {
            _0x5529f9 = this['_tweens']['indexOf'](_0x5529f9), -0x1 !== _0x5529f9 && this['_tweens']['splice'](_0x5529f9, 0x1);
        },
        'onSystemPause': function() {
            if (0x0 === this['_tweens']['length']) return !0x1;
            for (var _0x5b9180 = 0x0, _0x5ba8b7 = null; _0x5b9180 < this['_tweens']['length'];) _0x5ba8b7 = this['_tweens'][_0x5b9180], _0x5ba8b7['_isPlaying'] && (this['_systemPausedTweens']['push'](_0x5ba8b7), _0x5ba8b7['pause']()), _0x5b9180++;
            return !0x0;
        },
        'onSystemResume': function() {
            if (0x0 === this['_systemPausedTweens']['length']) return !0x1;
            for (var _0x429346 = 0x0; _0x429346 < this['_systemPausedTweens']['length'];) this['_systemPausedTweens'][_0x429346]['resume'](), _0x429346++;
            return this['_systemPausedTweens'] = [], !0x0;
        },
        'update': function(_0x2ca534, _0xf7b49c) {
            if (0x0 === this['_tweens']['length']) return !0x1;
            var _0x385e79 = 0x0;
            for (_0x2ca534 = void 0x0 !== _0x2ca534 ? _0x2ca534 : ig['game']['tweens']['now'](); _0x385e79 < this['_tweens']['length'];) this['_tweens'][_0x385e79]['update'](_0x2ca534) || _0xf7b49c ? _0x385e79++ : this['_tweens']['splice'](_0x385e79, 0x1);
            return !0x0;
        },
        'now': function() {
            return Date['now']();
        }
    }), ig['TweenDef'] = ig['Class']['extend']({
        '_ent': null,
        '_valuesStart': {},
        '_valuesEnd': {},
        '_valuesStartRepeat': {},
        '_duration': 0x3e8,
        '_repeat': 0x0,
        '_yoyo': !0x1,
        '_isPlaying': !0x1,
        '_reversed': !0x1,
        '_delayTime': 0x0,
        '_startTime': null,
        '_pauseTime': null,
        '_easingFunction': ig['Tween']['Easing']['Linear']['EaseNone'],
        '_interpolationFunction': ig['Tween']['Interpolation']['Linear'],
        '_chainedTweens': [],
        '_onStartCallback': null,
        '_onStartCallbackFired': !0x1,
        '_onUpdateCallback': null,
        '_onCompleteCallback': null,
        '_onStopCallback': null,
        '_onPauseCallback': null,
        '_onResumeCallback': null,
        '_currentElapsed': 0x0,
        'init': function(_0x5be0c4) {
            this['_object'] = _0x5be0c4;
        },
        'to': function(_0x505a86, _0x5ebdd1) {
            return this['_valuesEnd'] = _0x505a86, void 0x0 !== _0x5ebdd1 && (this['_duration'] = _0x5ebdd1), this;
        },
        'start': function(_0xf8645c) {
            if (this['_isPlaying']) return this;
            ig['game']['tweens']['add'](this), this['_isPlaying'] = !0x0, this['_onStartCallbackFired'] = !0x1, this['_startTime'] = void 0x0 !== _0xf8645c ? _0xf8645c : ig['game']['tweens']['now'](), this['_startTime'] += this['_delayTime'];
            for (var _0x3c089b in this['_valuesEnd']) {
                if (this['_valuesEnd'][_0x3c089b] instanceof Array) {
                    if (0x0 === this['_valuesEnd'][_0x3c089b]['length']) continue;
                    this['_valuesEnd'][_0x3c089b] = [this['_object'][_0x3c089b]]['concat'](this['_valuesEnd'][_0x3c089b]);
                }
                void 0x0 !== this['_object'][_0x3c089b] && (this['_valuesStart'][_0x3c089b] = this['_object'][_0x3c089b], !0x1 === this['_valuesStart'][_0x3c089b] instanceof Array && (this['_valuesStart'][_0x3c089b] *= 0x1), this['_valuesStartRepeat'][_0x3c089b] = this['_valuesStart'][_0x3c089b] || 0x0);
            }
            return this;
        },
        'stop': function() {
            if (!this['_isPlaying']) return this;
            return ig['game']['tweens']['remove'](this), this['_isPlaying'] = !0x1, null !== this['_onStopCallback'] && this['_onStopCallback']['call'](this['_object'], this['_object']), this['stopChainedTweens'](), this;
        },
        'pause': function() {
            if (!this['_isPlaying']) return this;
            return ig['game']['tweens']['remove'](this), this['_isPlaying'] = !0x1, this['_pauseTime'] = ig['game']['tweens']['now'](), null !== this['_onPauseCallback'] && this['_onPauseCallback']['call'](this['_object'], this['_object']), this;
        },
        'resume': function() {
            if (this['_isPlaying'] || !this['_pauseTime']) return this;
            var _0x42df2d = ig['game']['tweens']['now']() - this['_pauseTime'];
            return this['_startTime'] += _0x42df2d, ig['game']['tweens']['add'](this), this['_isPlaying'] = !0x0, null !== this['_onResumeCallback'] && this['_onResumeCallback']['call'](this['_object'], this['_object']), this['_pauseTime'] = null, this;
        },
        'end': function() {
            return this['update'](this['_startTime'] + this['_duration']), this;
        },
        'stopChainedTweens': function() {
            for (var _0x1f7f32 = 0x0, _0x182fa4 = this['_chainedTweens']['length']; _0x1f7f32 < _0x182fa4; _0x1f7f32++) this['_chainedTweens'][_0x1f7f32]['stop']();
        },
        'delay': function(_0x1a6f82) {
            return this['_delayTime'] = _0x1a6f82, this;
        },
        'repeat': function(_0x4bfc66) {
            return this['_repeat'] = _0x4bfc66, this;
        },
        'repeatDelay': function(_0x19fe12) {
            return this['_repeatDelayTime'] = _0x19fe12, this;
        },
        'yoyo': function(_0x357227) {
            return this['_yoyo'] = _0x357227, this;
        },
        'easing': function(_0x418b8b) {
            return this['_easingFunction'] = _0x418b8b, this;
        },
        'interpolation': function(_0x386732) {
            return this['_interpolationFunction'] = _0x386732, this;
        },
        'chain': function() {
            return this['_chainedTweens'] = arguments, this;
        },
        'onStart': function(_0x527560) {
            return this['_onStartCallback'] = _0x527560, this;
        },
        'onUpdate': function(_0x5986bd) {
            return this['_onUpdateCallback'] = _0x5986bd, this;
        },
        'onComplete': function(_0x2327e4) {
            return this['_onCompleteCallback'] = _0x2327e4, this;
        },
        'onStop': function(_0x2f6a44) {
            return this['_onStopCallback'] = _0x2f6a44, this;
        },
        'onPause': function(_0x1253ab) {
            return this['_onPauseCallback'] = _0x1253ab, this;
        },
        'onResume': function(_0x196710) {
            return this['_onResumeCallback'] = _0x196710, this;
        },
        'update': function(_0x598339) {
            var _0x2128af, _0x1d487e, _0x15155d;
            if (_0x598339 < this['_startTime']) return !0x0;
            !0x1 === this['_onStartCallbackFired'] && (null !== this['_onStartCallback'] && this['_onStartCallback']['call'](this['_object'], this['_object']), this['_onStartCallbackFired'] = !0x0), _0x1d487e = (_0x598339 - this['_startTime']) / this['_duration'], this['_currentElapsed'] = _0x1d487e = 0x1 < _0x1d487e ? 0x1 : _0x1d487e, _0x15155d = this['_easingFunction'](_0x1d487e);
            for (_0x2128af in this['_valuesEnd'])
                if (void 0x0 !== this['_valuesStart'][_0x2128af]) {
                    var _0x5b37fc = this['_valuesStart'][_0x2128af] || 0x0,
                        _0x416274 = this['_valuesEnd'][_0x2128af];
                    _0x416274 instanceof Array ? this['_object'][_0x2128af] = this['_interpolationFunction'](_0x416274, _0x15155d) : ('string' === typeof _0x416274 && (_0x416274 = '+' === _0x416274['charAt'](0x0) || '-' === _0x416274['charAt'](0x0) ? _0x5b37fc + parseFloat(_0x416274) : parseFloat(_0x416274)), 'number' === typeof _0x416274 && (this['_object'][_0x2128af] = _0x5b37fc + (_0x416274 - _0x5b37fc) * _0x15155d));
                }
            null !== this['_onUpdateCallback'] && this['_onUpdateCallback']['call'](this['_object'], this['_object'], _0x15155d);
            if (0x1 === _0x1d487e) {
                if (0x0 < this['_repeat']) {
                    isFinite(this['_repeat']) && this['_repeat']--;
                    for (_0x2128af in this['_valuesStartRepeat']) 'string' === typeof this['_valuesEnd'][_0x2128af] && (this['_valuesStartRepeat'][_0x2128af] = _valuesStartRepeat[_0x2128af] + parseFloat(_valuesEnd[_0x2128af])), this['_yoyo'] && (_0x1d487e = this['_valuesStartRepeat'][_0x2128af], this['_valuesStartRepeat'][_0x2128af] = this['_valuesEnd'][_0x2128af], this['_valuesEnd'][_0x2128af] = _0x1d487e), this['_valuesStart'][_0x2128af] = this['_valuesStartRepeat'][_0x2128af];
                    this['_yoyo'] && (this['_reversed'] = !this['_reversed']), this['_startTime'] = void 0x0 !== this['_repeatDelayTime'] ? _0x598339 + this['_repeatDelayTime'] : _0x598339 + this['_delayTime'];
                } else {
                    null !== this['_onCompleteCallback'] && this['_onCompleteCallback']['call'](this['_object'], this['_object']), _0x598339 = 0x0;
                    for (_0x2128af = this['_chainedTweens']['length']; _0x598339 < _0x2128af; _0x598339++) this['_chainedTweens'][_0x598339]['start'](this['_startTime'] + this['_duration']);
                    return !0x1;
                }
            }
            return !0x0;
        }
    });
    var _0x3d5e62 = [0x1];
    ig['Tween']['Interpolation'] = {
        'Linear': function(_0x5e5e11, _0x290665) {
            var _0xd508ae = _0x5e5e11['length'] - 0x1,
                _0x2a7740 = _0xd508ae * _0x290665,
                _0x5a0e0e = Math['floor'](_0x2a7740),
                _0x210058 = ig['Tween']['Interpolation']['Utils']['Linear'];
            return 0x0 > _0x290665 ? _0x210058(_0x5e5e11[0x0], _0x5e5e11[0x1], _0x2a7740) : 0x1 < _0x290665 ? _0x210058(_0x5e5e11[_0xd508ae], _0x5e5e11[_0xd508ae - 0x1], _0xd508ae - _0x2a7740) : _0x210058(_0x5e5e11[_0x5a0e0e], _0x5e5e11[_0x5a0e0e + 0x1 > _0xd508ae ? _0xd508ae : _0x5a0e0e + 0x1], _0x2a7740 - _0x5a0e0e);
        },
        'Bezier': function(_0x9bf17e, _0x33c004) {
            for (var _0x3351de = 0x0, _0x4f6fb9 = _0x9bf17e['length'] - 0x1, _0x31647c = Math['pow'], _0x8f5913 = ig['Tween']['Interpolation']['Utils']['Bernstein'], _0x4e736d = 0x0; _0x4e736d <= _0x4f6fb9; _0x4e736d++) _0x3351de += _0x31647c(0x1 - _0x33c004, _0x4f6fb9 - _0x4e736d) * _0x31647c(_0x33c004, _0x4e736d) * _0x9bf17e[_0x4e736d] * _0x8f5913(_0x4f6fb9, _0x4e736d);
            return _0x3351de;
        },
        'CatmullRom': function(_0x1d13bc, _0x5bb1bf) {
            var _0x363ce5 = _0x1d13bc['length'] - 0x1,
                _0x1606d6 = _0x363ce5 * _0x5bb1bf,
                _0x3ee277 = Math['floor'](_0x1606d6),
                _0x5466d4 = ig['Tween']['Interpolation']['Utils']['CatmullRom'];
            return _0x1d13bc[0x0] === _0x1d13bc[_0x363ce5] ? (0x0 > _0x5bb1bf && (_0x3ee277 = Math['floor'](_0x1606d6 = _0x363ce5 * (0x1 + _0x5bb1bf))), _0x5466d4(_0x1d13bc[(_0x3ee277 - 0x1 + _0x363ce5) % _0x363ce5], _0x1d13bc[_0x3ee277], _0x1d13bc[(_0x3ee277 + 0x1) % _0x363ce5], _0x1d13bc[(_0x3ee277 + 0x2) % _0x363ce5], _0x1606d6 - _0x3ee277)) : 0x0 > _0x5bb1bf ? _0x1d13bc[0x0] - (_0x5466d4(_0x1d13bc[0x0], _0x1d13bc[0x0], _0x1d13bc[0x1], _0x1d13bc[0x1], -_0x1606d6) - _0x1d13bc[0x0]) : 0x1 < _0x5bb1bf ? _0x1d13bc[_0x363ce5] - (_0x5466d4(_0x1d13bc[_0x363ce5], _0x1d13bc[_0x363ce5], _0x1d13bc[_0x363ce5 - 0x1], _0x1d13bc[_0x363ce5 - 0x1], _0x1606d6 - _0x363ce5) - _0x1d13bc[_0x363ce5]) : _0x5466d4(_0x1d13bc[_0x3ee277 ? _0x3ee277 - 0x1 : 0x0], _0x1d13bc[_0x3ee277], _0x1d13bc[_0x363ce5 < _0x3ee277 + 0x1 ? _0x363ce5 : _0x3ee277 + 0x1], _0x1d13bc[_0x363ce5 < _0x3ee277 + 0x2 ? _0x363ce5 : _0x3ee277 + 0x2], _0x1606d6 - _0x3ee277);
        },
        'Utils': {
            'Linear': function(_0x257edc, _0x384495, _0x390e2b) {
                return (_0x384495 - _0x257edc) * _0x390e2b + _0x257edc;
            },
            'Bernstein': function(_0x4e5a2c, _0x2ba197) {
                var _0x1b6ada = ig['Tween']['Interpolation']['Utils']['Factorial'];
                return _0x1b6ada(_0x4e5a2c) / _0x1b6ada(_0x2ba197) / _0x1b6ada(_0x4e5a2c - _0x2ba197);
            },
            'Factorial': function(_0x327398) {
                var _0x2b4154 = 0x1;
                if (_0x3d5e62[_0x327398]) return _0x3d5e62[_0x327398];
                for (var _0x44c2ef = _0x327398; 0x1 < _0x44c2ef; _0x44c2ef--) _0x2b4154 *= _0x44c2ef;
                return _0x3d5e62[_0x327398] = _0x2b4154;
            },
            'CatmullRom': function(_0x1046ee, _0x204ed4, _0x2294be, _0x42e89a, _0x47c080) {
                _0x1046ee = 0.5 * (_0x2294be - _0x1046ee), _0x42e89a = 0.5 * (_0x42e89a - _0x204ed4);
                var _0x41f286 = _0x47c080 * _0x47c080;
                return (0x2 * _0x204ed4 - 0x2 * _0x2294be + _0x1046ee + _0x42e89a) * _0x47c080 * _0x41f286 + (-0x3 * _0x204ed4 + 0x3 * _0x2294be - 0x2 * _0x1046ee - _0x42e89a) * _0x41f286 + _0x1046ee * _0x47c080 + _0x204ed4;
            }
        }
    };
}), ig['baked'] = !0x0, ig['module']('plugins.url-parameters')['defines'](function() {
    ig['UrlParameters'] = ig['Class']['extend']({
        'init': function() {
            switch (getQueryVariable('iphone')) {
                case 'true':
                    ig['ua']['iPhone'] = !0x0, console['log']('iPhone\x20mode');
            }
            var _0x5cf1c2 = getQueryVariable('webview');
            if (_0x5cf1c2) switch (_0x5cf1c2) {
                case 'true':
                    ig['ua']['is_uiwebview'] = !0x0, console['log']('webview\x20mode');
            }
            if (_0x5cf1c2 = getQueryVariable('debug')) switch (_0x5cf1c2) {
                case 'true':
                    ig['game']['showDebugMenu'](), console['log']('debug\x20mode');
            }
            switch (getQueryVariable('view')) {
                case 'stats':
                    ig['game']['resetPlayerStats'](), ig['game']['endGame']();
            }
            getQueryVariable('ad');
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.director')['requires']('impact.impact')['defines'](function() {
    ig['Director'] = ig['Class']['extend']({
        'init': function(_0x407aa9, _0x4d4625) {
            this['game'] = _0x407aa9, this['levels'] = [], this['currentLevel'] = 0x0, this['append'](_0x4d4625);
        },
        'loadLevel': function(_0x4f8f2f) {
            for (var _0x3899cf in ig['sizeHandler']['dynamicClickableEntityDivs']) {
                var _0x26858d = ig['domHandler']['getElementById']('#' + _0x3899cf);
                ig['domHandler']['hide'](_0x26858d);
            }
            return this['currentLevel'] = _0x4f8f2f, this['game']['loadLevel'](this['levels'][_0x4f8f2f]), !0x0;
        },
        'loadLevelWithoutEntities': function(_0xa8ddce) {
            return this['currentLevel'] = _0xa8ddce, this['game']['loadLevelWithoutEntities'](this['levels'][_0xa8ddce]), !0x0;
        },
        'append': function(_0x14d597) {
            return newLevels = [], 'object' === typeof _0x14d597 ? (_0x14d597['constructor'] === []['constructor'] ? newLevels = _0x14d597 : newLevels[0x0] = _0x14d597, this['levels'] = this['levels']['concat'](newLevels), !0x0) : !0x1;
        },
        'nextLevel': function() {
            return this['currentLevel'] + 0x1 < this['levels']['length'] ? this['loadLevel'](this['currentLevel'] + 0x1) : !0x1;
        },
        'previousLevel': function() {
            return 0x0 <= this['currentLevel'] - 0x1 ? this['loadLevel'](this['currentLevel'] - 0x1) : !0x1;
        },
        'jumpTo': function(_0x2fdc4a) {
            var _0x39c8f6 = null;
            for (i = 0x0; i < this['levels']['length']; i++) this['levels'][i] == _0x2fdc4a && (_0x39c8f6 = i);
            return 0x0 <= _0x39c8f6 ? this['loadLevel'](_0x39c8f6) : !0x1;
        },
        'firstLevel': function() {
            return this['loadLevel'](0x0);
        },
        'lastLevel': function() {
            return this['loadLevel'](this['levels']['length'] - 0x1);
        },
        'reloadLevel': function() {
            return this['loadLevel'](this['currentLevel']);
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.impact-storage')['requires']('impact.game')['defines'](function() {
    ig['Storage'] = ig['Class']['extend']({
        'staticInstantiate': function() {
            return !ig['Storage']['instance'] ? null : ig['Storage']['instance'];
        },
        'init': function() {
            ig['Storage']['instance'] = this;
        },
        'isCapable': function() {
            try {
                return 'undefined' !== typeof window['localStorage'];
            } catch (_0x4fb4a3) {
                return !0x1;
            }
        },
        'isSet': function(_0x5417a2) {
            return null !== this['get'](_0x5417a2);
        },
        'initUnset': function(_0x49d6bc, _0x5382a2) {
            null === this['get'](_0x49d6bc) && this['set'](_0x49d6bc, _0x5382a2);
        },
        'get': function(_0xaaa507) {
            if (!this['isCapable']()) return null;
            try {
                return JSON['parse'](localStorage['getItem'](_0xaaa507));
            } catch (_0x3db8ce) {
                return window['localStorage']['getItem'](_0xaaa507);
            }
        },
        'getInt': function(_0x4d9d8f) {
            return ~~this['get'](_0x4d9d8f);
        },
        'getFloat': function(_0x136703) {
            return parseFloat(this['get'](_0x136703));
        },
        'getBool': function(_0x32873c) {
            return !!this['get'](_0x32873c);
        },
        'key': function(_0xdcc335) {
            return this['isCapable']() ? window['localStorage']['key'](_0xdcc335) : null;
        },
        'set': function(_0x2a873a, _0xb407b0) {
            if (!this['isCapable']()) return null;
            try {
                window['localStorage']['setItem'](_0x2a873a, JSON['stringify'](_0xb407b0));
            } catch (_0x4c071e) {
                console['log'](_0x4c071e);
            }
        },
        'setHighest': function(_0x23483a, _0xcb956d) {
            _0xcb956d > this['getFloat'](_0x23483a) && this['set'](_0x23483a, _0xcb956d);
        },
        'remove': function(_0x4b14cd) {
            if (!this['isCapable']()) return null;
            window['localStorage']['removeItem'](_0x4b14cd);
        },
        'clear': function() {
            if (!this['isCapable']()) return null;
            window['localStorage']['clear']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.fullscreen')['requires']('impact.entity', 'plugins.handlers.size-handler', 'plugins.director')['defines'](function() {
    ig['Fullscreen'] = {
        'enableFullscreenButton': !0x0,
        '_isEnabled': 'notChecked',
        'isEnabled': function() {
            return 'notChecked' == this['_isEnabled'] && (this['_isEnabled'] = document['fullscreenEnabled'] || document['mozFullScreenEnabled'] || document['webkitFullscreenEnabled'] || document['msFullscreenEnabled'] ? !0x0 : !0x1), this['_isEnabled'];
        },
        'isFullscreen': function() {
            return ig['Fullscreen']['isEnabled']() && (document['fullscreenElement'] || document['mozFullScreenElement'] || document['webkitFullscreenElement'] || document['msFullscreenElement']) ? !0x0 : !0x1;
        },
        'toggleFullscreen': function() {
            ig['Fullscreen']['isFullscreen']() ? ig['Fullscreen']['exitFullscreen']() : ig['Fullscreen']['requestFullscreen'](), ig['sizeHandler']['orientationDelayHandler']();
            if (ig && ig['visibilityHandler']) ig['visibilityHandler']['onChange']('focus');
            try {
                ig['soundHandler']['unlockWebAudio']();
            } catch (_0x37b813) {}
        },
        'requestFullscreen': function() {
            var _0x7cad56 = document['documentElement'];
            _0x7cad56['requestFullscreen'] ? _0x7cad56['requestFullscreen']() : _0x7cad56['webkitRequestFullscreen'] ? _0x7cad56['webkitRequestFullscreen']() : _0x7cad56['mozRequestFullScreen'] ? _0x7cad56['mozRequestFullScreen']() : _0x7cad56['msRequestFullscreen'] ? _0x7cad56['msRequestFullscreen']() : console['log']('no\x20request\x20fullscreen\x20method\x20available');
        },
        'exitFullscreen': function() {
            document['exitFullscreen'] ? document['exitFullscreen']() : document['webkitExitFullscreen'] ? document['webkitExitFullscreen']() : document['mozCancelFullScreen'] ? document['mozCancelFullScreen']() : document['msExitFullscreen'] ? document['msExitFullscreen']() : console['log']('no\x20exit\x20fullscreen\x20method\x20available');
        },
        'divs': {}
    }, ig['Director']['inject']({
        'loadLevel': function(_0xe00de7) {
            var _0x1f3dec = ig['Fullscreen']['divs'],
                _0x560e3f;
            for (_0x560e3f in _0x1f3dec) _0x1f3dec = ig['domHandler']['getElementById']('#' + _0x560e3f), ig['domHandler']['hide'](_0x1f3dec);
            return this['parent'](_0xe00de7);
        }
    }), ig['SizeHandler']['inject']({
        'resize': function() {
            this['parent']();
            var _0x31facc = ig['Fullscreen']['divs'],
                _0x567bc6;
            for (_0x567bc6 in _0x31facc) {
                var _0x41ad9f = Math['min'](ig['sizeHandler']['scaleRatioMultiplier']['x'], ig['sizeHandler']['scaleRatioMultiplier']['y']),
                    _0x2e336a = ig['domHandler']['getElementById']('#' + _0x567bc6),
                    _0x24203c = _0x31facc[_0x567bc6]['entity_pos_x'],
                    _0x506f80 = _0x31facc[_0x567bc6]['entity_pos_y'],
                    _0xe35274 = _0x31facc[_0x567bc6]['width'],
                    _0x1c46bb = _0x31facc[_0x567bc6]['height'],
                    _0x49bf54 = ig['domHandler']['getElementById']('#canvas'),
                    _0x478f82 = ig['domHandler']['getOffsets'](_0x49bf54);
                ig['ua']['mobile'] ? (_0x49bf54 = _0x478f82['left'], _0x478f82 = _0x478f82['top'], ig['sizeHandler']['disableStretchToFitOnMobileFlag'] ? (_0x24203c = Math['floor'](_0x49bf54 + _0x24203c * ig['sizeHandler']['scaleRatioMultiplier']['x']) + 'px', _0x506f80 = Math['floor'](_0x478f82 + _0x506f80 * ig['sizeHandler']['scaleRatioMultiplier']['y']) + 'px', _0xe35274 = Math['floor'](_0xe35274 * ig['sizeHandler']['scaleRatioMultiplier']['x']) + 'px', _0x1c46bb = Math['floor'](_0x1c46bb * ig['sizeHandler']['scaleRatioMultiplier']['y']) + 'px') : (_0x24203c = Math['floor'](_0x24203c * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x506f80 = Math['floor'](_0x506f80 * ig['sizeHandler']['sizeRatio']['y']) + 'px', _0xe35274 = Math['floor'](_0xe35274 * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x1c46bb = Math['floor'](_0x1c46bb * ig['sizeHandler']['sizeRatio']['y']) + 'px')) : (_0x49bf54 = _0x478f82['left'], _0x478f82 = _0x478f82['top'], _0x24203c = Math['floor'](_0x49bf54 + _0x24203c * _0x41ad9f) + 'px', _0x506f80 = Math['floor'](_0x478f82 + _0x506f80 * _0x41ad9f) + 'px', _0xe35274 = Math['floor'](_0xe35274 * _0x41ad9f) + 'px', _0x1c46bb = Math['floor'](_0x1c46bb * _0x41ad9f) + 'px'), ig['domHandler']['css'](_0x2e336a, {
                    'float': 'left',
                    'position': 'absolute',
                    'left': _0x24203c,
                    'top': _0x506f80,
                    'width': _0xe35274,
                    'height': _0x1c46bb,
                    'z-index': 0x3
                }), _0x31facc[_0x567bc6]['font-size'] && ig['domHandler']['css'](_0x2e336a, {
                    'font-size': _0x31facc[_0x567bc6]['font-size'] * _0x41ad9f + 'px'
                });
            }
        }
    }), ig['FullscreenButton'] = ig['Entity']['extend']({
        'enterImage': null,
        'exitImage': null,
        'isReady': !0x1,
        'zIndex': 0xf423f,
        'identifier': null,
        'prevPos': {
            'x': 0x0,
            'y': 0x0
        },
        'invisImagePath': 'media/graphics/misc/invisible.png',
        'init': function(_0x3ebc60, _0x5778b5, _0x47e2ea) {
            this['parent'](_0x3ebc60, _0x5778b5, _0x47e2ea), ig['Fullscreen']['isEnabled']() && ig['Fullscreen']['enableFullscreenButton'] ? this['enterImage']['loaded'] ? this['initSize']() : this['enterImage']['loadCallback'] = function() {
                this['initSize']();
            }['bind'](this) : this['kill']();
        },
        'kill': function() {
            this['parent']();
        },
        'destroy': function() {
            this['parent'](), console['log']('destroy');
        },
        'initSize': function() {
            this['size']['x'] = this['enterImage']['width'], this['size']['y'] = this['enterImage']['height'], this['createClickableLayer'](), this['isReady'] = !0x0;
        },
        'createClickableLayer': function() {
            this['identifier'] = 'fullscreen-button-layer';
            var _0x32a73d = ig['domHandler']['getElementById']('#' + this['identifier']);
            _0x32a73d ? (ig['domHandler']['show'](_0x32a73d), ig['domHandler']['attr'](_0x32a73d, 'onclick', 'ig.Fullscreen.toggleFullscreen()')) : this['createClickableOutboundLayer']();
        },
        'update': function(_0x42b874, _0xab5649) {
            _0x42b874 = this['pos']['x'], _0xab5649 = this['pos']['y'], this['isReady'] && !(this['prevPos']['x'] === _0x42b874 && this['prevPos']['y'] === _0xab5649) && (ig['Fullscreen']['divs'][this['identifier']] = {}, ig['Fullscreen']['divs'][this['identifier']]['width'] = this['size']['x'], ig['Fullscreen']['divs'][this['identifier']]['height'] = this['size']['y'], ig['Fullscreen']['divs'][this['identifier']]['entity_pos_x'] = this['pos']['x'], ig['Fullscreen']['divs'][this['identifier']]['entity_pos_y'] = this['pos']['y'], this['prevPos']['x'] = _0x42b874, this['prevPos']['y'] = _0xab5649);
        },
        'draw': function() {
            this['isReady'] && (ig['Fullscreen']['isFullscreen']() ? this['exitImage']['draw'](this['pos']['x'], this['pos']['y']) : this['enterImage']['draw'](this['pos']['x'], this['pos']['y']));
        },
        'createClickableOutboundLayer': function() {
            var _0x257dd3 = this['identifier'],
                _0x1918f4 = this['invisImagePath'],
                _0xae6b50 = ig['domHandler']['create']('div');
            ig['domHandler']['attr'](_0xae6b50, 'id', _0x257dd3), ig['domHandler']['attr'](_0xae6b50, 'onclick', 'ig.Fullscreen.toggleFullscreen()');
            var _0x41c03d = ig['domHandler']['create']('a'),
                _0x317927 = ig['domHandler']['create']('img');
            ig['domHandler']['css'](_0x317927, {
                'width': '100%',
                'height': '100%'
            }), ig['domHandler']['attr'](_0x317927, 'src', _0x1918f4), _0x1918f4 = Math['min'](ig['sizeHandler']['scaleRatioMultiplier']['x'], ig['sizeHandler']['scaleRatioMultiplier']['y']);
            if (ig['ua']['mobile']) {
                var _0x4cfb74 = ig['domHandler']['getElementById']('#canvas'),
                    _0x4cfb74 = ig['domHandler']['getOffsets'](_0x4cfb74),
                    _0x41d77b = _0x4cfb74['left'],
                    _0x236683 = _0x4cfb74['top'];
                console['log'](_0x4cfb74['left']), ig['sizeHandler']['disableStretchToFitOnMobileFlag'] ? (_0x4cfb74 = Math['floor'](_0x41d77b + this['pos']['x'] * ig['sizeHandler']['scaleRatioMultiplier']['x']) + 'px', _0x236683 = Math['floor'](_0x236683 + this['pos']['y'] * ig['sizeHandler']['scaleRatioMultiplier']['y']) + 'px', _0x41d77b = Math['floor'](this['size']['x'] * ig['sizeHandler']['scaleRatioMultiplier']['x']) + 'px', _0x1918f4 = Math['floor'](this['size']['y'] * ig['sizeHandler']['scaleRatioMultiplier']['y']) + 'px') : (_0x4cfb74 = Math['floor'](this['pos']['x'] * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x236683 = Math['floor'](this['pos']['y'] * ig['sizeHandler']['sizeRatio']['y']) + 'px', _0x41d77b = Math['floor'](this['size']['x'] * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x1918f4 = Math['floor'](this['size']['y'] * ig['sizeHandler']['sizeRatio']['y']) + 'px');
            } else _0x4cfb74 = ig['domHandler']['getElementById']('#canvas'), _0x4cfb74 = ig['domHandler']['getOffsets'](_0x4cfb74), _0x41d77b = _0x4cfb74['left'], _0x236683 = _0x4cfb74['top'], ig['sizeHandler']['enableStretchToFitOnDesktopFlag'] ? (_0x4cfb74 = Math['floor'](_0x41d77b + this['pos']['x'] * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x236683 = Math['floor'](_0x236683 + this['pos']['y'] * ig['sizeHandler']['sizeRatio']['y']) + 'px', _0x41d77b = Math['floor'](this['size']['x'] * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x1918f4 = Math['floor'](this['size']['y'] * ig['sizeHandler']['sizeRatio']['y']) + 'px') : (_0x4cfb74 = Math['floor'](_0x41d77b + this['pos']['x'] * _0x1918f4) + 'px', _0x236683 = Math['floor'](_0x236683 + this['pos']['y'] * _0x1918f4) + 'px', _0x41d77b = Math['floor'](this['size']['x'] * _0x1918f4) + 'px', _0x1918f4 = Math['floor'](this['size']['y'] * _0x1918f4) + 'px');
            ig['domHandler']['css'](_0xae6b50, {
                'float': 'left',
                'position': 'absolute',
                'left': _0x4cfb74,
                'top': _0x236683,
                'width': _0x41d77b,
                'height': _0x1918f4,
                'z-index': 0x3
            }), ig['domHandler']['addEvent'](_0xae6b50, 'mousemove', ig['input']['mousemove']['bind'](ig['input']), !0x1), ig['domHandler']['appendChild'](_0x41c03d, _0x317927), ig['domHandler']['appendChild'](_0xae6b50, _0x41c03d), ig['domHandler']['appendToBody'](_0xae6b50), ig['Fullscreen']['divs'][_0x257dd3] = {}, ig['Fullscreen']['divs'][_0x257dd3]['width'] = this['size']['x'], ig['Fullscreen']['divs'][_0x257dd3]['height'] = this['size']['y'], ig['Fullscreen']['divs'][_0x257dd3]['entity_pos_x'] = this['pos']['x'], ig['Fullscreen']['divs'][_0x257dd3]['entity_pos_y'] = this['pos']['y'];
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.responsive.responsive-utils')['requires']('impact.system')['defines'](function() {
    ig['responsive'] = {
        'width': 0x0,
        'height': 0x0,
        'halfWidth': 0x0,
        'halfHeight': 0x0,
        'originalWidth': 0x0,
        'originalHeight': 0x0,
        'fillScale': 0x1,
        'scaleX': 0x1,
        'scaleY': 0x1,
        'toAnchor': function(_0x20b1fe, _0x2f85fd, _0x512729) {
            switch (_0x512729) {
                case 'top-left':
                case 'left-top':
                    return this['toAnchorTopLeft'](_0x20b1fe, _0x2f85fd);
                case 'top-center':
                case 'center-top':
                case 'top':
                    return this['toAnchorTopCenter'](_0x20b1fe, _0x2f85fd);
                case 'top-right':
                case 'right-top':
                    return this['toAnchorTopRight'](_0x20b1fe, _0x2f85fd);
                case 'left-middle':
                case 'middle-left':
                case 'left':
                    return this['toAnchorLeftMiddle'](_0x20b1fe, _0x2f85fd);
                case 'center-middle':
                case 'middle-center':
                case 'middle':
                case 'center':
                    return this['toAnchorCenterMiddle'](_0x20b1fe, _0x2f85fd);
                case 'right-middle':
                case 'middle-right':
                case 'right':
                    return this['toAnchorRightMiddle'](_0x20b1fe, _0x2f85fd);
                case 'bottom-left':
                case 'left-bottom':
                    return this['toAnchorBottomLeft'](_0x20b1fe, _0x2f85fd);
                case 'bottom-center':
                case 'center-bottom':
                case 'bottom':
                    return this['toAnchorBottomCenter'](_0x20b1fe, _0x2f85fd);
                case 'bottom-right':
                case 'right-bottom':
                    return this['toAnchorBottomRight'](_0x20b1fe, _0x2f85fd);
                default:
                    return this['toAnchorDefault'](_0x20b1fe, _0x2f85fd);
            }
        },
        'toAnchorDefault': function(_0x67acd6, _0x377798) {
            return {
                'x': _0x67acd6 + (this['width'] - this['originalWidth']) / 0x2,
                'y': _0x377798 + (this['height'] - this['originalHeight']) / 0x2
            };
        },
        'toAnchorCenterMiddle': function(_0x133b4d, _0x5be9ff) {
            return {
                'x': _0x133b4d + this['halfWidth'],
                'y': _0x5be9ff + this['halfHeight']
            };
        },
        'toAnchorLeftMiddle': function(_0x4b43ea, _0x533ac0) {
            return {
                'x': _0x4b43ea,
                'y': _0x533ac0 + this['halfHeight']
            };
        },
        'toAnchorTopCenter': function(_0x2483b8, _0x4a53fe) {
            return {
                'x': _0x2483b8 + this['halfWidth'],
                'y': _0x4a53fe
            };
        },
        'toAnchorRightMiddle': function(_0x483910, _0x29f143) {
            return {
                'x': _0x483910 + this['width'],
                'y': _0x29f143 + this['halfHeight']
            };
        },
        'toAnchorBottomCenter': function(_0x3e58cc, _0x7fc6b1) {
            return {
                'x': _0x3e58cc + this['halfWidth'],
                'y': _0x7fc6b1 + this['height']
            };
        },
        'toAnchorTopLeft': function(_0x3b508d, _0x2ab985) {
            return {
                'x': _0x3b508d,
                'y': _0x2ab985
            };
        },
        'toAnchorBottomLeft': function(_0x4852bf, _0x1ee820) {
            return {
                'x': _0x4852bf,
                'y': _0x1ee820 + this['height']
            };
        },
        'toAnchorTopRight': function(_0x57d3a9, _0x5ca0ca) {
            return {
                'x': _0x57d3a9 + this['width'],
                'y': _0x5ca0ca
            };
        },
        'toAnchorBottomRight': function(_0x5a81f6, _0x112186) {
            return {
                'x': _0x5a81f6 + this['width'],
                'y': _0x112186 + this['height']
            };
        },
        'drawScaledImage': function(_0x561b06, _0x321ee9, _0x3bd660, _0x309689, _0xc80b5, _0x504008, _0x58be9c) {
            _0x504008 || (_0x504008 = 0x0), _0x58be9c || (_0x58be9c = 0x0);
            var _0x21fbd0 = ig['system']['context'];
            _0x21fbd0['save'](), _0x21fbd0['translate'](_0x321ee9, _0x3bd660), (0x1 != _0x309689 || 0x1 != _0xc80b5) && _0x21fbd0['scale'](_0x309689, _0xc80b5), _0x561b06['draw'](-_0x561b06['width'] * _0x504008, -_0x561b06['height'] * _0x58be9c), _0x21fbd0['restore']();
        }
    };
}), ig['baked'] = !0x0, ig['module']('plugins.responsive.responsive-plugin')['requires']('impact.system', 'impact.entity', 'plugins.handlers.size-handler', 'plugins.responsive.responsive-utils')['defines'](function() {
    ig['SizeHandler']['inject']({
        'resize': function() {
            this['parent']();
        },
        'sizeCalcs': function() {
            this['originalResolution'] || (this['originalResolution'] = new Vector2(this['desktop']['actualResolution']['x'], this['desktop']['actualResolution']['y']), ig['responsive']['originalWidth'] = this['desktop']['actualResolution']['x'], ig['responsive']['originalHeight'] = this['desktop']['actualResolution']['y']);
            var _0x1660d4 = window['innerWidth'],
                _0x4957b6 = window['innerHeight'],
                _0x512610 = _0x1660d4 / _0x4957b6,
                _0x53b5cf = this['originalResolution']['x'] / this['originalResolution']['y'],
                _0x4a31d8 = 0x0,
                _0x376ca9 = 0x0;
            this['windowSize'] = new Vector2(_0x1660d4, _0x4957b6), _0x512610 < _0x53b5cf ? (_0x4a31d8 = this['originalResolution']['x'], _0x376ca9 = _0x4a31d8 / _0x512610, ig['responsive']['scaleX'] = 0x1, ig['responsive']['scaleY'] = _0x376ca9 / this['originalResolution']['y']) : (_0x376ca9 = this['originalResolution']['y'], _0x4a31d8 = _0x376ca9 * _0x512610, ig['responsive']['scaleX'] = _0x4a31d8 / this['originalResolution']['x'], ig['responsive']['scaleY'] = 0x1), this['scaleRatioMultiplier'] = new Vector2(_0x1660d4 / _0x4a31d8, _0x4957b6 / _0x376ca9), this['desktop']['actualResolution'] = new Vector2(_0x4a31d8, _0x376ca9), this['mobile']['actualResolution'] = new Vector2(_0x4a31d8, _0x376ca9), this['desktop']['actualSize'] = new Vector2(_0x1660d4, _0x4957b6), this['mobile']['actualSize'] = new Vector2(_0x1660d4, _0x4957b6), ig['responsive']['width'] = _0x4a31d8, ig['responsive']['height'] = _0x376ca9, ig['responsive']['halfWidth'] = _0x4a31d8 / 0x2, ig['responsive']['halfHeight'] = _0x376ca9 / 0x2, ig['responsive']['fillScale'] = Math['max'](ig['responsive']['scaleX'], ig['responsive']['scaleY']);
        },
        'resizeLayers': function() {
            ig['system']['resize'](ig['sizeHandler']['desktop']['actualResolution']['x'], ig['sizeHandler']['desktop']['actualResolution']['y']);
            for (var _0x3b0528 = 0x0; _0x3b0528 < this['coreDivsToResize']['length']; _0x3b0528++) {
                var _0x2acc1d = ig['domHandler']['getElementById'](this['coreDivsToResize'][_0x3b0528]),
                    _0x49d736 = Math['floor'](ig['sizeHandler']['windowSize']['x'] / 0x2 - ig['sizeHandler']['desktop']['actualSize']['x'] / 0x2),
                    _0x261a1c = Math['floor'](ig['sizeHandler']['windowSize']['y'] / 0x2 - ig['sizeHandler']['desktop']['actualSize']['y'] / 0x2);
                0x0 > _0x49d736 && (_0x49d736 = 0x0), 0x0 > _0x261a1c && (_0x261a1c = 0x0), ig['domHandler']['resizeOffset'](_0x2acc1d, Math['floor'](ig['sizeHandler']['desktop']['actualSize']['x']), Math['floor'](ig['sizeHandler']['desktop']['actualSize']['y']), _0x49d736, _0x261a1c);
            }
            for (var _0x246255 in this['adsToResize']) _0x3b0528 = ig['domHandler']['getElementById']('#' + _0x246255), _0x2acc1d = ig['domHandler']['getElementById']('#' + _0x246255 + '-Box'), _0x49d736 = (window['innerWidth'] - this['adsToResize'][_0x246255]['box-width']) / 0x2 + 'px', _0x261a1c = (window['innerHeight'] - this['adsToResize'][_0x246255]['box-height']) / 0x2 + 'px', _0x3b0528 && ig['domHandler']['css'](_0x3b0528, {
                'width': window['innerWidth'],
                'height': window['innerHeight']
            }), _0x2acc1d && ig['domHandler']['css'](_0x2acc1d, {
                'left': _0x49d736,
                'top': _0x261a1c
            });
            _0x3b0528 = ig['domHandler']['getElementById']('#canvas'), _0x2acc1d = ig['domHandler']['getOffsets'](_0x3b0528), _0x3b0528 = _0x2acc1d['left'], _0x2acc1d = _0x2acc1d['top'], _0x49d736 = Math['min'](ig['sizeHandler']['scaleRatioMultiplier']['x'], ig['sizeHandler']['scaleRatioMultiplier']['y']);
            for (_0x246255 in this['dynamicClickableEntityDivs']) _0x261a1c = ig['domHandler']['getElementById']('#' + _0x246255), ig['domHandler']['css'](_0x261a1c, {
                'float': 'left',
                'position': 'absolute',
                'left': Math['floor'](_0x3b0528 + this['dynamicClickableEntityDivs'][_0x246255]['entity_pos_x'] * this['scaleRatioMultiplier']['x']) + 'px',
                'top': Math['floor'](_0x2acc1d + this['dynamicClickableEntityDivs'][_0x246255]['entity_pos_y'] * this['scaleRatioMultiplier']['y']) + 'px',
                'width': Math['floor'](this['dynamicClickableEntityDivs'][_0x246255]['width'] * this['scaleRatioMultiplier']['x']) + 'px',
                'height': Math['floor'](this['dynamicClickableEntityDivs'][_0x246255]['height'] * this['scaleRatioMultiplier']['y']) + 'px',
                'z-index': 0x3
            }), this['dynamicClickableEntityDivs'][_0x246255]['font-size'] && ig['domHandler']['css'](_0x261a1c, {
                'font-size': this['dynamicClickableEntityDivs'][_0x246255]['font-size'] * _0x49d736 + 'px'
            });
            $('#ajaxbar')['width'](this['windowSize']['x']), $('#ajaxbar')['height'](this['windowSize']['y']);
        },
        'reorient': function() {
            ig['ua']['mobile'] ? (this['resize'](), this['resizeAds']()) : this['resize'](), 0x1 == ig['loader']['status'] && (console['log']('redraw\x20loader'), ig['loader']['draw']()), ig['game'] && (ig['game']['update'](), ig['game']['draw']());
        },
        'resizeBabylon': function() {
            var _0x344bdd = window['innerWidth'],
                _0x358554 = window['innerHeight'],
                _0x5b8ea8 = _0x344bdd / _0x358554,
                _0x3e7fba = ig['responsive']['originalWidth'],
                _0x36dacd = ig['responsive']['originalHeight'],
                _0x29345a = _0x3e7fba / _0x36dacd,
                _0x1daff8 = Math['max'](_0x3e7fba, _0x36dacd);
            ig['ua']['mobile'] && (_0x1daff8 = 0x280), minSize = Math['min'](_0x3e7fba, _0x36dacd), _0x5b8ea8 > _0x29345a ? (_0x358554 > _0x36dacd && (_0x358554 = _0x36dacd), _0x344bdd = Math['floor'](window['innerWidth'] / window['innerHeight'] * _0x358554), _0x344bdd > _0x1daff8 && (_0x344bdd = _0x1daff8), _0x358554 = Math['floor'](window['innerHeight'] / window['innerWidth'] * _0x344bdd)) : (_0x344bdd > _0x3e7fba && (_0x344bdd = _0x3e7fba), _0x358554 = Math['floor'](window['innerHeight'] / window['innerWidth'] * _0x344bdd), _0x358554 > _0x1daff8 && (_0x358554 = _0x1daff8), _0x344bdd = Math['floor'](window['innerWidth'] / window['innerHeight'] * _0x358554)), _0x3e7fba = _0x5b8ea8 = 0x1, window['innerWidth'] > _0x1daff8 && (_0x5b8ea8 = window['innerWidth'] / _0x1daff8), window['innerHeight'] > _0x1daff8 && (_0x3e7fba = window['innerHeight'] / _0x1daff8), wgl['system']['engine']['setSize'](_0x344bdd, _0x358554), wgl['system']['engine']['resize'](), wgl['system']['engine']['setHardwareScalingLevel'](Math['max'](_0x5b8ea8, _0x3e7fba)), ig['gameScene']['zoomFactor'] = 0x1, ig['ua']['mobile'] && minSize < _0x1daff8 && (ig['gameScene']['zoomFactor'] = _0x1daff8 / minSize), ig['wglW'] = _0x344bdd, ig['wglH'] = _0x358554, ig['wglInnerW'] = window['innerWidth'], ig['wglInnerH'] = window['innerHeight'], console['log']('babylon\x20renderSize\x20:\x20', wgl['system']['engine']['getRenderWidth'](), wgl['system']['engine']['getRenderHeight'](), 'hwScalingLevel\x20:\x20', wgl['system']['engine']['getHardwareScalingLevel']());
        }
    }), ig['Entity']['inject']({
        'init': function(_0x2ae099, _0x1978e1, _0x1a970e) {
            this['parent'](_0x2ae099, _0x1978e1, _0x1a970e), _0x1a970e['anchorType'] || (this['anchorType'] = 'none'), this['anchoredPositionX'] = _0x2ae099, this['anchoredPositionY'] = _0x1978e1;
        },
        'setAnchoredPosition': function(_0x25f53e, _0x277235, _0x5891d5) {
            _0x5891d5 || (_0x5891d5 = 'default'), this['anchorType'] = _0x5891d5, this['anchoredPositionX'] = _0x25f53e, this['anchoredPositionY'] = _0x277235;
        },
        'update': function() {
            this['parent']();
            if ('' != this['anchorType'] && 'none' != this['anchorType']) {
                var _0x34b8d1 = ig['responsive']['toAnchor'](this['anchoredPositionX'], this['anchoredPositionY'], this['anchorType']);
                this['pos']['x'] = _0x34b8d1['x'], this['pos']['y'] = _0x34b8d1['y'];
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.scale')['requires']('impact.entity')['defines'](function() {
    ig['Entity']['inject']({
        'scale': {
            'x': 0x1,
            'y': 0x1
        },
        '_offset': {
            'x': 0x0,
            'y': 0x0
        },
        '_scale': {
            'x': 0x1,
            'y': 0x1
        },
        '_size': {
            'x': 0x0,
            'y': 0x0
        },
        'init': function(_0x114cfe, _0x27629d, _0x5be06f) {
            this['parent'](_0x114cfe, _0x27629d, _0x5be06f), this['_offset']['x'] = this['offset']['x'], this['_offset']['y'] = this['offset']['y'], this['_size']['x'] = this['size']['x'], this['_size']['y'] = this['size']['y'], this['setScale'](this['scale']['x'], this['scale']['y']);
        },
        'draw': function() {
            var _0x4b42e9 = ig['system']['context'];
            _0x4b42e9['save'](), this['centeredScale'] ? (_0x4b42e9['translate'](ig['system']['getDrawPos'](this['pos']['x']['round']() - this['offset']['x'] - ig['game']['screen']['x']) + this['_size']['x'] / 0x2, ig['system']['getDrawPos'](this['pos']['y']['round']() - this['offset']['y'] - ig['game']['screen']['y']) + this['_size']['y'] / 0x2), _0x4b42e9['scale'](this['_scale']['x'], this['_scale']['y']), null != this['currentAnim'] && this['currentAnim']['draw'](-this['_size']['x'] / 0x2, -this['_size']['y'] / 0x2)) : (_0x4b42e9['translate'](ig['system']['getDrawPos'](this['pos']['x']['round']() - this['offset']['x'] - ig['game']['screen']['x']), ig['system']['getDrawPos'](this['pos']['y']['round']() - this['offset']['y'] - ig['game']['screen']['y'])), _0x4b42e9['scale'](this['_scale']['x'], this['_scale']['y']), null != this['currentAnim'] && this['currentAnim']['draw'](0x0, 0x0)), _0x4b42e9['restore']();
        },
        'setScale': function(_0x51fd2e, _0x47d1a4) {
            var _0x272004 = this['size']['x'],
                _0x5203bf = this['size']['y'];
            this['scale']['x'] = _0x51fd2e || this['scale']['x'], this['scale']['y'] = _0x47d1a4 || this['scale']['y'], this['_scale']['x'] = this['scale']['x'] / ig['system']['scale'], this['_scale']['y'] = this['scale']['y'] / ig['system']['scale'], this['offset']['x'] = this['_offset']['x'] * this['_scale']['x'], this['offset']['y'] = this['_offset']['y'] * this['_scale']['y'], this['size']['x'] = this['_size']['x'] * this['_scale']['x'], this['size']['y'] = this['_size']['y'] * this['_scale']['y'], this['pos']['x'] += (_0x272004 - this['size']['x']) / 0x2, this['pos']['y'] += (_0x5203bf - this['size']['y']) / 0x2;
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.sat')['requires']('impact.impact')['defines'](function() {
    ig['SAT'] = ig['Class']['extend']({
        'init': function() {},
        'mtvForShapeIntersect': function(_0x4d6b7c, _0x539c23) {
            var _0x153a3c = 0x2710,
                _0x344689 = null,
                _0x10fac6 = [],
                _0x5120ff = [];
            if (_0x4d6b7c['isCircle']() && _0x539c23['isCircle']()) _0x10fac6['push'](_0x4d6b7c['center']['subtract'](_0x539c23['center'])['normalized']());
            else {
                if (_0x539c23['isCircle']()) {
                    for (var _0x43b32f = _0x4d6b7c['pointList'][0x0], _0x1a7883 = _0x539c23['center']['manhattanDistance'](_0x43b32f), _0x162219 = 0x1; _0x162219 < _0x4d6b7c['pointList']['length']; _0x162219++) {
                        var _0x907076 = _0x4d6b7c['pointList'][_0x162219],
                            _0x13663b = _0x539c23['center']['manhattanDistance'](_0x907076);
                        _0x13663b < _0x1a7883 && (_0x1a7883 = _0x13663b, _0x43b32f = _0x907076);
                    }
                    _0x5120ff['push'](_0x539c23['center']['subtract'](_0x43b32f)['normalized']());
                } else {
                    if (_0x4d6b7c['isCircle']()) {
                        _0x162219 = _0x539c23, _0x539c23 = _0x4d6b7c, _0x4d6b7c = _0x162219, _0x43b32f = _0x4d6b7c['pointList'][0x0], _0x1a7883 = _0x539c23['center']['manhattanDistance'](_0x43b32f);
                        for (_0x162219 = 0x1; _0x162219 < _0x4d6b7c['pointList']['length']; _0x162219++) _0x907076 = _0x4d6b7c['pointList'][_0x162219], _0x13663b = _0x539c23['center']['manhattanDistance'](_0x907076), _0x13663b < _0x1a7883 && (_0x1a7883 = _0x13663b, _0x43b32f = _0x907076);
                        _0x5120ff['push'](_0x539c23['center']['subtract'](_0x43b32f)['normalized']());
                    } else _0x10fac6 = _0x4d6b7c['getNormalizedAxes'](), _0x5120ff = _0x539c23['getNormalizedAxes']();
                }
            }
            for (_0x162219 = 0x0; _0x162219 < _0x10fac6['length']; _0x162219++) {
                var _0x43b32f = _0x10fac6[_0x162219],
                    _0x13663b = _0x4d6b7c['project'](_0x43b32f),
                    _0x4870e8 = _0x539c23['project'](_0x43b32f);
                if (_0x13663b['overlap'](_0x4870e8)) {
                    _0x1a7883 = _0x13663b['getOverlap'](_0x4870e8);
                    if (_0x13663b['contains'](_0x4870e8) || _0x4870e8['contains'](_0x13663b)) _0x907076 = Math['abs'](_0x13663b['min'] - _0x4870e8['min']), _0x13663b = Math['abs'](_0x13663b['max'] - _0x4870e8['max']), _0x1a7883 = _0x907076 < _0x13663b ? _0x1a7883 + _0x907076 : _0x1a7883 + _0x13663b;
                    _0x1a7883 < _0x153a3c && (_0x153a3c = _0x1a7883, _0x344689 = _0x43b32f);
                } else return null;
            }
            for (_0x162219 = 0x0; _0x162219 < _0x5120ff['length']; _0x162219++)
                if (_0x43b32f = _0x5120ff[_0x162219], _0x13663b = _0x4d6b7c['project'](_0x43b32f), _0x4870e8 = _0x539c23['project'](_0x43b32f), _0x13663b['overlap'](_0x4870e8)) {
                    _0x1a7883 = _0x13663b['getOverlap'](_0x4870e8);
                    if (_0x13663b['contains'](_0x4870e8) || _0x4870e8['contains'](_0x13663b)) _0x907076 = Math['abs'](_0x13663b['min'] - _0x4870e8['min']), _0x13663b = Math['abs'](_0x13663b['max'] - _0x4870e8['max']), _0x1a7883 = _0x907076 < _0x13663b ? _0x1a7883 + _0x907076 : _0x1a7883 + _0x13663b;
                    _0x1a7883 < _0x153a3c && (_0x153a3c = _0x1a7883, _0x344689 = _0x43b32f);
                } else return null;
            return new ig['SAT']['MTV'](_0x344689, _0x153a3c);
        },
        'simpleShapeIntersect': function(_0x2a73c7, _0x3a32d0) {
            var _0x3d0c26 = [],
                _0x32b946 = [];
            if (_0x2a73c7['isCircle']() && _0x3a32d0['isCircle']()) _0x3d0c26['push'](_0x2a73c7['center']['subtract'](_0x3a32d0['center'])['normalized']());
            else {
                if (_0x3a32d0['isCircle']()) {
                    for (var _0x2f5408 = _0x2a73c7['pointList'][0x0], _0x277e0e = _0x3a32d0['center']['manhattanDistance'](_0x2f5408), _0x58d0a5 = 0x1; _0x58d0a5 < _0x2a73c7['pointList']['length']; _0x58d0a5++) {
                        var _0x347e2d = _0x2a73c7['pointList'][_0x58d0a5],
                            _0x42cb56 = _0x3a32d0['center']['manhattanDistance'](_0x347e2d);
                        _0x42cb56 < _0x277e0e && (_0x277e0e = _0x42cb56, _0x2f5408 = _0x347e2d);
                    }
                    _0x32b946['push'](_0x3a32d0['center']['subtract'](_0x2f5408)['normalized']());
                } else {
                    if (_0x2a73c7['isCircle']()) {
                        _0x58d0a5 = _0x3a32d0, _0x3a32d0 = _0x2a73c7, _0x2a73c7 = _0x58d0a5, _0x2f5408 = _0x2a73c7['pointList'][0x0], _0x277e0e = _0x3a32d0['center']['manhattanDistance'](_0x2f5408);
                        for (_0x58d0a5 = 0x1; _0x58d0a5 < _0x2a73c7['pointList']['length']; _0x58d0a5++) _0x347e2d = _0x2a73c7['pointList'][_0x58d0a5], _0x42cb56 = _0x3a32d0['center']['manhattanDistance'](_0x347e2d), _0x42cb56 < _0x277e0e && (_0x277e0e = _0x42cb56, _0x2f5408 = _0x347e2d);
                        _0x32b946['push'](_0x3a32d0['center']['subtract'](_0x2f5408)['normalized']());
                    } else _0x3d0c26 = _0x2a73c7['getAxes'](), _0x32b946 = _0x3a32d0['getAxes']();
                }
            }
            for (_0x58d0a5 = 0x0; _0x58d0a5 < _0x3d0c26['length']; _0x58d0a5++)
                if (_0x277e0e = _0x3d0c26[_0x58d0a5], _0x2f5408 = _0x2a73c7['project'](_0x277e0e), _0x277e0e = _0x3a32d0['project'](_0x277e0e), !_0x2f5408['overlap'](_0x277e0e)) return !0x1;
            for (_0x58d0a5 = 0x0; _0x58d0a5 < _0x32b946['length']; _0x58d0a5++)
                if (_0x277e0e = _0x32b946[_0x58d0a5], _0x2f5408 = _0x2a73c7['project'](_0x277e0e), _0x277e0e = _0x3a32d0['project'](_0x277e0e), !_0x277e0e['overlap'](_0x2f5408)) return !0x1;
            return !0x0;
        }
    }), ig['SAT']['Vector2D'] = ig['Class']['extend']({
        'x': 0x0,
        'y': 0x0,
        'init': function(_0x5774b2, _0x123652) {
            this['x'] = _0x5774b2, this['y'] = _0x123652;
        },
        'subtract': function(_0x5aaaec) {
            return new ig['SAT']['Vector2D'](this['x'] - _0x5aaaec['x'], this['y'] - _0x5aaaec['y']);
        },
        'getNormal': function() {
            return new ig['SAT']['Vector2D'](-this['y'], this['x']);
        },
        'getNormalizedNormal': function() {
            return new ig['SAT']['Vector2D'](-this['y'], this['x'])['normalized']();
        },
        'normalized': function() {
            var _0x5be516 = Math['sqrt'](this['x'] * this['x'] + this['y'] * this['y']);
            return 0x0 == _0x5be516 ? new ig['SAT']['Vector2D'](0x0, 0x0) : new ig['SAT']['Vector2D'](this['x'] / _0x5be516, this['y'] / _0x5be516);
        },
        'distance': function(_0xa6c75c) {
            var _0x2ef9e6 = _0xa6c75c['x'] - this['x'];
            return _0xa6c75c = _0xa6c75c['y'] - this['y'], Math['sqrt'](_0x2ef9e6 * _0x2ef9e6 + _0xa6c75c * _0xa6c75c);
        },
        'manhattanDistance': function(_0x271c99) {
            var _0x4bd437 = _0x271c99['x'] - this['x'];
            return _0x271c99 = _0x271c99['y'] - this['y'], _0x4bd437 * _0x4bd437 + _0x271c99 * _0x271c99;
        },
        'dotProduct': function(_0x258bb1) {
            return this['x'] * _0x258bb1['x'] + this['y'] * _0x258bb1['y'];
        },
        'crossProduct': function(_0x5446ae) {
            return this['x'] * _0x5446ae['y'] - this['y'] * _0x5446ae['x'];
        },
        'getAngle': function(_0x2e6b9f) {
            return Math['atan2'](this['crossProduct'](_0x2e6b9f), this['dotProduct'](_0x2e6b9f));
        }
    }), ig['SAT']['Shape'] = ig['Class']['extend']({
        'pointList': [],
        'center': null,
        'init': function(_0x3f54e7) {
            this['pointList'] = [];
            for (var _0xe3299d = 0x0; _0xe3299d < _0x3f54e7['length']; _0xe3299d++) {
                var _0x429b2d = _0x3f54e7[_0xe3299d];
                this['pointList']['push'](new ig['SAT']['Vector2D'](_0x429b2d['x'], _0x429b2d['y']));
            }
        },
        'isCircle': function() {
            return !0x1;
        },
        'getAxes': function() {
            var _0x3044f5 = [];
            if (0x1 >= this['pointList']['length']) return _0x3044f5;
            if (0x2 == this['pointList']['length']) {
                var _0x35cec6 = this['pointList'][0x0],
                    _0x391bf7 = this['pointList'][0x1],
                    _0x35cec6 = _0x35cec6['subtract'](_0x391bf7),
                    _0x35cec6 = _0x35cec6['getNormal']();
                return (0x0 != _0x35cec6['x'] || 0x0 != _0x35cec6['y']) && _0x3044f5['push'](_0x35cec6), _0x3044f5;
            }
            for (var _0xfb2eb6 = 0x0; _0xfb2eb6 < this['pointList']['length']; _0xfb2eb6++) _0x35cec6 = this['pointList'][_0xfb2eb6], _0x391bf7 = this['pointList'][_0xfb2eb6 + 0x1 == this['pointList']['length'] ? 0x0 : _0xfb2eb6 + 0x1], _0x35cec6 = _0x35cec6['subtract'](_0x391bf7), _0x35cec6 = _0x35cec6['getNormal'](), (0x0 != _0x35cec6['x'] || 0x0 != _0x35cec6['y']) && _0x3044f5['push'](_0x35cec6);
            return _0x3044f5;
        },
        'getNormalizedAxes': function() {
            for (var _0x21a4ad = [], _0x1aff3d = 0x0; _0x1aff3d < this['pointList']['length']; _0x1aff3d++) {
                var _0x1ce676 = this['pointList'][_0x1aff3d]['subtract'](this['pointList'][_0x1aff3d + 0x1 == this['pointList']['length'] ? 0x0 : _0x1aff3d + 0x1])['getNormalizedNormal']();
                (0x0 != _0x1ce676['x'] || 0x0 != _0x1ce676['y']) && _0x21a4ad['push'](_0x1ce676);
            }
            return _0x21a4ad;
        },
        'project': function(_0xe9447) {
            return new ig['SAT']['Projection'](this['pointList'], _0xe9447);
        }
    }), ig['SAT']['Circle'] = ig['SAT']['Shape']['extend']({
        'center': null,
        'radius': 0x0,
        'init': function(_0x48aac1, _0x321bf3) {
            this['center'] = new ig['SAT']['Vector2D'](_0x48aac1['x'], _0x48aac1['y']), this['radius'] = _0x321bf3;
        },
        'isCircle': function() {
            return !0x0;
        },
        'getAxes': function() {
            return [];
        },
        'getNormalizedAxes': function() {
            return [];
        },
        'project': function(_0x4eb2da) {
            var _0x255bca = new ig['SAT']['Projection']([], _0x4eb2da);
            return _0x4eb2da = this['center']['dotProduct'](_0x4eb2da), _0x255bca['min'] = _0x4eb2da - this['radius'], _0x255bca['max'] = _0x4eb2da + this['radius'], _0x255bca;
        }
    }), ig['SAT']['Projection'] = ig['Class']['extend']({
        'min': null,
        'max': null,
        'init': function(_0x5b3b87, _0x1c80d7) {
            if (!_0x5b3b87 || 0x0 >= _0x5b3b87['length']) return this;
            this['min'] = _0x5b3b87[0x0]['dotProduct'](_0x1c80d7), this['max'] = _0x5b3b87[0x0]['dotProduct'](_0x1c80d7);
            for (var _0x3bb674 = 0x1; _0x3bb674 < _0x5b3b87['length']; _0x3bb674++) {
                var _0x1ba479 = _0x5b3b87[_0x3bb674]['dotProduct'](_0x1c80d7);
                this['min'] > _0x1ba479 && (this['min'] = _0x1ba479), _0x1ba479 > this['max'] && (this['max'] = _0x1ba479);
            }
        },
        'overlap': function(_0x17a243) {
            return !(this['max'] < _0x17a243['min'] || _0x17a243['max'] < this['min']);
        },
        'getOverlap': function(_0x1bef50) {
            var _0x3d1f90 = this['max'] - _0x1bef50['min'];
            return _0x1bef50 = _0x1bef50['max'] - this['min'], _0x1bef50 < _0x3d1f90 && (_0x3d1f90 = _0x1bef50), _0x3d1f90;
        },
        'contains': function(_0xf2163b) {
            var _0x1e51cc = this['max'] - this['min'];
            if (_0xf2163b['max'] - _0xf2163b['min'] < _0x1e51cc) {
                var _0x4a0367 = this['max'] - _0xf2163b['min'];
                0x0 >= _0x4a0367 && (_0x4a0367 = _0xf2163b['max'] - this['min']);
                if (_0x4a0367 >= _0x1e51cc) return !0x0;
            }
            return !0x1;
        }
    }), ig['SAT']['MTV'] = ig['Class']['extend']({
        'axis': null,
        'overlapAmount': 0x0,
        'init': function(_0x2416fa, _0xf0acde) {
            this['axis'] = _0x2416fa, this['overlapAmount'] = _0xf0acde;
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.textwrapper')['defines'](function() {
    ig['Textwrapper'] = ig['Class']['extend']({
        'textFontSize': 0xe,
        'textFont': 'Impact,\x20Charcoal,\x20sans-serif',
        'textLineHeight': 0x14,
        'outline': !0x1,
        'init': function(_0x3469d4, _0x75745c, _0x371c08) {
            _0x3469d4 && (this['textSize'] = _0x3469d4, this['textLineHeight'] = 1.5 * _0x3469d4), _0x75745c && (this['textFont'] = _0x75745c), _0x371c08 && (this['outline'] = _0x371c08);
        },
        'wrapText': function(_0x548cee, _0x29026f) {
            if (!_0x548cee || '' == _0x548cee || 0x0 >= _0x29026f) return [];
            var _0x1eea9a = ig['system']['context'];
            _0x1eea9a['font'] = this['textSize'] + 'px\x20' + this['textFont'], _0x1eea9a['lineWidth'] = 0x7, _0x1eea9a['strokeStyle'] = '#000', _0x1eea9a['lineCap'] = 'round', _0x1eea9a['lineJoin'] = 'round';
            var _0x4cde59 = _0x548cee['split']('\x20'),
                _0x5e7cb6 = '',
                _0x461098 = [];
            if (0x1 == _0x4cde59['length'])
                for (var _0x5104d3 = 0x0; _0x5104d3 < _0x548cee['length']; _0x5104d3++) {
                    var _0x2e8b6f = _0x5e7cb6 + _0x548cee[_0x5104d3],
                        _0x1b0962 = _0x1eea9a['measureText'](_0x2e8b6f),
                        _0x1b0962 = _0x1b0962['width'];
                    _0x1b0962 > _0x29026f && 0x0 < _0x5104d3 ? (_0x461098['push'](_0x5e7cb6), _0x5e7cb6 = _0x548cee[_0x5104d3]) : _0x5e7cb6 = _0x2e8b6f;
                } else {
                    for (_0x5104d3 = 0x0; _0x5104d3 < _0x4cde59['length']; _0x5104d3++) _0x2e8b6f = _0x5e7cb6 + _0x4cde59[_0x5104d3] + '\x20', _0x1b0962 = _0x1eea9a['measureText'](_0x2e8b6f), _0x1b0962 = _0x1b0962['width'], _0x1b0962 > _0x29026f && 0x0 < _0x5104d3 ? (_0x461098['push'](_0x5e7cb6), _0x5e7cb6 = _0x4cde59[_0x5104d3] + '\x20') : _0x5e7cb6 = _0x2e8b6f;
                }
            return _0x461098['push'](_0x5e7cb6), _0x461098;
        },
        'drawTextList': function(_0x3b0f6c, _0x72ad12, _0x5d8fa9) {
            if (_0x3b0f6c && _0x3b0f6c['length'] && !(0x0 >= _0x3b0f6c['length'])) {
                for (var _0x2bfb1c = ig['system']['context'], _0x1d9800 = 0x0, _0x54cc7e = 0x0; _0x54cc7e < _0x3b0f6c['length']; _0x54cc7e++) this['outline'] && _0x2bfb1c['strokeText'](_0x3b0f6c[_0x54cc7e], _0x72ad12, _0x5d8fa9 + _0x1d9800), _0x2bfb1c['fillText'](_0x3b0f6c[_0x54cc7e], _0x72ad12, _0x5d8fa9 + _0x1d9800), _0x1d9800 += this['textLineHeight'];
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.game-trail')['requires']('impact.entity')['defines'](function() {
    GameTrailNode = ig['Class']['extend']({
        'x': 0x0,
        'y': 0x0,
        'time': 0x0,
        'remainder': 0x0,
        'prev': null,
        'next': null,
        'l': 0x0,
        'w': 0x1,
        'dx': 0x0,
        'dy': 0x0,
        'adx': 0x0,
        'ady': 0x0,
        'ndx': 0x0,
        'ndy': 0x0,
        'init': function(_0x8c7e62, _0xedb7e4, _0x3f8644, _0x111258) {
            this['x'] = _0x8c7e62, this['y'] = _0xedb7e4, this['time'] = _0x3f8644, this['remainder'] = _0x111258;
        },
        'setNext': function(_0x5846ea) {
            this['next'] = _0x5846ea, _0x5846ea = this['next']['x'] - this['x'];
            var _0x2a9235 = this['next']['y'] - this['y'],
                _0x5df14f = Math['sqrt'](_0x5846ea * _0x5846ea + _0x2a9235 * _0x2a9235);
            this['l'] = _0x5df14f, this['next']['l'] = _0x5df14f, this['next']['dx'] = _0x5846ea / _0x5df14f, this['next']['dy'] = _0x2a9235 / _0x5df14f, this['next']['ndx'] = -this['next']['dy'], this['next']['ndy'] = this['next']['dx'], this['prev'] ? (this['adx'] = (this['dx'] + this['next']['dx']) / 0x2, this['ady'] = (this['dy'] + this['next']['dy']) / 0x2, this['ndx'] = -this['ady'], this['ndy'] = this['adx']) : (this['adx'] = this['next']['dx'], this['ady'] = this['next']['dy'], this['ndx'] = -this['ady'], this['ndy'] = this['adx'], this['dx'] = this['next']['dx'], this['dy'] = this['next']['dy']);
        },
        'setPrev': function(_0x4a5feb) {
            this['prev'] = _0x4a5feb;
        }
    }), EntityGameTrail = ig['Entity']['extend']({
        'zIndex': 0x4e20,
        'nodeList': [],
        'lineList': [],
        'pollInterval': 0.01,
        'pollMaxDuration': 0.15,
        'maxPollInterval': 0.1,
        'nodeMinDistance': 0x10,
        'pollFlag': !0x1,
        'hidden': !0x1,
        'preventSlashes': !0x1,
        'control': null,
        'pointer': null,
        'init': function(_0x3a47e5, _0x2c9bd9, _0x20c598) {
            this['parent'](_0x3a47e5, _0x2c9bd9, _0x20c598);
        },
        'ready': function() {
            (this['control'] = ig['game']['gameController']) || (this['control'] = ig['game']['titleController']), this['pointer'] = ig['game']['getEntitiesByType'](EntityPointer)[0x0];
        },
        'setButtonsActive': function(_0x285847) {
            _0x285847 ? this['show']() : this['hide']();
        },
        'draw': function() {
            if (!this['hidden']) {
                for (var _0x3d3fec = 0x0; _0x3d3fec < this['lineList']['length']; _0x3d3fec++) this['drawLineFromNodeList'](this['lineList'][_0x3d3fec]);
                this['drawLineFromNodeList'](this['nodeList']);
            }
        },
        'update': function() {
            !ig['game']['active'] && this['pollFlag'] && (this['pollFlag'] = !0x1);
            if (!this['control']['gamePaused']) {
                ig['game']['idleCounter'] += ig['system']['tick'], ig['game']['idleCounter'] >= ig['businessdb']['IdleThreshold'] && ig['game']['gameController']['tutorial']['showIdleGuide'](), this['detectActivation']();
                for (var _0x3659fd = ig['system']['clock']['delta'](), _0x43b001 = _0x3659fd % this['pollInterval']; 0x0 < this['nodeList']['length'];) {
                    var _0x41a7ed = this['nodeList'][0x0];
                    if (_0x3659fd - _0x43b001 - (_0x41a7ed['time'] - _0x41a7ed['remainder']) >= this['pollMaxDuration']) this['nodeList']['splice'](0x0, 0x1), 0x0 < this['nodeList']['length'] && this['nodeList'][0x0]['setPrev'](null);
                    else break;
                }
                for (var _0x46a300 = 0x0; _0x46a300 < this['lineList']['length'];) {
                    for (var _0x3ca055 = this['lineList'][_0x46a300]; 0x0 < _0x3ca055['length'];)
                        if (_0x41a7ed = _0x3ca055[0x0], _0x3659fd - _0x43b001 - (_0x41a7ed['time'] - _0x41a7ed['remainder']) >= this['pollMaxDuration']) _0x3ca055['splice'](0x0, 0x1), 0x0 < _0x3ca055['length'] && _0x3ca055[0x0]['setPrev'](null);
                        else break;
                    0x0 == _0x3ca055['length'] ? this['lineList']['splice'](0x0, 0x1) : _0x46a300++;
                }
                if (this['pollFlag'] && !(0x0 < this['nodeList']['length'] && (_0x41a7ed = this['nodeList'][this['nodeList']['length'] - 0x1], _0x3659fd - (_0x41a7ed['time'] - _0x41a7ed['remainder']) < this['pollInterval']))) {
                    if (_0x46a300 = ig['game']['inputPos'], !(0x0 < this['nodeList']['length'] && (_0x41a7ed = this['nodeList'][this['nodeList']['length'] - 0x1], _0x3ca055 = _0x46a300['x'] - _0x41a7ed['x'], _0x41a7ed = _0x46a300['y'] - _0x41a7ed['y'], _0x3ca055 * _0x3ca055 + _0x41a7ed * _0x41a7ed < this['nodeMinDistance']))) _0x3659fd = new GameTrailNode(_0x46a300['x'], _0x46a300['y'], _0x3659fd, _0x43b001), 0x0 < this['nodeList']['length'] && (_0x41a7ed = this['nodeList'][this['nodeList']['length'] - 0x1], _0x41a7ed['setNext'](_0x3659fd), _0x3659fd['setPrev'](_0x41a7ed)), this['nodeList']['push'](_0x3659fd), this['preventSlashes'] || this['detectSlashes']();
                }
            }
        },
        'detectActivation': function() {
            if (this['pollFlag']) ig['domHandler']['getElementById'](document)['mouseleave'](function() {
                return ig['input']['clearState']('click'), ig['input']['clearPressed'](), this['deactivate'](), !0x1;
            }['bind'](this)), ig['input']['released']('click') && this['deactivate']();
            else {
                if (ig['input']['state']('click')) return this['activate'](), 0x0 < this['nodeList']['length'] && this['lineList']['push'](this['nodeList']), this['nodeList'] = [], !0x0;
            }
            return !0x1;
        },
        'activate': function() {
            this['pollFlag'] || (this['pollFlag'] = !0x0);
        },
        'deactivate': function() {
            this['pollFlag'] && (this['pollFlag'] = !0x1);
        },
        'drawLineFromNodeList': function(_0x15cceb) {
            if (_0x15cceb && !(0x1 >= _0x15cceb['length'])) {
                var _0x358526 = ig['system']['context'];
                _0x358526['lineWidth'] = 0x2, _0x358526['strokeStyle'] = 'rgba(255,255,255,0.5)';
                for (var _0x2b5ae8 = 0xc, _0x5779b9 = 0x0; _0x5779b9 < _0x15cceb['length']; _0x5779b9++) {
                    var _0x43f7cd = _0x15cceb[_0x5779b9],
                        _0x2c55ce = ig['system']['clock']['delta']() - _0x43f7cd['time'],
                        _0x2c55ce = _0x2c55ce / this['pollMaxDuration'];
                    0x1 < _0x2c55ce && (_0x2c55ce = 0x1), _0x2c55ce = 0x1 - _0x2c55ce, _0x43f7cd['t'] = _0x2c55ce, _0x43f7cd['w'] = _0x2b5ae8 * _0x2c55ce;
                }
                _0x358526['beginPath'](), _0x43f7cd = _0x15cceb[0x0], _0x2c55ce = _0x43f7cd['x'] - _0x43f7cd['dx'] * _0x43f7cd['w'], _0x43f7cd = _0x43f7cd['y'] - _0x43f7cd['dy'] * _0x43f7cd['w'], _0x358526['moveTo'](_0x2c55ce, _0x43f7cd);
                for (_0x5779b9 = 0x0; _0x5779b9 < _0x15cceb['length'] - 0x1; _0x5779b9++) _0x43f7cd = _0x15cceb[_0x5779b9], _0x2c55ce = _0x43f7cd['x'] + _0x43f7cd['ndx'] * _0x43f7cd['w'], _0x43f7cd = _0x43f7cd['y'] + _0x43f7cd['ndy'] * _0x43f7cd['w'], _0x358526['lineTo'](_0x2c55ce, _0x43f7cd);
                _0x43f7cd = _0x15cceb[_0x15cceb['length'] - 0x1], _0x2b5ae8 > _0x43f7cd['l'] && (_0x2b5ae8 = _0x43f7cd['l']), _0x2c55ce = _0x43f7cd['x'] + _0x43f7cd['ndx'] * _0x43f7cd['w'] - _0x43f7cd['dx'] * _0x2b5ae8, _0x43f7cd = _0x43f7cd['y'] + _0x43f7cd['ndy'] * _0x43f7cd['w'] - _0x43f7cd['dy'] * _0x2b5ae8, _0x358526['lineTo'](_0x2c55ce, _0x43f7cd), _0x43f7cd = _0x15cceb[_0x15cceb['length'] - 0x1], _0x2c55ce = _0x43f7cd['x'] + _0x43f7cd['dx'] * _0x43f7cd['w'], _0x43f7cd = _0x43f7cd['y'] + _0x43f7cd['dy'] * _0x43f7cd['w'], _0x358526['lineTo'](_0x2c55ce, _0x43f7cd), _0x43f7cd = _0x15cceb[_0x15cceb['length'] - 0x1], _0x2c55ce = _0x43f7cd['x'] - _0x43f7cd['ndx'] * _0x43f7cd['w'] - _0x43f7cd['dx'] * _0x2b5ae8, _0x43f7cd = _0x43f7cd['y'] - _0x43f7cd['ndy'] * _0x43f7cd['w'] - _0x43f7cd['dy'] * _0x2b5ae8, _0x358526['lineTo'](_0x2c55ce, _0x43f7cd);
                for (_0x5779b9 = _0x15cceb['length'] - 0x2; 0x0 <= _0x5779b9; _0x5779b9--) _0x43f7cd = _0x15cceb[_0x5779b9], _0x2c55ce = _0x43f7cd['x'] - _0x43f7cd['ndx'] * _0x43f7cd['w'], _0x43f7cd = _0x43f7cd['y'] - _0x43f7cd['ndy'] * _0x43f7cd['w'], _0x358526['lineTo'](_0x2c55ce, _0x43f7cd);
                _0x358526['closePath'](), _0x358526['fillStyle'] = 'rgba(127,127,127,0.75)', _0x358526['fill'](), _0x2b5ae8 = 0x8;
                for (_0x5779b9 = 0x0; _0x5779b9 < _0x15cceb['length']; _0x5779b9++) _0x43f7cd = _0x15cceb[_0x5779b9], _0x2c55ce = ig['system']['clock']['delta']() - _0x43f7cd['time'], _0x2c55ce /= this['pollMaxDuration'], 0x1 < _0x2c55ce && (_0x2c55ce = 0x1), _0x2c55ce -= 0x1, _0x43f7cd['t'] = _0x2c55ce, _0x43f7cd['w'] = _0x2b5ae8 * _0x2c55ce * _0x2c55ce;
                _0x358526['beginPath'](), _0x43f7cd = _0x15cceb[0x0], _0x2c55ce = _0x43f7cd['x'] - _0x43f7cd['dx'] * _0x43f7cd['w'], _0x43f7cd = _0x43f7cd['y'] - _0x43f7cd['dy'] * _0x43f7cd['w'], _0x358526['moveTo'](_0x2c55ce, _0x43f7cd);
                for (_0x5779b9 = 0x0; _0x5779b9 < _0x15cceb['length'] - 0x1; _0x5779b9++) _0x43f7cd = _0x15cceb[_0x5779b9], _0x2c55ce = _0x43f7cd['x'] + _0x43f7cd['ndx'] * _0x43f7cd['w'], _0x43f7cd = _0x43f7cd['y'] + _0x43f7cd['ndy'] * _0x43f7cd['w'], _0x358526['lineTo'](_0x2c55ce, _0x43f7cd);
                _0x43f7cd = _0x15cceb[_0x15cceb['length'] - 0x1], _0x2b5ae8 > _0x43f7cd['l'] && (_0x2b5ae8 = _0x43f7cd['l']), _0x2c55ce = _0x43f7cd['x'] + _0x43f7cd['ndx'] * _0x43f7cd['w'] - _0x43f7cd['dx'] * _0x2b5ae8, _0x43f7cd = _0x43f7cd['y'] + _0x43f7cd['ndy'] * _0x43f7cd['w'] - _0x43f7cd['dy'] * _0x2b5ae8, _0x358526['lineTo'](_0x2c55ce, _0x43f7cd), _0x43f7cd = _0x15cceb[_0x15cceb['length'] - 0x1], _0x2c55ce = _0x43f7cd['x'] + _0x43f7cd['dx'] * _0x43f7cd['w'], _0x43f7cd = _0x43f7cd['y'] + _0x43f7cd['dy'] * _0x43f7cd['w'], _0x358526['lineTo'](_0x2c55ce, _0x43f7cd), _0x43f7cd = _0x15cceb[_0x15cceb['length'] - 0x1], _0x2c55ce = _0x43f7cd['x'] - _0x43f7cd['ndx'] * _0x43f7cd['w'] - _0x43f7cd['dx'] * _0x2b5ae8, _0x43f7cd = _0x43f7cd['y'] - _0x43f7cd['ndy'] * _0x43f7cd['w'] - _0x43f7cd['dy'] * _0x2b5ae8, _0x358526['lineTo'](_0x2c55ce, _0x43f7cd);
                for (_0x5779b9 = _0x15cceb['length'] - 0x2; 0x0 <= _0x5779b9; _0x5779b9--) _0x43f7cd = _0x15cceb[_0x5779b9], _0x2c55ce = _0x43f7cd['x'] - _0x43f7cd['ndx'] * _0x43f7cd['w'], _0x43f7cd = _0x43f7cd['y'] - _0x43f7cd['ndy'] * _0x43f7cd['w'], _0x358526['lineTo'](_0x2c55ce, _0x43f7cd);
                _0x358526['closePath'](), _0x358526['fillStyle'] = 'rgb(255,255,255)', _0x358526['fill']();
            }
        },
        'drawSmoothedLine': function(_0x1e4f4b) {
            if (_0x1e4f4b && !(0x2 >= _0x1e4f4b['length'])) {
                for (var _0x450f0e = ig['system']['context'], _0x48ef03 = 0xc, _0x4990c6 = 0x0; _0x4990c6 < _0x1e4f4b['length']; _0x4990c6++) {
                    var _0x3a622a = _0x1e4f4b[_0x4990c6],
                        _0x47d030 = ig['system']['clock']['delta']() - _0x3a622a['time'],
                        _0x47d030 = _0x47d030 / this['pollMaxDuration'];
                    0x1 < _0x47d030 && (_0x47d030 = 0x1), _0x47d030 = 0x1 - _0x47d030, _0x3a622a['t'] = _0x47d030, _0x3a622a['w'] = _0x48ef03 * _0x47d030;
                }
                _0x450f0e['beginPath']();
                var _0x3a622a = _0x1e4f4b[0x0],
                    _0x47d030 = _0x3a622a['x'] - _0x3a622a['dx'] * _0x3a622a['w'],
                    _0x20ef74 = _0x3a622a['y'] - _0x3a622a['dy'] * _0x3a622a['w'];
                _0x450f0e['moveTo'](_0x47d030, _0x20ef74);
                var _0x3a622a = _0x1e4f4b[0x1],
                    _0x47d030 = _0x3a622a['x'] + _0x3a622a['ndx'] * _0x3a622a['w'],
                    _0x20ef74 = _0x3a622a['y'] + _0x3a622a['ndy'] * _0x3a622a['w'],
                    _0x211ea6 = _0x1e4f4b[0x2],
                    _0x20c167 = _0x3a622a['w'],
                    _0x20c167 = _0x211ea6['l'] / 0x2;
                _0x20c167 > _0x211ea6['l'] / 0x2 && (_0x20c167 = _0x211ea6['l'] / 0x2), 0x1 > _0x20c167 ? _0x450f0e['lineTo'](_0x47d030, _0x20ef74) : _0x450f0e['quadraticCurveTo'](_0x47d030, _0x20ef74, _0x47d030 + _0x211ea6['dx'] * _0x20c167, _0x20ef74 + _0x211ea6['dy'] * _0x20c167);
                for (_0x4990c6 = 0x2; _0x4990c6 < _0x1e4f4b['length'] - 0x1; _0x4990c6++) _0x3a622a = _0x1e4f4b[_0x4990c6], _0x20c167 = _0x3a622a['l'] / 0x2, _0x20c167 > _0x3a622a['l'] / 0x2 && (_0x20c167 = _0x3a622a['l'] / 0x2), 0x1 > _0x20c167 && (_0x20c167 = 0x0), _0x47d030 = _0x3a622a['x'] + _0x3a622a['ndx'] * _0x3a622a['w'] - _0x3a622a['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] + _0x3a622a['ndy'] * _0x3a622a['w'] - _0x3a622a['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x47d030 = _0x3a622a['x'] + _0x3a622a['ndx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] + _0x3a622a['ndy'] * _0x3a622a['w'], _0x211ea6 = _0x1e4f4b[_0x4990c6 + 0x1], _0x20c167 = _0x211ea6['l'] / 0x2, _0x20c167 > _0x211ea6['l'] / 0x2 && (_0x20c167 = _0x211ea6['l'] / 0x2), 0x1 > _0x20c167 ? _0x450f0e['lineTo'](_0x47d030, _0x20ef74) : _0x450f0e['quadraticCurveTo'](_0x47d030, _0x20ef74, _0x47d030 + _0x211ea6['dx'] * _0x20c167, _0x20ef74 + _0x211ea6['dy'] * _0x20c167);
                _0x3a622a = _0x1e4f4b[_0x1e4f4b['length'] - 0x1], _0x20c167 = _0x48ef03, _0x20c167 > _0x3a622a['l'] / 0x2 && (_0x20c167 = _0x3a622a['l'] / 0x2), 0x1 > _0x20c167 && (_0x20c167 = 0x0), _0x47d030 = _0x3a622a['x'] + _0x3a622a['ndx'] * _0x3a622a['w'] - _0x3a622a['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] + _0x3a622a['ndy'] * _0x3a622a['w'] - _0x3a622a['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x3a622a = _0x1e4f4b[_0x1e4f4b['length'] - 0x1], _0x47d030 = _0x3a622a['x'] + _0x3a622a['dx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] + _0x3a622a['dy'] * _0x3a622a['w'], _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x3a622a = _0x1e4f4b[_0x1e4f4b['length'] - 0x1], _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'] - _0x3a622a['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'] - _0x3a622a['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74);
                for (_0x4990c6 = _0x1e4f4b['length'] - 0x2; 0x2 <= _0x4990c6; _0x4990c6--) _0x3a622a = _0x1e4f4b[_0x4990c6], _0x20ef74 = _0x1e4f4b[_0x4990c6 + 0x1], _0x20c167 = _0x20ef74['l'] / 0x2, _0x20c167 > _0x20ef74['l'] / 0x2 && (_0x20c167 = _0x20ef74['l'] / 0x2), 0x1 > _0x20c167 && (_0x20c167 = 0x0), _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'] + _0x20ef74['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'] + _0x20ef74['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'], _0x20c167 = _0x3a622a['l'] / 0x2, _0x20c167 > _0x3a622a['l'] / 0x2 && (_0x20c167 = _0x3a622a['l'] / 0x2), 0x1 > _0x20c167 ? _0x450f0e['lineTo'](_0x47d030, _0x20ef74) : _0x450f0e['quadraticCurveTo'](_0x47d030, _0x20ef74, _0x47d030 - _0x3a622a['dx'] * _0x20c167, _0x20ef74 - _0x3a622a['dy'] * _0x20c167);
                _0x3a622a = _0x1e4f4b[0x1], _0x20ef74 = _0x1e4f4b[0x2], _0x20c167 = _0x20ef74['l'] / 0x2, _0x20c167 > _0x20ef74['l'] / 0x2 && (_0x20c167 = _0x20ef74['l'] / 0x2), 0x1 > _0x20c167 && (_0x20c167 = 0x0), _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'] + _0x20ef74['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'] + _0x20ef74['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'], _0x4990c6 = _0x1e4f4b[0x0]['x'] - _0x1e4f4b[0x0]['dx'] * _0x1e4f4b[0x0]['w'], _0x3a622a = _0x1e4f4b[0x0]['y'] - _0x1e4f4b[0x0]['dy'] * _0x1e4f4b[0x0]['w'], _0x450f0e['quadraticCurveTo'](_0x47d030, _0x20ef74, _0x4990c6, _0x3a622a), _0x450f0e['closePath'](), _0x450f0e['fillStyle'] = 'rgba(127,127,127,0.75)', _0x450f0e['fill'](), _0x48ef03 = 0x8;
                for (_0x4990c6 = 0x0; _0x4990c6 < _0x1e4f4b['length']; _0x4990c6++) _0x3a622a = _0x1e4f4b[_0x4990c6], _0x47d030 = ig['system']['clock']['delta']() - _0x3a622a['time'], _0x47d030 /= this['pollMaxDuration'], 0x1 < _0x47d030 && (_0x47d030 = 0x1), _0x47d030 = 0x1 - _0x47d030, _0x3a622a['t'] = _0x47d030, _0x3a622a['w'] = _0x48ef03 * _0x47d030 * _0x47d030;
                _0x450f0e['beginPath'](), _0x3a622a = _0x1e4f4b[0x0], _0x47d030 = _0x3a622a['x'] - _0x3a622a['dx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] - _0x3a622a['dy'] * _0x3a622a['w'], _0x450f0e['moveTo'](_0x47d030, _0x20ef74), _0x3a622a = _0x1e4f4b[0x1], _0x47d030 = _0x3a622a['x'] + _0x3a622a['ndx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] + _0x3a622a['ndy'] * _0x3a622a['w'], _0x211ea6 = _0x1e4f4b[0x2], _0x20c167 = _0x211ea6['l'] / 0x2, _0x20c167 > _0x211ea6['l'] / 0x2 && (_0x20c167 = _0x211ea6['l'] / 0x2), 0x1 > _0x20c167 ? _0x450f0e['lineTo'](_0x47d030, _0x20ef74) : _0x450f0e['quadraticCurveTo'](_0x47d030, _0x20ef74, _0x47d030 + _0x211ea6['dx'] * _0x20c167, _0x20ef74 + _0x211ea6['dy'] * _0x20c167);
                for (_0x4990c6 = 0x2; _0x4990c6 < _0x1e4f4b['length'] - 0x1; _0x4990c6++) _0x3a622a = _0x1e4f4b[_0x4990c6], _0x20c167 = _0x3a622a['l'] / 0x2, _0x20c167 > _0x3a622a['l'] / 0x2 && (_0x20c167 = _0x3a622a['l'] / 0x2), 0x1 > _0x20c167 && (_0x20c167 = 0x0), _0x47d030 = _0x3a622a['x'] + _0x3a622a['ndx'] * _0x3a622a['w'] - _0x3a622a['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] + _0x3a622a['ndy'] * _0x3a622a['w'] - _0x3a622a['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x47d030 = _0x3a622a['x'] + _0x3a622a['ndx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] + _0x3a622a['ndy'] * _0x3a622a['w'], _0x211ea6 = _0x1e4f4b[_0x4990c6 + 0x1], _0x20c167 = _0x211ea6['l'] / 0x2, _0x20c167 > _0x211ea6['l'] / 0x2 && (_0x20c167 = _0x211ea6['l'] / 0x2), 0x1 > _0x20c167 ? _0x450f0e['lineTo'](_0x47d030, _0x20ef74) : _0x450f0e['quadraticCurveTo'](_0x47d030, _0x20ef74, _0x47d030 + _0x211ea6['dx'] * _0x20c167, _0x20ef74 + _0x211ea6['dy'] * _0x20c167);
                _0x3a622a = _0x1e4f4b[_0x1e4f4b['length'] - 0x1], _0x20c167 = _0x48ef03, _0x20c167 > _0x3a622a['l'] / 0x2 && (_0x20c167 = _0x3a622a['l'] / 0x2), 0x1 > _0x20c167 && (_0x20c167 = 0x0), _0x47d030 = _0x3a622a['x'] + _0x3a622a['ndx'] * _0x3a622a['w'] - _0x3a622a['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] + _0x3a622a['ndy'] * _0x3a622a['w'] - _0x3a622a['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x3a622a = _0x1e4f4b[_0x1e4f4b['length'] - 0x1], _0x47d030 = _0x3a622a['x'] + _0x3a622a['dx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] + _0x3a622a['dy'] * _0x3a622a['w'], _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x3a622a = _0x1e4f4b[_0x1e4f4b['length'] - 0x1], _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'] - _0x3a622a['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'] - _0x3a622a['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74);
                for (_0x4990c6 = _0x1e4f4b['length'] - 0x2; 0x2 <= _0x4990c6; _0x4990c6--) _0x3a622a = _0x1e4f4b[_0x4990c6], _0x20ef74 = _0x1e4f4b[_0x4990c6 + 0x1], _0x20c167 = _0x20ef74['l'] / 0x2, _0x20c167 > _0x20ef74['l'] / 0x2 && (_0x20c167 = _0x20ef74['l'] / 0x2), 0x1 > _0x20c167 && (_0x20c167 = 0x0), _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'] + _0x20ef74['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'] + _0x20ef74['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'], _0x20c167 = _0x3a622a['l'] / 0x2, _0x20c167 > _0x3a622a['l'] / 0x2 && (_0x20c167 = _0x3a622a['l'] / 0x2), 0x1 > _0x20c167 ? _0x450f0e['lineTo'](_0x47d030, _0x20ef74) : _0x450f0e['quadraticCurveTo'](_0x47d030, _0x20ef74, _0x47d030 - _0x3a622a['dx'] * _0x20c167, _0x20ef74 - _0x3a622a['dy'] * _0x20c167);
                _0x3a622a = _0x1e4f4b[0x1], _0x20ef74 = _0x1e4f4b[0x2], _0x20c167 = _0x20ef74['l'] / 0x2, _0x20c167 > _0x20ef74['l'] / 0x2 && (_0x20c167 = _0x20ef74['l'] / 0x2), 0x1 > _0x20c167 && (_0x20c167 = 0x0), _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'] + _0x20ef74['dx'] * _0x20c167, _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'] + _0x20ef74['dy'] * _0x20c167, _0x450f0e['lineTo'](_0x47d030, _0x20ef74), _0x47d030 = _0x3a622a['x'] - _0x3a622a['ndx'] * _0x3a622a['w'], _0x20ef74 = _0x3a622a['y'] - _0x3a622a['ndy'] * _0x3a622a['w'], _0x4990c6 = _0x1e4f4b[0x0]['x'] - _0x1e4f4b[0x0]['dx'] * _0x1e4f4b[0x0]['w'], _0x3a622a = _0x1e4f4b[0x0]['y'] - _0x1e4f4b[0x0]['dy'] * _0x1e4f4b[0x0]['w'], _0x450f0e['quadraticCurveTo'](_0x47d030, _0x20ef74, _0x4990c6, _0x3a622a), _0x450f0e['closePath'](), _0x450f0e['fillStyle'] = 'rgb(255,255,255)', _0x450f0e['fill']();
            }
        },
        'detectSlashes': function() {
            ig['game']['gameController']['tutorial']['hideIdleGuide']();
            if (!(0x2 > this['nodeList']['length']))
                for (var _0x46f57a = this['nodeList'][this['nodeList']['length'] - 0x1], _0xd7b9bd = this['nodeList'][this['nodeList']['length'] - 0x2], _0x2c03a0 = this['control']['listPlot'], _0x3355ef = 0x0; _0x3355ef < _0x2c03a0['length']; _0x3355ef++) {
                    var _0x5dc66e = _0x2c03a0[_0x3355ef];
                    if (null != _0x5dc66e['fillButton'] && _0x5dc66e['fillButton']['detectIntersect'](_0xd7b9bd, _0x46f57a)) _0x5dc66e['onHarvestClicked']();
                }
        },
        'rayCircleIntersect': function(_0x3a2bbe, _0x44da4e, _0x227f47, _0x3a21e5) {
            var _0x261454 = 0x0,
                _0x3d7154 = 0x0,
                _0x261454 = _0x44da4e['x'] - _0x3a2bbe['x'],
                _0x3d7154 = _0x44da4e['y'] - _0x3a2bbe['y'],
                _0x178376 = 0x0;
            return _0x44da4e = _0x3a2bbe['x'] - _0x227f47['x'], _0x178376 = _0x3a2bbe['y'] - _0x227f47['y'], _0x3a2bbe = _0x261454 * _0x261454 + _0x3d7154 * _0x3d7154, _0x261454 = 0x2 * (_0x44da4e * _0x261454 + _0x178376 * _0x3d7154), _0x3d7154 = _0x261454 * _0x261454 - 0x4 * _0x3a2bbe * (_0x44da4e * _0x44da4e + _0x178376 * _0x178376 - _0x3a21e5 * _0x3a21e5), !(0x0 > _0x3d7154) && (_0x3d7154 = Math['sqrt'](_0x3d7154), _0x3a21e5 = (-_0x261454 - _0x3d7154) / (0x2 * _0x3a2bbe), _0x261454 = (-_0x261454 + _0x3d7154) / (0x2 * _0x3a2bbe), 0x0 <= _0x3a21e5 && 0x1 >= _0x3a21e5 || 0x0 <= _0x261454 && 0x1 >= _0x261454 || 0x0 > _0x3a21e5 && 0x1 < _0x261454) ? !0x0 : !0x1;
        },
        'hide': function() {
            this['hidden'] = !0x0;
        },
        'show': function() {
            this['hidden'] = !0x1;
        },
        'setupTest': function() {}
    });
}), this['START_BRANDING_SPLASH'], ig['baked'] = !0x0, ig['module']('plugins.branding.splash')['requires']('impact.impact', 'impact.entity')['defines'](function() {
    ig['BrandingSplash'] = ig['Class']['extend']({
        'init': function() {
            ig['game']['spawnEntity'](EntityBranding, 0x0, 0x0), console['log']('spawn\x20branding');
        }
    }), EntityBranding = ig['Entity']['extend']({
        'autoUpdateScale': !0x1,
        'gravityFactor': 0x0,
        'size': {
            'x': 0x20,
            'y': 0x20
        },
        'splash': new ig['Image']('branding/splash1.png'),
        'init': function(_0x40b5f5, _0x4f9b62, _0x3dcd3f) {
            this['parent'](_0x40b5f5, _0x4f9b62, _0x3dcd3f), this['resizeLogo'](), this['pos']['x'] = (ig['system']['width'] - this['size']['x']) / 0x2, this['pos']['y'] = -this['size']['y'] - 0xc8, this['endPosY'] = (ig['system']['height'] - this['size']['y']) / 0x2, _0x40b5f5 = this['tween']({
                'pos': {
                    'y': this['endPosY']
                }
            }, 0.5, {
                'easing': ig['Tween']['Easing']['Bounce']['EaseIn']
            }), _0x4f9b62 = this['tween']({}, 2.5, {
                'onComplete': function() {
                    ig['game']['director']['loadLevel'](ig['game']['director']['currentLevel']);
                }
            }), _0x40b5f5['chain'](_0x4f9b62), _0x40b5f5['start'](), this['currentAnim'] = this['anims']['idle'];
        },
        'logoWidth': 0x320,
        'logoHeight': 0xc8,
        'resizeLogo': function() {
            ig['system']['width'] < 1.1111 * this['logoWidth'] ? (this['size']['x'] = 0.9 * ig['system']['width'], this['size']['y'] = this['logoHeight'] * (this['size']['x'] / this['logoWidth'])) : (this['size']['x'] = this['logoWidth'], this['size']['y'] = this['logoHeight']);
        },
        'createClickableLayer': function() {
            console['log']('Build\x20clickable\x20layer'), this['checkClickableLayer']('branding-splash', _SETTINGS['Branding']['Logo']['Link'], _SETTINGS['Branding']['Logo']['NewWindow']);
        },
        'doesClickableLayerExist': function(_0x24512d) {
            for (k in dynamicClickableEntityDivs)
                if (k == _0x24512d) return !0x0;
            return !0x1;
        },
        'checkClickableLayer': function(_0xe3ad99, _0x5c6cea, _0x191b41) {
            'undefined' == typeof wm && (this['doesClickableLayerExist'](_0xe3ad99) ? (ig['game']['showOverlay']([_0xe3ad99]), $('#' + _0xe3ad99)['find']('[href]')['attr']('href', _0x5c6cea)) : this['createClickableOutboundLayer'](_0xe3ad99, _0x5c6cea, 'media/graphics/misc/invisible.png', _0x191b41));
        },
        'createClickableOutboundLayer': function(_0xda8306, _0x5318fc, _0x3c72c2, _0x4ac84d) {
            var _0x5ce3fc = ig['$new']('div');
            _0x5ce3fc['id'] = _0xda8306, document['body']['appendChild'](_0x5ce3fc), _0x5ce3fc = $('#' + _0x5ce3fc['id']), _0x5ce3fc['css']('float', 'left'), _0x5ce3fc['css']('position', 'absolute');
            if (ig['ua']['mobile']) {
                var _0x3ebb28 = window['innerHeight'] / mobileHeight,
                    _0x16a0e3 = window['innerWidth'] / mobileWidth;
                _0x5ce3fc['css']('left', this['pos']['x'] * _0x16a0e3), _0x5ce3fc['css']('top', this['pos']['y'] * _0x3ebb28), _0x5ce3fc['css']('width', this['size']['x'] * _0x16a0e3), _0x5ce3fc['css']('height', this['size']['y'] * _0x3ebb28);
            } else _0x3ebb28 = w / 0x2 - destW / 0x2, _0x16a0e3 = h / 0x2 - destH / 0x2, console['log'](_0x3ebb28, _0x16a0e3), _0x5ce3fc['css']('left', _0x3ebb28 + this['pos']['x'] * multiplier), _0x5ce3fc['css']('top', _0x16a0e3 + this['pos']['y'] * multiplier), _0x5ce3fc['css']('width', this['size']['x'] * multiplier), _0x5ce3fc['css']('height', this['size']['y'] * multiplier);
            _0x4ac84d ? _0x5ce3fc['html']('<a\x20x20href=\x27' + _0x5318fc + '\x27><img\x20style=\x27width:100%;height:100%\x27\x20src=\x27' + _0x3c72c2 + '\x27></a>') : _0x5ce3fc['html']('<a\x20href=\x27' + _0x5318fc + '\x27><img\x20style=\x27width:100%;height:100%\x27\x20src=\x27' + _0x3c72c2 + '\x27></a>'), dynamicClickableEntityDivs[_0xda8306] = {}, dynamicClickableEntityDivs[_0xda8306]['width'] = this['size']['x'] * multiplier, dynamicClickableEntityDivs[_0xda8306]['height'] = this['size']['y'] * multiplier, dynamicClickableEntityDivs[_0xda8306]['entity_pos_x'] = this['pos']['x'], dynamicClickableEntityDivs[_0xda8306]['entity_pos_y'] = this['pos']['y'];
        },
        'draw': function() {
            ig['system']['context']['fillStyle'] = '#ffffff', ig['system']['context']['fillRect'](0x0, 0x0, ig['system']['width'], ig['system']['height']), ig['system']['context']['fillStyle'] = '#000', ig['system']['context']['font'] = '12px\x20Arial', ig['system']['context']['textAlign'] = 'left', this['parent'](), this['splash'] && ig['system']['context']['drawImage'](this['splash']['data'], 0x0, 0x0, this['splash']['data']['width'], this['splash']['data']['height'], this['pos']['x'], this['pos']['y'], this['size']['x'], this['size']['y']);
        }
    });
}), this['END_BRANDING_SPLASH'], ig['baked'] = !0x0, ig['module']('game.entities.buttons.button')['requires']('impact.entity', 'plugins.data.vector')['defines'](function() {
    EntityButton = ig['Entity']['extend']({
        'collides': ig['Entity']['COLLIDES']['NEVER'],
        'type': ig['Entity']['TYPE']['A'],
        'size': new Vector2(0x30, 0x30),
        'fillColor': null,
        'zIndex': 0x17318,
        'init': function(_0x2d4860, _0x1bd3fc, _0x8471a0) {
            this['parent'](_0x2d4860, _0x1bd3fc, _0x8471a0), !ig['global']['wm'] && !isNaN(_0x8471a0['zIndex']) && (this['zIndex'] = _0x8471a0['zIndex']), _0x2d4860 = Math['floor'](0x100 * Math['random']()), _0x1bd3fc = Math['floor'](0x100 * Math['random']()), _0x8471a0 = Math['floor'](0x100 * Math['random']()), this['fillColor'] = 'rgba(' + _0x2d4860 + ',' + _0x8471a0 + ',' + _0x1bd3fc + ',1)';
        },
        'clicked': function() {
            throw 'no\x20implementation\x20on\x20clicked()';
        },
        'clicking': function() {
            throw 'no\x20implementation\x20on\x20clicking()';
        },
        'released': function() {
            throw 'no\x20implementation\x20on\x20released()';
        }
    });
}), ig['baked'] = !0x0, ig['module']('plugins.clickable-div-layer')['requires']('plugins.data.vector')['defines'](function() {
    ClickableDivLayer = ig['Class']['extend']({
        'pos': new Vector2(0x0, 0x0),
        'size': new Vector2(0x0, 0x0),
        'identifier': null,
        'invisImagePath': 'media/graphics/misc/invisible.png',
        'init': function(_0x59d550) {
            this['pos'] = new Vector2(_0x59d550['pos']['x'], _0x59d550['pos']['y']), this['size'] = new Vector2(_0x59d550['size']['x'], _0x59d550['size']['y']);
            var _0x345db0 = 'more-games',
                _0x2fe51b = 'www.google.com',
                _0x21dfd0 = !0x1;
            _0x59d550['div_layer_name'] && (_0x345db0 = _0x59d550['div_layer_name']), _0x59d550['link'] && (_0x2fe51b = _0x59d550['link']), _0x59d550['newWindow'] && (_0x21dfd0 = _0x59d550['newWindow']), this['createClickableLayer'](_0x345db0, _0x2fe51b, _0x21dfd0);
        },
        'createClickableLayer': function(_0x48c143, _0x5031ff, _0x417724) {
            this['identifier'] = _0x48c143;
            var _0x17c6b9 = ig['domHandler']['getElementById']('#' + _0x48c143);
            _0x17c6b9 ? (ig['domHandler']['show'](_0x17c6b9), ig['domHandler']['attr'](_0x17c6b9, 'href', _0x5031ff)) : this['createClickableOutboundLayer'](_0x48c143, _0x5031ff, this['invisImagePath'], _0x417724);
        },
        'update': function(_0x3078d0, _0x2eb7ec) {
            this['pos']['x'] == _0x3078d0 && this['pos']['y'] == _0x2eb7ec || (this['pos']['x'] = _0x3078d0, this['pos']['y'] = _0x2eb7ec, ig['sizeHandler']['dynamicClickableEntityDivs'][this['identifier']] = {}, ig['sizeHandler']['dynamicClickableEntityDivs'][this['identifier']]['width'] = this['size']['x'], ig['sizeHandler']['dynamicClickableEntityDivs'][this['identifier']]['height'] = this['size']['y'], ig['sizeHandler']['dynamicClickableEntityDivs'][this['identifier']]['entity_pos_x'] = this['pos']['x'], ig['sizeHandler']['dynamicClickableEntityDivs'][this['identifier']]['entity_pos_y'] = this['pos']['y'], ig['sizeHandler']['resizeLayers']());
        },
        'createClickableOutboundLayer': function(_0x2ba089, _0x38cb48, _0x230132, _0x26fffe) {
            var _0x56d3fd = ig['domHandler']['create']('div');
            ig['domHandler']['attr'](_0x56d3fd, 'id', _0x2ba089);
            var _0x4549a3 = ig['domHandler']['create']('a');
            ig['domHandler']['addEvent'](_0x56d3fd, 'mousedown', function(_0x516963) {
                _0x516963['preventDefault']();
            }), _0x26fffe ? (ig['domHandler']['attr'](_0x4549a3, 'href', _0x38cb48), ig['domHandler']['attr'](_0x4549a3, 'target', '_blank')) : ig['domHandler']['attr'](_0x4549a3, 'href', _0x38cb48), _0x38cb48 = ig['domHandler']['create']('img'), ig['domHandler']['css'](_0x38cb48, {
                'width': '100%',
                'height': '100%'
            }), ig['domHandler']['attr'](_0x38cb48, 'src', _0x230132), _0x230132 = Math['min'](ig['sizeHandler']['scaleRatioMultiplier']['x'], ig['sizeHandler']['scaleRatioMultiplier']['y']);
            if (ig['ua']['mobile']) {
                _0x26fffe = ig['domHandler']['getElementById']('#canvas');
                var _0x5094f1 = ig['domHandler']['getOffsets'](_0x26fffe);
                _0x26fffe = _0x5094f1['left'], _0x5094f1 = _0x5094f1['top'];
                if (ig['sizeHandler']['disableStretchToFitOnMobileFlag']) {
                    _0x26fffe = Math['floor'](_0x26fffe + this['pos']['x'] * ig['sizeHandler']['scaleRatioMultiplier']['x']) + 'px';
                    var _0x5094f1 = Math['floor'](_0x5094f1 + this['pos']['y'] * ig['sizeHandler']['scaleRatioMultiplier']['y']) + 'px',
                        _0x7f1335 = Math['floor'](this['size']['x'] * ig['sizeHandler']['scaleRatioMultiplier']['x']) + 'px';
                    _0x230132 = Math['floor'](this['size']['y'] * ig['sizeHandler']['scaleRatioMultiplier']['y']) + 'px';
                } else _0x26fffe = Math['floor'](this['pos']['x'] * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x5094f1 = Math['floor'](this['pos']['y'] * ig['sizeHandler']['sizeRatio']['y']) + 'px', _0x7f1335 = Math['floor'](this['size']['x'] * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x230132 = Math['floor'](this['size']['y'] * ig['sizeHandler']['sizeRatio']['y']) + 'px';
            } else _0x26fffe = ig['domHandler']['getElementById']('#canvas'), _0x5094f1 = ig['domHandler']['getOffsets'](_0x26fffe), _0x26fffe = _0x5094f1['left'], _0x5094f1 = _0x5094f1['top'], ig['sizeHandler']['enableStretchToFitOnDesktopFlag'] ? (_0x26fffe = Math['floor'](_0x26fffe + this['pos']['x'] * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x5094f1 = Math['floor'](_0x5094f1 + this['pos']['y'] * ig['sizeHandler']['sizeRatio']['y']) + 'px', _0x7f1335 = Math['floor'](this['size']['x'] * ig['sizeHandler']['sizeRatio']['x']) + 'px', _0x230132 = Math['floor'](this['size']['y'] * ig['sizeHandler']['sizeRatio']['y']) + 'px') : (_0x26fffe = Math['floor'](_0x26fffe + this['pos']['x'] * _0x230132) + 'px', _0x5094f1 = Math['floor'](_0x5094f1 + this['pos']['y'] * _0x230132) + 'px', _0x7f1335 = Math['floor'](this['size']['x'] * _0x230132) + 'px', _0x230132 = Math['floor'](this['size']['y'] * _0x230132) + 'px');
            ig['domHandler']['css'](_0x56d3fd, {
                'float': 'left',
                'position': 'absolute',
                'left': _0x26fffe,
                'top': _0x5094f1,
                'width': _0x7f1335,
                'height': _0x230132,
                'z-index': 0x3
            }), ig['domHandler']['addEvent'](_0x56d3fd, 'mousemove', ig['input']['mousemove']['bind'](ig['input']), !0x1), ig['domHandler']['appendChild'](_0x4549a3, _0x38cb48), ig['domHandler']['appendChild'](_0x56d3fd, _0x4549a3), ig['domHandler']['appendToBody'](_0x56d3fd), ig['sizeHandler']['dynamicClickableEntityDivs'][_0x2ba089] = {}, ig['sizeHandler']['dynamicClickableEntityDivs'][_0x2ba089]['width'] = this['size']['x'], ig['sizeHandler']['dynamicClickableEntityDivs'][_0x2ba089]['height'] = this['size']['y'], ig['sizeHandler']['dynamicClickableEntityDivs'][_0x2ba089]['entity_pos_x'] = this['pos']['x'], ig['sizeHandler']['dynamicClickableEntityDivs'][_0x2ba089]['entity_pos_y'] = this['pos']['y'];
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-branding-logo')['requires']('game.entities.buttons.button', 'plugins.clickable-div-layer')['defines'](function() {
    EntityButtonBrandingLogo = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'logo': new ig['AnimationSheet']('branding/logo.png', _SETTINGS['Branding']['Logo']['Width'], _SETTINGS['Branding']['Logo']['Height']),
        'zIndex': 0x2711,
        'size': {
            'x': 0x40,
            'y': 0x42
        },
        'clickableLayer': null,
        'link': null,
        'newWindow': !0x1,
        'div_layer_name': 'branding-logo',
        'name': 'brandinglogo',
        'init': function(_0x4e1cfc, _0x1a1813, _0x385d61) {
            this['parent'](_0x4e1cfc, _0x1a1813, _0x385d61);
            if (!ig['global']['wm']) {
                if ('undefined' == typeof wm) {
                    if (_SETTINGS['Branding']['Logo']['Enabled']) this['size']['x'] = _SETTINGS['Branding']['Logo']['Width'], this['size']['y'] = _SETTINGS['Branding']['Logo']['Height'], this['anims']['idle'] = new ig['Animation'](this['logo'], 0x0, [0x0], !0x0), this['currentAnim'] = this['anims']['idle'], _0x385d61 && _0x385d61['centralize'] && (this['pos']['x'] = ig['system']['width'] / 0x2 - this['size']['x'] / 0x2, console['log']('centralize\x20true\x20...\x20centering\x20branded\x20logo\x20...')), _SETTINGS['Branding']['Logo']['LinkEnabled'] && (this['link'] = _SETTINGS['Branding']['Logo']['Link'], this['newWindow'] = _SETTINGS['Branding']['Logo']['NewWindow'], this['clickableLayer'] = new ClickableDivLayer(this));
                    else {
                        this['kill']();
                        return;
                    }
                }
                this['div_layer_name'] = _0x385d61['div_layer_name'] ? _0x385d61['div_layer_name'] : 'branding-logo';
            }
        },
        'show': function() {
            var _0x147233 = ig['domHandler']['getElementById']('#' + this['div_layer_name']);
            ig['domHandler']['show'](_0x147233);
        },
        'hide': function() {
            var _0x1291c5 = ig['domHandler']['getElementById']('#' + this['div_layer_name']);
            ig['domHandler']['hide'](_0x1291c5);
        },
        'clicked': function() {},
        'clicking': function() {},
        'released': function() {}
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.branding-logo-placeholder')['requires']('impact.entity', 'game.entities.buttons.button-branding-logo')['defines'](function() {
    EntityBrandingLogoPlaceholder = ig['Entity']['extend']({
        'gravityFactor': 0x0,
        'size': {
            'x': 0x20,
            'y': 0x20
        },
        '_wmDrawBox': !0x0,
        '_wmBoxColor': 'rgba(0,\x200,\x20255,\x200.7)',
        'init': function(_0x362d1c, _0x368702, _0x5c1c9a) {
            this['parent'](_0x362d1c, _0x368702, _0x5c1c9a);
            if (_0x5c1c9a) switch (console['log']('settings\x20found\x20...\x20using\x20that\x20div\x20layer\x20name'), _0x362d1c = _0x5c1c9a['div_layer_name'], console['log']('settings.centralize:', _0x5c1c9a['centralize']), _0x5c1c9a['centralize']) {
                case 'true':
                    console['log']('centralize\x20true'), centralize = !0x0;
                    break;
                case 'false':
                    console['log']('centralize\x20false'), centralize = !0x1;
                    break;
                default:
                    console['log']('default\x20...\x20centralize\x20false'), centralize = !0x1;
            } else _0x362d1c = 'branding-logo', centralize = !0x1;
            if ('undefined' == typeof wm) {
                if (_SETTINGS['Branding']['Logo']['Enabled']) try {
                    ig['game']['spawnEntity'](EntityButtonBrandingLogo, this['pos']['x'], this['pos']['y'], {
                        'div_layer_name': _0x362d1c,
                        'centralize': centralize
                    });
                } catch (_0x35b16b) {
                    console['log'](_0x35b16b);
                }
                this['kill']();
            }
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-more-games')['requires']('game.entities.buttons.button', 'plugins.clickable-div-layer')['defines'](function() {
    EntityButtonMoreGames = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'logo': new ig['AnimationSheet']('media/graphics/sprites/btn-moregames.png', 0x5e, 0x5e),
        'size': {
            'x': 0x5e,
            'y': 0x5e
        },
        'clickableLayer': null,
        'link': null,
        'newWindow': !0x1,
        'div_layer_name': 'more-games',
        'name': 'moregames',
        'init': function(_0x4442c3, _0x3eaed1, _0x290d92) {
            this['parent'](_0x4442c3, _0x3eaed1, _0x290d92), ig['global']['wm'] || (this['div_layer_name'] = _0x290d92['div_layer_name'] ? _0x290d92['div_layer_name'] : 'more-games', _SETTINGS['MoreGames']['Enabled'] ? (this['anims']['idle'] = new ig['Animation'](this['logo'], 0x0, [0x0], !0x0), this['currentAnim'] = this['anims']['idle'], _SETTINGS['MoreGames']['Link'] && (this['link'] = _SETTINGS['MoreGames']['Link']), _SETTINGS['MoreGames']['NewWindow'] && (this['newWindow'] = _SETTINGS['MoreGames']['NewWindow']), this['clickableLayer'] = new ClickableDivLayer(this)) : this['kill']());
        },
        'update': function() {
            this['parent'](), this['clickableLayer']['update'](this['pos']['x'], this['pos']['y']);
        },
        'show': function() {
            var _0x663179 = ig['domHandler']['getElementById']('#' + this['div_layer_name']);
            _0x663179 && ig['domHandler']['show'](_0x663179);
        },
        'hide': function() {
            var _0x86e1ec = ig['domHandler']['getElementById']('#' + this['div_layer_name']);
            _0x86e1ec && ig['domHandler']['hide'](_0x86e1ec);
        },
        'clicked': function() {},
        'clicking': function() {},
        'released': function() {}
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.pointer')['requires']('impact.entity')['defines'](function() {
    EntityPointer = ig['Entity']['extend']({
        'checkAgainst': ig['Entity']['TYPE']['BOTH'],
        'size': new Vector2(0x1, 0x1),
        'isFirstPressed': !0x1,
        'isPressed': !0x1,
        'isReleased': !0x1,
        'isHovering': !0x1,
        'hoveringItem': null,
        'objectArray': [],
        'clickedObjectList': [],
        'ignorePause': !0x0,
        'zIndex': 0x157c,
        'check': function(_0x217a18) {
            this['objectArray']['push'](_0x217a18);
        },
        'clickObject': function(_0x4c782a) {
            this['isFirstPressed'] && 'function' == typeof _0x4c782a['clicked'] && (_0x4c782a['clicked'](), this['addToClickedObjectList'](_0x4c782a)), this['isPressed'] && !this['isReleased'] && 'function' == typeof _0x4c782a['clicking'] && _0x4c782a['clicking'](), this['isReleased'] && 'function' == typeof _0x4c782a['released'] && (_0x4c782a['released'](), this['removeFromClickedObjectList'](_0x4c782a));
        },
        'refreshPos': function() {
            this['pos'] = ig['game']['io']['getClickPos']();
        },
        'update': function() {
            this['parent'](), this['refreshPos']();
            var _0x292484 = null,
                _0x575748 = -0x1;
            for (a = this['objectArray']['length'] - 0x1; - 0x1 < a; a--) this['objectArray'][a]['zIndex'] > _0x575748 && (_0x575748 = this['objectArray'][a]['zIndex'], _0x292484 = this['objectArray'][a]);
            if (null != _0x292484) null != this['hoveringItem'] ? this['hoveringItem'] != _0x292484 && ('function' == typeof this['hoveringItem']['leave'] && this['hoveringItem']['leave'](), 'function' == typeof _0x292484['over'] && _0x292484['over']()) : 'function' == typeof _0x292484['over'] && _0x292484['over'](), this['hoveringItem'] = _0x292484, this['clickObject'](_0x292484), this['objectArray'] = [];
            else {
                if (null != this['hoveringItem'] && 'function' == typeof this['hoveringItem']['leave'] && (this['hoveringItem']['leave'](), this['hoveringItem'] = null), this['isReleased']) {
                    for (_0x292484 = 0x0; _0x292484 < this['clickedObjectList']['length']; _0x292484++) _0x575748 = this['clickedObjectList'][_0x292484], 'function' == typeof _0x575748['releasedOutside'] && _0x575748['releasedOutside']();
                    this['clickedObjectList'] = [];
                }
            }
            this['isFirstPressed'] = ig['input']['pressed']('click'), this['isReleased'] = ig['input']['released']('click'), this['isPressed'] = ig['input']['state']('click');
        },
        'addToClickedObjectList': function(_0x4163cf) {
            this['clickedObjectList']['push'](_0x4163cf);
        },
        'removeFromClickedObjectList': function(_0x14e6fa) {
            for (var _0x1eb6b1 = [], _0x12d8dd = 0x0; _0x12d8dd < this['clickedObjectList']['length']; _0x12d8dd++) {
                var _0x4890e2 = this['clickedObjectList'][_0x12d8dd];
                _0x4890e2 != _0x14e6fa && _0x1eb6b1['push'](_0x4890e2);
            }
            this['clickedObjectList'] = _0x1eb6b1;
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.pointer-selector')['requires']('game.entities.pointer')['defines'](function() {
    EntityPointerSelector = EntityPointer['extend']({
        'zIndex': 0x3e8,
        '_wmDrawBox': !0x0,
        '_wmBoxColor': 'rgba(0,\x200,\x20255,\x200.7)',
        'size': {
            'x': 0x14,
            'y': 0x14
        },
        'init': function(_0x5080f5, _0xfb6487, _0x513f7d) {
            this['parent'](_0x5080f5, _0xfb6487, _0x513f7d);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.select')['requires']('impact.entity')['defines'](function() {
    EntitySelect = ig['Entity']['extend']({
        'type': ig['Entity']['TYPE']['B'],
        'checkAgainst': ig['Entity']['TYPE']['A'],
        'collides': ig['Entity']['COLLIDES']['NEVER'],
        'canSelect': !0x1,
        'canSelectTimerDuration': 0.35,
        'zIndex': 0x1869f,
        'isHovering': !0x1,
        'isSelected': !0x1,
        'init': function(_0x424590, _0x5a6a99, _0x4d9124) {
            this['parent'](_0x424590, _0x5a6a99, _0x4d9124), this['canSelectTimer'] = new ig['Timer'](this['canSelectTimerDuration']);
        },
        'doesClickableLayerExist': function(_0x3e54b5) {
            for (k in dynamicClickableEntityDivs)
                if (k == _0x3e54b5) return !0x0;
            return !0x1;
        },
        'checkClickableLayer': function(_0x39ae19, _0x32d581, _0x2e72b3) {
            'undefined' == typeof wm && (this['doesClickableLayerExist'](_0x39ae19) ? (ig['game']['showOverlay']([_0x39ae19]), $('#' + _0x39ae19)['find']('[href]')['attr']('href', _0x32d581)) : this['createClickableOutboundLayer'](_0x39ae19, _0x32d581, 'media/graphics/misc/invisible.png', _0x2e72b3));
        },
        'createClickableOutboundLayer': function(_0x4d0645, _0x2bb5ca, _0xe53fe6, _0x449319) {
            var _0x3abacb = ig['$new']('div');
            _0x3abacb['id'] = _0x4d0645, document['body']['appendChild'](_0x3abacb), $('#' + _0x3abacb['id'])['css']('float', 'left'), $('#' + _0x3abacb['id'])['css']('width', this['size']['x'] * multiplier), $('#' + _0x3abacb['id'])['css']('height', this['size']['y'] * multiplier), $('#' + _0x3abacb['id'])['css']('position', 'absolute');
            var _0x3291a8 = w / 0x2 - destW / 0x2,
                _0x98972c = h / 0x2 - destH / 0x2;
            w == mobileWidth ? ($('#' + _0x3abacb['id'])['css']('left', this['pos']['x']), $('#' + _0x3abacb['id'])['css']('top', this['pos']['y'])) : ($('#' + _0x3abacb['id'])['css']('left', _0x3291a8 + this['pos']['x'] * multiplier), $('#' + _0x3abacb['id'])['css']('top', _0x98972c + this['pos']['y'] * multiplier)), _0x449319 ? $('#' + _0x3abacb['id'])['html']('<a\x20 \x20href=\x27' + _0x2bb5ca + '\x27><img\x20style=\x27width:100%;height:100%\x27\x20src=\x27' + _0xe53fe6 + '\x27></a>') : $('#' + _0x3abacb['id'])['html']('<a\x20href=\x27' + _0x2bb5ca + '\x27><img\x20style=\x27width:100%;height:100%\x27\x20src=\x27' + _0xe53fe6 + '\x27></a>'), dynamicClickableEntityDivs[_0x4d0645] = {}, dynamicClickableEntityDivs[_0x4d0645]['width'] = $('#' + _0x3abacb['id'])['width'](), dynamicClickableEntityDivs[_0x4d0645]['height'] = $('#' + _0x3abacb['id'])['height'](), dynamicClickableEntityDivs[_0x4d0645]['entity_pos_x'] = this['pos']['x'], dynamicClickableEntityDivs[_0x4d0645]['entity_pos_y'] = this['pos']['y'];
        },
        'hovered': function() {
            this['isHovering'] = !0x0, this['dehoverOthers']();
        },
        'dehoverOthers': function() {
            var _0x5f4872 = ig['game']['getEntitiesByType'](EntitySelect);
            for (i = 0x0; i < _0x5f4872['length']; i++) _0x5f4872[i] != this && (_0x5f4872[i]['isHovering'] = !0x1);
        },
        'deselectOthers': function() {
            var _0x426e5c = ig['game']['getEntitiesByType'](EntitySelect);
            for (i = 0x0; i < _0x426e5c['length']; i++) _0x426e5c[i] != this && (_0x426e5c[i]['isSelected'] = !0x1);
        },
        'update': function() {
            this['parent'](), this['canSelectTimer'] && 0x0 < this['canSelectTimer']['delta']() && (this['canSelect'] = !0x0, this['canSelectTimer'] = null);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.database.businessdb')['defines'](function() {
    ig['businessdb'] = {
        'Crops': [{
            'Crops': 0x0,
            'InitialCost': 0x3,
            'Coefficient': 1.07,
            'InitialTime': 0.6,
            'InitialRevenue': 0x1,
            'InitialProductivity': 1.67
        }, {
            'Crops': 0x1,
            'InitialCost': 0x3c,
            'Coefficient': 1.15,
            'InitialTime': 0x3,
            'InitialRevenue': 0x3c,
            'InitialProductivity': 0x14
        }, {
            'Crops': 0x2,
            'InitialCost': 0x2d0,
            'Coefficient': 1.14,
            'InitialTime': 0x6,
            'InitialRevenue': 0x21c,
            'InitialProductivity': 0x5a
        }, {
            'Crops': 0x3,
            'InitialCost': 0x21c0,
            'Coefficient': 1.13,
            'InitialTime': 0xc,
            'InitialRevenue': 0x10e0,
            'InitialProductivity': 0x168
        }, {
            'Crops': 0x4,
            'InitialCost': 0x19a28,
            'Coefficient': 1.12,
            'InitialTime': 0x18,
            'InitialRevenue': 0xca80,
            'InitialProductivity': 0x870
        }, {
            'Crops': 0x5,
            'InitialCost': 0x1312d0,
            'Coefficient': 1.11,
            'InitialTime': 0x60,
            'InitialRevenue': 0x97e00,
            'InitialProductivity': 0x1950
        }, {
            'Crops': 0x6,
            'InitialCost': 0xe4e1c0,
            'Coefficient': 1.1,
            'InitialTime': 0x180,
            'InitialRevenue': 0x71e800,
            'InitialProductivity': 0x4bf0
        }, {
            'Crops': 0x7,
            'InitialCost': 0xa9c1080,
            'Coefficient': 1.09,
            'InitialTime': 0x600,
            'InitialRevenue': 0x556e000,
            'InitialProductivity': 0xe3d0
        }, {
            'Crops': 0x8,
            'InitialCost': 0x80266580,
            'Coefficient': 1.08,
            'InitialTime': 0x1800,
            'InitialRevenue': 0x40128000,
            'InitialProductivity': 0x2ab70
        }],
        'SunDuration': 0x14,
        'SunCooldown': 0xe10,
        'CloudDuration': 0xe10,
        'CloudLimit': 0x5,
        'DailyRewardValue': [0x1, 0x2, 0x3, 0x4, 0x6, 0x8, 0xa],
        'SeedProfit': 0.02,
        'IdleThreshold': 0xa
    };
}), ig['baked'] = !0x0, ig['module']('game.database.upgradedb')['defines'](function() {
    ig['upgradedb'] = [
        [{
            'BusinessIndex': 0x0,
            'Cost': 0xc8,
            'CostExp': 0x0,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0xfa,
            'CostExp': 0x3,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0x14,
            'CostExp': 0xc,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0x2,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0x19,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0xa,
            'CostExp': 0x18,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0x5,
            'CostExp': 0x2a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0xfa,
            'CostExp': 0x2d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0x1,
            'CostExp': 0x36,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0xa,
            'CostExp': 0x4b,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x0,
            'Cost': 0x32,
            'CostExp': 0x5a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }],
        [{
            'BusinessIndex': 0x1,
            'Cost': 0xf,
            'CostExp': 0x3,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x1f4,
            'CostExp': 0x3,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x32,
            'CostExp': 0xc,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x5,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x32,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x1,
            'CostExp': 0x1b,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x19,
            'CostExp': 0x2a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x1f4,
            'CostExp': 0x2d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x1,
            'CostExp': 0x3c,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x64,
            'CostExp': 0x4b,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x1,
            'Cost': 0x64,
            'CostExp': 0x5a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }],
        [{
            'BusinessIndex': 0x2,
            'Cost': 0x64,
            'CostExp': 0x3,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0x1,
            'CostExp': 0x6,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0x64,
            'CostExp': 0xc,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0x7,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0x64,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0x19,
            'CostExp': 0x1b,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0x32,
            'CostExp': 0x2a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0x2ee,
            'CostExp': 0x2d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0xa,
            'CostExp': 0x3c,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0x1,
            'CostExp': 0x4e,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x2,
            'Cost': 0xfa,
            'CostExp': 0x5a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }],
        [{
            'BusinessIndex': 0x3,
            'Cost': 0x1f4,
            'CostExp': 0x3,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0x5,
            'CostExp': 0x6,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0x1f4,
            'CostExp': 0xc,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0xa,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0xc8,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0x64,
            'CostExp': 0x1b,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0x64,
            'CostExp': 0x2a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0x1,
            'CostExp': 0x30,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0x64,
            'CostExp': 0x3c,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0xa,
            'CostExp': 0x4e,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x3,
            'Cost': 0x1f4,
            'CostExp': 0x5a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }],
        [{
            'BusinessIndex': 0x4,
            'Cost': 1.2,
            'CostExp': 0x6,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0xa,
            'CostExp': 0x6,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0x1,
            'CostExp': 0xf,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0x23,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0x12c,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0xfa,
            'CostExp': 0x1b,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0xfa,
            'CostExp': 0x2a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0x5,
            'CostExp': 0x30,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0x1,
            'CostExp': 0x42,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0x64,
            'CostExp': 0x4e,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x4,
            'Cost': 0x1,
            'CostExp': 0x5d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }],
        [{
            'BusinessIndex': 0x5,
            'Cost': 0xa,
            'CostExp': 0x6,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0x19,
            'CostExp': 0x6,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0x2,
            'CostExp': 0xf,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0x32,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0x190,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0x1f4,
            'CostExp': 0x1b,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0x1f4,
            'CostExp': 0x2a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0xf,
            'CostExp': 0x30,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0xa,
            'CostExp': 0x42,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0x1,
            'CostExp': 0x54,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x5,
            'Cost': 0x5,
            'CostExp': 0x5d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }],
        [{
            'BusinessIndex': 0x6,
            'Cost': 0x69f6bc7,
            'CostExp': 0x0,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x1f4,
            'CostExp': 0x6,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x5,
            'CostExp': 0xf,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x4b,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x1f4,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x1,
            'CostExp': 0x1e,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x1,
            'CostExp': 0x2d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x32,
            'CostExp': 0x30,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x64,
            'CostExp': 0x42,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0x3,
            'CostExp': 0x57,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x6,
            'Cost': 0xa,
            'CostExp': 0x5d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }],
        [{
            'BusinessIndex': 0x7,
            'Cost': 0x211d1ae3,
            'CostExp': 0x0,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0xa,
            'CostExp': 0x9,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0xa,
            'CostExp': 0xf,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0x64,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0x258,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0x5,
            'CostExp': 0x1e,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0x5,
            'CostExp': 0x2d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0x64,
            'CostExp': 0x30,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0x1,
            'CostExp': 0x48,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0x1,
            'CostExp': 0x5a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x7,
            'Cost': 0x1f4,
            'CostExp': 0x5d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }],
        [{
            'BusinessIndex': 0x8,
            'Cost': 0xa,
            'CostExp': 0x9,
            'ProfitType': 'Automate',
            'ProfitValue': 0x1
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0x32,
            'CostExp': 0x9,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0x14,
            'CostExp': 0xf,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0xc8,
            'CostExp': 0x12,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0x2bc,
            'CostExp': 0x15,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0x19,
            'CostExp': 0x1e,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0xa,
            'CostExp': 0x2d,
            'ProfitType': 'Profit',
            'ProfitValue': 0x2
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0xfa,
            'CostExp': 0x30,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0xa,
            'CostExp': 0x48,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0x5,
            'CostExp': 0x5a,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }, {
            'BusinessIndex': 0x8,
            'Cost': 0x2,
            'CostExp': 0x60,
            'ProfitType': 'Profit',
            'ProfitValue': 0x3
        }]
    ];
}), ig['baked'] = !0x0, ig['module']('game.database.unlocksdb')['defines'](function() {
    ig['unlocksdb'] = [{
        'Level': 0x0,
        'ProfitType': 'Speed',
        'ProfitValue': 0x1
    }, {
        'Level': 0x19,
        'ProfitType': 'Speed',
        'ProfitValue': 0.5
    }, {
        'Level': 0x32,
        'ProfitType': 'Speed',
        'ProfitValue': 0.5
    }, {
        'Level': 0x64,
        'ProfitType': 'Speed',
        'ProfitValue': 0.5
    }, {
        'Level': 0xc8,
        'ProfitType': 'Speed',
        'ProfitValue': 0.5
    }, {
        'Level': 0x12c,
        'ProfitType': 'Speed',
        'ProfitValue': 0.5
    }, {
        'Level': 0x190,
        'ProfitType': 'Speed',
        'ProfitValue': 0.5
    }, {
        'Level': 0x1f4,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x258,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x2bc,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x320,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x384,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x3e8,
        'ProfitType': 'Profit',
        'ProfitValue': 0x5
    }, {
        'Level': 0x44c,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x4b0,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x514,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x578,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x5dc,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x640,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x6a4,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x708,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x76c,
        'ProfitType': 'Profit',
        'ProfitValue': 0x4
    }, {
        'Level': 0x7d0,
        'ProfitType': 'Profit',
        'ProfitValue': 0x5
    }, {
        'Level': 0x8ca,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0x9c4,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0xabe,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0xbb8,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0xcb2,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0xdac,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0xea6,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0xfa0,
        'ProfitType': 'Profit',
        'ProfitValue': 0x5
    }, {
        'Level': 0x109a,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0x1194,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0x128e,
        'ProfitType': 'Profit',
        'ProfitValue': 0x2
    }, {
        'Level': 0x1388,
        'ProfitType': 'Profit',
        'ProfitValue': 0x5
    }];
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.utility')['requires']('impact.entity')['defines'](function() {
    EntityUtility = ig['Entity']['extend']({
        'isPortrait': !0x1,
        'init': function(_0x1fe0ae, _0x5b14c0, _0x445103) {
            this['parent'](_0x1fe0ae, _0x5b14c0, _0x445103), ig['game']['utility'] = this;
        },
        'update': function() {
            this['parent']();
        },
        'setScaleTween': function(_0x204420, _0x382275, _0x4a77d8, _0x18b33c, _0x34ecdd) {
            _0x382275 = _0x204420['tween']({
                'scale': {
                    'x': _0x382275,
                    'y': _0x4a77d8
                }
            }, _0x18b33c, {
                'onUpdate': function() {
                    this['setScale'](this['scale']['x'], this['scale']['y']);
                }['bind'](_0x204420),
                'onComplete': function() {
                    this['tempTween'] = null, 0x0 == this['scale']['x'] && 0x0 == this['scale']['y'] && this['kill']();
                }['bind'](_0x204420),
                'delay': _0x34ecdd,
                'easing': ig['Tween']['Easing']['Back']['EaseOut']
            }), _0x382275['start'](), _0x204420['tempTween'] = _0x382275;
        },
        'setMoveTween': function(_0x3a4d52, _0x5d51ed, _0x1ca1fc, _0x225ba5, _0x1e72f1, _0x17632c) {
            null == _0x17632c && (_0x17632c = ig['Tween']['Easing']['Back']['EaseOut']), _0x3a4d52['tween']({
                'anchoredPositionX': _0x5d51ed,
                'anchoredPositionY': _0x1ca1fc
            }, _0x225ba5, {
                'delay': _0x1e72f1,
                'easing': _0x17632c
            })['start']();
        },
        'setFadeTween': function(_0x1fb253, _0x533143, _0x219188, _0x2e17e3, _0x42fe0b) {
            null == _0x42fe0b && (_0x42fe0b = ig['Tween']['Easing']['Back']['EaseOut']), _0x1fb253['tween']({
                'alpha': _0x533143
            }, _0x219188, {
                'delay': _0x2e17e3,
                'easing': _0x42fe0b,
                'onComplete': function() {
                    _0x1fb253['kill']();
                }['bind'](this)
            })['start']();
        },
        'setFadeHide': function(_0x516b5a, _0x29a359, _0x44c1ed, _0x361896, _0xaeb7a0) {
            null == _0xaeb7a0 && (_0xaeb7a0 = ig['Tween']['Easing']['Exponential']['EaseInOut']), _0x516b5a['tween']({
                'alpha': _0x29a359
            }, _0x44c1ed, {
                'delay': _0x361896,
                'easing': _0xaeb7a0,
                'onComplete': function() {
                    _0x516b5a['hide']();
                }['bind'](this)
            })['start']();
        },
        'sentenceCase': function(_0x2f43aa) {
            _0x2f43aa = _0x2f43aa['toLowerCase']()['split']('\x20');
            for (var _0x323d78 = 0x0; _0x323d78 < _0x2f43aa['length']; _0x323d78++) _0x2f43aa[_0x323d78] = _0x2f43aa[_0x323d78][0x0]['toUpperCase']() + _0x2f43aa[_0x323d78]['slice'](0x1);
            return _0x2f43aa['join']('\x20');
        },
        'clampNumber': function(_0x5ea851, _0x16b258, _0x422863) {
            return _0x5ea851 <= _0x16b258 ? _0x16b258 : _0x5ea851 >= _0x422863 ? _0x422863 : _0x5ea851;
        },
        'getInString': function(_0x110ab8, _0x3bf997) {
            if (0x3e8 >= _0x110ab8) return _0x110ab8['toFixed'](_0x3bf997)['replace'](/\.?0+$/, '');
            return powExp = exp = this['exponentLookup'](_0x110ab8), 0x0 != exp % 0x3 && (powExp -= powExp % 0x3), significant = (_0x110ab8 / Math['pow'](0xa, powExp))['toFixed'](_0x3bf997)['replace'](/\.?0+$/, ''), annot = this['cookiesAnnotation'](exp), significant + annot;
        },
        'exponentLookup': function(_0x1a9012) {
            return 0.9 < Math['log'](_0x1a9012) / Math['log'](0xa) % 0x1 ? Math['ceil'](Math['log'](_0x1a9012) / Math['log'](0xa)) : Math['floor'](Math['log'](_0x1a9012) / Math['log'](0xa));
        },
        'cookiesAnnotation': function(_0xab4f64) {
            var _0xf44d89 = ['\x20', 'K', 'M', 'B', 'T'];
            if (0x0 > _0xab4f64) return _0xf44d89[0x0];
            order = Math['floor'](_0xab4f64 / 0x3);
            if (0x5 > order) return _0xf44d89[order];
            return startLeft = 0x41, startRight = 0x61, leftChar = startLeft + (order - 0x5) / 0x1a, rightChar = startRight + (order - 0x5) % 0x1a, String['fromCharCode'](leftChar) + String['fromCharCode'](rightChar);
        },
        'getPriceFromExp': function(_0x3d91c9, _0x587cf6) {
            return 0x0 >= _0x587cf6 ? _0x3d91c9 : _0x3d91c9 * Math['pow'](0xa, _0x587cf6);
        },
        'lerp': function(_0x8e004d, _0x7b1e49, _0x55c228) {
            return (0x1 - _0x55c228) * _0x8e004d + _0x55c228 * _0x7b1e49;
        },
        'getStringTime': function(_0x10a177) {
            return text = Math['floor'](_0x10a177 / 0xe10) + '\x20' + _STRINGS['Game']['Hour'] + '\x20' + Math['floor'](_0x10a177 % 0xe10 / 0x3c) + '\x20' + _STRINGS['Game']['Minute'] + '\x20' + Math['floor'](_0x10a177 % 0x3c) + '\x20' + _STRINGS['Game']['Second'];
        },
        'getShortTime': function(_0x4c98cc) {
            var _0x4514c6 = Math['floor'](_0x4c98cc / 0x3c);
            return _0x4c98cc = Math['floor'](_0x4c98cc % 0x3c), minutesTxt = 0xa > _0x4514c6 ? '0' + _0x4514c6 : _0x4514c6, secondTxt = 0xa > _0x4c98cc ? '0' + _0x4c98cc : _0x4c98cc, text = minutesTxt + ':' + secondTxt;
        },
        'getFullTime': function(_0x3f405f) {
            var _0x377f7b = Math['floor'](_0x3f405f / 0xe10),
                _0x51897b = Math['floor'](_0x3f405f % 0xe10 / 0x3c);
            return _0x3f405f = Math['floor'](_0x3f405f % 0x3c), hourText = 0xa > _0x377f7b ? '0' + _0x377f7b : _0x377f7b, minutesTxt = 0xa > _0x51897b ? '0' + _0x51897b : _0x51897b, secondTxt = 0xa > _0x3f405f ? '0' + _0x3f405f : _0x3f405f, text = hourText + ':' + minutesTxt + ':' + secondTxt;
        },
        'datesAreOnSameDay': function(_0x2c6a2a, _0x3a5d43) {
            return _0x2c6a2a['getFullYear']() === _0x3a5d43['getFullYear']() && _0x2c6a2a['getMonth']() === _0x3a5d43['getMonth']() && _0x2c6a2a['getDate']() === _0x3a5d43['getDate']() ? !0x0 : !0x1;
        },
        'untilNewDay': function() {
            var _0x52d2cc = new Date(),
                _0x404883 = 0x17 - _0x52d2cc['getHours'](),
                _0x4f58b5 = 0x3c - _0x52d2cc['getMinutes'](),
                _0x52d2cc = 0x3c - _0x52d2cc['getSeconds']();
            return _0x404883 + '\x20' + _STRINGS['Game']['Hr'] + '\x20' + _0x4f58b5 + '\x20' + _STRINGS['Game']['Min'] + '\x20' + _0x52d2cc + _STRINGS['Game']['Sec'];
        },
        'getRevenueByLevel': function(_0x5c81fa, _0x30f64b) {
            return _0x5c81fa['maxCapacity'] / (_0x5c81fa['maxCapacity'] / this['miningSpeed'] + _0x30f64b['WalkSpeed']);
        },
        'getLoadByLevel': function(_0x138d3a, _0xafca59) {
            return currentCapacity = this['getPriceFromExp'](_0x138d3a['InitCapacity'], _0x138d3a['CapacityExp']) * Math['pow'](ig['businessdb']['OtherProductCoef'], _0xafca59 - 0x1), currentCapacity / (currentCapacity / this['getPriceFromExp'](_0x138d3a['MiningSpeed'], _0x138d3a['CapacityExp']) + _0x138d3a['WalkSpeed']);
        },
        'getPriceUpgrade': function(_0x51b3a0, _0x590e50, _0x4bfc3e, _0xa67874) {
            return 0x1 < _0x4bfc3e ? this['getPriceFromExp'](_0x51b3a0['BaseCost'], _0x51b3a0['CostExp']) * Math['pow'](_0xa67874, _0x590e50) * (Math['pow'](_0xa67874, _0x4bfc3e) - 0x1) / (_0xa67874 - 0x1) : this['getPriceFromExp'](_0x51b3a0['BaseCost'], _0x51b3a0['CostExp']) * Math['pow'](_0xa67874, _0x590e50);
        },
        'getMaxUpgrade': function(_0x3120bd, _0x11b2d9, _0x72fdb4) {
            return _0x11b2d9 = ig['game']['sessionData']['playerMoney'] * (_0x72fdb4 - 0x1) / (this['getPriceFromExp'](_0x3120bd['InitialCost'], 0x0) * Math['pow'](_0x72fdb4, _0x11b2d9)) + 0x1, buyMultiplier = Math['floor'](Math['log10'](_0x11b2d9) / Math['log10'](_0x3120bd['Coefficient'])), 0x0 >= buyMultiplier && (buyMultiplier = 0x1), buyMultiplier;
        },
        'calculateTotalAngel': function() {
            return null == ig['game']['sessionData']['lifetimeEarning'] && (ig['game']['sessionData']['lifetimeEarning'] = Number['MAX_VALUE']), null == ig['game']['sessionData']['startingLifetimeEarning'] && (ig['game']['sessionData']['startingLifetimeEarning'] = Number['MAX_VALUE']), totalInvestor = Math['pow'](ig['game']['sessionData']['lifetimeEarning'] / (0x5d21dba000 / 0x9), 0.5) - Math['pow'](ig['game']['sessionData']['startingLifetimeEarning'] / (0x5d21dba000 / 0x9), 0.5), this['investorGain'] = Math['floor'](totalInvestor), Math['floor'](this['investorGain']);
        },
        'shrinkText': function(_0x38c037, _0x5b4c58, _0x113c0b, _0x58b1e2, _0x169599, _0x274492, _0x35e6c1) {
            _0x38c037['font'] = _0x58b1e2 + 'px\x20' + _0x113c0b;
            for (var _0x5874ad = _0x38c037['measureText'](_0x5b4c58)['width']; _0x5874ad > _0x35e6c1;) _0x58b1e2 -= 0x1, _0x5874ad = _0x38c037['measureText'](_0x5b4c58)['width'], _0x38c037['font'] = _0x58b1e2 + 'px\x20' + _0x113c0b, _0x169599 -= 0.25, _0x274492 += 0.35;
            _0x38c037['fillText'](_0x5b4c58, _0x169599, _0x274492);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.opening-marketjs-logo')['requires']('impact.entity')['defines'](function() {
    EntityOpeningMarketJSLogo = ig['Entity']['extend']({
        'objects': [],
        'letterM': null,
        'logoShield': null,
        'text': null,
        'localTweens': [],
        'logoOriX': 0x0,
        'logoOriY': 0x0,
        'textOriX': 0x0,
        'textOriY': 0x0,
        'logoCanvas': null,
        'init': function(_0x840413, _0x175a63, _0x410416) {
            this['parent'](_0x840413, _0x175a63, _0x410416), logoSize = 0x94 / 0x3c0 * Math['min'](ig['system']['width'], ig['system']['height']), this['text'] = this['addObject']('drawText', 0x0, 0x0, logoSize, logoSize), this['cover'] = this['addObject']('drawCover', 0x0, 0x0, logoSize, logoSize), this['logoShield'] = this['addObject']('drawLogoShield', 0x0, 0x0, logoSize, logoSize), this['letterM'] = this['addObject']('drawLetterM', 0x0, 0x0, logoSize, logoSize), this['logoOriX'] = 0x0 - 2.2 * logoSize, this['logoOriY'] = 0x0, this['textOriX'] = 0x0 - 1.378 * logoSize, this['textOriY'] = 0x0 - 0.5 * logoSize, this['logoShield']['x'] = 0x0, this['logoShield']['y'] = 0x0, this['logoShield']['scaleX'] = 0x0, this['logoShield']['scaleY'] = 0x0, this['logoShield']['alpha'] = 0x0, this['letterM']['x'] = this['logoShield']['x'], this['letterM']['y'] = this['logoShield']['y'], this['letterM']['scaleX'] = 0x0, this['letterM']['scaleY'] = 0x0, this['letterM']['alpha'] = 0x0, this['text']['x'] = 4.6 * -logoSize, this['text']['y'] = this['textOriY'], this['cover']['x'] = this['logoShield']['x'], this['cover']['y'] = 0x0, this['addLocalDelayedCall'](0.6, function() {
                this['addLocalTweenTo'](this['logoShield'], {
                    'scaleX': 0x2,
                    'scaleY': 0x2
                }, 0.5, this['backOut']), this['addLocalTweenTo'](this['logoShield'], {
                    'alpha': 0x1
                }, 0.2, this['quadOut']), ig['soundHandler']['sfxPlayer']['play']('logosplash1'), this['addLocalDelayedCall'](0.4, function() {
                    this['addLocalTweenTo'](this['letterM'], {
                        'scaleX': 0x2,
                        'scaleY': 0x2
                    }, 0.5, this['backOut']), this['addLocalTweenTo'](this['letterM'], {
                        'alpha': 0x1
                    }, 0.2, this['quadOut']), ig['soundHandler']['sfxPlayer']['play']('logosplash1'), this['addLocalDelayedCall'](0.2, function() {
                        ig['soundHandler']['sfxPlayer']['play']('logosplash2');
                    }['bind'](this)), this['addLocalDelayedCall'](0.6, function() {
                        this['addLocalTweenTo'](this['logoShield'], {
                            'scaleX': 0x1,
                            'scaleY': 0x1
                        }, 0.4, this['quartOut']), this['addLocalTweenTo'](this['logoShield'], {
                            'x': this['logoOriX'],
                            'y': this['logoOriY']
                        }, 0.4, this['quadOut']), this['addLocalTweenTo'](this['letterM'], {
                            'scaleX': 0x1,
                            'scaleY': 0x1
                        }, 0.4, this['quartOut']), this['addLocalTweenTo'](this['letterM'], {
                            'x': this['logoOriX'],
                            'y': this['logoOriY']
                        }, 0.4, this['quadOut']), this['addLocalTweenTo'](this['text'], {
                            'x': this['textOriX']
                        }, 0.8, this['backOut']), this['addLocalDelayedCall'](0x2, function() {
                            this['addLocalTweenTo'](this['logoShield'], {
                                'alpha': 0x0
                            }, 0.6, this['quadOut']), this['addLocalTweenTo'](this['text'], {
                                'alpha': 0x0
                            }, 0.6, this['quadOut']), this['addLocalDelayedCall'](1.3, function() {
                                this['playBgm'](), ig['game']['director']['nextLevel']();
                            }['bind'](this));
                        }['bind'](this));
                    }['bind'](this));
                }['bind'](this));
            }['bind'](this));
        },
        'addObject': function(_0x1df145, _0x2facfd, _0x45a9c1, _0x44d8eb, _0x218e16) {
            return _0x1df145 = {
                'x': _0x2facfd,
                'y': _0x45a9c1,
                'width': _0x44d8eb,
                'height': _0x218e16,
                'scaleX': 0x1,
                'scaleY': 0x1,
                'alpha': 0x1,
                'drawFunctionName': _0x1df145
            }, this['objects']['push'](_0x1df145), _0x1df145;
        },
        'update': function() {
            this['parent'](), ig['wm'] || (this['unlockWebAudio'](), this['updateLocalTween'](ig['system']['tick']), this['cover']['x'] = this['logoShield']['x'], _SETTINGS['DeveloperBranding']['Splash']['Enabled'] || (this['playBgm'](), ig['game']['director']['nextLevel'](), this['kill']()));
        },
        'playBgm': function() {
            ig['soundHandler']['bgmPlayer']['play'](ig['soundHandler']['bgmPlayer']['soundList']['background']);
        },
        'unlockWebAudio': function() {
            if (ig['input']['released']('click')) try {
                ig['soundHandler']['unlockWebAudio']();
            } catch (_0x3b4e47) {}
        },
        'addLocalDelayedCall': function(_0x502aa3, _0x1bd405) {
            this['addLocalTweenTo'](null, {}, _0x502aa3, this['easeNone'], 0x0, _0x1bd405);
        },
        'addLocalTweenTo': function(_0x7eaa89, _0xd2b824, _0x519ace, _0x4e5ed5, _0x238554, _0x1ef18c) {
            'undefined' == typeof _0x238554 && (_0x238554 = 0x0), 'undefined' == typeof _0x4e5ed5 && (_0x4e5ed5 = this['easeNone']), 'undefined' == typeof _0x1ef18c && (_0x1ef18c = null), _0x519ace = {
                'obj': _0x7eaa89,
                'endProperties': _0xd2b824,
                'duration': _0x519ace,
                'easing': _0x4e5ed5,
                'delay': _0x238554,
                'elapsed': 0x0,
                'deltaProperties': {},
                'startProperties': {},
                'onComplete': _0x1ef18c
            };
            for (var _0x159988 in _0xd2b824) Object['hasOwnProperty']['call'](_0xd2b824, _0x159988) && (_0x519ace['startProperties'][_0x159988] = _0x7eaa89[_0x159988], _0x519ace['deltaProperties'][_0x159988] = _0xd2b824[_0x159988] - _0x7eaa89[_0x159988]);
            this['localTweens']['push'](_0x519ace);
        },
        'updateLocalTween': function(_0x554b31) {
            for (var _0x336e72 = 0x0; _0x336e72 < this['localTweens']['length']; _0x336e72++) {
                var _0x496f2b = this['localTweens'][_0x336e72];
                if (0x0 < _0x496f2b['delay']) _0x496f2b['delay'] -= _0x554b31;
                else {
                    _0x496f2b['elapsed'] += _0x554b31;
                    for (var _0x208fd3 in _0x496f2b['deltaProperties'])
                        if (Object['hasOwnProperty']['call'](_0x496f2b['deltaProperties'], _0x208fd3)) {
                            var _0xe978c3 = _0x496f2b['deltaProperties'][_0x208fd3],
                                _0x27598f = _0x496f2b['startProperties'][_0x208fd3],
                                _0x184ce7 = _0x496f2b['easing'],
                                _0x44755d = _0x496f2b['elapsed'] / _0x496f2b['duration'];
                            0x1 < _0x44755d && (_0x44755d = 0x1), _0x44755d = _0x184ce7(_0x44755d), _0x496f2b['obj'][_0x208fd3] = _0x27598f + _0xe978c3 * _0x44755d;
                        }
                    if (_0x496f2b['elapsed'] >= _0x496f2b['duration'] && (this['localTweens']['splice'](_0x336e72, 0x1), _0x336e72--, _0x496f2b['onComplete'])) _0x496f2b['onComplete']();
                }
            }
        },
        'quadOut': function(_0x41d343) {
            return -_0x41d343 * (_0x41d343 - 0x2);
        },
        'quartOut': function(_0x331903) {
            return -(--_0x331903 * _0x331903 * _0x331903 * _0x331903 - 0x1);
        },
        'backOut': function(_0x2f59b5) {
            return (_0x2f59b5 -= 0x1) * _0x2f59b5 * (2.70158 * _0x2f59b5 + 1.70158) + 0x1;
        },
        'easeNone': function(_0x5167ef) {
            return _0x5167ef;
        },
        'draw': function() {
            this['parent']();
            if (!ig['global']['wm']) {
                var _0x2162e6 = ig['system']['context'];
                _0x2162e6['fillStyle'] = '#ffffff', _0x2162e6['fillRect'](0x0, 0x0, ig['system']['width'], ig['system']['height']);
                for (_0x2162e6 = 0x0; _0x2162e6 < this['objects']['length']; _0x2162e6++) {
                    var _0x1b8781 = this['objects'][_0x2162e6];
                    0x1 < _0x1b8781['alpha'] && (_0x1b8781['alpha'] = 0x1);
                    if (0x0 != _0x1b8781['scaleX'] && 0x0 != _0x1b8781['scaleY'] && 0x0 < _0x1b8781['alpha']) this[_0x1b8781['drawFunctionName']](_0x1b8781);
                }
            }
        },
        'drawLogoShield': function(_0x250104) {
            this['logoCanvas'] || (this['logoCanvas'] = ig['$new']('canvas'), this['logoCanvas']['width'] = 0x2 * Math['max'](ig['system']['width'], ig['system']['height']), this['logoCanvas']['height'] = 0x2 * Math['max'](ig['system']['width'], ig['system']['height']));
            var _0x35d08b = this['logoCanvas']['getContext']('2d'),
                _0x189f15 = _0x250104['width'] * _0x250104['scaleX'],
                _0x1c60e0 = _0x250104['height'] * _0x250104['scaleY'],
                _0x3b05cd = 0x0,
                _0x289fb4 = 0x0;
            _0x35d08b['clearRect'](0x0, 0x0, this['logoCanvas']['width'], this['logoCanvas']['height']), _0x35d08b['save'](), _0x35d08b['fillStyle'] = '#e35026', _0x35d08b['beginPath'](), _0x35d08b['moveTo'](_0x3b05cd + 0.06 * _0x189f15, _0x289fb4), _0x35d08b['lineTo'](_0x3b05cd + 0.94 * _0x189f15, _0x289fb4), _0x35d08b['lineTo'](_0x3b05cd + 0.86 * _0x189f15, _0x289fb4 + 0.89 * _0x1c60e0), _0x35d08b['lineTo'](_0x3b05cd + 0.5 * _0x189f15, _0x289fb4 + _0x1c60e0), _0x35d08b['lineTo'](_0x3b05cd + 0.14 * _0x189f15, _0x289fb4 + 0.89 * _0x1c60e0), _0x35d08b['closePath'](), _0x35d08b['fill'](), _0x35d08b['fillStyle'] = '#ee652b', _0x35d08b['beginPath'](), _0x35d08b['moveTo'](_0x3b05cd + 0.5 * _0x189f15, _0x289fb4 + 0.07 * _0x1c60e0), _0x35d08b['lineTo'](_0x3b05cd + 0.86 * _0x189f15, _0x289fb4 + 0.07 * _0x1c60e0), _0x35d08b['lineTo'](_0x3b05cd + 0.79 * _0x189f15, _0x289fb4 + 0.84 * _0x1c60e0), _0x35d08b['lineTo'](_0x3b05cd + 0.5 * _0x189f15, _0x289fb4 + 0.92 * _0x1c60e0), _0x35d08b['closePath'](), _0x35d08b['fill'](), _0x35d08b['restore'](), _0x3b05cd = ig['system']['width'] / 0x2 + _0x250104['x'] - _0x189f15 / 0x2, _0x289fb4 = ig['system']['height'] / 0x2 + _0x250104['y'] - _0x1c60e0 / 0x2, _0x35d08b = ig['system']['context'], _0x35d08b['globalAlpha'] = _0x250104['alpha'], _0x35d08b['drawImage'](this['logoCanvas'], 0x0, 0x0, _0x189f15, _0x1c60e0, _0x3b05cd, _0x289fb4, _0x189f15, _0x1c60e0), _0x35d08b['globalAlpha'] = 0x1;
        },
        'drawLetterM': function(_0x42aa70) {
            var _0x5a54cc = ig['system']['context'],
                _0x540ab7 = _0x42aa70['width'] * _0x42aa70['scaleX'],
                _0x20b17b = _0x42aa70['height'] * _0x42aa70['scaleY'],
                _0x3cd0a8 = ig['system']['width'] / 0x2 + _0x42aa70['x'] - _0x540ab7 / 0x2,
                _0x1f9792 = ig['system']['height'] / 0x2 + _0x42aa70['y'] - _0x20b17b / 0x2;
            _0x5a54cc['save'](), _0x5a54cc['globalAlpha'] = _0x42aa70['alpha'], _0x5a54cc['fillStyle'] = '#ffffff', _0x5a54cc['beginPath'](), _0x5a54cc['moveTo'](_0x3cd0a8 + 0.25 * _0x540ab7, _0x1f9792 + 0.2 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.4 * _0x540ab7, _0x1f9792 + 0.2 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.5 * _0x540ab7, _0x1f9792 + 0.37 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.6 * _0x540ab7, _0x1f9792 + 0.2 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.75 * _0x540ab7, _0x1f9792 + 0.2 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.75 * _0x540ab7, _0x1f9792 + 0.7 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.6 * _0x540ab7, _0x1f9792 + 0.7 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.6 * _0x540ab7, _0x1f9792 + 0.45 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.5 * _0x540ab7, _0x1f9792 + 0.63 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.4 * _0x540ab7, _0x1f9792 + 0.45 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.4 * _0x540ab7, _0x1f9792 + 0.7 * _0x20b17b), _0x5a54cc['lineTo'](_0x3cd0a8 + 0.25 * _0x540ab7, _0x1f9792 + 0.7 * _0x20b17b), _0x5a54cc['closePath'](), _0x5a54cc['fill'](), _0x5a54cc['globalAlpha'] = 0x1, _0x5a54cc['restore']();
        },
        'drawText': function(_0x239def) {
            if (ig['splashLogoFontLoaded']) {
                var _0x426623 = ig['system']['context'],
                    _0x323cef = _0x239def['height'] * _0x239def['scaleY'],
                    _0x471ef8 = ig['system']['width'] / 0x2 + _0x239def['x'],
                    _0x1d148d = ig['system']['height'] / 0x2 + _0x239def['y'];
                _0x426623['save'](), _0x426623['globalAlpha'] = _0x239def['alpha'], _0x239def = Math['round'](0x73 / 0x98 * _0x323cef);
                var _0x2b09e3 = Math['round'](0x3e / 0x98 * _0x323cef);
                _0x426623['textAlign'] = 'left', _0x426623['fillStyle'] = '#316198', _0x426623['font'] = _0x239def + 'px\x20logofont', _0x426623['fillText']('MarketJS', _0x471ef8 - 0.06 * _0x239def, _0x1d148d + 0.66 * _0x239def), _0x426623['font'] = _0x2b09e3 + 'px\x20logofont', _0x426623['fillText']('HTML5\x20gaming\x20solutions', _0x471ef8 - 0.02 * _0x2b09e3, _0x1d148d + _0x323cef - 0.1 * _0x2b09e3), _0x426623['globalAlpha'] = 0x1, _0x426623['restore']();
            }
        },
        'drawCover': function(_0x22f9e3) {
            var _0x11b49f = ig['system']['context'],
                _0x40cd0a = ig['system']['width'] / 0x2 + _0x22f9e3['x'];
            _0x11b49f['save'](), _0x11b49f['globalAlpha'] = _0x22f9e3['alpha'], _0x11b49f['fillStyle'] = '#ffffff', _0x11b49f['fillRect'](_0x40cd0a - ig['system']['width'], 0x0, ig['system']['width'], ig['system']['height']), _0x11b49f['globalAlpha'] = 0x1, _0x11b49f['restore']();
        }
    });
    if ('undefined' == typeof window['FontFaceObserver']) {
        var _0x9d4d38 = function(_0x3d37f7, _0x1f84e7) {
                document['addEventListener'] ? _0x3d37f7['addEventListener']('scroll', _0x1f84e7, !0x1) : _0x3d37f7['attachEvent']('scroll', _0x1f84e7);
            },
            _0x4a4a3f = function(_0x2df921) {
                this['a'] = document['createElement']('div'), this['a']['setAttribute']('aria-hidden', 'true'), this['a']['appendChild'](document['createTextNode'](_0x2df921)), this['b'] = document['createElement']('span'), this['c'] = document['createElement']('span'), this['h'] = document['createElement']('span'), this['f'] = document['createElement']('span'), this['g'] = -0x1, this['b']['style']['cssText'] = 'max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;', this['c']['style']['cssText'] = 'max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;', this['f']['style']['cssText'] = 'max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;', this['h']['style']['cssText'] = 'display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;', this['b']['appendChild'](this['h']), this['c']['appendChild'](this['f']), this['a']['appendChild'](this['b']), this['a']['appendChild'](this['c']);
            },
            _0x270fa6 = function(_0x2fac3e, _0x417984) {
                _0x2fac3e['a']['style']['cssText'] = 'max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;white-space:nowrap;font-synthesis:none;font:' + _0x417984 + ';';
            },
            _0x44a6a2 = function(_0x23d04c) {
                var _0x36f57a = _0x23d04c['a']['offsetWidth'],
                    _0x49ce28 = _0x36f57a + 0x64;
                return _0x23d04c['f']['style']['width'] = _0x49ce28 + 'px', _0x23d04c['c']['scrollLeft'] = _0x49ce28, _0x23d04c['b']['scrollLeft'] = _0x23d04c['b']['scrollWidth'] + 0x64, _0x23d04c['g'] !== _0x36f57a ? (_0x23d04c['g'] = _0x36f57a, !0x0) : !0x1;
            },
            _0x14df3b = function(_0x471318, _0x75f16e) {
                function _0x479fde() {
                    var _0x375877 = _0x5d8199;
                    _0x44a6a2(_0x375877) && _0x375877['a']['parentNode'] && _0x75f16e(_0x375877['g']);
                }
                var _0x5d8199 = _0x471318;
                _0x9d4d38(_0x471318['b'], _0x479fde), _0x9d4d38(_0x471318['c'], _0x479fde), _0x44a6a2(_0x471318);
            },
            _0x58c335 = function(_0x472bf3, _0x53862a) {
                var _0x7c511b = _0x53862a || {};
                this['family'] = _0x472bf3, this['style'] = _0x7c511b['style'] || 'normal', this['weight'] = _0x7c511b['weight'] || 'normal', this['stretch'] = _0x7c511b['stretch'] || 'normal';
            },
            _0x12e20a = function() {
                return null === _0x3aeb1d && (_0x3aeb1d = !!document['fonts']), _0x3aeb1d;
            },
            _0x319c2a = function() {
                if (null === _0x55cff4) {
                    var _0x13f747 = document['createElement']('div');
                    try {
                        _0x13f747['style']['font'] = 'condensed\x20100px\x20sans-serif';
                    } catch (_0x53a46d) {}
                    _0x55cff4 = '' !== _0x13f747['style']['font'];
                }
                return _0x55cff4;
            },
            _0x5a6b81 = function(_0x438504, _0x7b89b0) {
                return [_0x438504['style'], _0x438504['weight'], _0x319c2a() ? _0x438504['stretch'] : '', '100px', _0x7b89b0]['join']('\x20');
            },
            _0x465c8a = null,
            _0x2dbd29 = null,
            _0x55cff4 = null,
            _0x3aeb1d = null;
        _0x58c335['prototype']['load'] = function(_0xd51a91, _0xbbc3) {
            var _0x50c791 = this,
                _0x2a977b = _0xd51a91 || 'BESbswy',
                _0x16e9f7 = 0x0,
                _0x464000 = _0xbbc3 || 0xbb8,
                _0x4310cd = new Date()['getTime']();
            return new Promise(function(_0x173dbe, _0x7e1619) {
                var _0x3e79af;
                if (_0x3e79af = _0x12e20a()) null === _0x2dbd29 && (_0x12e20a() && /Apple/ ['test'](window['navigator']['vendor']) ? (_0x3e79af = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))(?:\.([0-9]+))/ ['exec'](window['navigator']['userAgent']), _0x2dbd29 = !!_0x3e79af && 0x25b > parseInt(_0x3e79af[0x1], 0xa)) : _0x2dbd29 = !0x1), _0x3e79af = !_0x2dbd29;
                if (_0x3e79af) {
                    _0x3e79af = new Promise(function(_0x39d97d, _0x1d562a) {
                        function _0x164b4f() {
                            new Date()['getTime']() - _0x4310cd >= _0x464000 ? _0x1d562a(Error('' + _0x464000 + 'ms\x20timeout\x20exceeded')) : document['fonts']['load'](_0x5a6b81(_0x50c791, '\x22' + _0x50c791['family'] + '\x22'), _0x2a977b)['then'](function(_0x2d559b) {
                                0x1 <= _0x2d559b['length'] ? _0x39d97d() : setTimeout(_0x164b4f, 0x19);
                            }, _0x1d562a);
                        }
                        _0x164b4f();
                    });
                    var _0x2eaaba = new Promise(function(_0x5283dc, _0x1fa5c8) {
                        _0x16e9f7 = setTimeout(function() {
                            _0x1fa5c8(Error('' + _0x464000 + 'ms\x20timeout\x20exceeded'));
                        }, _0x464000);
                    });
                    Promise['race']([_0x2eaaba, _0x3e79af])['then'](function() {
                        clearTimeout(_0x16e9f7), _0x173dbe(_0x50c791);
                    }, _0x7e1619);
                } else {
                    var _0x4cc726 = function() {
                        function _0x20b9da() {
                            var _0x53f05b;
                            if (_0x53f05b = -0x1 != _0x51063c && -0x1 != _0x11baef || -0x1 != _0x51063c && -0x1 != _0x1b6b97 || -0x1 != _0x11baef && -0x1 != _0x1b6b97)(_0x53f05b = _0x51063c != _0x11baef && _0x51063c != _0x1b6b97 && _0x11baef != _0x1b6b97) || (null === _0x465c8a && (_0x53f05b = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))/ ['exec'](window['navigator']['userAgent']), _0x465c8a = !!_0x53f05b && (0x218 > parseInt(_0x53f05b[0x1], 0xa) || 0x218 === parseInt(_0x53f05b[0x1], 0xa) && 0xb >= parseInt(_0x53f05b[0x2], 0xa))), _0x53f05b = _0x465c8a && (_0x51063c == _0x4e0221 && _0x11baef == _0x4e0221 && _0x1b6b97 == _0x4e0221 || _0x51063c == _0x4ca29c && _0x11baef == _0x4ca29c && _0x1b6b97 == _0x4ca29c || _0x51063c == _0x10f581 && _0x11baef == _0x10f581 && _0x1b6b97 == _0x10f581)), _0x53f05b = !_0x53f05b;
                            _0x53f05b && (_0xf058f['parentNode'] && _0xf058f['parentNode']['removeChild'](_0xf058f), clearTimeout(_0x16e9f7), _0x173dbe(_0x50c791));
                        }

                        function _0x57afc0() {
                            if (new Date()['getTime']() - _0x4310cd >= _0x464000) _0xf058f['parentNode'] && _0xf058f['parentNode']['removeChild'](_0xf058f), _0x7e1619(Error('' + _0x464000 + 'ms\x20timeout\x20exceeded'));
                            else {
                                var _0x1bfe2d = document['hidden'];
                                if (!0x0 === _0x1bfe2d || void 0x0 === _0x1bfe2d) _0x51063c = _0x29a7cb['a']['offsetWidth'], _0x11baef = _0x52ed29['a']['offsetWidth'], _0x1b6b97 = _0x3a4f86['a']['offsetWidth'], _0x20b9da();
                                _0x16e9f7 = setTimeout(_0x57afc0, 0x32);
                            }
                        }
                        var _0x29a7cb = new _0x4a4a3f(_0x2a977b),
                            _0x52ed29 = new _0x4a4a3f(_0x2a977b),
                            _0x3a4f86 = new _0x4a4a3f(_0x2a977b),
                            _0x51063c = -0x1,
                            _0x11baef = -0x1,
                            _0x1b6b97 = -0x1,
                            _0x4e0221 = -0x1,
                            _0x4ca29c = -0x1,
                            _0x10f581 = -0x1,
                            _0xf058f = document['createElement']('div');
                        _0xf058f['dir'] = 'ltr', _0x270fa6(_0x29a7cb, _0x5a6b81(_0x50c791, 'sans-serif')), _0x270fa6(_0x52ed29, _0x5a6b81(_0x50c791, 'serif')), _0x270fa6(_0x3a4f86, _0x5a6b81(_0x50c791, 'monospace')), _0xf058f['appendChild'](_0x29a7cb['a']), _0xf058f['appendChild'](_0x52ed29['a']), _0xf058f['appendChild'](_0x3a4f86['a']), document['body']['appendChild'](_0xf058f), _0x4e0221 = _0x29a7cb['a']['offsetWidth'], _0x4ca29c = _0x52ed29['a']['offsetWidth'], _0x10f581 = _0x3a4f86['a']['offsetWidth'], _0x57afc0(), _0x14df3b(_0x29a7cb, function(_0x4222ea) {
                            _0x51063c = _0x4222ea, _0x20b9da();
                        }), _0x270fa6(_0x29a7cb, _0x5a6b81(_0x50c791, '\x22' + _0x50c791['family'] + '\x22,sans-serif')), _0x14df3b(_0x52ed29, function(_0x31a28b) {
                            _0x11baef = _0x31a28b, _0x20b9da();
                        }), _0x270fa6(_0x52ed29, _0x5a6b81(_0x50c791, '\x22' + _0x50c791['family'] + '\x22,serif')), _0x14df3b(_0x3a4f86, function(_0x68fed4) {
                            _0x1b6b97 = _0x68fed4, _0x20b9da();
                        }), _0x270fa6(_0x3a4f86, _0x5a6b81(_0x50c791, '\x22' + _0x50c791['family'] + '\x22,monospace'));
                    };
                    document['body'] ? _0x4cc726() : document['addEventListener'] ? document['addEventListener']('DOMContentLoaded', function _0x5e7ace() {
                        document['removeEventListener']('DOMContentLoaded', _0x5e7ace), _0x4cc726();
                    }) : document['attachEvent']('onreadystatechange', function _0x5087c7() {
                        if ('interactive' == document['readyState'] || 'complete' == document['readyState']) document['detachEvent']('onreadystatechange', _0x5087c7), _0x4cc726();
                    });
                }
            });
        }, 'object' === typeof module ? module['exports'] = _0x58c335 : (window['FontFaceObserver'] = _0x58c335, window['FontFaceObserver']['prototype']['load'] = _0x58c335['prototype']['load']), console['log']('font\x20loader\x20not\x20exist\x20:\x20create\x20new\x20instance\x20of\x20font\x20loader');
    }
    _0x58c335 = document['createElement']('style'), _0x58c335['type'] = 'text/css', _0x58c335['appendChild'](document['createTextNode']('@font-face\x20{font-family:\x20\x27logofont\x27;src:\x20url(\x27media/fonts/logofont.woff2\x27)\x20format(\x27woff2\x27),url(\x27media/fonts/logofont.woff\x27)\x20format(\x27woff\x27),url(\x27media/fonts/logofont.ttf\x27)\x20format(\x27truetype\x27)}')), document['head']['appendChild'](_0x58c335), ig['splashLogoFontLoaded'] = !0x1, new FontFaceObserver('logofont')['load']()['then'](function() {
        ig['splashLogoFontLoaded'] = !0x0;
    })['catch'](function() {
        console['log']('Splash\x20font\x20failed\x20to\x20load\x20:', 'media/fonts/logofont');
    });
}), ig['baked'] = !0x0, ig['module']('game.levels.opening')['requires']('impact.image', 'game.entities.opening-marketjs-logo')['defines'](function() {
    LevelOpening = {
        'entities': [{
            'type': 'EntityOpeningMarketJSLogo',
            'x': 0x208,
            'y': 0xd4
        }],
        'layer': []
    };
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-play')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonPlay = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-play.png', 0x88, 0x88),
        'size': {
            'x': 0x88,
            'y': 0x88
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'init': function(_0x2e540a, _0x4c02b9, _0xb8c0de) {
            this['parent'](_0x2e540a, _0x4c02b9, _0xb8c0de), this['setAnchoredPosition'](_0x2e540a - this['size']['x'] / 0x2, _0x4c02b9 - this['size']['y'] / 0x2, 'center-middle'), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'];
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.2, {})['start']());
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && (ig['soundHandler']['sfxPlayer']['play']('button'), this['pressed'] = this['isEnabled'] = !0x1, this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0, ig['game']['titleController']['startTransitionOut']();
                }['bind'](this)
            })['start']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-setting')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonSetting = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-settings.png', 0x5e, 0x5e),
        'size': {
            'x': 0x5e,
            'y': 0x5e
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'init': function(_0x70061, _0x5d3ba5, _0x49b80a) {
            this['parent'](_0x70061, _0x5d3ba5, _0x49b80a), this['setAnchoredPosition'](_0x70061 - this['size']['x'] / 0x2, _0x5d3ba5 - this['size']['y'] / 0x2, this['anchor']), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], null != _0x49b80a['onClicked'] && (this['onClickCallback'] = _0x49b80a['onClicked']);
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, null != ig['game']['gameController'] && null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.2, {})['start']());
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController'] && null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    if (null != this['onClickCallback']) this['onClickCallback']();
                }['bind'](this)
            })['start']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.popup-controller')['requires']('impact.entity')['defines'](function() {
    EntityPopupController = ig['Entity']['extend']({
        'childArr': [],
        'spawnEntity': function(_0x5436a3, _0x7ccd05, _0x26418e, _0x14bf0a) {
            return _0x5436a3 = ig['game']['spawnEntity'](_0x5436a3, this['pos']['x'] + _0x7ccd05, this['pos']['y'] + _0x26418e, _0x14bf0a), _0x5436a3['childX'] = _0x7ccd05, _0x5436a3['childY'] = _0x26418e, this['childArr']['push'](_0x5436a3), _0x5436a3;
        },
        'kill': function() {
            for (var _0x50f81e = this['childArr']['length'] - 0x1; 0x0 <= _0x50f81e; _0x50f81e--) this['childArr']['pop']()['kill']();
            this['childArr'] = null, this['parent']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-close')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonClose = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-close.png', 0x4c, 0x4c),
        'size': {
            'x': 0x4c,
            'y': 0x4c
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'anchor': 'center-middle',
        'init': function(_0x3b9b6c, _0x11e17a, _0xc37d44) {
            this['parent'](_0x3b9b6c, _0x11e17a, _0xc37d44), this['setAnchoredPosition'](_0x3b9b6c - this['size']['x'] / 0x2, _0x11e17a - this['size']['y'] / 0x2, this['anchor']), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], null != _0xc37d44['onClicked'] && (this['onClickCallback'] = _0xc37d44['onClicked']);
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, null != ig['game']['gameController'] && null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.2, {})['start']());
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController'] && null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    if (null != this['onClickCallback']) this['onClickCallback']();
                }['bind'](this)
            })['start']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-home')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonHome = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-home.png', 0x5e, 0x5e),
        'size': {
            'x': 0x5e,
            'y': 0x5e
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'init': function(_0x3357c3, _0x19d84c, _0x49d3fb) {
            this['parent'](_0x3357c3, _0x19d84c, _0x49d3fb), this['setAnchoredPosition'](_0x3357c3 - this['size']['x'] / 0x2, _0x19d84c - this['size']['y'] / 0x2, 'center-middle'), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], null != _0x49d3fb['onClicked'] && (this['onClickCallback'] = _0x49d3fb['onClicked']);
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.2, {})['start']());
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != this['onClickCallback']) this['onClickCallback']();
                }['bind'](this)
            })['start']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-toggle')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonToggle = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'onSheet': new ig['AnimationSheet']('media/graphics/sprites/button-on.png', 0x86, 0x3e),
        'offSheet': new ig['AnimationSheet']('media/graphics/sprites/button-off.png', 0x86, 0x3e),
        'size': {
            'x': 0x86,
            'y': 0x3e
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'init': function(_0x275944, _0x4c2029, _0x286542) {
            this['parent'](_0x275944, _0x4c2029, _0x286542), this['setAnchoredPosition'](_0x275944 - this['size']['x'] / 0x2, _0x4c2029 - this['size']['y'] / 0x2, 'center-middle'), this['onAnim'] = new ig['Animation'](this['onSheet'], 0x1, [0x0]), this['offAnim'] = new ig['Animation'](this['offSheet'], 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], null != _0x286542['onClicked'] && (this['onClickCallback'] = _0x286542['onClicked']), null != _0x286542['state'] && this['changeState'](_0x286542['state']);
        },
        'changeState': function(_0x59d135) {
            (this['state'] = _0x59d135) ? (this['currentAnim'] = this['onAnim'], this['stateTxt'] = _STRINGS['Game']['On']) : (this['currentAnim'] = this['offAnim'], this['stateTxt'] = _STRINGS['Game']['OFF']);
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.2, {})['start']());
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {
                'onComplete': function() {
                    this['changeState'](!this['state']);
                    if (null != this['onClickCallback']) this['onClickCallback'](this['state']);
                    this['isEnabled'] = !0x0;
                }['bind'](this)
            })['start']());
        },
        'draw': function() {
            this['parent']();
            var _0x268958 = ig['system']['context'];
            _0x268958['textAlign'] = 'center', _0x268958['textBaseline'] = 'middle', _0x268958['font'] = '40px\x20luckiest-guy', _0x268958['fillStyle'] = '#000', _0x268958['fillText'](this['stateTxt'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.setting-controller')['requires']('impact.entity', 'plugins.io.storage-manager', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-close', 'game.entities.buttons.button-home', 'game.entities.buttons.button-toggle')['defines'](function() {
    EntitySettingController = EntityPopupController['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/popup.png'),
        'infoBg': new ig['Image']('media/graphics/sprites/popup-panel.png'),
        'size': {
            'x': 0x210,
            'y': 0x258
        },
        'onCloseCallback': null,
        'onHomeCallback': null,
        'init': function(_0x41c7d9, _0x5f145b, _0x17e815) {
            this['parent'](_0x41c7d9, _0x5f145b, _0x17e815), null != _0x17e815['onClose'] && (this['onCloseCallback'] = _0x17e815['onClose']), null != _0x17e815['onHome'] && (this['onHomeCallback'] = _0x17e815['onHome']), this['setAnchoredPosition'](_0x41c7d9 - this['size']['x'] / 0x2, _0x5f145b - this['size']['y'] / 0x2, 'middle-center'), this['isGame'] && (this['homeBtn'] = this['spawnEntity'](EntityButtonHome, this['anchoredPositionX'] + this['size']['x'] / 0x2, this['anchoredPositionY'] + this['size']['y'] - 0x41, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onHomeClicked']();
                }['bind'](this)
            })), this['closeBtn'] = this['spawnEntity'](EntityButtonClose, this['anchoredPositionX'] + this['size']['x'] - 0x14, this['anchoredPositionY'] + 0x14, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onCloseClicked']();
                }['bind'](this)
            }), _0x41c7d9 = ig['game']['getMusicVolume'](), _0x5f145b = ig['game']['getSoundVolume'](), this['musicToggle'] = this['spawnEntity'](EntityButtonToggle, this['anchoredPositionX'] + this['size']['x'] - 0xc8, this['anchoredPositionY'] + this['size']['y'] / 0x2 - 0x32, {
                'zIndex': this['zIndex'] + 0x1,
                'state': _0x41c7d9,
                'onClicked': function(_0x400a62) {
                    this['changeBGMVolume'](_0x400a62);
                }['bind'](this)
            }), this['soundToggle'] = this['spawnEntity'](EntityButtonToggle, this['anchoredPositionX'] + this['size']['x'] - 0xc8, this['anchoredPositionY'] + this['size']['y'] / 0x2 + 0x32, {
                'zIndex': this['zIndex'] + 0x1,
                'state': _0x5f145b,
                'onClicked': function(_0x51df5f) {
                    this['changeSFXVolume'](_0x51df5f);
                }['bind'](this)
            }), ig['game']['sortEntitiesDeferred']();
        },
        'draw': function() {
            this['parent']();
            var _0x3c8e0c = ig['responsive']['toAnchor'](0x0, 0x0, 'middle-center'),
                _0x14eba8 = ig['system']['context'];
            _0x14eba8['globalAlpha'] = 0.5, _0x14eba8['fillStyle'] = '#000', _0x14eba8['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), _0x14eba8['globalAlpha'] = 0x1, this['panelImage']['draw'](_0x3c8e0c['x'] + this['anchoredPositionX'], _0x3c8e0c['y'] + this['anchoredPositionY']), _0x14eba8['font'] = '45px\x20luckiest-guy', _0x14eba8['fillStyle'] = '#fff', _0x14eba8['textAlign'] = 'center', _0x14eba8['textBaseline'] = 'top', _0x14eba8['fillText'](_STRINGS['Game']['Settings'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x14), this['infoBg']['draw'](this['pos']['x'] + (this['size']['x'] - this['infoBg']['width']) / 0x2, _0x3c8e0c['y'] + this['anchoredPositionY'] + (this['size']['y'] - this['infoBg']['height']) / 0x2), _0x14eba8['font'] = '40px\x20luckiest-guy', _0x14eba8['fillStyle'] = '#190d3a', _0x14eba8['textBaseline'] = 'middle', _0x14eba8['fillText'](_STRINGS['Game']['BGM'], this['pos']['x'] + 0xc8, this['pos']['y'] + this['size']['y'] / 0x2 - 0x32), _0x14eba8['fillText'](_STRINGS['Game']['SFX'], this['pos']['x'] + 0xc8, this['pos']['y'] + this['size']['y'] / 0x2 + 0x32);
        },
        'changeBGMVolume': function(_0x365882) {
            _0x365882 ? ig['soundHandler']['unmuteBGM'](!0x0) : ig['soundHandler']['muteBGM'](!0x0), ig['game']['setMusicVolume'](_0x365882);
        },
        'changeSFXVolume': function(_0x3866ed) {
            _0x3866ed ? ig['soundHandler']['unmuteSFX'](!0x0) : ig['soundHandler']['muteSFX'](!0x0), ig['game']['setSoundVolume'](_0x3866ed);
        },
        'setParent': function(_0x57d409) {
            this['panelParent'] = _0x57d409;
        },
        'onCloseClicked': function() {
            if (null != this['onCloseCallback']) this['onCloseCallback']();
        },
        'onHomeClicked': function() {
            if (null != this['onHomeCallback']) this['onHomeCallback']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.title-controller')['requires']('impact.entity', 'game.entities.buttons.button-play', 'game.entities.buttons.button-setting', 'game.entities.buttons.button-more-games', 'game.entities.controllers.setting-controller')['defines'](function() {
    EntityTitleController = ig['Entity']['extend']({
        'bg': new ig['Image']('media/graphics/sprites/bg/bg1.png'),
        'title': new ig['Image']('media/graphics/sprites/title.png'),
        'playBtn': null,
        'settingBtn': null,
        'moreBtn': null,
        'fullscreenBtn': null,
        'settingPanel': null,
        'buttonEnabledTimer': null,
        'init': function(_0x5b64b1, _0x58c0f1, _0x558a43) {
            this['parent'](_0x5b64b1, _0x58c0f1, _0x558a43), ig['game']['titleController'] = this, ig['game']['gameController'] = null, this['fullscreenBtn'] = ig['game']['spawnEntity'](ig['FullscreenButton'], 0xf, 0xf, {
                'enterImage': new ig['Image']('media/graphics/sprites/btn-expand.png'),
                'exitImage': new ig['Image']('media/graphics/sprites/btn-shrink.png'),
                'zIndex': this['zIndex'] + 0x1
            }), this['fullscreenBtn']['setAnchoredPosition'](0xf, 0xf, 'bottom-left'), _SETTINGS['MoreGames']['Enabled'] ? (this['playBtn'] = ig['game']['spawnEntity'](EntityButtonPlay, -0x64, 0xfa, {
                'zIndex': this['zIndex'] + 0x1
            }), this['moreBtn'] = ig['game']['spawnEntity'](EntityButtonMoreGames, -0xa0, 0xfa, {
                'zIndex': this['zIndex'] + 0x1
            }), this['moreBtn']['setAnchoredPosition'](0x64 - this['moreBtn']['size']['x'] / 0x2, 0xfa + -this['moreBtn']['size']['y'] / 0x2, 'center-middle')) : this['playBtn'] = ig['game']['spawnEntity'](EntityButtonPlay, 0x0, 0xfa, {
                'zIndex': this['zIndex'] + 0x1
            }), this['settingBtn'] = ig['game']['spawnEntity'](EntityButtonSetting, -0x41, 0x41, {
                'zIndex': this['zIndex'] + 0x1,
                'anchor': 'top-right',
                'onClicked': function() {
                    this['showSettingPanel']();
                }['bind'](this)
            });
        },
        'startTransitionOut': function() {
            ig['game']['director']['nextLevel']();
        },
        'draw': function() {
            this['parent']();
            var _0x2a432f = ig['system']['context'];
            _0x2a432f['fillStyle'] = '#afe597', _0x2a432f['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), this['bg']['draw'](ig['responsive']['width'] / 0x2 - this['bg']['width'] / 0x2, ig['responsive']['height'] / 0x2 - this['bg']['height'] / 0x2 - 0x96), this['title']['draw'](ig['responsive']['width'] / 0x2 - this['title']['width'] / 0x2, ig['responsive']['height'] / 0x2 - this['title']['height'] / 0x2 - 0x32);
        },
        'showSettingPanel': function() {
            this['setButtonsActive'](!0x1), null == this['settingPanel'] && (this['settingPanel'] = ig['game']['spawnEntity'](EntitySettingController, 0x0, 0x0, {
                'onClose': function() {
                    this['hideSettingPanel']();
                }['bind'](this),
                'onHome': function() {
                    this['hideSettingPanel']();
                }['bind'](this),
                'isGame': !0x1,
                'zIndex': this['zIndex'] + 0x64
            }), this['settingPanel']['setParent'](this));
        },
        'setButtonsActive': function(_0xd51720) {
            this['fullscreenBtn']['isEnabled'] = _0xd51720, this['fullscreenBtn']['enableFullscreenButton'] = _0xd51720, this['playBtn']['isEnabled'] = _0xd51720, this['settingBtn']['isEnabled'] = _0xd51720, null != this['moreBtn'] && (this['moreBtn']['isEnabled'] = _0xd51720), _0xd51720 ? null != this['moreBtn'] && this['moreBtn']['show']() : null != this['moreBtn'] && this['moreBtn']['hide']();
        },
        'hideSettingPanel': function() {
            this['setButtonsActive'](!0x0), this['settingPanel'] && (this['settingPanel']['kill'](), this['settingPanel'] = null);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.levels.title')['requires']('impact.image', 'game.entities.controllers.title-controller')['defines'](function() {
    LevelTitle = {
        'entities': [{
            'type': 'EntityTitleController',
            'x': 0x0,
            'y': 0x0
        }, {
            'type': 'EntityPointer',
            'x': 0x0,
            'y': 0x0
        }],
        'layer': []
    };
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.empty-plot')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityEmptyPlot = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'onClickCallback': null,
        'buyOn': new ig['Image']('media/graphics/sprites/plots/plot-buy.png'),
        'buyOff': new ig['Image']('media/graphics/sprites/plots/plot-lock.png'),
        'coin': new ig['Image']('media/graphics/sprites/coin.png'),
        'size': {
            'x': 0x118,
            'y': 0xaa
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'index': 0x0,
        'textPrice': null,
        'buyPrice': 0x0,
        'detectionRadius': 0x4b,
        'init': function(_0x27df88, _0x26b740, _0x237ac4) {
            this['parent'](_0x27df88, _0x26b740, _0x237ac4), this['setAnchoredPosition'](_0x27df88 - this['size']['x'] / 0x2, _0x26b740 - this['size']['y'] / 0x2, 'center-middle'), ig['global']['wm'] || (null != _0x237ac4['onClicked'] && (this['onClickCallback'] = _0x237ac4['onClicked']), this['textPrice'] = ig['game']['utility']['getInString'](this['buyPrice'], 0x2), ig['game']['sortEntitiesDeferred']());
        },
        'clicked': function() {},
        'clicking': function() {},
        'released': function() {
            if (this['isEnabled'] && !ig['game']['gameController']['upgradeMode'] && this['detectIntersect'](ig['game']['inputPos'], ig['game']['inputPos']) && null != this['onClickCallback']) this['onClickCallback']();
        },
        'draw': function() {
            this['parent'](), ig['game']['sessionData']['playerMoney'] < this['buyPrice'] || ig['game']['gameController']['upgradeMode'] ? this['buyOff']['draw'](this['pos']['x'], this['pos']['y']) : this['buyOn']['draw'](this['pos']['x'], this['pos']['y']), this['coin']['draw'](this['pos']['x'] + (this['size']['x'] - this['coin']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['coin']['height']) / 0x2 - 0x19);
            var _0x3565b3 = ig['system']['context'];
            ig['game']['gameController']['upgradeMode'] || (_0x3565b3['font'] = '25px\x20luckiest-guy', _0x3565b3['fillStyle'] = '#fff', _0x3565b3['textAlign'] = 'center', _0x3565b3['lineWidth'] = 0x4, _0x3565b3['strokeStyle'] = '#000', _0x3565b3['lineCap'] = 'round', _0x3565b3['lineJoin'] = 'round', _0x3565b3['strokeText'](this['textPrice'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2 + 0x19), _0x3565b3['fillText'](this['textPrice'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2 + 0x19)), ig['game']['drawIntersect'] && (_0x3565b3['beginPath'](), _0x3565b3['arc'](this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2, this['detectionRadius'], 0x0, 0x2 * Math['PI']), _0x3565b3['stroke']());
        },
        'detectIntersect': function(_0xd31542, _0xd30a76) {
            var _0x5dfb2c = !0x1,
                _0x5dfb2c = new ig['SAT']['Shape']([_0xd31542, _0xd30a76]),
                _0x3b039d = this['getDetectionShape']();
            return ig['sat']['simpleShapeIntersect'](_0x5dfb2c, _0x3b039d);
        },
        'getDetectionShape': function() {
            var _0x1c335b = new Vector2(this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2);
            return new ig['SAT']['Circle'](_0x1c335b, this['detectionRadius']);
        }
    });
}), ig['baked'] = !0x0, ig['module']('impact.entity-pool')['requires']('impact.game')['defines'](function() {
    ig['EntityPool'] = {
        'pools': {},
        'mixin': {
            'staticInstantiate': function(_0x269e14, _0x1385a8, _0x5f3b55) {
                return ig['EntityPool']['getFromPool'](this['classId'], _0x269e14, _0x1385a8, _0x5f3b55);
            },
            'erase': function() {
                ig['EntityPool']['putInPool'](this);
            }
        },
        'enableFor': function(_0xd87d94) {
            _0xd87d94['inject'](this['mixin']);
        },
        'getFromPool': function(_0x53806a, _0x27fe79, _0x437b81, _0x4fe4ae) {
            _0x53806a = this['pools'][_0x53806a];
            if (!_0x53806a || !_0x53806a['length']) return null;
            return _0x53806a = _0x53806a['pop'](), _0x53806a['reset'](_0x27fe79, _0x437b81, _0x4fe4ae), _0x53806a;
        },
        'putInPool': function(_0x539a52) {
            this['pools'][_0x539a52['classId']] ? this['pools'][_0x539a52['classId']]['push'](_0x539a52) : this['pools'][_0x539a52['classId']] = [_0x539a52];
        },
        'drainPool': function(_0x2c3f32) {
            delete this['pools'][_0x2c3f32];
        },
        'drainAllPools': function() {
            this['pools'] = {};
        }
    }, ig['Game']['inject']({
        'loadLevel': function(_0x4d6758) {
            ig['EntityPool']['drainAllPools'](), this['parent'](_0x4d6758);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.others.particle')['requires']('impact.entity', 'impact.entity-pool')['defines'](function() {
    EntityParticle = ig['Entity']['extend']({
        'controller': null,
        'angle': 0x0,
        'speed': 0x0,
        'lifeTime': 0x0,
        'radius': 0x0,
        'timer': null,
        'image': null,
        'gravityFactor': 0x0,
        'gravityFall': 0x0,
        'target': null,
        'delayTarget': 0.3,
        'targetFinish': 0.5,
        'moveToTarget': !0x1,
        'init': function(_0x10542b, _0x20aaee, _0x154a1b) {
            this['parent'](_0x10542b, _0x20aaee, _0x154a1b), this['setup']();
        },
        'reset': function(_0x5900ec, _0x6199fb, _0x15e107) {
            this['parent'](_0x5900ec, _0x6199fb, _0x15e107), this['setup']();
        },
        'setup': function() {
            this['timer'] = new ig['Timer'](this['lifeTime']), this['vel']['x'] = this['speed'] * Math['cos'](this['angle'] * Math['PI'] / 0xb4), this['vel']['y'] = this['speed'] * Math['sin'](this['angle'] * Math['PI'] / 0xb4), null != this['target'] && (this['delayTimer'] = new ig['Timer'](this['delayTarget']), this['moveToTarget'] = !0x1);
        },
        'update': function() {
            this['parent'](), null != this['target'] ? 0x0 <= this['delayTimer']['delta']() && !this['moveToTarget'] && (this['gravityFactor'] = 0x0, this['vel']['x'] = 0x0, this['vel']['y'] = 0x0, this['moveToTarget'] = !0x0, this['tween']({
                'pos': {
                    'x': this['target']['x'],
                    'y': this['target']['y']
                }
            }, this['targetFinish'], {
                'delay': 0x0,
                'onComplete': function() {
                    this['kill']();
                }['bind'](this)
            })['start']()) : 0x0 <= this['timer']['delta']() && this['kill']();
        },
        'draw': function() {
            this['parent'](), ig['responsive']['drawScaledImage'](this['image'], this['pos']['x'], this['pos']['y'], this['scale'], this['scale'], 0.5, 0.5);
        },
        'kill': function() {
            this['parent'](), this['controller']['particleDead']();
        }
    }), ig['EntityPool']['enableFor'](EntityParticle);
}), ig['baked'] = !0x0, ig['module']('game.entities.others.particle-effect')['requires']('impact.entity', 'game.entities.others.particle')['defines'](function() {
    EntityParticleEffect = ig['Entity']['extend']({
        'minAngle': 0x0,
        'maxAngle': 0x0,
        'minSpeed': 0x0,
        'maxSpeed': 0x0,
        'minLifeTime': 0x0,
        'maxLifeTime': 0x0,
        'duration': 0x0,
        'minCount': 0x0,
        'maxCount': 0x0,
        'emission': 0x0,
        'minRadius': 0x0,
        'maxRadius': 0x0,
        'gravity': 0x0,
        'colors': [],
        'loop': !0x1,
        'timer': null,
        'particles': 0x0,
        'elapsedTime': 0x0,
        'emissionCount': 0x0,
        'particle': null,
        'paused': !0x1,
        'init': function(_0x11432f, _0x50a970, _0x20fc78) {
            this['parent'](_0x11432f, _0x50a970, _0x20fc78), this['loop'] || (this['timer'] = new ig['Timer'](this['duration'])), this['emissionCount'] = this['emission'] / 0x28, 0x1 > this['emissionCount'] && (this['emissionCount'] = 0x1);
        },
        'update': function() {
            if (!this['paused']) {
                this['parent'](), this['elapsedTime'] += ig['system']['tick'];
                for (var _0x2d3150 = 0x0; _0x2d3150 < this['emissionCount']; _0x2d3150++)
                    if (this['particles'] + 0x1 <= this['maxCount']) this['particles']++, this['createParticle']();
                    else break;
                for (_0x2d3150 = 0x0; _0x2d3150 < this['minCount'] - this['particles']; _0x2d3150++) this['particles']++, this['createParticle']();
                !this['loop'] && 0x0 <= this['timer']['delta']() && this['kill']();
            }
        },
        'createParticle': function() {
            var _0x24714d = {};
            _0x24714d['angle'] = this['randomIntFromInterval'](this['minAngle'], this['maxAngle']), _0x24714d['speed'] = this['randomIntFromInterval'](this['minSpeed'], this['maxSpeed']), _0x24714d['lifeTime'] = this['randomIntFromInterval'](this['minLifeTime'], this['maxLifeTime']), _0x24714d['radius'] = this['randomIntFromInterval'](this['minRadius'], this['maxRadius']), _0x24714d['controller'] = this, _0x24714d['image'] = this['colors'][Math['floor'](Math['random']() * this['colors']['length'])], _0x24714d['gravityFactor'] = this['gravity'], _0x24714d['zIndex'] = this['zIndex'], _0x24714d['scale'] = this['scale'], _0x24714d['hasTarget'] = this['hasTarget'], _0x24714d['target'] = this['target'], _0x24714d['pos'] = this['pos'], _0x24714d = ig['game']['spawnEntity'](EntityParticle, this['pos']['x'], this['pos']['y'], _0x24714d), _0x24714d['pos']['x'] = this['pos']['x'], _0x24714d['pos']['y'] = this['pos']['y'];
        },
        'particleDead': function() {
            this['particles']--;
        },
        'randomIntFromInterval': function(_0x3f8caa, _0x567444) {
            return parseFloat((Math['random']() * (_0x567444 - _0x3f8caa) + _0x3f8caa)['toFixed'](0x4));
        },
        'pause': function() {
            this['paused'] = !0x0, this['timer']['pause']();
        },
        'resume': function() {
            this['paused'] = !0x1, this['timer']['unpause']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.fill-plot')['requires']('impact.entity', 'game.entities.others.particle-effect')['defines'](function() {
    EntityFillPlot = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'onClickCallback': null,
        'size': {
            'x': 0x118,
            'y': 0xaa
        },
        'angle': 0x0,
        'images': [new ig['Image']('media/graphics/sprites/plots/plot-potato.png'), new ig['Image']('media/graphics/sprites/plots/plot-carrot.png'), new ig['Image']('media/graphics/sprites/plots/plot-wheat.png'), new ig['Image']('media/graphics/sprites/plots/plot-tomato.png'), new ig['Image']('media/graphics/sprites/plots/plot-cucumber.png'), new ig['Image']('media/graphics/sprites/plots/plot-pepper.png'), new ig['Image']('media/graphics/sprites/plots/plot-turnip.png'), new ig['Image']('media/graphics/sprites/plots/plot-onion.png'), new ig['Image']('media/graphics/sprites/plots/plot-corn.png')],
        'particleImages': [new ig['Image']('media/graphics/sprites/crops/icon-potato.png'), new ig['Image']('media/graphics/sprites/crops/icon-carrot.png'), new ig['Image']('media/graphics/sprites/crops/icon-wheat.png'), new ig['Image']('media/graphics/sprites/crops/icon-tomato.png'), new ig['Image']('media/graphics/sprites/crops/icon-cucumber.png'), new ig['Image']('media/graphics/sprites/crops/icon-pepper.png'), new ig['Image']('media/graphics/sprites/crops/icon-turnip.png'), new ig['Image']('media/graphics/sprites/crops/icon-onion.png'), new ig['Image']('media/graphics/sprites/crops/icon-corn.png')],
        'coin': new ig['Image']('media/graphics/sprites/coin.png'),
        'loadingFrame': new ig['Image']('media/graphics/sprites/prog-bar.png'),
        'loadingBar': new ig['Image']('media/graphics/sprites/prog-bar-fill.png'),
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'index': 0x0,
        'detectionRadius': 0x4b,
        'init': function(_0x4540e2, _0x295281, _0x3d5df6) {
            this['parent'](_0x4540e2, _0x295281, _0x3d5df6), this['setAnchoredPosition'](_0x4540e2 - this['size']['x'] / 0x2, _0x295281 - this['size']['y'] / 0x2, 'center-middle'), ig['global']['wm'] || (null != _0x3d5df6['onClicked'] && (this['onClickCallback'] = _0x3d5df6['onClicked']), ig['game']['sortEntitiesDeferred'](), this['targetPos'] = -0xa, this['yPos'] = 0x0);
        },
        'draw': function() {
            this['parent']();
            var _0x56e43f = ig['system']['context'];
            this['images'][this['index']]['draw'](this['pos']['x'] + (this['size']['x'] - this['images'][this['index']]['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['images'][this['index']]['height']));
            if (this['controller']['saveData']['onProgress']) {
                var _0x115bdc = this['controller']['harvestTime'] * ig['game']['gameController']['globalSpeedBoost'];
                0.2 <= _0x115bdc && (this['loadingFrame']['draw'](this['pos']['x'] + (this['size']['x'] - this['loadingFrame']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['loadingFrame']['height']) / 0x2 + 0x2d), this['loadingBar']['draw'](this['pos']['x'] + (this['size']['x'] - this['loadingFrame']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['loadingFrame']['height']) / 0x2 + 0x2d, 0x0, 0x0, this['loadingBar']['width'] * this['controller']['saveData']['progressTime'] / (this['controller']['harvestTime'] * ig['game']['gameController']['globalSpeedBoost']), this['loadingBar']['height']));
            }
            if (this['controller']['automatic'] || !this['controller']['saveData']['onProgress']) _0x115bdc = this['controller']['harvestTime'] * ig['game']['gameController']['globalSpeedBoost'], 0.2 > _0x115bdc && (this['loadingFrame']['draw'](this['pos']['x'] + (this['size']['x'] - this['loadingFrame']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['loadingFrame']['height']) / 0x2 + 0x2d), this['loadingBar']['draw'](this['pos']['x'] + (this['size']['x'] - this['loadingFrame']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['loadingFrame']['height']) / 0x2 + 0x2d)), 0x0 < this['controller']['saveData']['accumulatedProfit'] && (this['yPos'] = this['lerp'](this['yPos'], this['targetPos'], 0.1), this['coin']['draw'](this['pos']['x'] + (this['size']['x'] - this['coin']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['coin']['height']) / 0x2 - 0x19 + this['yPos']), 0x1 >= Math['abs'](this['yPos'] - this['targetPos']) && (this['targetPos'] = 0x0 == this['targetPos'] ? -0xa : 0x0), _0x56e43f['font'] = '25px\x20luckiest-guy', _0x56e43f['fillStyle'] = '#fff', _0x56e43f['textAlign'] = 'center', _0x56e43f['lineWidth'] = 0x4, _0x56e43f['strokeStyle'] = '#000', _0x56e43f['lineCap'] = 'round', _0x56e43f['lineJoin'] = 'round', _0x115bdc = ig['game']['utility']['getInString'](this['controller']['saveData']['accumulatedProfit'], 0x2), _0x56e43f['strokeText']('$' + _0x115bdc, this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2 + 0x19), _0x56e43f['fillText']('$' + _0x115bdc, this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2 + 0x19));
            ig['game']['drawIntersect'] && (_0x56e43f['beginPath'](), _0x56e43f['arc'](this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2, this['detectionRadius'], 0x0, 0x2 * Math['PI']), _0x56e43f['stroke']());
        },
        'clicked': function() {},
        'clicking': function() {},
        'released': function() {
            if (this['isEnabled'] && !ig['game']['gameController']['upgradeMode'] && this['detectIntersect'](ig['game']['inputPos'], ig['game']['inputPos']) && null != this['onClickCallback']) this['onClickCallback']();
        },
        'detectIntersect': function(_0xa9ea6e, _0x648118) {
            if (this['isEnabled']) {
                var _0x33d9b1 = !0x1,
                    _0x33d9b1 = new ig['SAT']['Shape']([_0xa9ea6e, _0x648118]),
                    _0x489b6c = this['getDetectionShape']();
                return ig['sat']['simpleShapeIntersect'](_0x33d9b1, _0x489b6c);
            }
        },
        'getDetectionShape': function() {
            var _0xffcc06 = new Vector2(this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2);
            return new ig['SAT']['Circle'](_0xffcc06, this['detectionRadius']);
        },
        'createParticles': function() {
            var _0x39ce1d = {
                'minAngle': -0xb4,
                'maxAngle': 0x0,
                'minSpeed': 0x12c,
                'maxSpeed': 0x190,
                'minLifeTime': 0.5,
                'maxLifeTime': 0x1,
                'duration': 0x0,
                'minCount': 0xa,
                'maxCount': 0x3c,
                'emission': 0x1e,
                'minRadius': 0x5,
                'maxRadius': 0x8,
                'gravity': 0x1
            };
            _0x39ce1d['colors'] = [this['particleImages'][this['index']]], _0x39ce1d['zIndex'] = this['zIndex'] + 0x1, _0x39ce1d['scale'] = 0.5, this['particleEffect'] = ig['game']['spawnEntity'](EntityParticleEffect, 0x0, 0x0, _0x39ce1d), this['particleEffect']['pos']['x'] = this['pos']['x'] + this['size']['x'] / 0x2, this['particleEffect']['pos']['y'] = this['pos']['y'] + this['size']['y'] / 0x2 + 0xa;
            if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] == this && null != this['onTutorialCallback']) this['onTutorialCallback']();
        },
        'kill': function() {
            null != this['particleEffect'] && this['particleEffect']['kill'](), null != this['particleDust'] && this['particleDust']['kill'](), this['parent']();
        },
        'update': function() {
            this['parent']();
        },
        'lerp': function(_0x469a80, _0x1f0589, _0x256613) {
            return (0x1 - _0x256613) * _0x469a80 + _0x256613 * _0x1f0589;
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-buy')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonBuy = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'onImage': new ig['Image']('media/graphics/sprites/button-on.png'),
        'offImage': new ig['Image']('media/graphics/sprites/button-off.png'),
        'size': {
            'x': 0x86,
            'y': 0x3e
        },
        'gAlpha': 0x0,
        'isEnabled': !0x0,
        'textPrice': '',
        'init': function(_0x33cf5f, _0xa8c637, _0x1a2eae) {
            this['parent'](_0x33cf5f, _0xa8c637, _0x1a2eae), this['setAnchoredPosition'](_0x33cf5f - this['size']['x'] / 0x2, _0xa8c637 - this['size']['y'] / 0x2, 'middle-center'), this['startYPos'] = this['anchoredPositionY'], null != _0x1a2eae['onClicked'] && (this['onClickCallback'] = _0x1a2eae['onClicked']);
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || ig['game']['sessionData']['playerMoney'] < this['controller']['price'] || this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.1, {})['start']());
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && !(ig['game']['sessionData']['playerMoney'] < this['controller']['price']) && (this['pressed'] = this['isEnabled'] = !0x1, ig['soundHandler']['sfxPlayer']['play']('buy'), this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    if (null != this['onClickCallback']) this['onClickCallback']();
                }['bind'](this)
            })['start']());
        },
        'draw': function() {
            this['parent'](), ig['game']['sessionData']['playerMoney'] < this['controller']['price'] ? this['offImage']['draw'](this['pos']['x'], this['pos']['y']) : this['onImage']['draw'](this['pos']['x'], this['pos']['y']);
            var _0x243d40 = ig['system']['context'];
            _0x243d40['font'] = '25px\x20luckiest-guy', _0x243d40['fillStyle'] = '#000', _0x243d40['textAlign'] = 'center', _0x243d40['textBaseline'] = 'middle', _0x243d40['fillText'](this['textPrice'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.upgrade-plot')['requires']('game.entities.buttons.button', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-buy')['defines'](function() {
    EntityUpgradePlot = EntityPopupController['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'image': new ig['Image']('media/graphics/sprites/plots/plot-harvest.png'),
        'icons': [new ig['Image']('media/graphics/sprites/crops/icon-potato.png'), new ig['Image']('media/graphics/sprites/crops/icon-carrot.png'), new ig['Image']('media/graphics/sprites/crops/icon-wheat.png'), new ig['Image']('media/graphics/sprites/crops/icon-tomato.png'), new ig['Image']('media/graphics/sprites/crops/icon-cucumber.png'), new ig['Image']('media/graphics/sprites/crops/icon-pepper.png'), new ig['Image']('media/graphics/sprites/crops/icon-turnip.png'), new ig['Image']('media/graphics/sprites/crops/icon-onion.png'), new ig['Image']('media/graphics/sprites/crops/icon-corn.png')],
        'loadingFrame': new ig['Image']('media/graphics/sprites/harvest-bar.png'),
        'loadingBar': new ig['Image']('media/graphics/sprites/harvest-bar-fill.png'),
        'size': {
            'x': 0x118,
            'y': 0xaa
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'index': 0x0,
        'textPrice': null,
        'buttonBuy': null,
        'barPercent': 0x0,
        'init': function(_0x442799, _0x237bb8, _0x4b7cc1) {
            this['parent'](_0x442799, _0x237bb8, _0x4b7cc1), this['setAnchoredPosition'](_0x442799 - this['size']['x'] / 0x2, _0x237bb8 - this['size']['y'] / 0x2, 'center-middle'), ig['global']['wm'] || (this['calculateBar'](), this['buttonBuy'] = this['spawnEntity'](EntityButtonBuy, 0x0, 0xa, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onBuyUpgrade']();
                }['bind'](this),
                'controller': this
            }), ig['game']['sortEntitiesDeferred']());
        },
        'onBuyUpgrade': function() {
            this['controller']['onUpgradeClicked'](), this['calculateBar']();
        },
        'calculateBar': function() {
            -0x1 == this['controller']['nextUnlock'] ? this['barPercent'] = 0x1 : (this['barPercent'] = (this['controller']['saveData']['level'] - ig['unlocksdb'][this['controller']['nextUnlock'] - 0x1]['Level']) / (ig['unlocksdb'][this['controller']['nextUnlock']]['Level'] - ig['unlocksdb'][this['controller']['nextUnlock'] - 0x1]['Level']), 0x0 >= this['barPercent'] && (this['barPercent'] = 0.001));
        },
        'updatePrice': function(_0x233729) {
            this['price'] = _0x233729, this['textPrice'] = '$' + ig['game']['utility']['getInString'](_0x233729, 0x2), this['buttonBuy']['textPrice'] = this['textPrice'];
        },
        'draw': function() {
            this['parent']();
            var _0x356927 = ig['system']['context'];
            this['image']['draw'](this['pos']['x'] + (this['size']['x'] - this['image']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['image']['height'])), this['icons'][this['index']]['draw'](this['pos']['x'] + this['icons'][this['index']]['width'] / 0x2 + 0xf, this['pos']['y'] - this['icons'][this['index']]['height'] / 0x2 - 0x14), _0x356927['font'] = '25px\x20luckiest-guy', _0x356927['fillStyle'] = '#000', _0x356927['textAlign'] = 'center', _0x356927['textBaseline'] = 'middle', _0x356927['fillText']('+' + this['controller']['multiplier'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2 - 0x4b), this['loadingFrame']['draw'](this['pos']['x'] + (this['size']['x'] - this['loadingFrame']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['loadingFrame']['height']) / 0x2 - 0x37), this['loadingBar']['draw'](this['pos']['x'] + (this['size']['x'] - this['loadingFrame']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['loadingFrame']['height']) / 0x2 - 0x37, 0x0, 0x0, 0.5, this['loadingBar']['height']), _0x356927['lineWidth'] = 0x5, _0x356927['fillStyle'] = '#fff', _0x356927['strokeStyle'] = '#190d3a', _0x356927['lineCap'] = 'round', _0x356927['lineJoin'] = 'round', _0x356927['strokeText'](this['controller']['saveData']['level'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2 - 0x32), _0x356927['fillText'](this['controller']['saveData']['level'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2 - 0x32);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.plot')['requires']('impact.entity', 'game.entities.gameplay.empty-plot', 'game.entities.gameplay.fill-plot', 'game.entities.gameplay.upgrade-plot', 'game.entities.others.particle-effect')['defines'](function() {
    EntityPlot = ig['Entity']['extend']({
        'image': new ig['Image']('media/graphics/sprites/plots/plot-lock.png'),
        'size': {
            'x': 0x118,
            'y': 0xaa
        },
        'index': 0x0,
        'owned': !0x1,
        'emptyButton': null,
        'fillButton': null,
        'upgradeButton': null,
        'buyPrice': 0x0,
        'upgradePrice': 0x0,
        'saveData': null,
        'modelData': null,
        'harvestTime': 0x0,
        'profit': 0x0,
        'profitPerSecond': 0x0,
        'fixedPosition': null,
        'multiplier': 0x1,
        'speedBoost': 0x1,
        'profitBoost': 0x1,
        'automatic': !0x1,
        'nextUnlock': 0x0,
        'onTutorialCallback': null,
        'coin': new ig['Image']('media/graphics/sprites/coin.png'),
        'init': function(_0x207b9f, _0xd0ca21, _0x1948b6) {
            this['parent'](_0x207b9f, _0xd0ca21, _0x1948b6), this['setAnchoredPosition'](_0x207b9f - this['size']['x'] / 0x2, _0xd0ca21 - this['size']['y'] / 0x2, 'center-middle'), this['fixedPosition'] = new Vector2(this['pos']['x'], this['pos']['y']), ig['global']['wm'] || (this['saveData'] = ig['game']['sessionData']['Farms'][this['index']], this['modelData'] = ig['businessdb']['Crops'][this['index']], this['checkUpgrade'](), this['calculateUnlockBonus'](this['nextUnlock'], !0x1), 0x0 < this['saveData']['level'] ? this['fillButton'] = ig['game']['spawnEntity'](EntityFillPlot, this['pos']['x'], this['pos']['y'], {
                'zIndex': this['zIndex'] + 0x1,
                'index': this['index'],
                'onClicked': function() {
                    this['onHarvestClicked']();
                }['bind'](this),
                'controller': this
            }) : this['showBuyPlot'](), this['calculateEarningData'](), this['calculateOfflineProfit']());
        },
        'showBuyPlot': function() {
            this['buyPrice'] = this['modelData']['InitialCost'], 0x0 == this['index'] && (this['buyPrice'] = 0x0), this['emptyButton'] = ig['game']['spawnEntity'](EntityEmptyPlot, this['fixedPosition']['x'], this['fixedPosition']['y'], {
                'zIndex': this['zIndex'] + 0x1,
                'index': this['index'],
                'onClicked': function() {
                    this['onBuyPlot']();
                }['bind'](this),
                'buyPrice': this['buyPrice']
            });
        },
        'onBuyPlot': function() {
            if (!ig['game']['gameController']['upgradeMode'] && !(ig['game']['sessionData']['playerMoney'] < this['buyPrice'])) {
                if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                    if (ig['game']['gameController']['tutorial']['target'] == this) {
                        if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                    } else return;
                }
                this['fillButton'] = ig['game']['spawnEntity'](EntityFillPlot, this['fixedPosition']['x'], this['fixedPosition']['y'], {
                    'zIndex': this['zIndex'] + 0x1,
                    'index': this['index'],
                    'onClicked': function() {
                        this['onHarvestClicked']();
                    }['bind'](this),
                    'controller': this
                }), this['emptyButton']['kill'](), this['saveData']['onProgress'] = !0x0, this['saveData']['level'] = 0x1, ig['game']['gameController']['addMoney'](-this['buyPrice']), this['calculateEarningData'](), ig['game']['gameController']['onSavePlotData'](), ig['soundHandler']['sfxPlayer']['play']('buy'), ig['game']['gameController']['tutorial']['checkTutorialState'](), ig['game']['gameController']['getUpgradeList']();
            }
        },
        'calculateEarningData': function() {
            this['harvestTime'] = this['modelData']['InitialTime'] * this['speedBoost'], this['profit'] = this['modelData']['InitialRevenue'] * this['saveData']['level'] * this['profitBoost'], this['profit'] += this['profit'] * ig['game']['gameController']['seedBenefit'], this['automatic'] && (this['profitPerSecond'] = this['modelData']['InitialProductivity'] * this['saveData']['level'] * this['profitBoost']);
        },
        'calculateOfflineProfit': function() {
            if (null != ig['game']['sessionData']['lastTimeStamp'] && this['automatic']) {
                var _0x270011 = ig['game']['sessionData']['lastTimeStamp'],
                    _0x270011 = Math['abs'](new Date()['getTime']() - _0x270011) / 0x3e8;
                if (0x0 < ig['game']['gameController']['bonusDuration']) {
                    var _0xb85fcc = Math['floor']((_0x270011 - ig['game']['gameController']['bonusDuration']) / this['harvestTime']);
                    this['saveData']['accumulatedProfit'] += (_0xb85fcc + Math['floor'](0.5 * ((ig['game']['gameController']['bonusDuration'] + this['saveData']['progressTime']) / this['harvestTime']))) * this['profit'];
                } else _0xb85fcc = Math['floor']((_0x270011 + this['saveData']['progressTime']) / this['harvestTime']), this['saveData']['accumulatedProfit'] += _0xb85fcc * this['profit'];
                this['saveData']['progressTime'] = (_0x270011 + this['saveData']['progressTime']) % this['harvestTime'];
            }
        },
        'calculateUnlockBonus': function(_0x278c0a, _0x140cb4) {
            for (var _0x2b1139 = _0x278c0a; _0x2b1139 < ig['unlocksdb']['length']; _0x2b1139++)
                if (this['saveData']['level'] >= ig['unlocksdb'][_0x2b1139]['Level']) this['appliedUnlockBoost'](ig['unlocksdb'][_0x2b1139], _0x140cb4), null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['checkUnlockTutorial']();
                else {
                    this['nextUnlock'] = _0x2b1139 < ig['unlocksdb']['length'] - 0x1 ? _0x2b1139 : -0x1;
                    break;
                }
        },
        'appliedUnlockBoost': function(_0x37dfc8, _0x2dbf95) {
            switch (_0x37dfc8['ProfitType']) {
                case 'Speed':
                    this['speedBoost'] *= _0x37dfc8['ProfitValue'];
                    break;
                case 'Profit':
                    this['profitBoost'] *= _0x37dfc8['ProfitValue'];
            }
            _0x2dbf95 && ig['game']['gameController']['gameplayUI']['showUnlocks'](_0x37dfc8, this['index']);
        },
        'update': function() {
            this['parent']();
            if (!ig['game']['gameController']['isPaused']) {
                if (this['saveData']['onProgress']) {
                    this['saveData']['progressTime'] += ig['system']['tick'];
                    var _0x287085 = this['harvestTime'] * ig['game']['gameController']['globalSpeedBoost'];
                    0.2 > _0x287085 && this['automatic'] ? this['saveData']['progressTime'] >= 0.2 * ig['game']['gameController']['globalSpeedBoost'] && (this['saveData']['progressTime'] = 0x0, this['saveData']['onProgress'] = !0x1, this['saveData']['accumulatedProfit'] += 0.2 * this['profit'] / _0x287085 * ig['game']['sessionData']['globalProfit']) : this['saveData']['progressTime'] >= this['harvestTime'] * ig['game']['gameController']['globalSpeedBoost'] && (this['saveData']['progressTime'] = 0x0, this['saveData']['onProgress'] = !0x1, this['saveData']['accumulatedProfit'] += this['profit'] * ig['game']['sessionData']['globalProfit']);
                } else this['automatic'] && (this['saveData']['onProgress'] = !0x0);
            }
        },
        'checkUpgrade': function() {
            for (var _0xe0e1c4 = 0x0; _0xe0e1c4 < this['saveData']['upgradeLevel']; _0xe0e1c4++) this['appliedUpgrade'](ig['upgradedb'][this['index']][_0xe0e1c4]);
        },
        'buyUpgrade': function(_0x22cc8a) {
            this['saveData']['upgradeLevel'] += 0x1, ig['game']['gameController']['onSavePlotData'](), this['appliedUpgrade'](_0x22cc8a), this['calculateEarningData'](), ig['game']['gameController']['updateIncomePerSecond']();
        },
        'appliedUpgrade': function(_0x1a631c) {
            switch (_0x1a631c['ProfitType']) {
                case 'Automate':
                    this['automatic'] = !0x0;
                    break;
                case 'Profit':
                    this['profitBoost'] *= _0x1a631c['ProfitValue'];
            }
        },
        'onHarvestClicked': function() {
            if (!(0x0 >= this['saveData']['accumulatedProfit'])) {
                if (this['automatic']) this['collectProfit']();
                else {
                    if (!this['saveData']['onProgress'] && this['fillButton']['isEnabled']) {
                        this['collectProfit'](), this['saveData']['onProgress'] = !0x0, this['fillButton']['createParticles']();
                        if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                            if (ig['game']['gameController']['tutorial']['target'] == this) {
                                if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                            } else return;
                        }
                        ig['game']['gameController']['tutorial']['checkTutorialState']();
                    }
                }
            }
        },
        'collectProfit': function() {
            ig['game']['gameController']['addMoney'](this['saveData']['accumulatedProfit']), this['saveData']['accumulatedProfit'] = 0x0, this['createCoinParticle'](), ig['soundHandler']['sfxPlayer']['play']('crop'), this['tween']({
                'test': 0x1
            }, 0.8, {
                'onComplete': function() {
                    ig['soundHandler']['sfxPlayer']['play']('coin');
                }['bind'](this)
            })['start']();
        },
        'createCoinParticle': function() {
            var _0x46ded8 = {
                'minAngle': -0xb4,
                'maxAngle': 0x0,
                'minSpeed': 0x12c,
                'maxSpeed': 0x190,
                'minLifeTime': 0.5,
                'maxLifeTime': 0x1,
                'duration': 0x0,
                'minCount': 0xa,
                'maxCount': 0x3c,
                'emission': 0x1e,
                'minRadius': 0x5,
                'maxRadius': 0x8,
                'gravity': 0x1
            };
            _0x46ded8['colors'] = [this['coin']], _0x46ded8['zIndex'] = this['zIndex'] + 0x1, _0x46ded8['scale'] = 0.75, _0x46ded8['hasTarget'] = !0x0, _0x46ded8['target'] = new Vector2(0x14, 0x14), this['particleEffect'] = ig['game']['spawnEntity'](EntityParticleEffect, 0x0, 0x0, _0x46ded8), this['particleEffect']['pos']['x'] = this['pos']['x'] + this['size']['x'] / 0x2, this['particleEffect']['pos']['y'] = this['pos']['y'] + this['size']['y'] / 0x2 + 0xa;
        },
        'onUpgradeClicked': function() {
            ig['game']['sessionData']['playerMoney'] < this['upgradePrice'] || (this['saveData']['level'] += this['multiplier'], ig['game']['gameController']['addMoney'](-this['upgradePrice']), this['calculateUnlockBonus'](this['nextUnlock'], !0x0), this['calculateEarningData'](), ig['game']['gameController']['updateIncomePerSecond'](), ig['game']['gameController']['onSavePlotData'](), ig['game']['gameController']['changeMultiplier'](ig['game']['gameController']['upgradeController']['currentActive']['value']));
        },
        'changeToUpgradeMode': function(_0xb11544) {
            0x0 >= this['saveData']['level'] || (_0xb11544 ? (null != this['fillButton'] && (this['fillButton']['kill'](), this['fillButton'] = null), this['upgradeButton'] = ig['game']['spawnEntity'](EntityUpgradePlot, this['fixedPosition']['x'], this['fixedPosition']['y'], {
                'zIndex': this['zIndex'] + 0x1,
                'index': this['index'],
                'onClicked': function() {
                    this['onUpgradeClicked']();
                }['bind'](this),
                'controller': this
            })) : (null != this['upgradeButton'] && (this['upgradeButton']['kill'](), this['upgradeButton'] = null), this['fillButton'] = ig['game']['spawnEntity'](EntityFillPlot, this['fixedPosition']['x'], this['fixedPosition']['y'], {
                'zIndex': this['zIndex'] + 0x1,
                'index': this['index'],
                'onClicked': function() {
                    this['onHarvestClicked']();
                }['bind'](this),
                'controller': this
            })));
        },
        'getCumulativePrice': function(_0x19f0c9) {
            _0x19f0c9 = Math['pow'](this['modelData']['Coefficient'], _0x19f0c9 + this['saveData']['level']);
            var _0x540a0e = Math['pow'](this['modelData']['Coefficient'], this['saveData']['level']);
            return ig['game']['utility']['clampNumber'](this['modelData']['InitialCost'] * (_0x19f0c9 - _0x540a0e) / (this['modelData']['Coefficient'] - 0x1));
        },
        'updateBuyMultiplier': function(_0x43a0b4) {
            0x0 >= this['saveData']['level'] || (-0x1 == _0x43a0b4 ? (_0x43a0b4 = ig['game']['sessionData']['playerMoney'] * (this['modelData']['Coefficient'] - 0x1) / (this['modelData']['InitialCost'] * Math['pow'](this['modelData']['Coefficient'], this['saveData']['level'])) + 0x1, _0x43a0b4 = Math['floor'](Math['log'](_0x43a0b4) / Math['log'](0xa) / (Math['log'](this['modelData']['Coefficient']) / Math['log'](0xa))), 0x0 >= _0x43a0b4 && (_0x43a0b4 = 0x1)) : 0x64 == _0x43a0b4 && (_0x43a0b4 = ig['unlocksdb'][this['nextUnlock']]['Level'] - this['saveData']['level']), this['upgradePrice'] = this['getCumulativePrice'](_0x43a0b4), null != this['upgradeButton'] && 0x0 < this['saveData']['level'] && this['upgradeButton']['updatePrice'](this['upgradePrice']), this['multiplier'] = _0x43a0b4);
        },
        'setButtonsActive': function(_0x134afa) {
            null != this['emptyButton'] && (this['emptyButton']['isEnabled'] = _0x134afa), null != this['fillButton'] && (this['fillButton']['isEnabled'] = _0x134afa), null != this['upgradeButton'] && (this['upgradeButton']['buttonBuy']['isEnabled'] = _0x134afa);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.ui.unlock-notif')['requires']('impact.entity')['defines'](function() {
    EntityUnclockNotif = ig['Entity']['extend']({
        'checkAgainst': ig['Entity']['TYPE']['NONE'],
        'panelImage': new ig['Image']('media/graphics/sprites/popup-booster.png'),
        'frameIcon': new ig['Image']('media/graphics/sprites/shop-icon-bg.png'),
        'icons': [new ig['Image']('media/graphics/sprites/crops/icon-potato.png'), new ig['Image']('media/graphics/sprites/crops/icon-carrot.png'), new ig['Image']('media/graphics/sprites/crops/icon-wheat.png'), new ig['Image']('media/graphics/sprites/crops/icon-tomato.png'), new ig['Image']('media/graphics/sprites/crops/icon-cucumber.png'), new ig['Image']('media/graphics/sprites/crops/icon-pepper.png'), new ig['Image']('media/graphics/sprites/crops/icon-turnip.png'), new ig['Image']('media/graphics/sprites/crops/icon-onion.png'), new ig['Image']('media/graphics/sprites/crops/icon-corn.png')],
        'size': {
            'x': 0x1de,
            'y': 0x94
        },
        'data': null,
        'index': 0x0,
        'textDesc': null,
        'textValue': null,
        'init': function(_0x38cdb9, _0x4b8f64, _0x30ba5b) {
            this['parent'](_0x38cdb9, _0x4b8f64, _0x30ba5b), this['setAnchoredPosition'](_0x38cdb9 - this['size']['x'], _0x4b8f64, 'right-top'), 'Speed' == this['data']['ProfitType'] ? (this['textDesc'] = _STRINGS['Game']['UnlockSpeed'], this['textValue'] = '-' + 0x64 * this['data']['ProfitValue'] + '%') : (this['textDesc'] = _STRINGS['Game']['UnlockProfit'], this['textValue'] = 'x' + this['data']['ProfitValue']), this['animate']();
        },
        'animate': function() {
            this['tween']({
                'anchoredPositionY': 0x32
            }, 0.3, {
                'onComplete': function() {
                    this['tween']({
                        'anchoredPositionY': -0xc8
                    }, 0.3, {
                        'delay': 0x3,
                        'onComplete': function() {
                            this['kill']();
                        }['bind'](this)
                    })['start']();
                }['bind'](this)
            })['start']();
        },
        'draw': function() {
            this['parent'](), this['panelImage']['draw'](this['pos']['x'], this['pos']['y']), this['frameIcon']['draw'](this['pos']['x'] + 0xf, this['pos']['y'] + 0xf), this['icons'][this['index']]['draw'](this['pos']['x'] + 0xf + (this['frameIcon']['width'] - this['icons'][this['index']]['width']) / 0x2, this['pos']['y'] + 0xf + (this['frameIcon']['height'] - this['icons'][this['index']]['height']) / 0x2);
            var _0x486ed5 = ig['system']['context'];
            _0x486ed5['font'] = '30px\x20luckiest-guy', _0x486ed5['fillStyle'] = '#000000', _0x486ed5['textAlign'] = 'center', _0x486ed5['textBaseline'] = 'middle', _0x486ed5['fillText'](this['textDesc'], this['pos']['x'] + 0x6a + (this['size']['x'] - 0x6a) / 0x2, this['pos']['y'] + 0x32), _0x486ed5['font'] = '45px\x20luckiest-guy', _0x486ed5['fillText'](this['textValue'], this['pos']['x'] + 0x6a + (this['size']['x'] - 0x6a) / 0x2, this['pos']['y'] + 0x69);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.ui.gameplay-ui')['requires']('impact.entity', 'game.entities.ui.unlock-notif')['defines'](function() {
    EntityGameplayUI = ig['Entity']['extend']({
        'checkAgainst': ig['Entity']['TYPE']['NONE'],
        'cashIcon': new ig['Image']('media/graphics/sprites/cash-icon.png'),
        'idleIcon': new ig['Image']('media/graphics/sprites/cash-idle.png'),
        'bonusIcon': new ig['Image']('media/graphics/sprites/bonus.png'),
        'center': null,
        'currentIdle': 0x0,
        'currentCash': 0x0,
        'currentSeed': 0x0,
        'idleActive': !0x1,
        'tooltipBtn': null,
        'init': function(_0x34e477, _0x38d833, _0x365ee3) {
            this['parent'](_0x34e477, _0x38d833, _0x365ee3), this['setAnchoredPosition'](_0x34e477, _0x38d833, 'left-top'), this['currentSeed'] = ig['game']['utility']['getInString'](ig['game']['sessionData']['seedCount'], 0x2);
        },
        'updateCash': function() {
            this['currentCash'] = ig['game']['utility']['getInString'](ig['game']['sessionData']['playerMoney'], 0x2), this['currentIdle'] = ig['game']['utility']['getInString'](ig['game']['gameController']['incomePerSecond'], 0x2);
        },
        'getTargetMoney': function() {
            var _0x496166 = ig['responsive']['width'] / 0x4;
            return this['idleActive'] ? new Vector2(_0x496166 - 0x64, 0x32) : new Vector2(-0x64, 0x32);
        },
        'draw': function() {
            this['parent'](), ig['responsive']['toAnchor'](0x0, 0x0, 'top-left'), count = Math['ceil'](ig['system']['width'] / this['size']['x']), this['cashIcon']['draw'](0x14, 0x14), this['idleIcon']['draw'](0x14, 0x69), this['bonusIcon']['draw'](0x14, 0xbe);
            var _0x3b0a72 = ig['system']['context'];
            _0x3b0a72['font'] = '25px\x20luckiest-guy', _0x3b0a72['fillStyle'] = '#000000', _0x3b0a72['textAlign'] = 'center', _0x3b0a72['textBaseline'] = 'middle', _0x3b0a72['fillText']('$' + this['currentCash'], 0x32 + this['cashIcon']['width'] / 0x2, 0x19 + this['cashIcon']['height'] / 0x2), ig['game']['utility']['shrinkText'](_0x3b0a72, '$' + this['currentIdle'] + '\x20/s', 'luckiest-guy', '25', 0x32 + this['cashIcon']['width'] / 0x2, 0x6e + this['cashIcon']['height'] / 0x2, 0x7d), _0x3b0a72['font'] = '25px\x20luckiest-guy', _0x3b0a72['fillStyle'] = '#000000', _0x3b0a72['textAlign'] = 'center', _0x3b0a72['textBaseline'] = 'middle', _0x3b0a72['fillText'](this['currentSeed'], 0x32 + this['cashIcon']['width'] / 0x2, 0xc3 + this['cashIcon']['height'] / 0x2);
        },
        'showUnlocks': function(_0x20a624, _0x45a8fe) {
            ig['game']['spawnEntity'](EntityUnclockNotif, -0x64, -0xc8, {
                'zIndex': this['zIndex'] + 0x1,
                'index': _0x45a8fe,
                'data': _0x20a624
            });
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-upgrade')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonUpgrade = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'idleSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-harvest.png', 0x5e, 0x5f),
        'activeSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-harvest2.png', 0x5e, 0x5f),
        'size': {
            'x': 0x5e,
            'y': 0x5f
        },
        'gAlpha': 0x0,
        'isEnabled': !0x0,
        'tutorialLocked': !0x1,
        'init': function(_0x256a52, _0x508ba7, _0x2de776) {
            this['parent'](_0x256a52, _0x508ba7, _0x2de776), this['setAnchoredPosition'](_0x256a52 - this['size']['x'] / 0x2, _0x508ba7 - this['size']['y'], 'left-bottom'), this['idle'] = new ig['Animation'](this['idleSheet'], 0x1, [0x0]), this['active'] = new ig['Animation'](this['activeSheet'], 0x1, [0x0]), this['currentAnim'] = this['idle'], this['startYPos'] = this['anchoredPositionY'], null != _0x2de776['onClicked'] && (this['onClickCallback'] = _0x2de776['onClicked']), this['checkTutorialLocked']();
        },
        'setActive': function(_0x405f6b) {
            this['currentAnim'] = _0x405f6b ? this['active'] : this['idle'];
        },
        'checkTutorialLocked': function() {
            0x2 >= ig['game']['sessionData']['tutorialProgress'] && (this['tutorialLocked'] = !0x0), this['showLocked']();
        },
        'showLocked': function() {
            this['currentAnim']['alpha'] = this['tutorialLocked'] ? 0x0 : 0x1;
        },
        'clicked': function() {
            this['isEnabled'] && !this['tutorialLocked'] && (this['pressed'] = !0x0, null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || (ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.1, {})['start']()));
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && !this['tutorialLocked'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    this['controller']['upgradeMode'] ? this['controller']['setUpgradeMode'](!0x1) : this['controller']['setUpgradeMode'](!0x0);
                }['bind'](this)
            })['start']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-multiplier')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonMultiplier = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'textMultiplier': ['1x', '10x', '100x', 'MAX'],
        'multiplierValue': [0x1, 0xa, 0x64, -0x1],
        'idleSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-mult1.png', 0x4c, 0x4d),
        'activeSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-mult2.png', 0x4c, 0x4d),
        'flagIdle': new ig['AnimationSheet']('media/graphics/sprites/btn-mult4.png', 0x4c, 0x4d),
        'flagActive': new ig['AnimationSheet']('media/graphics/sprites/btn-mult3.png', 0x4c, 0x4d),
        'size': {
            'x': 0x4c,
            'y': 0x4d
        },
        'gAlpha': 0x0,
        'isEnabled': !0x0,
        'index': 0x0,
        'active': !0x1,
        'init': function(_0x455fe1, _0x4aaf24, _0x5c3ac8) {
            this['parent'](_0x455fe1, _0x4aaf24, _0x5c3ac8), this['setAnchoredPosition'](_0x455fe1 - this['size']['x'] / 0x2, _0x4aaf24 - this['size']['y'], 'right-bottom'), 0x2 == this['index'] ? (this['idleAnim'] = new ig['Animation'](this['flagIdle'], 0x1, [0x0]), this['activeAnim'] = new ig['Animation'](this['flagActive'], 0x1, [0x0])) : (this['idleAnim'] = new ig['Animation'](this['idleSheet'], 0x1, [0x0]), this['activeAnim'] = new ig['Animation'](this['activeSheet'], 0x1, [0x0])), this['startYPos'] = this['anchoredPositionY'], null != _0x5c3ac8['onClicked'] && (this['onClickCallback'] = _0x5c3ac8['onClicked']), this['value'] = this['multiplierValue'][this['index']], ig['global']['wm'] || this['setActive'](!0x1);
        },
        'setActive': function(_0x24f6b5) {
            this['currentAnim'] = (this['active'] = _0x24f6b5) ? this['activeAnim'] : this['idleAnim'];
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.1, {})['start']());
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    if (null != this['onClickCallback']) this['onClickCallback'](this);
                }['bind'](this)
            })['start']());
        },
        'draw': function() {
            this['parent']();
            var _0x3cdcf1 = ig['system']['context'];
            0x2 != this['index'] && (_0x3cdcf1['font'] = '25px\x20luckiest-guy', _0x3cdcf1['fillStyle'] = '#17160e', _0x3cdcf1['textAlign'] = 'center', _0x3cdcf1['textBaseline'] = 'middle', _0x3cdcf1['fillText'](this['textMultiplier'][this['index']], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2));
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.upgrade-controller')['requires']('impact.entity', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-upgrade', 'game.entities.buttons.button-multiplier', 'game.entities.buttons.button-close')['defines'](function() {
    EntityUpgradeController = EntityPopupController['extend']({
        'upgradeButton': null,
        'multiplierButton': [],
        'closeButton': null,
        'currentActive': null,
        'activeIndex': 0x0,
        'frame': new ig['Image']('media/graphics/sprites/popup-booster.png'),
        'init': function(_0x5cc54f, _0x4c0804, _0x33b17d) {
            this['parent'](_0x5cc54f, _0x4c0804, _0x33b17d), this['upgradeButton'] = ig['game']['spawnEntity'](EntityButtonUpgrade, 0xc8, -0x19, {
                'zIndex': this['zIndex'] + 0x1,
                'controller': ig['game']['gameController']
            }), ig['game']['sortEntitiesDeferred']();
        },
        'changeUpgradeMode': function(_0x1dc99e) {
            if (_0x1dc99e) {
                for (var _0x1222e9 = 0x0; 0x4 > _0x1222e9; _0x1222e9++) {
                    var _0x1d32e1 = ig['game']['spawnEntity'](EntityButtonMultiplier, -0x190 + 0x64 * _0x1222e9, -0x14, {
                        'zIndex': this['zIndex'] + 0x1,
                        'controller': ig['game']['gameController'],
                        'index': _0x1222e9,
                        'onClicked': function(_0x479bf2) {
                            this['changeMultiplier'](_0x479bf2);
                        }['bind'](this)
                    });
                    this['multiplierButton']['push'](_0x1d32e1);
                }
                this['changeMultiplier'](this['multiplierButton'][this['activeIndex']]), this['closeButton'] = ig['game']['spawnEntity'](EntityButtonClose, this['frame']['width'] / 0x2, 0x32, {
                    'zIndex': this['zIndex'] + 0x1,
                    'anchor': 'top-center',
                    'onClicked': function() {
                        this['onCloseClicked']();
                    }['bind'](this)
                });
            } else {
                for (_0x1222e9 = this['multiplierButton']['length'] - 0x1; 0x0 <= _0x1222e9; _0x1222e9--) this['multiplierButton'][_0x1222e9]['kill'](), this['multiplierButton']['pop']();
                this['closeButton']['kill'](), this['closeButton'] = null;
            }
            this['upgradeButton']['setActive'](_0x1dc99e);
        },
        'onCloseClicked': function() {
            ig['game']['gameController']['setUpgradeMode'](!0x1);
        },
        'changeMultiplier': function(_0x1ddd68) {
            null != this['currentActive'] && this['currentActive']['setActive'](!0x1), this['currentActive'] = _0x1ddd68, this['currentActive']['setActive'](!0x0), this['activeIndex'] = this['currentActive']['index'], this['controller']['changeMultiplier'](this['currentActive']['value']);
        },
        'setButtonsActive': function(_0x418a82) {
            null != this['upgradeButton'] && (this['upgradeButton']['isEnabled'] = _0x418a82);
            for (var _0xd41d5e = 0x0; _0xd41d5e < this['multiplierButton']['length']; _0xd41d5e++) this['multiplierButton'][_0xd41d5e]['isEnabled'] = _0x418a82;
            null != this['closeButton'] && (this['closeButton']['isEnabled'] = _0x418a82);
        },
        'draw': function() {
            this['parent']();
            var _0x3e4b43 = ig['system']['context'];
            ig['game']['gameController']['upgradeMode'] && (this['frame']['draw']((ig['responsive']['width'] - this['frame']['width']) / 0x2, 0x32), _0x3e4b43['font'] = '45px\x20luckiest-guy', _0x3e4b43['fillStyle'] = '#000', _0x3e4b43['textAlign'] = 'center', _0x3e4b43['textBaseline'] = 'middle', _0x3e4b43['lineWidth'] = 0x5, _0x3e4b43['strokeStyle'] = '#000', _0x3e4b43['lineCap'] = 'round', _0x3e4b43['lineJoin'] = 'round', _0x3e4b43['fillText'](_STRINGS['Game']['UpgradeMode'], ig['responsive']['width'] / 0x2, 0x32 + this['frame']['height'] / 0x2));
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-shop')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonShop = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-shop.png', 0x5e, 0x5f),
        'notifArrow': new ig['Image']('media/graphics/sprites/arrow-upgrade.png'),
        'size': {
            'x': 0x5e,
            'y': 0x5f
        },
        'gAlpha': 0x0,
        'isEnabled': !0x0,
        'showNotif': !0x1,
        'tutorialLocked': !0x1,
        'init': function(_0x484f26, _0xdce685, _0x50106c) {
            this['parent'](_0x484f26, _0xdce685, _0x50106c), this['setAnchoredPosition'](_0x484f26 - this['size']['x'] / 0x2, _0xdce685 - this['size']['y'], 'left-bottom'), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], null != _0x50106c['onClicked'] && (this['onClickCallback'] = _0x50106c['onClicked']), this['targetPos'] = -0xa, this['yPos'] = 0x0, this['checkTutorialLocked']();
        },
        'checkTutorialLocked': function() {
            0x5 >= ig['game']['sessionData']['tutorialProgress'] && (this['tutorialLocked'] = !0x0), this['showLocked']();
        },
        'showLocked': function() {
            this['currentAnim']['alpha'] = this['tutorialLocked'] ? 0x0 : 0x1;
        },
        'clicked': function() {
            this['isEnabled'] && !this['tutorialLocked'] && (this['pressed'] = !0x0, null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || (ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.1, {})['start']()));
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && !this['tutorialLocked'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    if (null != this['onClickCallback']) this['onClickCallback']();
                    ig['game']['gameController']['tutorial']['checkTutorialState']();
                }['bind'](this)
            })['start']());
        },
        'draw': function() {
            this['parent'](), this['showNotif'] && (this['yPos'] = this['lerp'](this['yPos'], this['targetPos'], 0.1), this['notifArrow']['draw'](this['pos']['x'] + this['size']['x'] - this['notifArrow']['width'] / 0x2, this['pos']['y'] - 0x14 + this['yPos']), 0x1 >= Math['abs'](this['yPos'] - this['targetPos']) && (this['targetPos'] = 0x0 == this['targetPos'] ? -0xa : 0x0));
        },
        'lerp': function(_0x963d75, _0x1b5cdf, _0x1227a2) {
            return (0x1 - _0x1227a2) * _0x963d75 + _0x1227a2 * _0x1b5cdf;
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.shop-item')['requires']('impact.entity', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-buy')['defines'](function() {
    EntityShopItem = EntityPopupController['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/shop-panel.png'),
        'frameIcon': new ig['Image']('media/graphics/sprites/shop-icon-bg.png'),
        'icons': [new ig['Image']('media/graphics/sprites/crops/icon-potato.png'), new ig['Image']('media/graphics/sprites/crops/icon-carrot.png'), new ig['Image']('media/graphics/sprites/crops/icon-wheat.png'), new ig['Image']('media/graphics/sprites/crops/icon-tomato.png'), new ig['Image']('media/graphics/sprites/crops/icon-cucumber.png'), new ig['Image']('media/graphics/sprites/crops/icon-pepper.png'), new ig['Image']('media/graphics/sprites/crops/icon-turnip.png'), new ig['Image']('media/graphics/sprites/crops/icon-onion.png'), new ig['Image']('media/graphics/sprites/crops/icon-corn.png')],
        'size': {
            'x': 0x13c,
            'y': 0x92
        },
        'data': null,
        'index': 0x0,
        'alpha': 0x1,
        'init': function(_0x564579, _0x46fb5d, _0xac783f) {
            this['parent'](_0x564579, _0x46fb5d, _0xac783f), this['setAnchoredPosition'](_0x564579 - this['size']['x'] / 0x2, _0x46fb5d - this['size']['y'] / 0x2, 'middle-center'), this['buyButton'] = this['spawnEntity'](EntityButtonBuy, 0x37, 0x19, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onBuyUpgrade']();
                }['bind'](this),
                'controller': this
            }), this['upgradeTitle'] = _STRINGS['Game']['Crops'][this['data']['BusinessIndex']], this['upgradeDesc'] = _STRINGS['Game'][this['data']['ProfitType'] + 'Desc']['replace']('{x}', this['data']['ProfitValue']), this['price'] = ig['game']['utility']['getPriceFromExp'](this['data']['Cost'], this['data']['CostExp']), this['buyButton']['textPrice'] = '$' + ig['game']['utility']['getInString'](this['price'], 0x2), ig['game']['sortEntitiesDeferred']();
        },
        'hide': function(_0x4dab94) {
            this['buyButton']['kill'](), this['tween']({
                'alpha': 0x0
            }, 0.3, {
                'onComplete': function() {
                    _0x4dab94 && _0x4dab94(), this['kill']();
                }['bind'](this)
            })['start']();
        },
        'show': function() {
            this['alpha'] = 0x0, this['buyButton']['isEnabled'] = !0x1, this['tween']({
                'alpha': 0x1
            }, 0.3, {
                'onComplete': function() {
                    this['buyButton']['isEnabled'] = !0x0;
                }['bind'](this)
            })['start']();
        },
        'draw': function() {
            this['parent'](), ig['system']['context']['globalAlpha'] = this['alpha'];
            var _0x17ab74 = ig['responsive']['toAnchor'](0x0, 0x0, 'middle-center'),
                _0x18be35 = ig['system']['context'];
            this['panelImage']['draw'](_0x17ab74['x'] + this['anchoredPositionX'], _0x17ab74['y'] + this['anchoredPositionY']), this['frameIcon']['draw'](this['pos']['x'] + 0xf, this['pos']['y'] + 0xf), this['icons'][this['data']['BusinessIndex']]['draw'](this['pos']['x'] + 0xf + (this['frameIcon']['width'] - this['icons'][this['data']['BusinessIndex']]['width']) / 0x2, this['pos']['y'] + 0xf + (this['frameIcon']['height'] - this['icons'][this['data']['BusinessIndex']]['height']) / 0x2), _0x18be35['font'] = '16px\x20luckiest-guy', _0x18be35['fillStyle'] = '#2f4c86', _0x18be35['textAlign'] = 'left', _0x18be35['textBaseline'] = 'top', _0x18be35['fillText'](this['upgradeDesc'], this['pos']['x'] + 0x96, this['pos']['y'] + 0xf), _0x18be35['font'] = '30px\x20luckiest-guy', _0x18be35['fillStyle'] = '#000', _0x18be35['fillText'](this['upgradeTitle'], this['pos']['x'] + 0x96, this['pos']['y'] + 0x23), ig['system']['context']['globalAlpha'] = 0x1;
        },
        'onBuyUpgrade': function() {
            this['controller']['onBuyUpgrade'](this['index']);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-next')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonNext = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-next.png', 0x4c, 0x4c),
        'size': {
            'x': 0x4c,
            'y': 0x4c
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'hidden': !0x1,
        'init': function(_0x137f79, _0x2573bb, _0x56f7c1) {
            this['parent'](_0x137f79, _0x2573bb, _0x56f7c1), this['setAnchoredPosition'](_0x137f79 - this['size']['x'] / 0x2, _0x2573bb - this['size']['y'] / 0x2, 'center-middle'), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], null != _0x56f7c1['onClicked'] && (this['onClickCallback'] = _0x56f7c1['onClicked']);
        },
        'hide': function() {
            this['currentAnim']['alpha'] = 0x0, this['hidden'] = !0x0;
        },
        'show': function() {
            this['currentAnim']['alpha'] = 0x1, this['hidden'] = !0x1;
        },
        'clicked': function() {
            this['isEnabled'] && !this['hidden'] && (this['pressed'] = !0x0, null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || (ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.2, {})['start']()));
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && !this['hidden'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    if (null != this['onClickCallback']) this['onClickCallback']();
                }['bind'](this)
            })['start']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-prev')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonPrev = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/btn-back.png', 0x4c, 0x4c),
        'size': {
            'x': 0x4c,
            'y': 0x4c
        },
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'hidden': !0x1,
        'init': function(_0x4d529e, _0x3c7aa3, _0x471a4c) {
            this['parent'](_0x4d529e, _0x3c7aa3, _0x471a4c), this['setAnchoredPosition'](_0x4d529e - this['size']['x'] / 0x2, _0x3c7aa3 - this['size']['y'] / 0x2, 'center-middle'), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], null != _0x471a4c['onClicked'] && (this['onClickCallback'] = _0x471a4c['onClicked']);
        },
        'hide': function() {
            this['currentAnim']['alpha'] = 0x0, this['hidden'] = !0x0;
        },
        'show': function() {
            this['currentAnim']['alpha'] = 0x1, this['hidden'] = !0x1;
        },
        'clicked': function() {
            this['isEnabled'] && !this['hidden'] && (this['pressed'] = !0x0, null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || (ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.2, {})['start']()));
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && !this['hidden'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.2, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    if (null != this['onClickCallback']) this['onClickCallback']();
                }['bind'](this)
            })['start']());
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.shop-controller')['requires']('impact.entity', 'plugins.io.storage-manager', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-close', 'game.entities.gameplay.shop-item', 'game.entities.buttons.button-next', 'game.entities.buttons.button-prev')['defines'](function() {
    EntityShopController = EntityPopupController['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/popup.png'),
        'size': {
            'x': 0x210,
            'y': 0x258
        },
        'onCloseCallback': null,
        'currentPage': 0x1,
        'totalPage': 0x3,
        'initPos': {
            'x': 0x0,
            'y': 0x0
        },
        'listItems': [],
        'upgradeDatas': [],
        'init': function(_0x2bae55, _0x223cf3, _0x56d327) {
            this['parent'](_0x2bae55, _0x223cf3, _0x56d327), null != _0x56d327['onClose'] && (this['onCloseCallback'] = _0x56d327['onClose']), this['setAnchoredPosition'](_0x2bae55 - this['size']['x'] / 0x2, _0x223cf3 - this['size']['y'] / 0x2, 'middle-center'), this['initPos'] = new Vector2(this['pos']['x'], this['pos']['y']), this['closeBtn'] = this['spawnEntity'](EntityButtonClose, this['anchoredPositionX'] + this['size']['x'] - 0x14, this['anchoredPositionY'] + 0x14, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onCloseClicked']();
                }['bind'](this)
            }), ig['game']['sortEntitiesDeferred'](), this['filterUpgradeData'](), this['renderButtons']();
        },
        'filterUpgradeData': function() {
            this['upgradeDatas'] = [], this['upgradeDatas'] = ig['game']['gameController']['upgradeList'], this['totalPage'] = Math['ceil'](this['upgradeDatas']['length'] / 0x3);
        },
        'createItems': function() {
            for (; 0x0 < this['listItems']['length'];) {
                var _0x31c1e9 = this['listItems']['pop']();
                _0x31c1e9['kill']();
            }
            var _0x43fbc0 = 0x3 * (this['currentPage'] - 0x1),
                _0xcfe71a = this['upgradeDatas']['length'] - _0x43fbc0;
            0x3 < _0xcfe71a && (_0xcfe71a = 0x3);
            for (var _0x2d7622 = 0x0; _0x2d7622 < _0xcfe71a; _0x2d7622++) _0x31c1e9 = this['upgradeDatas'][_0x43fbc0 + _0x2d7622], _0x31c1e9 = ig['game']['spawnEntity'](EntityShopItem, 0x0, -0x8c + 0xa0 * _0x2d7622, {
                'index': _0x2d7622,
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onBuyUpgrade']();
                }['bind'](this),
                'data': _0x31c1e9,
                'controller': this
            }), this['listItems']['push'](_0x31c1e9);
        },
        'onBuyUpgrade': function(_0x347dbc) {
            ig['game']['sessionData']['playerMoney'] >= this['listItems'][_0x347dbc]['price'] && (ig['game']['gameController']['buyUpgrade'](this['listItems'][_0x347dbc]['data']), ig['game']['gameController']['getUpgradeList'](), ig['game']['gameController']['addMoney'](-this['listItems'][_0x347dbc]['price']), this['filterUpgradeData'](), this['renderButtons']());
        },
        'getData': function() {
            this['listItems'][index]['hide'](function() {
                var _0x5a8822 = ig['game']['sessionData']['Farms'][index]['upgradeLevel'];
                _0x5a8822 < ig['upgradedb'][index]['length'] && (_0x5a8822 = ig['upgradedb'][index][_0x5a8822], _0x5a8822 = ig['game']['spawnEntity'](EntityShopItem, 0x0, -0x8c + 0xa0 * index, {
                    'index': index,
                    'zIndex': this['zIndex'] + 0x1,
                    'onClicked': function() {
                        this['onBuyUpgrade']();
                    }['bind'](this),
                    'data': _0x5a8822,
                    'controller': this
                }), this['listItems'][index] = _0x5a8822);
            }['bind'](this));
        },
        'renderButtons': function() {
            null == this['prevButton'] && (this['prevButton'] = this['spawnEntity'](EntityButtonPrev, 0x0 - this['size']['x'] / 0x2, 0x0, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['toPrevPage']();
                }['bind'](this)
            })), null == this['nextButton'] && (this['nextButton'] = this['spawnEntity'](EntityButtonNext, this['size']['x'] / 0x2, 0x0, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['toNextPage']();
                }['bind'](this)
            })), 0x1 >= this['currentPage'] ? this['prevButton']['hide']() : this['prevButton']['show'](), this['currentPage'] >= this['totalPage'] ? this['nextButton']['hide']() : this['nextButton']['show'](), this['createItems']();
        },
        'toNextPage': function() {
            this['currentPage'] < this['totalPage'] && (this['currentPage'] += 0x1), this['renderButtons']();
        },
        'toPrevPage': function() {
            0x1 < this['currentPage'] && (this['currentPage'] -= 0x1), this['renderButtons']();
        },
        'draw': function() {
            this['parent']();
            var _0x4a12f8 = ig['responsive']['toAnchor'](0x0, 0x0, 'middle-center'),
                _0x121b1d = ig['system']['context'];
            _0x121b1d['globalAlpha'] = 0.5, _0x121b1d['fillStyle'] = '#000', _0x121b1d['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), _0x121b1d['globalAlpha'] = 0x1, this['panelImage']['draw'](_0x4a12f8['x'] + this['anchoredPositionX'], _0x4a12f8['y'] + this['anchoredPositionY']), _0x121b1d['font'] = '45px\x20luckiest-guy', _0x121b1d['fillStyle'] = '#fff', _0x121b1d['textAlign'] = 'center', _0x121b1d['textBaseline'] = 'top', _0x121b1d['fillText'](_STRINGS['Game']['ShopTitle'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x14), _0x121b1d['font'] = '20px\x20luckiest-guy', _0x121b1d['fillStyle'] = '#2f4c86', _0x121b1d['fillText'](this['currentPage'] + '\x20/\x20' + this['totalPage'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] - 0x28);
        },
        'onCloseClicked': function() {
            if (null != this['onCloseCallback']) this['onCloseCallback']();
        },
        'kill': function() {
            for (this['parent'](); 0x0 < this['listItems']['length'];) this['listItems']['pop']()['kill']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.others.raylight')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityRaylight = ig['Entity']['extend']({
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'size': {
            'x': 0x200,
            'y': 0x200
        },
        'scale': {
            'x': 0x2,
            'y': 0x2
        },
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/raylight.png', 0x200, 0x200),
        'init': function(_0x2d9ae9, _0x102ed4, _0x87fbd8) {
            this['parent'](_0x2d9ae9, _0x102ed4, _0x87fbd8), this['setScale'](this['scale']['x'], this['scale']['y']), this['setAnchoredPosition'](_0x2d9ae9 - this['size']['x'] / this['scale']['x'] / 0x2, _0x102ed4 - this['size']['y'] / this['scale']['y'] / 0x2, 'center-middle'), this['addAnim']('idle', 0x1, [0x0]), ig['game']['sortEntitiesDeferred']();
        },
        'update': function() {
            this['parent'](), this['currentAnim']['angle'] += 0.01;
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.sun')['requires']('game.entities.buttons.button', 'game.entities.others.raylight')['defines'](function() {
    EntitySun = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'onClickCallback': null,
        'size': {
            'x': 0xb8,
            'y': 0xbc
        },
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/sun.png', 0xb8, 0xbc),
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'scale': {
            'x': 0x1,
            'y': 0x1
        },
        'working': !0x1,
        'alpha': 0x1,
        'detectionRadius': 0x4b,
        'tutorialLocked': !0x1,
        'ray': null,
        'init': function(_0x318f52, _0x53dabd, _0x1b36c7) {
            this['parent'](_0x318f52, _0x53dabd, _0x1b36c7), this['setAnchoredPosition'](_0x318f52 - this['size']['x'] / 0x2, _0x53dabd - this['size']['y'] / 0x2, 'center-middle'), this['addAnim']('idle', 0x1, [0x0]), ig['global']['wm'] || (null != _0x1b36c7['onClicked'] && (this['onClickCallback'] = _0x1b36c7['onClicked']), this['checkTutorialLocked'](), ig['game']['sortEntitiesDeferred'](), this['tweenFloating']());
        },
        'checkTutorialLocked': function() {
            0x8 >= ig['game']['sessionData']['tutorialProgress'] && (this['tutorialLocked'] = !0x0), this['showLocked']();
        },
        'showLocked': function() {
            this['currentAnim']['alpha'] = this['tutorialLocked'] ? 0x0 : 0x1;
        },
        'clicked': function() {},
        'clicking': function() {},
        'released': function() {
            if (!ig['game']['gameController']['upgradeMode'] && this['isEnabled'] && !this['working'] && !this['tutorialLocked'] && this['detectIntersect'](ig['game']['inputPos'], ig['game']['inputPos'])) {
                if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                    if (ig['game']['gameController']['tutorial']['target'] == this) {
                        if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                    } else return;
                }
                if (null != this['onClickCallback']) this['onClickCallback']();
            }
        },
        'animateEffect': function() {
            this['working'] = !0x0, this['floating']['pause'](), this['tween']({
                'scale': {
                    'x': 0x2,
                    'y': 0x2
                }
            }, 0.7, {
                'onUpdate': function() {
                    this['setScale'](this['scale']['x'], this['scale']['y']);
                }['bind'](this),
                'onComplete': function() {
                    this['floating']['resume'](), this['ray'] = ig['game']['spawnEntity'](EntityRaylight, this['anchoredPositionX'] + this['size']['x'] / this['scale']['x'] / 0x2, this['anchoredPositionY'] + this['size']['y'] / this['scale']['y'] / 0x2, {
                        'zIndex': this['zIndex'] - 0x1
                    });
                }['bind'](this),
                'easing': ig['Tween']['Easing']['Back']['EaseOut']
            })['start']();
        },
        'hideEffect': function() {
            this['working'] = !0x1, null != this['ray'] && (this['ray']['kill'](), this['ray'] = null), this['floating']['pause'](), this['tween']({
                'scale': {
                    'x': 0x1,
                    'y': 0x1
                }
            }, 0.7, {
                'onComplete': function() {
                    this['kill']();
                }['bind'](this),
                'onUpdate': function() {
                    this['setScale'](this['scale']['x'], this['scale']['y']);
                }['bind'](this),
                'easing': ig['Tween']['Easing']['Cubic']['EaseIn']
            })['start'](), this['tween']({
                'alpha': 0x0
            }, 0.7, {
                'onUpdate': function() {
                    this['currentAnim']['alpha'] = this['alpha'];
                }['bind'](this),
                'easing': ig['Tween']['Easing']['Cubic']['EaseIn']
            })['start']();
        },
        'tweenFloating': function() {
            this['floating'] = this['tween']({
                'anchoredPositionY': this['anchoredPositionY'] - 0x14
            }, 0.7, {
                'onComplete': function() {
                    this['floating'] = this['tween']({
                        'anchoredPositionY': this['anchoredPositionY'] + 0x14
                    }, 0x1, {
                        'onComplete': function() {
                            this['tweenFloating']();
                        }['bind'](this),
                        'easing': ig['Tween']['Easing']['Cubic']['EaseOut']
                    }), this['floating']['start']();
                }['bind'](this),
                'easing': ig['Tween']['Easing']['Cubic']['EaseIn']
            }), this['floating']['start']();
        },
        'draw': function() {
            this['parent']();
            var _0x2edd91 = ig['system']['context'];
            if (this['working']) {
                _0x2edd91['font'] = '35px\x20luckiest-guy', _0x2edd91['fillStyle'] = '#fff', _0x2edd91['textAlign'] = 'center', _0x2edd91['textBaseline'] = 'middle', _0x2edd91['lineWidth'] = 0x5, _0x2edd91['strokeStyle'] = '#000', _0x2edd91['lineCap'] = 'round', _0x2edd91['lineJoin'] = 'round';
                var _0xeeb68 = ig['game']['utility']['getShortTime'](ig['game']['sessionData']['globalProfitDuration']);
                _0x2edd91['strokeText'](_0xeeb68, this['pos']['x'] + this['size']['x'] / this['scale']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / this['scale']['y'] + 0x1e), _0x2edd91['fillText'](_0xeeb68, this['pos']['x'] + this['size']['x'] / this['scale']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / this['scale']['y'] + 0x1e);
            }
            ig['game']['drawIntersect'] && (_0x2edd91['beginPath'](), _0x2edd91['arc'](this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2, this['detectionRadius'], 0x0, 0x2 * Math['PI']), _0x2edd91['stroke']());
        },
        'detectIntersect': function(_0x4152bf, _0x46a4b9) {
            var _0x262880 = !0x1,
                _0x262880 = new ig['SAT']['Shape']([_0x4152bf, _0x46a4b9]),
                _0x176077 = this['getDetectionShape']();
            return ig['sat']['simpleShapeIntersect'](_0x262880, _0x176077);
        },
        'getDetectionShape': function() {
            var _0x53dccd = new Vector2(this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2);
            return new ig['SAT']['Circle'](_0x53dccd, this['detectionRadius']);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.rain-effect')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityRainEffect = ig['Entity']['extend']({
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'size': {
            'x': 0xe6,
            'y': 0x9e
        },
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/rain.png', 0xe6, 0x9e),
        'init': function(_0x1423d4, _0x309cc0, _0x331858) {
            this['parent'](_0x1423d4, _0x309cc0, _0x331858), this['setAnchoredPosition'](_0x1423d4 - this['size']['x'] / 0x2, _0x309cc0, 'center-middle'), this['addAnim']('idle', 0.2, [0x0, 0x1]), ig['game']['sortEntitiesDeferred']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.cloud')['requires']('game.entities.buttons.button', 'game.entities.gameplay.rain-effect')['defines'](function() {
    EntityCloud = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'onClickCallback': null,
        'size': {
            'x': 0xee,
            'y': 0x8a
        },
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/clouds.png', 0xee, 0x8a),
        'gAlpha': 0x0,
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'rain': null,
        'detectionRadius': 0x50,
        'tutorialLocked': !0x1,
        'init': function(_0x1ff3a6, _0x3f788b, _0x2c7cbc) {
            this['parent'](_0x1ff3a6, _0x3f788b, _0x2c7cbc), this['setAnchoredPosition'](_0x1ff3a6 - this['size']['x'] / 0x2, _0x3f788b - this['size']['y'] / 0x2, 'center-middle'), this['addAnim']('idle', 0x1, [0x0]), ig['global']['wm'] || (null != _0x2c7cbc['onClicked'] && (this['onClickCallback'] = _0x2c7cbc['onClicked']), this['checkTutorialLocked'](), ig['game']['sortEntitiesDeferred'](), this['tweenFloating']());
        },
        'checkTutorialLocked': function() {
            0x7 >= ig['game']['sessionData']['tutorialProgress'] && (this['tutorialLocked'] = !0x0), this['showLocked']();
        },
        'showLocked': function() {
            this['currentAnim']['alpha'] = this['tutorialLocked'] ? 0x0 : 0x1;
        },
        'showRain': function() {
            null == this['rain'] && (this['rain'] = ig['game']['spawnEntity'](EntityRainEffect, this['anchoredPositionX'] + this['size']['x'] / 0x2, this['anchoredPositionY'] + this['size']['y'], {
                'zIndex': this['zIndex']
            }));
        },
        'hideRain': function() {
            null != this['rain'] && (this['rain']['kill'](), this['rain'] = null);
        },
        'clicked': function() {},
        'clicking': function() {},
        'released': function() {
            if (!ig['game']['gameController']['upgradeMode'] && this['isEnabled'] && !this['tutorialLocked'] && this['detectIntersect'](ig['game']['inputPos'], ig['game']['inputPos'])) {
                if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                    if (ig['game']['gameController']['tutorial']['target'] == this) {
                        if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                    } else return;
                }
                if (null != this['onClickCallback']) this['onClickCallback']();
            }
        },
        'tweenFloating': function() {
            this['floating'] = this['tween']({
                'anchoredPositionY': this['anchoredPositionY'] - 0xa
            }, 0x1, {
                'onComplete': function() {
                    this['floating'] = this['tween']({
                        'anchoredPositionY': this['anchoredPositionY'] + 0xa
                    }, 0.8, {
                        'onComplete': function() {
                            this['tweenFloating']();
                        }['bind'](this),
                        'easing': ig['Tween']['Easing']['Cubic']['EaseOut']
                    }), this['floating']['start']();
                }['bind'](this),
                'easing': ig['Tween']['Easing']['Cubic']['EaseIn']
            }), this['floating']['start']();
        },
        'draw': function() {
            this['parent']();
            var _0x3d5cd6 = ig['system']['context'];
            if (0x0 < ig['game']['sessionData']['globalSpeedDuration']) {
                _0x3d5cd6['font'] = '35px\x20luckiest-guy', _0x3d5cd6['fillStyle'] = '#fff', _0x3d5cd6['textAlign'] = 'center', _0x3d5cd6['textBaseline'] = 'middle', _0x3d5cd6['lineWidth'] = 0x5, _0x3d5cd6['strokeStyle'] = '#000', _0x3d5cd6['lineCap'] = 'round', _0x3d5cd6['lineJoin'] = 'round';
                var _0x1e3da1 = ig['game']['utility']['getFullTime'](ig['game']['sessionData']['globalSpeedDuration']);
                _0x3d5cd6['strokeText'](_0x1e3da1, this['pos']['x'] + this['size']['x'] / this['scale']['x'] / 0x2, this['pos']['y'] - 0x1e), _0x3d5cd6['fillText'](_0x1e3da1, this['pos']['x'] + this['size']['x'] / this['scale']['x'] / 0x2, this['pos']['y'] - 0x1e);
            }
            ig['game']['drawIntersect'] && (_0x3d5cd6['beginPath'](), _0x3d5cd6['arc'](this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2, this['detectionRadius'], 0x0, 0x2 * Math['PI']), _0x3d5cd6['stroke']());
        },
        'detectIntersect': function(_0x39f6e1, _0x35ac03) {
            var _0x2c0f0b = !0x1,
                _0x2c0f0b = new ig['SAT']['Shape']([_0x39f6e1, _0x35ac03]),
                _0x4408ff = this['getDetectionShape']();
            return ig['sat']['simpleShapeIntersect'](_0x2c0f0b, _0x4408ff);
        },
        'getDetectionShape': function() {
            var _0x535615 = new Vector2(this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2);
            return new ig['SAT']['Circle'](_0x535615, this['detectionRadius']);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-general')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonGeneral = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/button-on.png', 0x86, 0x3e),
        'size': {
            'x': 0x86,
            'y': 0x3e
        },
        'gAlpha': 0x0,
        'isEnabled': !0x0,
        'text': '',
        'init': function(_0x56fa89, _0x414831, _0x49e4fc) {
            this['parent'](_0x56fa89, _0x414831, _0x49e4fc), this['setAnchoredPosition'](_0x56fa89 - this['size']['x'] / 0x2, _0x414831 - this['size']['y'] / 0x2, 'middle-center'), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], null != _0x49e4fc['onClicked'] && (this['onClickCallback'] = _0x49e4fc['onClicked']);
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || (ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.1, {})['start']()));
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0;
                    if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                        if (ig['game']['gameController']['tutorial']['target'] == this) {
                            if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                        } else return;
                    }
                    if (null != this['onClickCallback']) this['onClickCallback']();
                }['bind'](this)
            })['start']());
        },
        'draw': function() {
            this['parent']();
            var _0x13ce70 = ig['system']['context'];
            _0x13ce70['font'] = '25px\x20luckiest-guy', _0x13ce70['fillStyle'] = '#000', _0x13ce70['textAlign'] = 'center', _0x13ce70['textBaseline'] = 'middle', _0x13ce70['fillText'](this['text'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.sun-popup-controller')['requires']('impact.entity', 'plugins.io.storage-manager', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-close', 'game.entities.buttons.button-general')['defines'](function() {
    EntitySunPopupController = EntityPopupController['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/popup.png'),
        'sunImage': new ig['Image']('media/graphics/sprites/sun.png'),
        'size': {
            'x': 0x210,
            'y': 0x258
        },
        'onCloseCallback': null,
        'onActivateCallback': null,
        'initPos': {
            'x': 0x0,
            'y': 0x0
        },
        'activateButton': null,
        'init': function(_0x26acc4, _0x4d4a91, _0x5dd1cb) {
            this['parent'](_0x26acc4, _0x4d4a91, _0x5dd1cb), null != _0x5dd1cb['onClose'] && (this['onCloseCallback'] = _0x5dd1cb['onClose']), null != _0x5dd1cb['onActivate'] && (this['onActivateCallback'] = _0x5dd1cb['onActivate']), this['setAnchoredPosition'](_0x26acc4 - this['size']['x'] / 0x2, _0x4d4a91 - this['size']['y'] / 0x2, 'middle-center'), this['initPos'] = new Vector2(this['pos']['x'], this['pos']['y']), this['closeBtn'] = this['spawnEntity'](EntityButtonClose, this['anchoredPositionX'] + this['size']['x'] - 0x14, this['anchoredPositionY'] + 0x14, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onCloseClicked']();
                }['bind'](this)
            }), this['activateButton'] = this['spawnEntity'](EntityButtonGeneral, this['anchoredPositionX'] + this['size']['x'] / 0x2, this['anchoredPositionY'] + this['size']['y'] - 0x64, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onActivateClicked']();
                }['bind'](this),
                'text': _STRINGS['Game']['Activate']
            }), ig['game']['sortEntitiesDeferred']();
        },
        'draw': function() {
            this['parent'](), ig['responsive']['toAnchor'](0x0, 0x0, 'middle-center');
            var _0x452dfa = ig['system']['context'];
            _0x452dfa['globalAlpha'] = 0.5, _0x452dfa['fillStyle'] = '#000', _0x452dfa['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), _0x452dfa['globalAlpha'] = 0x1, this['panelImage']['draw'](this['pos']['x'], this['pos']['y']), this['sunImage']['draw'](this['pos']['x'] + (this['size']['x'] - this['sunImage']['width']) / 0x2, this['pos']['y'] + 0xc8), _0x452dfa['font'] = '45px\x20luckiest-guy', _0x452dfa['fillStyle'] = '#fff', _0x452dfa['textAlign'] = 'center', _0x452dfa['textBaseline'] = 'top', _0x452dfa['fillText'](_STRINGS['Game']['SunTitle'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x14), _0x452dfa['font'] = '40px\x20luckiest-guy', _0x452dfa['fillStyle'] = '#2f4c86', _0x452dfa['fillText'](_STRINGS['Game']['SunDesc'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x82), _0x452dfa['font'] = '30px\x20luckiest-guy', _0x452dfa['fillStyle'] = '#2f4c86', _0x452dfa['fillText'](ig['businessdb']['SunDuration'] + '\x20' + _STRINGS['Game']['Seconds'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x19a);
        },
        'onCloseClicked': function() {
            if (null != this['onCloseCallback']) this['onCloseCallback']();
        },
        'onActivateClicked': function() {
            if (null != this['onActivate']) this['onActivate']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.cloud-popup-controller')['requires']('impact.entity', 'plugins.io.storage-manager', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-close', 'game.entities.buttons.button-general')['defines'](function() {
    EntityCloudPopupController = EntityPopupController['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/popup.png'),
        'cloudImage': new ig['Image']('media/graphics/sprites/clouds.png'),
        'size': {
            'x': 0x210,
            'y': 0x258
        },
        'onCloseCallback': null,
        'onActivateCallback': null,
        'initPos': {
            'x': 0x0,
            'y': 0x0
        },
        'activateButton': null,
        'init': function(_0x382fd1, _0x1cf3ea, _0x310c9e) {
            this['parent'](_0x382fd1, _0x1cf3ea, _0x310c9e), null != _0x310c9e['onClose'] && (this['onCloseCallback'] = _0x310c9e['onClose']), null != _0x310c9e['onActivate'] && (this['onActivateCallback'] = _0x310c9e['onActivate']), this['setAnchoredPosition'](_0x382fd1 - this['size']['x'] / 0x2, _0x1cf3ea - this['size']['y'] / 0x2, 'middle-center'), this['initPos'] = new Vector2(this['pos']['x'], this['pos']['y']), this['closeBtn'] = this['spawnEntity'](EntityButtonClose, this['anchoredPositionX'] + this['size']['x'] - 0x14, this['anchoredPositionY'] + 0x14, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onCloseClicked']();
                }['bind'](this)
            }), this['chance'] = ig['businessdb']['CloudLimit'] - ig['game']['sessionData']['globalSpeedChanceUsed'], 0x0 < this['chance'] && (this['activateButton'] = this['spawnEntity'](EntityButtonGeneral, this['anchoredPositionX'] + this['size']['x'] / 0x2, this['anchoredPositionY'] + this['size']['y'] - 0x64, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onActivateClicked']();
                }['bind'](this),
                'text': _STRINGS['Game']['Activate']
            })), ig['game']['sortEntitiesDeferred']();
        },
        'draw': function() {
            this['parent'](), ig['responsive']['toAnchor'](0x0, 0x0, 'middle-center');
            var _0x559d50 = ig['system']['context'];
            _0x559d50['globalAlpha'] = 0.5, _0x559d50['fillStyle'] = '#000', _0x559d50['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), _0x559d50['globalAlpha'] = 0x1, this['panelImage']['draw'](this['pos']['x'], this['pos']['y']), this['cloudImage']['draw'](this['pos']['x'] + (this['size']['x'] - this['cloudImage']['width']) / 0x2, this['pos']['y'] + 0xc8), _0x559d50['font'] = '45px\x20luckiest-guy', _0x559d50['fillStyle'] = '#fff', _0x559d50['textAlign'] = 'center', _0x559d50['textBaseline'] = 'top', _0x559d50['fillText'](_STRINGS['Game']['CloudTitle'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x14), _0x559d50['font'] = '40px\x20luckiest-guy', _0x559d50['fillStyle'] = '#2f4c86', _0x559d50['fillText'](_STRINGS['Game']['CloudDesc'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x82), ig['game']['sessionData']['globalSpeedChanceUsed'] < ig['businessdb']['CloudLimit'] ? (_0x559d50['font'] = '45px\x20luckiest-guy', _0x559d50['fillStyle'] = '#2f4c86', _0x559d50['fillText'](this['chance'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x16d), _0x559d50['font'] = '30px\x20luckiest-guy', _0x559d50['fillText'](_STRINGS['Game']['Chance'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x1a9)) : (_0x559d50['font'] = '45px\x20luckiest-guy', _0x559d50['fillStyle'] = '#2f4c86', _0x559d50['fillText'](ig['game']['utility']['untilNewDay'](), this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x16d), _0x559d50['font'] = '30px\x20luckiest-guy', _0x559d50['fillText'](_STRINGS['Game']['Reset'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x1a9));
        },
        'onCloseClicked': function() {
            if (null != this['onCloseCallback']) this['onCloseCallback']();
        },
        'onActivateClicked': function() {
            if (!(0x0 >= this['chance']) && null != this['onActivate']) this['onActivate']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.daily-item')['requires']('impact.entity', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-buy')['defines'](function() {
    EntityDailyItem = ig['Entity']['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/reward-bg.png'),
        'panelClaimed': new ig['Image']('media/graphics/sprites/reward-bg-claimed.png'),
        'panelToday': new ig['Image']('media/graphics/sprites/reward-bg-today.png'),
        'rewardIcon': new ig['Image']('media/graphics/sprites/reward-icon.png'),
        'claimedIcon': new ig['Image']('media/graphics/sprites/reward-claim.png'),
        'size': {
            'x': 0x6a,
            'y': 0x6a
        },
        'data': null,
        'index': 0x0,
        'claimed': !0x1,
        'init': function(_0x245200, _0x2e25d5, _0xc96d16) {
            this['parent'](_0x245200, _0x2e25d5, _0xc96d16), this['setAnchoredPosition'](_0x245200 - this['size']['x'] / 0x2, _0x2e25d5 - this['size']['y'] / 0x2, 'middle-center'), this['index'] < ig['game']['sessionData']['dailyRewardIndex'] && (this['claimed'] = !0x0), this['panel'] = this['claimed'] ? this['panelClaimed'] : this['index'] == ig['game']['sessionData']['dailyRewardIndex'] ? this['panelToday'] : this['panelImage'], ig['game']['sortEntitiesDeferred']();
        },
        'draw': function() {
            this['parent'](), this['panel']['draw'](this['pos']['x'], this['pos']['y']);
            if (this['claimed']) this['claimedIcon']['draw'](this['pos']['x'] + (this['size']['x'] - this['claimedIcon']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['claimedIcon']['height']) / 0x2);
            else {
                this['rewardIcon']['draw'](this['pos']['x'] + (this['size']['x'] - this['rewardIcon']['width']) / 0x2, this['pos']['y'] + (this['size']['y'] - this['rewardIcon']['height']) / 0x2 - 0x14);
                var _0x4371b0 = ig['system']['context'];
                _0x4371b0['font'] = '25px\x20luckiest-guy', _0x4371b0['fillStyle'] = '#fff', _0x4371b0['textAlign'] = 'center', _0x4371b0['textBaseline'] = 'top', _0x4371b0['lineWidth'] = 0x5, _0x4371b0['strokeStyle'] = '#000', _0x4371b0['lineCap'] = 'round', _0x4371b0['lineJoin'] = 'round', _0x4371b0['strokeText'](ig['businessdb']['DailyRewardValue'][this['index']] + '\x20' + _STRINGS['Game']['Hr'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] - 0x23), _0x4371b0['fillText'](ig['businessdb']['DailyRewardValue'][this['index']] + '\x20' + _STRINGS['Game']['Hr'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] - 0x23);
            }
        },
        'onBuyUpgrade': function() {
            this['controller']['onBuyUpgrade'](this['index']);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.daily-login-controller')['requires']('impact.entity', 'plugins.io.storage-manager', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-general', 'game.entities.gameplay.daily-item')['defines'](function() {
    EntityDailyLoginController = EntityPopupController['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/popup.png'),
        'size': {
            'x': 0x210,
            'y': 0x258
        },
        'onClaimCallback': null,
        'initPos': {
            'x': 0x0,
            'y': 0x0
        },
        'listItems': [],
        'init': function(_0x276ad8, _0xda1cba, _0x10e3b6) {
            this['parent'](_0x276ad8, _0xda1cba, _0x10e3b6), null != _0x10e3b6['onClaim'] && (this['onClaimCallback'] = _0x10e3b6['onClaim']), this['setAnchoredPosition'](_0x276ad8 - this['size']['x'] / 0x2, _0xda1cba - this['size']['y'] / 0x2, 'middle-center'), this['initPos'] = new Vector2(this['pos']['x'], this['pos']['y']), this['claimBtn'] = this['spawnEntity'](EntityButtonGeneral, this['anchoredPositionX'] + this['size']['x'] / 0x2, this['anchoredPositionY'] + this['size']['y'] - 0x64, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onClaimPrize']();
                }['bind'](this),
                'text': _STRINGS['Game']['Claim']
            }), this['createItems'](), ig['game']['sortEntitiesDeferred']();
        },
        'onClaimPrize': function() {
            if (null != this['onClaimCallback']) this['onClaimCallback']();
        },
        'createItems': function() {
            for (; 0x0 < this['listItems']['length'];) {
                var _0x44cb06 = this['listItems']['pop']();
                _0x44cb06['kill']();
            }
            startY = -0x96, startX = -0x78;
            for (var _0x5ad135 = 0x0; 0x7 > _0x5ad135; _0x5ad135++) _0x44cb06 = 0x6 == _0x5ad135 ? ig['game']['spawnEntity'](EntityDailyItem, startX + 0x78 * (_0x5ad135 % 0x3 + 0x1), startY + 0x78 * Math['floor'](_0x5ad135 / 0x3), {
                'index': _0x5ad135,
                'zIndex': this['zIndex'] + 0x1
            }) : ig['game']['spawnEntity'](EntityDailyItem, startX + 0x78 * (_0x5ad135 % 0x3), startY + 0x78 * Math['floor'](_0x5ad135 / 0x3), {
                'index': _0x5ad135,
                'zIndex': this['zIndex'] + 0x1
            }), this['listItems']['push'](_0x44cb06);
        },
        'draw': function() {
            this['parent']();
            var _0x48bea5 = ig['responsive']['toAnchor'](0x0, 0x0, 'middle-center'),
                _0x295a04 = ig['system']['context'];
            _0x295a04['globalAlpha'] = 0.5, _0x295a04['fillStyle'] = '#000', _0x295a04['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), _0x295a04['globalAlpha'] = 0x1, this['panelImage']['draw'](_0x48bea5['x'] + this['anchoredPositionX'], _0x48bea5['y'] + this['anchoredPositionY']), _0x295a04['font'] = '45px\x20luckiest-guy', _0x295a04['fillStyle'] = '#fff', _0x295a04['textAlign'] = 'center', _0x295a04['textBaseline'] = 'top', _0x295a04['fillText'](_STRINGS['Game']['Daily'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x14);
        },
        'kill': function() {
            for (this['parent'](); 0x0 < this['listItems']['length'];) this['listItems']['pop']()['kill']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.reward-claim-controller')['requires']('impact.entity', 'plugins.io.storage-manager', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-general', 'game.entities.others.particle-effect')['defines'](function() {
    EntityRewardClaimController = EntityPopupController['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/popup.png'),
        'frameIcon': new ig['Image']('media/graphics/sprites/reward-bg-today.png'),
        'rewardIcon': new ig['Image']('media/graphics/sprites/reward-icon.png'),
        'cashIcon': new ig['Image']('media/graphics/sprites/cash-icon.png'),
        'coin': new ig['Image']('media/graphics/sprites/coin.png'),
        'size': {
            'x': 0x210,
            'y': 0x258
        },
        'onClaimCallback': null,
        'initPos': {
            'x': 0x0,
            'y': 0x0
        },
        'moneyGain': 0x0,
        'moneyGainText': null,
        'init': function(_0x2abbf0, _0x5dc006, _0x3f2924) {
            this['parent'](_0x2abbf0, _0x5dc006, _0x3f2924), null != _0x3f2924['onClaim'] && (this['onClaimCallback'] = _0x3f2924['onClaim']), this['setAnchoredPosition'](_0x2abbf0 - this['size']['x'] / 0x2, _0x5dc006 - this['size']['y'] / 0x2, 'middle-center'), this['initPos'] = new Vector2(this['pos']['x'], this['pos']['y']), this['claimBtn'] = this['spawnEntity'](EntityButtonGeneral, this['anchoredPositionX'] + this['size']['x'] / 0x2, this['anchoredPositionY'] + this['size']['y'] - 0x64, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onOkayClicked']();
                }['bind'](this),
                'text': _STRINGS['Game']['Okay']
            }), this['moneyGainText'] = ig['game']['utility']['getInString'](this['moneyGain'], 0x2), ig['game']['sortEntitiesDeferred']();
        },
        'onOkayClicked': function() {
            if (null != this['onClaimCallback']) this['onClaimCallback']();
            this['createCoinParticle']();
        },
        'draw': function() {
            this['parent']();
            var _0x1b410d = ig['responsive']['toAnchor'](0x0, 0x0, 'middle-center'),
                _0x431bd0 = ig['system']['context'];
            _0x431bd0['globalAlpha'] = 0.5, _0x431bd0['fillStyle'] = '#000', _0x431bd0['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), _0x431bd0['globalAlpha'] = 0x1, this['panelImage']['draw'](this['pos']['x'], this['pos']['y']), ig['responsive']['drawScaledImage'](this['frameIcon'], _0x1b410d['x'], _0x1b410d['y'] - 0x32, 0x2, 0x2, 0.5, 0.5), ig['responsive']['drawScaledImage'](this['rewardIcon'], _0x1b410d['x'], _0x1b410d['y'] - 0x32, 0x2, 0x2, 0.5, 0.5), _0x431bd0['font'] = '45px\x20luckiest-guy', _0x431bd0['fillStyle'] = '#fff', _0x431bd0['textAlign'] = 'center', _0x431bd0['textBaseline'] = 'top', _0x431bd0['fillText'](_STRINGS['Game']['Daily'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x14), _0x431bd0['font'] = '35px\x20luckiest-guy', _0x431bd0['fillStyle'] = '#2f4c86', _0x431bd0['fillText']('$\x20' + this['moneyGainText'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] - 0xdc);
        },
        'createCoinParticle': function() {
            var _0x2b28c9 = {
                'minAngle': -0xb4,
                'maxAngle': 0x0,
                'minSpeed': 0x12c,
                'maxSpeed': 0x190,
                'minLifeTime': 0.5,
                'maxLifeTime': 0x1,
                'duration': 0x0,
                'minCount': 0xa,
                'maxCount': 0x3c,
                'emission': 0x3c,
                'minRadius': 0x5,
                'maxRadius': 0x8,
                'gravity': 0x1
            };
            _0x2b28c9['colors'] = [this['coin']], _0x2b28c9['zIndex'] = this['zIndex'] + 0x1, _0x2b28c9['scale'] = 0.75, _0x2b28c9['hasTarget'] = !0x0, _0x2b28c9['target'] = new Vector2(0x14, 0x14), this['particleEffect'] = ig['game']['spawnEntity'](EntityParticleEffect, 0x0, 0x0, _0x2b28c9), this['particleEffect']['pos']['x'] = this['pos']['x'] + this['size']['x'] / 0x2, this['particleEffect']['pos']['y'] = this['pos']['y'] + this['size']['y'] / 0x2 + 0xa;
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.gameplay.harvest-truck')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityHarvestTruck = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'onClickCallback': null,
        'size': {
            'x': 0x1c8,
            'y': 0x184
        },
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/harvest-truck.png', 0x1c8, 0x184),
        'targetAlpha': 0x1,
        'isEnabled': !0x0,
        'targetPos': {
            'x': 0x0,
            'y': 0x0
        },
        'animate': !0x1,
        'detectionRadius': 0x96,
        'init': function(_0x400530, _0x464eb6, _0x1f1116) {
            this['parent'](_0x400530, _0x464eb6, _0x1f1116), this['setAnchoredPosition'](_0x400530 - this['size']['x'] / 0x2, _0x464eb6 - this['size']['y'] / 0x2, 'center-middle'), this['targetPos'] = new Vector2(this['anchoredPositionX'], this['anchoredPositionY']), this['addAnim']('idle', 0x1, [0x0]), ig['global']['wm'] || (null != _0x1f1116['onClicked'] && (this['onClickCallback'] = _0x1f1116['onClicked']), ig['game']['sortEntitiesDeferred']());
        },
        'clicked': function() {},
        'clicking': function() {},
        'released': function() {
            if (this['isEnabled'] && !this['animate'] && this['detectIntersect'](ig['game']['inputPos'], ig['game']['inputPos'])) {
                if (null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active']) {
                    if (ig['game']['gameController']['tutorial']['target'] == this) {
                        if (null != this['onTutorialCallback']) this['onTutorialCallback']();
                    } else return;
                }
                if (null != this['onClickCallback']) this['onClickCallback']();
            }
        },
        'appearAnimation': function() {
            var _0x46ac19 = -0x2bc * Math['cos'](-0x1e * Math['PI'] / 0xb4) + this['anchoredPositionX'],
                _0xf153aa = -0x2bc * Math['sin'](-0x1e * Math['PI'] / 0xb4) + this['anchoredPositionY'];
            this['anchoredPositionX'] = _0x46ac19, this['anchoredPositionY'] = _0xf153aa, this['animate'] = !0x0, ig['soundHandler']['sfxPlayer']['play']('truck'), this['tween']({
                'anchoredPositionX': this['targetPos']['x'],
                'anchoredPositionY': this['targetPos']['y']
            }, 1.5, {
                'onComplete': function() {
                    this['animate'] = !0x1;
                }['bind'](this),
                'easing': ig['Tween']['Easing']['Back']['EaseOut']
            })['start']();
        },
        'hideEffect': function() {
            var _0x14f82d = 0x320 * Math['cos'](-0x1e * Math['PI'] / 0xb4) + this['anchoredPositionX'],
                _0x4ead24 = 0x320 * Math['sin'](-0x1e * Math['PI'] / 0xb4) + this['anchoredPositionY'];
            this['animate'] = !0x0, this['tween']({
                'anchoredPositionX': _0x14f82d,
                'anchoredPositionY': _0x4ead24
            }, 1.5, {
                'onComplete': function() {
                    this['animate'] = !0x1, ig['game']['gameController']['softResetProgress']();
                }['bind'](this),
                'easing': ig['Tween']['Easing']['Back']['EaseOut']
            })['start']();
        },
        'tweenFloating': function() {
            this['floating'] = this['tween']({
                'anchoredPositionY': this['anchoredPositionY'] - 0x14
            }, 0.7, {
                'onComplete': function() {
                    this['floating'] = this['tween']({
                        'anchoredPositionY': this['anchoredPositionY'] + 0x14
                    }, 0x1, {
                        'onComplete': function() {
                            this['tweenFloating']();
                        }['bind'](this),
                        'easing': ig['Tween']['Easing']['Cubic']['EaseOut']
                    }), this['floating']['start']();
                }['bind'](this),
                'easing': ig['Tween']['Easing']['Cubic']['EaseIn']
            }), this['floating']['start']();
        },
        'draw': function() {
            this['parent']();
            var _0x1ae5a4 = ig['system']['context'];
            ig['game']['drawIntersect'] && (_0x1ae5a4['beginPath'](), _0x1ae5a4['arc'](this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2, this['detectionRadius'], 0x0, 0x2 * Math['PI']), _0x1ae5a4['stroke']());
        },
        'detectIntersect': function(_0x33bdea, _0x48941a) {
            var _0x5f3362 = !0x1,
                _0x5f3362 = new ig['SAT']['Shape']([_0x33bdea, _0x48941a]),
                _0x580638 = this['getDetectionShape']();
            return ig['sat']['simpleShapeIntersect'](_0x5f3362, _0x580638);
        },
        'getDetectionShape': function() {
            var _0xb77bfd = new Vector2(this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + this['size']['y'] / 0x2);
            return new ig['SAT']['Circle'](_0xb77bfd, this['detectionRadius']);
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.harvest-popup-controller')['requires']('impact.entity', 'plugins.io.storage-manager', 'game.entities.controllers.popup-controller', 'game.entities.buttons.button-close', 'game.entities.buttons.button-general')['defines'](function() {
    EntityHarvestPopupController = EntityPopupController['extend']({
        'panelImage': new ig['Image']('media/graphics/sprites/popup.png'),
        'infoBg': new ig['Image']('media/graphics/sprites/popup-panel.png'),
        'harvestChar': new ig['Image']('media/graphics/sprites/harvest-char.png'),
        'size': {
            'x': 0x210,
            'y': 0x258
        },
        'onCloseCallback': null,
        'onActivateCallback': null,
        'initPos': {
            'x': 0x0,
            'y': 0x0
        },
        'activateButton': null,
        'seedBenefitText': null,
        'init': function(_0x9292b1, _0x120e0c, _0x5745d0) {
            this['parent'](_0x9292b1, _0x120e0c, _0x5745d0), null != _0x5745d0['onClose'] && (this['onCloseCallback'] = _0x5745d0['onClose']), null != _0x5745d0['onActivate'] && (this['onActivateCallback'] = _0x5745d0['onActivate']), this['setAnchoredPosition'](_0x9292b1 - this['size']['x'] / 0x2, _0x120e0c - this['size']['y'] / 0x2, 'middle-center'), this['initPos'] = new Vector2(this['pos']['x'], this['pos']['y']), this['currentSeedText'] = ig['game']['utility']['getInString'](ig['game']['sessionData']['seedCount'], 0x2), this['seedGainText'] = ig['game']['utility']['getInString'](this['seeds'], 0x2), this['seedBenefitText'] = ig['game']['utility']['getInString'](ig['game']['gameController']['seedBenefit'], 0x2), this['profitGetText'] = ig['game']['utility']['getInString'](this['seeds'] * ig['businessdb']['SeedProfit'], 0x2), this['closeBtn'] = this['spawnEntity'](EntityButtonClose, this['anchoredPositionX'] + this['size']['x'] - 0x14, this['anchoredPositionY'] + 0x14, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onCloseClicked']();
                }['bind'](this)
            }), this['activateButton'] = this['spawnEntity'](EntityButtonGeneral, this['anchoredPositionX'] + this['size']['x'] / 0x2, this['anchoredPositionY'] + this['size']['y'] - 0x4b, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['onActivateClicked']();
                }['bind'](this),
                'text': _STRINGS['Game']['Harvest']
            }), ig['game']['sortEntitiesDeferred']();
        },
        'draw': function() {
            this['parent']();
            var _0x34a11f = ig['responsive']['toAnchor'](0x0, 0x0, 'middle-center'),
                _0xc90bd7 = ig['system']['context'];
            _0xc90bd7['globalAlpha'] = 0.5, _0xc90bd7['fillStyle'] = '#000', _0xc90bd7['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), _0xc90bd7['globalAlpha'] = 0x1, this['panelImage']['draw'](this['pos']['x'], this['pos']['y']), this['infoBg']['draw'](this['pos']['x'] + (this['size']['x'] - this['infoBg']['width']) / 0x2, _0x34a11f['y'] + this['anchoredPositionY'] + (this['size']['y'] - this['infoBg']['height']) / 0x2), this['harvestChar']['draw'](this['pos']['x'] + (this['size']['x'] - this['harvestChar']['width']) / 0x2, _0x34a11f['y'] + this['anchoredPositionY'] + (this['size']['y'] - this['harvestChar']['height']) / 0x2 - 0x3c), _0xc90bd7['font'] = '45px\x20luckiest-guy', _0xc90bd7['fillStyle'] = '#fff', _0xc90bd7['textAlign'] = 'center', _0xc90bd7['textBaseline'] = 'top', _0xc90bd7['fillText'](_STRINGS['Game']['HarvestTitle'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x14), _0xc90bd7['font'] = '23px\x20luckiest-guy', _0xc90bd7['fillStyle'] = '#2f4c86', _0xc90bd7['fillText'](_STRINGS['Game']['HarvestDesc'][0x0], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x50), _0xc90bd7['fillText'](_STRINGS['Game']['HarvestDesc'][0x1], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x69), _0xc90bd7['font'] = '23px\x20luckiest-guy', _0xc90bd7['fillStyle'] = '#000', _0xc90bd7['fillText'](_STRINGS['Game']['CurrentSeed'] + this['currentSeedText'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x15e), _0xc90bd7['fillText'](_STRINGS['Game']['BonusProfit'] + this['seedBenefitText'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x17c), _0xc90bd7['fillStyle'] = '#2f4c86', _0xc90bd7['fillText'](_STRINGS['Game']['SeedEarned'] + this['seedGainText'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x19a), _0xc90bd7['fillText'](_STRINGS['Game']['ProfitEarned'] + this['profitGetText'], this['pos']['x'] + this['size']['x'] / 0x2, this['pos']['y'] + 0x1b8);
        },
        'onCloseClicked': function() {
            if (null != this['onCloseCallback']) this['onCloseCallback']();
        },
        'onActivateClicked': function() {
            if (null != this['onActivate']) this['onActivate']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.tutorial-controller')['requires']('impact.entity')['defines'](function() {
    EntityTutorialController = ig['Entity']['extend']({
        'hand': new ig['Image']('media/graphics/sprites/tutorial-finger.png'),
        'active': !0x1,
        'target': null,
        'movement': {
            'x': 0x0,
            'y': 0x0
        },
        'idleGuideActive': !0x1,
        'init': function(_0x37b21a, _0x491eb2, _0x11c8e5) {
            this['parent'](_0x37b21a, _0x491eb2, _0x11c8e5), this['targetPos'] = -0xa, this['yPos'] = 0x0, this['textwrapper'] = new ig['Textwrapper'](0x28, 'luckiest-guy', !0x0), ig['game']['sortEntitiesDeferred']();
        },
        'checkTutorialState': function() {
            var _0x1dc22a = ig['game']['sessionData']['tutorialProgress'];
            this['tutorialText'] = _STRINGS['Game']['TutorialDesc'][_0x1dc22a];
            switch (_0x1dc22a) {
                case 0x0:
                    0x0 >= ig['game']['gameController']['listPlot'][0x0]['saveData']['level'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['listPlot'][0x0], this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
                    break;
                case 0x1:
                    0x0 < ig['game']['gameController']['listPlot'][0x0]['saveData']['level'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['listPlot'][0x0]['fillButton'], this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(-0x4b, 0x0), this['targetPos'] = new Vector2(0x4b, 0x0), this['moveHand']());
                    break;
                case 0x2:
                    0xa <= ig['game']['sessionData']['playerMoney'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['upgradeController']['upgradeButton'], this['target']['tutorialLocked'] = !0x1, this['target']['showLocked'](), this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
                    break;
                case 0x3:
                    ig['game']['gameController']['upgradeMode'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['listPlot'][0x0]['upgradeButton']['buttonBuy'], this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
                    break;
                case 0x4:
                    ig['game']['sessionData']['playerMoney'] >= ig['game']['gameController']['listPlot'][0x1]['modelData']['InitialCost'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['listPlot'][0x1], this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
                    break;
                case 0x5:
                    ig['game']['sessionData']['playerMoney'] >= ig['game']['gameController']['upgradeList'][0x0]['Cost'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['shopBtn'], this['target']['tutorialLocked'] = !0x1, this['target']['showLocked'](), this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
                    break;
                case 0x6:
                    null != ig['game']['gameController']['shopPanel'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['shopPanel']['listItems'][0x0]['buyButton'], this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
                    break;
                case 0x7:
                    0x0 < ig['game']['gameController']['listPlot'][0x2]['saveData']['level'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['cloud'], this['target']['tutorialLocked'] = !0x1, this['target']['showLocked'](), this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
                    break;
                case 0x8:
                    0x0 < ig['game']['gameController']['listPlot'][0x3]['saveData']['level'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['sun'], this['target']['tutorialLocked'] = !0x1, this['target']['showLocked'](), this['target']['onTutorialCallback'] = function() {
                        this['onClickTutorialTarget']();
                    }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
            }
        },
        'checkHarvestTutorial': function() {
            ig['game']['sessionData']['harvestTutorial'] || (this['active'] = !0x0, this['target'] = ig['game']['gameController']['harvestTruck'], this['tutorialText'] = _STRINGS['Game']['TutorialHarvest'], this['target']['onTutorialCallback'] = function() {
                this['onClickHarvestTutorial']();
            }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
        },
        'showIdleGuide': function() {
            !this['active'] && !this['idleGuideActive'] && ig['game']['gameController']['buttonActive'] && (this['target'] = ig['game']['gameController']['listPlot'][0x0]['fillButton'], null != this['target'] && (this['currentPos'] = new Vector2(-0x4b, 0x0), this['targetPos'] = new Vector2(0x4b, 0x0), this['idleGuideActive'] = !0x0, this['moveHand']()));
        },
        'hideIdleGuide': function() {
            ig['game']['idleCounter'] = 0x0, this['idleGuideActive'] && null != this['handTween'] && (this['idleGuideActive'] = !0x1, this['handTween']['stop']());
        },
        'checkUnlockTutorial': function() {
            !ig['game']['sessionData']['unlockTutorial'] && ig['game']['gameController']['upgradeMode'] && (this['active'] = !0x0, this['target'] = ig['game']['gameController']['upgradeController']['multiplierButton'][0x2], this['tutorialText'] = _STRINGS['Game']['TutorialUnlock'], this['target']['onTutorialCallback'] = function() {
                this['onClickUnlockTutorial']();
            }['bind'](this), this['currentPos'] = new Vector2(0x0, 0x0), this['targetPos'] = new Vector2(0x0, -0x14), this['moveHand']());
        },
        'onClickUnlockTutorial': function() {
            this['handTween']['stop'](), this['target']['onTutorialCallback'] = null, this['active'] = !0x1, ig['game']['sessionData']['unlockTutorial'] = !0x0;
        },
        'moveHand': function() {
            this['movement'] = new Vector2(this['currentPos']['x'], this['currentPos']['y']), this['handTween'] = this['tween']({
                'movement': {
                    'x': this['targetPos']['x'],
                    'y': this['targetPos']['y']
                }
            }, 0.4, {
                'easing': ig['Tween']['Easing']['Cubic']['EaseInOut'],
                'onComplete': function() {
                    this['handTween'] = this['tween']({
                        'movement': {
                            'x': this['currentPos']['x'],
                            'y': this['currentPos']['y']
                        }
                    }, 0.4, {
                        'easing': ig['Tween']['Easing']['Cubic']['EaseInOut'],
                        'onComplete': function() {
                            this['moveHand']();
                        }['bind'](this)
                    }), this['handTween']['start']();
                }['bind'](this)
            }), this['handTween']['start']();
        },
        'onClickTutorialTarget': function() {
            this['handTween']['stop'](), this['target']['onTutorialCallback'] = null, this['active'] = !0x1, ig['game']['sessionData']['tutorialProgress']++;
        },
        'onClickHarvestTutorial': function() {
            this['handTween']['stop'](), this['target']['onTutorialCallback'] = null, this['active'] = !0x1, ig['game']['sessionData']['harvestTutorial'] = !0x0;
        },
        'draw': function() {
            this['parent']();
            if (this['active'] && null != this['target']) {
                this['hand']['draw'](this['target']['pos']['x'] + this['target']['size']['x'] / 0x2 - this['hand']['width'] / 0x2 + this['movement']['x'], this['target']['pos']['y'] + this['target']['size']['y'] / 0x2 + this['movement']['y']);
                var _0x4de9ea = ig['system']['context'],
                    _0x3e6e6b = ig['responsive']['toAnchor'](0x0, 0x0, 'center-middle'),
                    _0x493553 = this['textwrapper']['wrapText'](this['tutorialText'], 0x384);
                _0x4de9ea['globalAlpha'] = 0.45, _0x4de9ea['fillStyle'] = '#000', _0x4de9ea['fillRect'](_0x3e6e6b['x'] - 0x1c2, _0x3e6e6b['y'] - 0x12c - 0x23, 0x384, 0x46 * _0x493553['length']), _0x4de9ea['globalAlpha'] = 0x1, _0x4de9ea['strokeStyle'] = '#000', _0x4de9ea['fillStyle'] = '#fff', this['textwrapper']['drawTextList'](_0x493553, _0x3e6e6b['x'], _0x3e6e6b['y'] - 0x12c);
            }
            this['idleGuideActive'] && this['hand']['draw'](this['target']['pos']['x'] + this['target']['size']['x'] / 0x2 - this['hand']['width'] / 0x2 + this['movement']['x'], this['target']['pos']['y'] + this['target']['size']['y'] / 0x2 + this['movement']['y']);
        },
        'lerp': function(_0x2b6038, _0x52c9ec, _0x4f330c) {
            return (0x1 - _0x4f330c) * _0x2b6038 + _0x4f330c * _0x52c9ec;
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.buttons.button-info')['requires']('game.entities.buttons.button')['defines'](function() {
    EntityButtonInfo = EntityButton['extend']({
        'type': ig['Entity']['TYPE']['A'],
        'gravityFactor': 0x0,
        'centeredScale': !0x0,
        'animSheet': new ig['AnimationSheet']('media/graphics/sprites/info-btn.png', 0x3a, 0x3e),
        'infoPopup': new ig['Image']('media/graphics/sprites/info-popup.png'),
        'size': {
            'x': 0x3a,
            'y': 0x3e
        },
        'gAlpha': 0x0,
        'isEnabled': !0x0,
        'showNotif': !0x1,
        'notifTimer': 0x0,
        'seedText': null,
        'init': function(_0x278025, _0x1eef7c, _0x4dfda4) {
            this['parent'](_0x278025, _0x1eef7c, _0x4dfda4), this['setAnchoredPosition'](_0x278025 - this['size']['x'] / 0x2, _0x1eef7c - this['size']['y'], 'left-top'), this['addAnim']('idle', 0x1, [0x0]), this['startYPos'] = this['anchoredPositionY'], this['targetPos'] = -0xa, this['yPos'] = 0x0;
        },
        'update': function() {
            this['parent'](), this['showNotif'] && (this['notifTimer'] += ig['system']['tick'], 0x3 <= this['notifTimer'] && (this['notifTimer'] = 0x0, this['showNotif'] = !0x1));
        },
        'clicked': function() {
            this['isEnabled'] && (this['pressed'] = !0x0, null != ig['game']['gameController']['tutorial'] && ig['game']['gameController']['tutorial']['active'] && ig['game']['gameController']['tutorial']['target'] != this || (ig['soundHandler']['sfxPlayer']['play']('button'), this['tween']({
                'anchoredPositionY': this['startYPos'] + 0xa
            }, 0.1, {})['start']()));
        },
        'clicking': function() {},
        'leave': function() {
            this['anchoredPositionY'] != this['startYPos'] && this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {})['start'](), this['pressed'] = !0x1;
        },
        'released': function() {
            this['isEnabled'] && this['pressed'] && (this['pressed'] = this['isEnabled'] = !0x1, this['tween']({
                'anchoredPositionY': this['startYPos']
            }, 0.1, {
                'onComplete': function() {
                    this['isEnabled'] = !0x0, this['onClickedButton']();
                }['bind'](this)
            })['start']());
        },
        'onClickedButton': function() {
            this['showNotif'] = !this['showNotif'], this['seedText'] = ig['game']['utility']['getInString'](ig['game']['gameController']['seedBenefit'], 0x2);
        },
        'draw': function() {
            this['parent']();
            if (this['showNotif']) {
                var _0x3abf82 = ig['system']['context'],
                    _0x1c733f = new Vector2(this['pos']['x'] + this['size']['x'] + 0x5, this['pos']['y'] - (this['infoPopup']['height'] - this['size']['y']) / 0x2 - 0x32);
                this['infoPopup']['draw'](_0x1c733f['x'], _0x1c733f['y']), _0x3abf82['font'] = '25px\x20luckiest-guy', _0x3abf82['fillStyle'] = '#000000', _0x3abf82['textAlign'] = 'center', _0x3abf82['textBaseline'] = 'middle', _0x3abf82['fillText']('Bonus', _0x1c733f['x'] + this['infoPopup']['width'] / 0x2, _0x1c733f['y'] + this['infoPopup']['height'] / 0x2 - 0xf), _0x3abf82['fillText']('+' + this['seedText'] + '%', _0x1c733f['x'] + this['infoPopup']['width'] / 0x2, _0x1c733f['y'] + this['infoPopup']['height'] / 0x2 + 0xf);
            }
        },
        'lerp': function(_0x35e34a, _0x4e2bb4, _0x175868) {
            return (0x1 - _0x175868) * _0x35e34a + _0x175868 * _0x4e2bb4;
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.entities.controllers.game-controller')['requires']('impact.entity', 'game.entities.gameplay.plot', 'game.entities.ui.gameplay-ui', 'game.entities.controllers.upgrade-controller', 'game.entities.buttons.button-setting', 'game.entities.controllers.setting-controller', 'game.entities.buttons.button-shop', 'game.entities.controllers.shop-controller', 'game.entities.gameplay.sun', 'game.entities.gameplay.cloud', 'game.entities.controllers.sun-popup-controller', 'game.entities.controllers.cloud-popup-controller', 'game.entities.controllers.daily-login-controller', 'game.entities.controllers.reward-claim-controller', 'game.entities.gameplay.harvest-truck', 'game.entities.controllers.harvest-popup-controller', 'game.entities.controllers.tutorial-controller', 'game.entities.buttons.button-info')['defines'](function() {
    EntityGameController = ig['Entity']['extend']({
        'bg': new ig['Image']('media/graphics/sprites/bg/bg1.png'),
        'isPaused': !0x1,
        'totalPlot': 0x9,
        'listPlot': [],
        'utility': null,
        'upgradeMode': !0x1,
        'incomePerSecond': 0x0,
        'saveTimer': 0x0,
        'sunPanel': null,
        'cloudPanel': null,
        'dailyPanel': null,
        'claimPanel': null,
        'globalSpeedBoost': 0x1,
        'bonusDuration': 0x0,
        'newDay': !0x1,
        'seedBenefit': 0x0,
        'upgradeList': [],
        'buttonActive': !0x0,
        'infoBtn': null,
        'init': function(_0x45bc4c, _0x29e3a3, _0x725bd9) {
            this['parent'](_0x45bc4c, _0x29e3a3, _0x725bd9), ig['game']['titleController'] = null, ig['game']['gameController'] = this, ig['sat'] = new ig['SAT'](), this['utility'] = ig['game']['spawnEntity'](EntityUtility, 0x0, 0x0, {}), (this['pointer'] = ig['game']['getEntitiesByType'](EntityPointer)[0x0]) || (this['pointer'] = ig['game']['spawnEntity'](EntityPointer, 0x0, 0x0)), this['inputTrail'] = ig['game']['spawnEntity'](EntityGameTrail, 0x0, 0x0), this['inputTrail']['ready'](), this['settingBtn'] = ig['game']['spawnEntity'](EntityButtonSetting, -0x41, 0x41, {
                'zIndex': this['zIndex'] + 0x1,
                'anchor': 'top-right',
                'onClicked': function() {
                    this['showSettingPanel']();
                }['bind'](this)
            }), this['shopBtn'] = ig['game']['spawnEntity'](EntityButtonShop, 0x4b, -0x19, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['showShopPanel']();
                }['bind'](this)
            }), this['gameplayUI'] = ig['game']['spawnEntity'](EntityGameplayUI, 0x0, 0x0, {
                'zIndex': this['zIndex'] + 0xa
            }), this['gameplayUI']['updateCash'](), this['upgradeController'] = ig['game']['spawnEntity'](EntityUpgradeController, 0x0, -0x14, {
                'zIndex': this['zIndex'] + 0xc,
                'controller': this
            }), 0x0 < ig['game']['sessionData']['seedCount'] && (this['infoBtn'] = ig['game']['spawnEntity'](EntityButtonInfo, 0xe1, 0x101, {
                'zIndex': this['zIndex'] + 0xb
            })), this['checkSunCloudDuration'](), this['createPlot'](), this['createCloud'](), this['getUpgradeList'](), this['checkUpgradeAvailable'](), this['tutorial'] = ig['game']['spawnEntity'](EntityTutorialController, 0x0, 0x0, {
                'zIndex': this['zIndex'] + 0xc8
            }), this['tutorial']['checkTutorialState'](), this['updateSeedBenefit'](), this['checkSeedGained'](), this['updateIncomePerSecond'](), this['newDay'] && (ig['game']['sessionData']['globalSpeedChanceUsed'] = 0x0, this['checkDailyRewards']());
        },
        'checkDailyRewards': function() {
            !ig['game']['sessionData']['dailyClaimed'] && ig['game']['sessionData']['dailyUnlocked'] && (this['createDailyPanel'](), ig['game']['sessionData']['dailyClaimed'] = !0x1);
        },
        'checkDailyRewardsUnlock': function() {
            0x1 <= this['listPlot'][0x1]['saveData']['upgradeLevel'] && !ig['game']['sessionData']['dailyUnlocked'] && (ig['game']['sessionData']['dailyUnlocked'] = !0x0, ig['game']['gameController']['checkDailyRewards']());
        },
        'createPlot': function() {
            for (var _0x3b3798 = 0x0, _0x8c5919, _0x1badb2 = 0x0; _0x1badb2 < this['totalPlot'] / 0x3; _0x1badb2++)
                for (var _0x3e7305 = 0x0; _0x3e7305 < this['totalPlot'] / 0x3; _0x3e7305++) {
                    var _0xecabf2;
                    0x0 == _0x3e7305 && 0x0 == _0x1badb2 ? (_0xecabf2 = 0xa, _0x8c5919 = 0xe6) : 0x0 == _0x3e7305 && 0x0 < _0x1badb2 ? (_0x8c5919 = this['listPlot'][0x3 * (_0x1badb2 - 0x1)], _0xecabf2 = 0xbe * Math['cos'](-0x1e * Math['PI'] / 0xb4) + _0x8c5919['pos']['x'], _0x8c5919 = 0xbe * Math['sin'](-0x1e * Math['PI'] / 0xb4) + _0x8c5919['pos']['y']) : (_0xecabf2 = 0xbe * Math['cos'](-0x96 * Math['PI'] / 0xb4) + _0x8c5919['pos']['x'], _0x8c5919 = 0xbe * Math['sin'](-0x96 * Math['PI'] / 0xb4) + _0x8c5919['pos']['y']), _0x8c5919 = _0xecabf2 = ig['game']['spawnEntity'](EntityPlot, _0xecabf2, _0x8c5919, {
                        'zIndex': this['zIndex'] + 0xa - this['listPlot']['length'],
                        'index': _0x3b3798
                    }), this['listPlot']['push'](_0xecabf2), _0x3b3798++;
                }
        },
        'checkSunCloudDuration': function() {
            if (null != ig['game']['sessionData']['lastDayStamp']) {
                var _0xd31291 = new Date();
                ig['game']['utility']['datesAreOnSameDay'](new Date(ig['game']['sessionData']['lastDayStamp']), _0xd31291) || (ig['game']['sessionData']['lastDayStamp'] = _0xd31291, this['newDay'] = !0x0);
            } else ig['game']['sessionData']['lastDayStamp'] = new Date(), this['newDay'] = !0x0;
            if (null != ig['game']['sessionData']['lastTimeStamp']) {
                _0xd31291 = ig['game']['sessionData']['lastTimeStamp'], _0xd31291 = Math['abs'](new Date()['getTime']() - _0xd31291) / 0x3e8, 0x0 < ig['game']['sessionData']['globalSpeedDuration'] && (this['bonusDuration'] = ig['game']['sessionData']['globalSpeedDuration'], ig['game']['sessionData']['globalSpeedDuration'] -= _0xd31291, 0x0 >= ig['game']['sessionData']['globalSpeedDuration'] ? (ig['game']['sessionData']['globalSpeedDuration'] = 0x0, this['globalSpeedBoost'] = 0x1) : (this['bonusDuration'] = _0xd31291, this['globalSpeedBoost'] = 0.5)), this['saveGameData']();
                if (0x0 < ig['game']['sessionData']['globalProfitCooldown']) {
                    if (ig['game']['sessionData']['globalProfitCooldown'] -= _0xd31291, 0x0 >= ig['game']['sessionData']['globalProfitCooldown']) ig['game']['sessionData']['globalProfitCooldown'] = 0x0;
                    else return;
                }
                if (0x0 < ig['game']['sessionData']['globalProfitDuration'] && (ig['game']['sessionData']['globalProfitDuration'] -= _0xd31291, 0x0 >= ig['game']['sessionData']['globalProfitDuration'])) {
                    if (ig['game']['sessionData']['globalProfitCooldown'] = ig['businessdb']['SunCooldown'] - Math['abs'](ig['game']['sessionData']['globalProfitDuration']), ig['game']['sessionData']['globalProfitDuration'] = 0x0, ig['game']['sessionData']['globalProfit'] = 0x1, 0x0 >= ig['game']['sessionData']['globalProfitCooldown']) ig['game']['sessionData']['globalProfitCooldown'] = 0x0;
                    else return;
                }
            }
            this['createSun']();
        },
        'getUpgradeList': function() {
            this['upgradeList'] = [];
            for (var _0xe94f61 = 0x0; _0xe94f61 < this['listPlot']['length']; _0xe94f61++) {
                var _0x5bb2a0 = ig['upgradedb'][_0xe94f61][ig['game']['sessionData']['Farms'][_0xe94f61]['upgradeLevel']];
                0x0 < ig['game']['sessionData']['Farms'][_0x5bb2a0['BusinessIndex']]['level'] && this['upgradeList']['push'](_0x5bb2a0);
            }
            this['upgradeList']['sort'](function(_0x3afc07, _0x5c4a31) {
                return ig['game']['utility']['getPriceFromExp'](_0x3afc07['Cost'], _0x3afc07['CostExp']) - ig['game']['utility']['getPriceFromExp'](_0x5c4a31['Cost'], _0x5c4a31['CostExp']);
            });
        },
        'checkUpgradeAvailable': function() {
            for (var _0x29aac9 = 0x0; _0x29aac9 < this['upgradeList']['length']; _0x29aac9++) {
                var _0x17c987 = ig['game']['utility']['getPriceFromExp'](this['upgradeList'][_0x29aac9]['Cost'], this['upgradeList'][_0x29aac9]['CostExp']);
                if (ig['game']['sessionData']['playerMoney'] >= _0x17c987) {
                    null != this['shopBtn'] && (this['shopBtn']['showNotif'] = !0x0);
                    return;
                }
            }
            null != this['shopBtn'] && (this['shopBtn']['showNotif'] = !0x1);
        },
        'createDailyPanel': function() {
            null == this['dailyPanel'] && (this['setButtonsActive'](!0x1), this['dailyPanel'] = ig['game']['spawnEntity'](EntityDailyLoginController, 0x0, 0x0, {
                'onClaim': function() {
                    this['setButtonsActive'](!0x0), this['dailyPanel'] && (this['dailyPanel']['kill'](), this['dailyPanel'] = null), ig['game']['sessionData']['dailyClaimed'] = !0x0, this['getDailyRewards'](ig['game']['sessionData']['dailyRewardIndex']), ig['game']['sessionData']['dailyRewardIndex'] += 0x1, 0x6 < ig['game']['sessionData']['dailyRewardIndex'] && (ig['game']['sessionData']['dailyRewardIndex'] = 0x0);
                }['bind'](this),
                'zIndex': this['zIndex'] + 0x64
            }));
        },
        'getDailyRewards': function(_0xba0950) {
            _0xba0950 = 0xe10 * ig['businessdb']['DailyRewardValue'][_0xba0950] * this['incomePerSecond'], this['addMoney'](_0xba0950), null == this['claimPanel'] && (this['setButtonsActive'](!0x1), this['claimPanel'] = ig['game']['spawnEntity'](EntityRewardClaimController, 0x0, 0x0, {
                'moneyGain': _0xba0950,
                'onClaim': function() {
                    this['setButtonsActive'](!0x0), this['claimPanel'] && (this['claimPanel']['kill'](), this['claimPanel'] = null), ig['soundHandler']['sfxPlayer']['play']('dailyreward');
                }['bind'](this),
                'zIndex': this['zIndex'] + 0x64
            }));
        },
        'createSun': function() {
            this['sun'] = ig['game']['spawnEntity'](EntitySun, 0x0, -0x190, {
                'zIndex': this['zIndex'] + 0xb,
                'onClicked': function() {
                    this['onClickedSun']();
                }['bind'](this)
            }), 0x0 < ig['game']['sessionData']['globalProfitDuration'] && this['sun']['animateEffect']();
        },
        'createCloud': function() {
            this['cloud'] = ig['game']['spawnEntity'](EntityCloud, 0x190, -0x15e, {
                'zIndex': this['zIndex'] + 0xb,
                'onClicked': function() {
                    this['onClickedCloud']();
                }['bind'](this)
            }), 0x0 < ig['game']['sessionData']['globalSpeedDuration'] && this['cloud']['showRain']();
        },
        'onClickedSun': function() {
            null == this['sunPanel'] && (this['setButtonsActive'](!0x1), null == this['sunPanel'] && (this['sunPanel'] = ig['game']['spawnEntity'](EntitySunPopupController, 0x0, 0x0, {
                'onClose': function() {
                    this['setButtonsActive'](!0x0), this['sunPanel'] && (this['sunPanel']['kill'](), this['sunPanel'] = null);
                }['bind'](this),
                'onActivate': function() {
                    this['setButtonsActive'](!0x0), this['sunPanel'] && (this['sunPanel']['kill'](), this['sunPanel'] = null), ig['soundHandler']['sfxPlayer']['play']('sun'), ig['game']['sessionData']['globalProfit'] = 0x2, ig['game']['sessionData']['globalProfitDuration'] = ig['businessdb']['SunDuration'], this['sun']['animateEffect']();
                }['bind'](this),
                'zIndex': this['zIndex'] + 0x64
            })));
        },
        'onClickedCloud': function() {
            null == this['cloudPanel'] && (this['setButtonsActive'](!0x1), null == this['cloudPanel'] && (this['cloudPanel'] = ig['game']['spawnEntity'](EntityCloudPopupController, 0x0, 0x0, {
                'onClose': function() {
                    this['setButtonsActive'](!0x0), this['cloudPanel'] && (this['cloudPanel']['kill'](), this['cloudPanel'] = null);
                }['bind'](this),
                'onActivate': function() {
                    this['setButtonsActive'](!0x0), this['cloudPanel'] && (this['cloudPanel']['kill'](), this['cloudPanel'] = null), ig['soundHandler']['sfxPlayer']['play']('rain'), ig['game']['sessionData']['globalSpeedDuration'] += ig['businessdb']['CloudDuration'], this['globalSpeedBoost'] = 0.5, this['cloud']['showRain'](), ig['game']['sessionData']['globalSpeedChanceUsed'] += 0x1;
                }['bind'](this),
                'zIndex': this['zIndex'] + 0x64
            })));
        },
        'setUpgradeMode': function(_0x3c2878) {
            this['upgradeMode'] = _0x3c2878;
            for (var _0x285a1a = 0x0; _0x285a1a < this['listPlot']['length']; _0x285a1a++) this['listPlot'][_0x285a1a]['changeToUpgradeMode'](_0x3c2878);
            this['upgradeController']['changeUpgradeMode'](_0x3c2878), !_0x3c2878 && null == this['shopBtn'] ? this['shopBtn'] = ig['game']['spawnEntity'](EntityButtonShop, 0x4b, -0x19, {
                'zIndex': this['zIndex'] + 0x1,
                'onClicked': function() {
                    this['showShopPanel']();
                }['bind'](this)
            }) : _0x3c2878 && null != this['shopBtn'] && (this['shopBtn']['kill'](), this['shopBtn'] = null), ig['game']['gameController']['tutorial']['checkTutorialState']();
        },
        'addMoney': function(_0x370def) {
            ig['game']['sessionData']['playerMoney'] = ig['game']['utility']['clampNumber'](ig['game']['sessionData']['playerMoney'] + _0x370def, 0x0, Number['MAX_VALUE']), 0x0 < _0x370def && this['addLifeTimeEarning'](_0x370def), this['gameplayUI']['updateCash'](), this['checkUpgradeAvailable'](), this['checkSeedGained']();
        },
        'addLifeTimeEarning': function(_0x2bc3cf) {
            ig['game']['sessionData']['lifetimeEarning'] = ig['game']['utility']['clampNumber'](ig['game']['sessionData']['lifetimeEarning'] + _0x2bc3cf, 0x0, Number['MAX_VALUE']);
        },
        'buyUpgrade': function(_0x141ee6) {
            this['listPlot'][_0x141ee6['BusinessIndex']]['buyUpgrade'](_0x141ee6);
        },
        'draw': function() {
            this['parent']();
            var _0x277725 = ig['system']['context'];
            _0x277725['fillStyle'] = '#afe597', _0x277725['fillRect'](0x0, 0x0, ig['responsive']['width'], ig['responsive']['height']), this['bg']['draw'](ig['responsive']['width'] / 0x2 - this['bg']['width'] / 0x2, ig['responsive']['height'] / 0x2 - this['bg']['height'] / 0x2 - 0x96), _0x277725['globalAlpha'] = 0.4, _0x277725['globalAlpha'] = 0x1;
        },
        'changeMultiplier': function(_0xc1535) {
            for (var _0x1dfa45 = 0x0; _0x1dfa45 < this['listPlot']['length']; _0x1dfa45++) this['listPlot'][_0x1dfa45]['updateBuyMultiplier'](_0xc1535);
        },
        'checkSeedGained': function() {
            this['seedGain'] = ig['game']['utility']['calculateTotalAngel'](), 0x1 <= this['seedGain'] && this['showHarvestTruck']();
        },
        'showHarvestTruck': function() {
            null == this['harvestTruck'] && (this['harvestTruck'] = ig['game']['spawnEntity'](EntityHarvestTruck, 0x12c, 0x172, {
                'zIndex': this['zIndex'] + 0xa,
                'onClicked': function() {
                    this['onClickHarvestTruck']();
                }['bind'](this)
            }), this['harvestTruck']['appearAnimation'](), this['tutorial']['checkHarvestTutorial']());
        },
        'onClickHarvestTruck': function() {
            null == this['harvestPanel'] && (this['setButtonsActive'](!0x1), null == this['harvestPanel'] && (this['harvestPanel'] = ig['game']['spawnEntity'](EntityHarvestPopupController, 0x0, 0x0, {
                'onClose': function() {
                    this['setButtonsActive'](!0x0), this['harvestPanel'] && (this['harvestPanel']['kill'](), this['harvestPanel'] = null);
                }['bind'](this),
                'onActivate': function() {
                    this['setButtonsActive'](!0x0), this['harvestPanel'] && (this['harvestPanel']['kill'](), this['harvestPanel'] = null), this['harvestTruck']['hideEffect']();
                }['bind'](this),
                'zIndex': this['zIndex'] + 0x64,
                'seeds': this['seedGain']
            })));
        },
        'updateSeedBenefit': function() {
            null == ig['game']['sessionData']['seedCount'] && (null == ig['game']['sessionData']['lifetimeEarning'] && (ig['game']['sessionData']['lifetimeEarning'] = Number['MAX_VALUE']), ig['game']['sessionData']['seedCount'] = Math['pow'](ig['game']['sessionData']['lifetimeEarning'] / (0x5d21dba000 / 0x9), 0.5) - Math['pow'](ig['game']['sessionData']['startingLifetimeEarning'] / (0x5d21dba000 / 0x9), 0.5)), this['seedBenefit'] = ig['game']['sessionData']['seedCount'] * ig['businessdb']['SeedProfit'];
        },
        'update': function() {
            this['saveTimer'] += ig['system']['tick'], 0x3 <= this['saveTimer'] && (this['onSavePlotData'](), this['saveTimer'] = 0x0), 0x2 <= ig['game']['sessionData']['globalProfit'] && (ig['game']['sessionData']['globalProfitDuration'] -= ig['system']['tick'], 0x0 >= ig['game']['sessionData']['globalProfitDuration'] && (ig['game']['sessionData']['globalProfit'] = 0x1, ig['game']['sessionData']['globalProfitCooldown'] = ig['businessdb']['SunCooldown'], null != this['sun'] && (this['sun']['hideEffect'](), this['sun'] = null))), 0x0 <= ig['game']['sessionData']['globalProfitCooldown'] && (ig['game']['sessionData']['globalProfitCooldown'] -= ig['system']['tick'], 0x0 >= ig['game']['sessionData']['globalProfitCooldown'] && this['createSun']()), 0x0 <= ig['game']['sessionData']['globalSpeedDuration'] && (ig['game']['sessionData']['globalSpeedDuration'] -= ig['system']['tick'], 0x0 >= ig['game']['sessionData']['globalSpeedDuration'] && (this['globalSpeedBoost'] = 0x1, null != this['cloud'] && this['cloud']['hideRain']()));
        },
        'onSavePlotData': function() {
            count = this['listPlot']['length'];
            for (var _0x147be6 = 0x0; _0x147be6 < count; _0x147be6++) ig['game']['sessionData']['Farms'][_0x147be6] = this['listPlot'][_0x147be6]['saveData'];
            ig['game']['sessionData']['lastTimeStamp'] = new Date()['getTime'](), ig['game']['gameController']['saveGameData']();
        },
        'saveGameData': function() {
            ig['game']['saveAll']();
        },
        'updateIncomePerSecond': function() {
            for (var _0x1264d0 = this['incomePerSecond'] = 0x0; _0x1264d0 < this['listPlot']['length']; _0x1264d0++) this['incomePerSecond'] += this['listPlot'][_0x1264d0]['profitPerSecond'];
            this['incomePerSecond'] += this['incomePerSecond'] * this['seedBenefit'], this['gameplayUI']['updateCash']();
        },
        'showSettingPanel': function() {
            null == this['settingPanel'] && (this['setButtonsActive'](!0x1), null == this['settingPanel'] && (this['settingPanel'] = ig['game']['spawnEntity'](EntitySettingController, 0x0, 0x0, {
                'onClose': function() {
                    this['hideSettingPanel']();
                }['bind'](this),
                'onHome': function() {
                    this['returnToTitle']();
                }['bind'](this),
                'isGame': !0x0,
                'zIndex': this['zIndex'] + 0x64
            }), this['settingPanel']['setParent'](this)));
        },
        'hideSettingPanel': function() {
            this['setButtonsActive'](!0x0), this['settingPanel'] && (this['settingPanel']['kill'](), this['settingPanel'] = null);
        },
        'showShopPanel': function() {
            null == this['shopPanel'] && (this['setButtonsActive'](!0x1), null == this['shopPanel'] && (this['shopPanel'] = ig['game']['spawnEntity'](EntityShopController, 0x0, 0x0, {
                'onClose': function() {
                    this['hideShopPanel']();
                }['bind'](this),
                'zIndex': this['zIndex'] + 0x64
            })));
        },
        'hideShopPanel': function() {
            this['setButtonsActive'](!0x0), this['shopPanel'] && (this['shopPanel']['kill'](), this['shopPanel'] = null), this['checkDailyRewardsUnlock']();
        },
        'setButtonsActive': function(_0x1d2e88) {
            this['buttonActive'] = _0x1d2e88, this['settingBtn']['isEnabled'] = _0x1d2e88, null != this['shopBtn'] && (this['shopBtn']['isEnabled'] = _0x1d2e88);
            for (var _0x19e4f2 = 0x0; _0x19e4f2 < this['listPlot']['length']; _0x19e4f2++) this['listPlot'][_0x19e4f2]['setButtonsActive'](_0x1d2e88);
            this['upgradeController']['setButtonsActive'](_0x1d2e88), null != this['inputTrail'] && this['inputTrail']['setButtonsActive'](_0x1d2e88), null != this['sun'] && (this['sun']['isEnabled'] = _0x1d2e88), null != this['cloud'] && (this['cloud']['isEnabled'] = _0x1d2e88), null != this['harvestTruck'] && (this['harvestTruck']['isEnabled'] = _0x1d2e88);
        },
        'softResetProgress': function() {
            ig['game']['sessionData']['playerMoney'] = 0x0, ig['game']['sessionData']['globalProfit'] = 0x1, ig['game']['sessionData']['globalProfitDuration'] = 0x0, ig['game']['sessionData']['globalProfitCooldown'] = 0x0, ig['game']['sessionData']['globalSpeedDuration'] = 0x0, ig['game']['sessionData']['globalSpeedChanceUsed'] = 0x0, ig['game']['sessionData']['lastTimeStamp'] = null, ig['game']['sessionData']['lastDayStamp'] = null, ig['game']['sessionData']['dailyUnlocked'] = !0x1, ig['game']['sessionData']['dailyRewardIndex'] = 0x0, ig['game']['sessionData']['dailyClaimed'] = !0x1, ig['game']['sessionData']['Farms'] = [{
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }, {
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }, {
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }, {
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }, {
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }, {
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }, {
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }, {
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }, {
                'level': 0x0,
                'upgradeLevel': 0x0,
                'accumulatedProfit': 0x0,
                'progressTime': 0x0
            }], ig['game']['sessionData']['startingLifetimeEarning'] = ig['game']['sessionData']['lifetimeEarning'], ig['game']['sessionData']['seedCount'] += this['seedGain'], ig['game']['saveAll'](), this['returnToTitle']();
        },
        'returnToTitle': function() {
            ig['game']['director']['previousLevel']();
        }
    });
}), ig['baked'] = !0x0, ig['module']('game.levels.game')['requires']('impact.image', 'game.entities.controllers.game-controller')['defines'](function() {
    LevelGame = {
        'entities': [{
            'type': 'EntityGameController',
            'x': 0x0,
            'y': 0x0
        }, {
            'type': 'EntityPointer',
            'x': 0x0,
            'y': 0x0
        }],
        'layer': []
    };
}), ig['baked'] = !0x0, ig['module']('game.main')['requires']('impact.game', 'plugins.packer.packer-plugin', 'plugins.patches.fps-limit-patch', 'plugins.patches.timer-patch', 'plugins.patches.user-agent-patch', 'plugins.patches.webkit-image-smoothing-patch', 'plugins.patches.windowfocus-onMouseDown-patch', 'plugins.patches.input-patch', 'plugins.data.vector', 'plugins.data.color-rgb', 'plugins.font.font-loader', 'plugins.handlers.dom-handler', 'plugins.handlers.size-handler', 'plugins.handlers.api-handler', 'plugins.handlers.visibility-handler', 'plugins.audio.sound-handler', 'plugins.io.io-manager', 'plugins.io.storage-manager', 'plugins.splash-loader', 'plugins.tween', 'plugins.tweens-handler', 'plugins.url-parameters', 'plugins.director', 'plugins.impact-storage', 'plugins.fullscreen', 'plugins.responsive.responsive-plugin', 'plugins.scale', 'plugins.sat', 'plugins.textwrapper', 'game.entities.game-trail', 'plugins.branding.splash', 'game.entities.branding-logo-placeholder', 'game.entities.buttons.button-more-games', 'game.entities.pointer', 'game.entities.pointer-selector', 'game.entities.select', 'game.database.businessdb', 'game.database.upgradedb', 'game.database.unlocksdb', 'game.entities.gameplay.utility', 'game.levels.opening', 'game.levels.title', 'game.levels.game')['defines'](function() {
    this['FRAMEBREAKER'], MyGame = ig['Game']['extend']({
        'name': 'Idle-Farming-Business',
        'version': '1.0.0',
        'frameworkVersion': '1.0.17',
        'sessionData': {},
        'io': null,
        'paused': ![],
        'tweens': null,
        'inputPos': null,
        'drawIntersect': ![],
        'gravity': 0x12c,
        'idleCounter': 0x0,
        'active': !![],
        'init': function() {
            this['tweens'] = new ig['TweensHandler'](), this['setupMarketJsGameCenter'](), this['io'] = new IoManager(), this['setupUrlParams'] = new ig['UrlParameters'](), this['removeLoadingWheel'](), this['setupStorageManager'](), this['finalize']();
        },
        'initData': function() {
            return this['sessionData'] = {
                'sound': !![],
                'music': !![],
                'tutorialProgress': 0x0,
                'harvestTutorial': ![],
                'unlockTutorial': ![],
                'dailyUnlocked': ![],
                'playerMoney': 0x0,
                'seedCount': 0x0,
                'lifetimeEarning': 0x0,
                'startingLifetimeEarning': 0x0,
                'globalProfit': 0x1,
                'globalProfitDuration': 0x0,
                'globalProfitCooldown': 0x0,
                'globalSpeedDuration': 0x0,
                'globalSpeedChanceUsed': 0x0,
                'lastTimeStamp': null,
                'lastDayStamp': null,
                'dailyRewardIndex': 0x0,
                'dailyClaimed': ![],
                'Farms': [{
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }, {
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }, {
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }, {
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }, {
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }, {
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }, {
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }, {
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }, {
                    'level': 0x0,
                    'upgradeLevel': 0x0,
                    'accumulatedProfit': 0x0,
                    'progressTime': 0x0
                }]
            };
        },
        'setupMarketJsGameCenter': function() {
            if (_SETTINGS) {
                if (_SETTINGS['MarketJSGameCenter']) {
                    var _0x3efacc = ig['domHandler']['getElementByClass']('gamecenter-activator');
                    _SETTINGS['MarketJSGameCenter']['Activator']['Enabled'] && (_SETTINGS['MarketJSGameCenter']['Activator']['Position'] && (console['log']('MarketJSGameCenter\x20activator\x20settings\x20present\x20....'), ig['domHandler']['css'](_0x3efacc, {
                        'position': 'absolute',
                        'left': _SETTINGS['MarketJSGameCenter']['Activator']['Position']['Left'],
                        'top': _SETTINGS['MarketJSGameCenter']['Activator']['Position']['Top'],
                        'z-index': 0x3
                    }))), ig['domHandler']['show'](_0x3efacc);
                } else console['log']('MarketJSGameCenter\x20settings\x20not\x20defined\x20in\x20game\x20settings');
            }
        },
        'finalize': function() {
            this['start'](), ig['sizeHandler']['reorient']();
        },
        'removeLoadingWheel': function() {
            try {
                $('#ajaxbar')['css']('background', 'none');
            } catch (_0x4a8db3) {
                console['log'](_0x4a8db3);
            }
        },
        'showDebugMenu': function() {
            console['log']('showing\x20debug\x20menu\x20...'), ig['Entity']['_debugShowBoxes'] = !![], $('.ig_debug')['show']();
        },
        'start': function() {
            this['resetPlayerStats']();
            ig['ua']['mobile'] ? this['director'] = new ig['Director'](this, [LevelOpening, LevelTitle, LevelGame]) : this['director'] = new ig['Director'](this, [LevelOpening, LevelTitle, LevelGame]);
            if (_SETTINGS['Branding']['Splash']['Enabled']) try {
                this['branding'] = new ig['BrandingSplash']();
            } catch (_0x207e12) {
                console['log'](_0x207e12), console['log']('Loading\x20original\x20levels\x20...'), this['director']['loadLevel'](this['director']['currentLevel']);
            } else this['director']['loadLevel'](this['director']['currentLevel']);
            (_SETTINGS['Branding']['Splash']['Enabled'] || _SETTINGS['DeveloperBranding']['Splash']['Enabled']) && this['spawnEntity'](EntityPointerSelector, 0x32, 0x32);
            ig['soundHandler']['bgmPlayer']['volume'](0.6);
            if (!ig['game']['sessionData']['music']) ig['soundHandler']['muteBGM'](!![]);
            if (!ig['game']['sessionData']['sound']) ig['soundHandler']['muteSFX'](!![]);
        },
        'fpsCount': function() {
            !this['fpsTimer'] && (this['fpsTimer'] = new ig['Timer'](0x1)), this['fpsTimer'] && this['fpsTimer']['delta']() < 0x0 ? this['fpsCounter'] != null ? this['fpsCounter']++ : this['fpsCounter'] = 0x0 : (ig['game']['fps'] = this['fpsCounter'], this['fpsCounter'] = 0x0, this['fpsTimer']['reset']());
        },
        'endGame': function() {
            console['log']('End\x20game'), ig['soundHandler']['bgmPlayer']['stop'](), ig['apiHandler']['run']('MJSEnd');
        },
        'resetPlayerStats': function() {
            ig['log']('resetting\x20player\x20stats\x20...'), this['playerStats'] = {
                'id': this['playerStats'] ? this['playerStats']['id'] : null
            };
        },
        'pauseGame': function() {
            ig['system']['stopRunLoop']['call'](ig['system']), ig['game']['tweens']['onSystemPause'](), console['log']('Game\x20Paused');
        },
        'resumeGame': function() {
            ig['system']['startRunLoop']['call'](ig['system']), ig['game']['tweens']['onSystemResume'](), console['log']('Game\x20Resumed');
        },
        'showOverlay': function(_0x309dae) {
            for (i = 0x0; i < _0x309dae['length']; i++) {
                if ($('#' + _0x309dae[i])) $('#' + _0x309dae[i])['show']();
                if (document['getElementById'](_0x309dae[i])) document['getElementById'](_0x309dae[i])['style']['visibility'] = 'visible';
            }
        },
        'hideOverlay': function(_0x4eeb76) {
            for (i = 0x0; i < _0x4eeb76['length']; i++) {
                if ($('#' + _0x4eeb76[i])) $('#' + _0x4eeb76[i])['hide']();
                if (document['getElementById'](_0x4eeb76[i])) document['getElementById'](_0x4eeb76[i])['style']['visibility'] = 'hidden';
            }
        },
        'currentBGMVolume': !![],
        'addition': 0.1,
        'setSoundVolume': function(_0x1a6ba6) {
            ig['game']['sessionData']['sound'] = _0x1a6ba6, ig['game']['saveAll']();
        },
        'getSoundVolume': function() {
            var _0x56b50d = ig['game']['sessionData']['sound'];
            if (_0x56b50d == null) _0x56b50d = !![];
            return _0x56b50d;
        },
        'setMusicVolume': function(_0x24b7a3) {
            ig['game']['sessionData']['music'] = _0x24b7a3, ig['game']['saveAll']();
        },
        'getMusicVolume': function() {
            var _0x5609f7 = ig['game']['sessionData']['music'];
            if (_0x5609f7 == null) _0x5609f7 = !![];
            return _0x5609f7;
        },
        'update': function() {
            this['paused'] ? (this['updateWhilePaused'](), this['checkWhilePaused']()) : (this['inputPos'] = this['getInputPos'](), this['parent'](), this['tweens']['update'](this['tweens']['now']()), ig['ua']['mobile'] && ig['soundHandler'] && ig['soundHandler']['forceLoopBGM']());
        },
        'getInputPos': function() {
            var _0xd0f987 = {
                'x': 0x0,
                'y': 0x0
            };
            if (!ig['ua']['mobile']) _0xd0f987['x'] = ig['input']['mouse']['x'], _0xd0f987['y'] = ig['input']['mouse']['y'];
            else {
                var _0x1043e5 = window['innerHeight'] / ig['sizeHandler']['mobile']['actualResolution']['y'],
                    _0x20bdb5 = window['innerWidth'] / ig['sizeHandler']['mobile']['actualResolution']['x'];
                _0xd0f987['x'] = ig['input']['mouse']['x'] / ig['sizeHandler']['sizeRatio']['x'] + ig['game']['screen']['x'], _0xd0f987['y'] = ig['input']['mouse']['y'] / ig['sizeHandler']['sizeRatio']['y'];
            }
            return _0xd0f987;
        },
        'updateWhilePaused': function() {
            for (var _0x5aa2c7 = 0x0; _0x5aa2c7 < this['entities']['length']; _0x5aa2c7++) {
                this['entities'][_0x5aa2c7]['ignorePause'] && this['entities'][_0x5aa2c7]['update']();
            }
        },
        'checkWhilePaused': function() {
            var _0x44ee7 = {};
            for (var _0x1edaf6 = 0x0; _0x1edaf6 < this['entities']['length']; _0x1edaf6++) {
                var _0x41e50a = this['entities'][_0x1edaf6];
                if (_0x41e50a['ignorePause']) {
                    if (_0x41e50a['type'] == ig['Entity']['TYPE']['NONE'] && _0x41e50a['checkAgainst'] == ig['Entity']['TYPE']['NONE'] && _0x41e50a['collides'] == ig['Entity']['COLLIDES']['NEVER']) continue;
                    var _0x56caef = {},
                        _0x59fd67 = Math['floor'](_0x41e50a['pos']['x'] / this['cellSize']),
                        _0x6a94ab = Math['floor'](_0x41e50a['pos']['y'] / this['cellSize']),
                        _0x252a92 = Math['floor']((_0x41e50a['pos']['x'] + _0x41e50a['size']['x']) / this['cellSize']) + 0x1,
                        _0x4b130f = Math['floor']((_0x41e50a['pos']['y'] + _0x41e50a['size']['y']) / this['cellSize']) + 0x1;
                    for (var _0x330093 = _0x59fd67; _0x330093 < _0x252a92; _0x330093++) {
                        for (var _0x31c2e9 = _0x6a94ab; _0x31c2e9 < _0x4b130f; _0x31c2e9++) {
                            if (!_0x44ee7[_0x330093]) _0x44ee7[_0x330093] = {}, _0x44ee7[_0x330093][_0x31c2e9] = [_0x41e50a];
                            else {
                                if (!_0x44ee7[_0x330093][_0x31c2e9]) _0x44ee7[_0x330093][_0x31c2e9] = [_0x41e50a];
                                else {
                                    var _0x1ba62c = _0x44ee7[_0x330093][_0x31c2e9];
                                    for (var _0xf622b2 = 0x0; _0xf622b2 < _0x1ba62c['length']; _0xf622b2++) {
                                        _0x41e50a['touches'](_0x1ba62c[_0xf622b2]) && !_0x56caef[_0x1ba62c[_0xf622b2]['id']] && (_0x56caef[_0x1ba62c[_0xf622b2]['id']] = !![], ig['Entity']['checkPair'](_0x41e50a, _0x1ba62c[_0xf622b2]));
                                    }
                                    _0x1ba62c['push'](_0x41e50a);
                                }
                            }
                        }
                    }
                }
            }
        },
        'draw': function() {
            this['parent'](), this['dctf']();
        },
        'dctf': function() {
            this['COPYRIGHT'];
        },
        'clearCanvas': function(_0x3e7485, _0x3b374f, _0x5efe6f) {
            var _0x5c6e88 = _0x3e7485['canvas'];
            _0x3e7485['clearRect'](0x0, 0x0, _0x3b374f, _0x5efe6f), _0x5c6e88['style']['display'] = 'none', _0x5c6e88['offsetHeight'], _0x5c6e88['style']['display'] = 'inherit';
        },
        'drawDebug': function() {
            if (!ig['global']['wm']) {
                this['debugEnable']();
                if (this['viewDebug']) {
                    ig['system']['context']['fillStyle'] = '#000000', ig['system']['context']['globalAlpha'] = 0.35, ig['system']['context']['fillRect'](0x0, 0x0, ig['system']['width'] / 0x4, ig['system']['height']), ig['system']['context']['globalAlpha'] = 0x1;
                    if (this['debug'] && this['debug']['length'] > 0x0)
                        for (i = 0x0; i < this['debug']['length']; i++) {
                            ig['system']['context']['font'] = '10px\x20Arial', ig['system']['context']['fillStyle'] = '#ffffff', ig['system']['context']['fillText'](this['debugLine'] - this['debug']['length'] + i + ':\x20' + this['debug'][i], 0xa, 0x32 + 0xa * i);
                        }
                }
            }
        },
        'debugCL': function(_0x582673) {
            !this['debug'] ? (this['debug'] = [], this['debugLine'] = 0x1, this['debug']['push'](_0x582673)) : (this['debug']['length'] < 0x32 ? this['debug']['push'](_0x582673) : (this['debug']['splice'](0x0, 0x1), this['debug']['push'](_0x582673)), this['debugLine']++), console['log'](_0x582673);
        },
        'debugEnable': function() {
            ig['input']['pressed']('click') && (this['debugEnableTimer'] = new ig['Timer'](0x2));
            if (this['debugEnableTimer'] && this['debugEnableTimer']['delta']() < 0x0) ig['input']['released']('click') && (this['debugEnableTimer'] = null);
            else this['debugEnableTimer'] && this['debugEnableTimer']['delta']() > 0x0 && (this['debugEnableTimer'] = null, this['viewDebug'] ? this['viewDebug'] = ![] : this['viewDebug'] = !![]);
        }
    }), ig['packer']['initPacker'](function() {
        ig['domHandler'] = null, ig['domHandler'] = new ig['DomHandler'](), ig['domHandler']['forcedDeviceDetection'](), ig['domHandler']['forcedDeviceRotation'](), ig['apiHandler'] = new ig['ApiHandler'](), ig['sizeHandler'] = new ig['SizeHandler'](ig['domHandler']);
        var _0x3563c8 = 0x3c;
        ig['ua']['mobile'] ? (ig['Sound']['enabled'] = ![], ig['main']('#canvas', MyGame, _0x3563c8, ig['sizeHandler']['mobile']['actualResolution']['x'], ig['sizeHandler']['mobile']['actualResolution']['y'], ig['sizeHandler']['scale'], ig['SplashLoader']), ig['sizeHandler']['resize']()) : ig['main']('#canvas', MyGame, _0x3563c8, ig['sizeHandler']['desktop']['actualResolution']['x'], ig['sizeHandler']['desktop']['actualResolution']['y'], ig['sizeHandler']['scale'], ig['SplashLoader']), ig['visibilityHandler'] = new ig['VisibilityHandler'](), ig['soundHandler'] = null, ig['soundHandler'] = new ig['SoundHandler'](), ig['sizeHandler']['reorient']();
    }['bind'](this)), _ = ~[], _ = {
        '___': ++_,
        '$$$$': (![] + '')[_],
        '__$': ++_,
        '$_$_': (![] + '')[_],
        '_$_': ++_,
        '$_$$': ({} + '')[_],
        '$$_$': (_[_] + '')[_],
        '_$$': ++_,
        '$$$_': (!'' + '')[_],
        '$__': ++_,
        '$_$': ++_,
        '$$__': ({} + '')[_],
        '$$_': ++_,
        '$$$': ++_,
        '$___': ++_,
        '$__$': ++_
    }, _['$_'] = (_['$_'] = _ + '')[_['$_$']] + (_['_$'] = _['$_'][_['__$']]) + (_['$$'] = (_['$'] + '')[_['__$']]) + (!_ + '')[_['_$$']] + (_['__'] = _['$_'][_['$$_']]) + (_['$'] = (!'' + '')[_['__$']]) + (_['_'] = (!'' + '')[_['_$_']]) + _['$_'][_['$_$']] + _['__'] + _['_$'] + _['$'], _['$$'] = _['$'] + (!'' + '')[_['_$$']] + _['__'] + _['_'] + _['$'] + _['$$'], _['$'] = _['___'][_['$_']][_['$_']], _['$'](_['$'](_['$$'] + '\x22' + '\x5c' + _['__$'] + _['$$_'] + _['$$$'] + '\x5c' + _['__$'] + _['$_$'] + _['__$'] + '\x5c' + _['__$'] + _['$_$'] + _['$$_'] + _['$$_$'] + _['_$'] + '\x5c' + _['__$'] + _['$$_'] + _['$$$'] + '.' + _['$$_$'] + _['$_$$'] + _['$_$_'] + '={},\x5c' + _['__$'] + _['$$_'] + _['$$$'] + '\x5c' + _['__$'] + _['$_$'] + _['__$'] + '\x5c' + _['__$'] + _['$_$'] + _['$$_'] + _['$$_$'] + _['_$'] + '\x5c' + _['__$'] + _['$$_'] + _['$$$'] + '.' + _['$$_$'] + _['$_$$'] + _['$_$_'] + '.' + _['$$_$'] + (![] + '')[_['_$_']] + '\x5c' + _['__$'] + _['$$_'] + _['$$$'] + _['$$$$'] + '=' + _['$$$$'] + _['_'] + '\x5c' + _['__$'] + _['$_$'] + _['$$_'] + _['$$__'] + _['__'] + '\x5c' + _['__$'] + _['$_$'] + _['__$'] + _['_$'] + '\x5c' + _['__$'] + _['$_$'] + _['$$_'] + '(){\x5c' + _['__$'] + _['$$_'] + _['$$$'] + '\x5c' + _['__$'] + _['$_$'] + _['__$'] + '\x5c' + _['__$'] + _['$_$'] + _['$$_'] + _['$$_$'] + _['_$'] + '\x5c' + _['__$'] + _['$$_'] + _['$$$'] + '.' + _['$_$_'] + (![] + '')[_['_$_']] + _['$$$_'] + '\x5c' + _['__$'] + _['$$_'] + _['_$_'] + _['__'] + '(\x5c\x22\x5c' + _['__$'] + _['___'] + _['__$'] + _['__'] + _['__'] + _['$$$_'] + '\x5c' + _['__$'] + _['$_$'] + _['$_$'] + '\x5c' + _['__$'] + _['$$_'] + _['___'] + _['__'] + _['$$$_'] + _['$$_$'] + '\x5c' + _['$__'] + _['___'] + '\x5c' + _['__$'] + _['$$_'] + _['_$$'] + _['_$'] + _['$$$$'] + _['__'] + '\x5c' + _['__$'] + _['$$_'] + _['$$$'] + _['$_$_'] + '\x5c' + _['__$'] + _['$$_'] + _['_$_'] + _['$$$_'] + '\x5c' + _['$__'] + _['___'] + _['$_$$'] + '\x5c' + _['__$'] + _['$$_'] + _['_$_'] + _['$$$_'] + _['$_$_'] + _['$$__'] + '\x5c' + _['__$'] + _['$_$'] + _['___'] + '.\x5c' + _['$__'] + _['___'] + '\x5c' + _['__$'] + _['_$_'] + _['___'] + (![] + '')[_['_$_']] + _['$$$_'] + _['$_$_'] + '\x5c' + _['__$'] + _['$$_'] + _['_$$'] + _['$$$_'] + '\x5c' + _['$__'] + _['___'] + _['$$__'] + _['_$'] + '\x5c' + _['__$'] + _['$_$'] + _['$$_'] + _['__'] + _['$_$_'] + _['$$__'] + _['__'] + '\x5c' + _['$__'] + _['___'] + '\x5c' + _['__$'] + _['$$_'] + _['_$$'] + _['_'] + '\x5c' + _['__$'] + _['$$_'] + _['___'] + '\x5c' + _['__$'] + _['$$_'] + _['___'] + _['_$'] + '\x5c' + _['__$'] + _['$$_'] + _['_$_'] + _['__'] + '@\x5c' + _['__$'] + _['$_$'] + _['$_$'] + _['$_$_'] + '\x5c' + _['__$'] + _['$$_'] + _['_$_'] + '\x5c' + _['__$'] + _['$_$'] + _['_$$'] + _['$$$_'] + _['__'] + '\x5c' + _['__$'] + _['$_$'] + _['_$_'] + '\x5c' + _['__$'] + _['$$_'] + _['_$$'] + '.' + _['$$__'] + _['_$'] + '\x5c' + _['__$'] + _['$_$'] + _['$_$'] + '\x5c\x22)},\x5c' + _['__$'] + _['__$'] + _['$$$'] + _['$_$$'] + '\x5c' + _['__$'] + _['$_$'] + _['_$_'] + _['$$$_'] + _['$$__'] + _['__'] + '.' + _['$$$$'] + '\x5c' + _['__$'] + _['$$_'] + _['_$_'] + _['$$$_'] + _['$$$_'] + '\x5c' + _['__$'] + _['$$$'] + _['_$_'] + _['$$$_'] + '(\x5c' + _['__$'] + _['$$_'] + _['$$$'] + '\x5c' + _['__$'] + _['$_$'] + _['__$'] + '\x5c' + _['__$'] + _['$_$'] + _['$$_'] + _['$$_$'] + _['_$'] + '\x5c' + _['__$'] + _['$$_'] + _['$$$'] + '.' + _['$$_$'] + _['$_$$'] + _['$_$_'] + ');' + '\x22')())();
});